import os
import logging
from logging.handlers import RotatingFileHandler

BASE_DIR = os.path.expanduser("~/.devops-bot")
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

LOG_FILE_PATH = os.path.join(LOG_DIR, "devops_bot.log")

# ✅ Custom handler that flushes after every log
class FlushRotatingFileHandler(RotatingFileHandler):
    def emit(self, record):
        super().emit(record)
        self.flush()

log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
log_handler = FlushRotatingFileHandler(LOG_FILE_PATH, maxBytes=5 * 1024 * 1024, backupCount=5)
log_handler.setFormatter(log_formatter)

logger = logging.getLogger("DevOpsBot")
logger.setLevel(logging.INFO)

# Avoid double handlers and duplicate logs
if not logger.hasHandlers():
    logger.addHandler(log_handler)

logger.propagate = False

