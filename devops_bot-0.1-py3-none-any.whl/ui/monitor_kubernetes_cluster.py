import smtplib
import click
import json
import subprocess
import paramiko
import os
import time
import yaml
import hashlib
import zipfile
from datetime import datetime
import copy
import logging
from deepdiff import DeepDiff
from flask_socketio import SocketIO, emit
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, stream_with_context, jsonify, g
import socket
from collections import defaultdict
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from datetime import datetime, timedelta, timezone


app = Flask(__name__, static_folder='static')
socketio = SocketIO(app)
BASE_DIR = os.path.expanduser("~/.devops-bot")
CONFIGS_DIR = os.path.join(BASE_DIR, "configs")
CREDENTIALS_DIR = os.path.join(BASE_DIR, "credentials")
CONFIGS_FILE = os.path.join(BASE_DIR, "pigeon.dob")
DEPLOYMENT_SNAPSHOT_DIR =  os.path.join(CONFIGS_DIR, "dks_deployment")
CLONE_DIR = "/tmp/k8s_monitoring_repo"
MAX_NORMAL_DRIFTS = 5
MAX_CRITICAL_DRIFTS = 10
DRIFT_ARCHIVE_DIR = os.path.expanduser("~/.devops-bot/drift-archive")
os.makedirs(DRIFT_ARCHIVE_DIR, exist_ok=True)
DRIFT_REPORT_DIR = os.path.join(CONFIGS_DIR, "drift-reports")
CHECK_INTERVAL = 15  # seconds
DKS_HOSTS_FILE =  os.path.join(CONFIGS_DIR, "dks_hosts")
# Ensure the drift reports directory exists
os.makedirs(DRIFT_REPORT_DIR, exist_ok=True)



def hash_drift(diff_string):
    """Create a short hash of a drift report to detect duplicates."""
    return hashlib.md5(diff_string.encode()).hexdigest()

def is_critical_drift(diff_text):
    """
    Determine if a drift is critical by checking for specific keywords.
    """
    critical_keywords = ["image", "replicas", "strategy"]
    for line in diff_text.lower().splitlines():
        if any(keyword in line for keyword in critical_keywords):
            return True
    return False
def email_weekly_drift_summary():
    """
    Sends a summary email of drift reports modified in the last 7 days.
    Only runs on Sundays, and uses notification settings from pigeon.dob.
    """
    if datetime.now().weekday() != 6:  # Sunday only
        return

    from datetime import datetime, timedelta
    cutoff = datetime.now() - timedelta(days=7)
    summary = []

    for file in os.listdir(DRIFT_REPORT_DIR):
        path = os.path.join(DRIFT_REPORT_DIR, file)
        if os.path.isfile(path):
            mtime = datetime.fromtimestamp(os.path.getmtime(path))
            if mtime >= cutoff:
                summary.append(f"- {file} (Modified: {mtime.strftime('%Y-%m-%d %H:%M:%S')})")

    if summary:
        body = "📦 *Weekly Drift Report Summary*\n\n" + "\n".join(summary)

        config = load_notification_config()
        if config:
            # Reuse global notification settings
            recipients = {
                "notification_recipients": config.get("notification_recipients", {}),
                "notification_channels": config.get("notification_channels", ["email"])
            }
            send_notification("Weekly Drift Summary", body, recipients)
        else:
            print("⚠️ No valid notification config found. Weekly summary not sent.")
    else:
        print("📭 No new drift reports to summarize this week.")


def monitor_kubernetes_cluster():
    print("🔵 Robust Kubernetes config monitor started!", flush=True)

    while True:
        try:
            master_ip = get_dks_master_ip()
            if not master_ip:
                print("❌ No Kubernetes master IP found. Skipping check...", flush=True)
                time.sleep(CHECK_INTERVAL)
                continue

            print("🔍 Scanning deployments...", flush=True)
            deployments = get_all_k8s_deployments(master_ip)

            if not deployments:
                print("⚠️ No deployments found in cluster.", flush=True)
                time.sleep(CHECK_INTERVAL)
                continue

            for deployment_name in deployments:
                print(f"📂 Checking deployment: {deployment_name}", flush=True)

                live_config = get_live_k8s_config(master_ip, deployment_name)
                if not live_config:
                    print(f"❌ Failed to fetch live config for {deployment_name}", flush=True)
                    continue

                snapshot = load_deployment_snapshot_by_name(deployment_name)
                if not snapshot:
                    print(f"⚠️ No snapshot found for {deployment_name}", flush=True)
                    continue

                repo_url = snapshot["repo_url"]
                branch = snapshot.get("branch", "main")
                notification = snapshot.get("send_notification", {})

                repo_path = clone_or_update_repo(repo_url, branch=branch)
                expected_config = get_k8s_manifest_from_repo(repo_path, deployment_name)

                if not expected_config:
                    print(f"❌ Manifest for {deployment_name} not found in repo.", flush=True)
                    continue

                drift = detect_config_drift(expected_config, live_config, deployment_name)

                if drift:
                    if drift == "SKIP_NOTIFICATION":
                        print(f"⚠️ Duplicate drift for {deployment_name}. Skipping sync and notification.", flush=True)
                        continue  # Skip to next deployment

                    print(f"🚨 Drift detected in {deployment_name}:\n{drift}", flush=True)

                    print("🔁 Re-syncing deployment from Git...", flush=True)
                    success = deploy_application_on_master(master_ip, deployment_name, repo_url, branch=branch)

                    if success:
                        print(f"✅ Deployment {deployment_name} successfully re-synced!", flush=True)
                        # ⛔ DO NOT send any notification if sync succeeds
                    else:
                        print(f"❌ Deployment sync failed for {deployment_name}", flush=True)
                        if snapshot.get("DEPLOYMENT_FAILURE") and notification.get("enabled"):
                            report_path = get_drift_report_path(deployment_name)
                            send_notification(
                                "Deployment Failed After Drift",
                                f"Drift found in `{deployment_name}` and sync failed.\n\nReport:\n{report_path}",
                                notification
                            )
                else:
                    print(f"✅ {deployment_name} is fully in sync.", flush=True)

                # ✅ POD HEALTH CHECK
                if snapshot.get("POD_HEALTH") and notification.get("enabled"):
                    pod_json = get_k8s_pod_json(master_ip)
                    issues = check_pod_health_issues(pod_json)
                    if issues:
                        issue_text = "\n".join([f"[{i['namespace']}] {i['pod']} - {i['issue']}" for i in issues])
                        print(f"🚨 Pod issues found in {deployment_name}", flush=True)
                        send_notification("Pod Health Alert", issue_text, notification)
                    else:
                        print("✅ All pods are healthy.", flush=True)

            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            print(f"❌ CRITICAL ERROR in monitor_kubernetes_cluster: {e}", flush=True)


def detect_config_drift(expected_config, live_config, deployment_name=None):
    def strip_auto_fields(config):
        config = copy.deepcopy(config)
        for field in ["status"]:
            config.pop(field, None)
        if "metadata" in config:
            for meta_field in [
                "creationTimestamp", "resourceVersion", "selfLink",
                "uid", "annotations", "managedFields", "generation"
            ]:
                config["metadata"].pop(meta_field, None)
        return config

    def hash_drift(diff_string):
        return hashlib.md5(diff_string.encode()).hexdigest()

    def is_critical_drift(diff_text):
        critical_keywords = ["image", "replicas", "strategy"]
        for line in diff_text.lower().splitlines():
            if any(keyword in line for keyword in critical_keywords):
                return True
        return False

    expected = strip_auto_fields(expected_config)
    live = strip_auto_fields(live_config)

    diff = DeepDiff(expected, live, ignore_order=True)
    if not diff:
        return None

    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    markdown_lines = [
        f"# 📦 Drift Report for `{deployment_name}`",
        f"**Timestamp**: `{timestamp}`",
        "",
        "```diff"
    ]
    for line in diff.pretty().splitlines():
        prefix = "-"
        if "dictionary_item_added" in line:
            prefix = "+"
        elif "dictionary_item_removed" in line:
            prefix = "-"
        markdown_lines.append(f"{prefix} {line}")
    markdown_lines.append("```")

    report_md = "\n".join(markdown_lines)

    # Deduplication
    is_critical = is_critical_drift(report_md)
    safe_name = deployment_name.replace('/', '_')
    drift_hash = hash_drift(report_md)
    hash_file = os.path.join(DRIFT_REPORT_DIR, f"{safe_name}.last.hash")

    if os.path.exists(hash_file):
        with open(hash_file, "r") as f:
            last_hash = f.read().strip()
        if last_hash == drift_hash:
            print("⚠️ Drift is same as last. Skipping report and notification.", flush=True)
            return "SKIP_NOTIFICATION"

    with open(hash_file, "w") as f:
        f.write(drift_hash)

    # Save Markdown Report
    filename = f"{safe_name}_{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
    report_path = os.path.join(DRIFT_REPORT_DIR, filename)
    with open(report_path, "w") as f:
        f.write(report_md)
    print(f"📁 Drift report saved: {report_path}", flush=True)

    # Archive old reports
    all_reports = sorted([
        f for f in os.listdir(DRIFT_REPORT_DIR)
        if f.startswith(safe_name) and f.endswith(".md")
    ], reverse=True)

    retention_limit = MAX_CRITICAL_DRIFTS if is_critical else MAX_NORMAL_DRIFTS
    if len(all_reports) > retention_limit:
        old_reports = all_reports[retention_limit:]
        for old_file in old_reports:
            try:
                base_name = old_file.replace(".md", "")
                zip_path = os.path.join(DRIFT_ARCHIVE_DIR, f"{base_name}.zip")
                report_full_path = os.path.join(DRIFT_REPORT_DIR, old_file)
                with zipfile.ZipFile(zip_path, 'w') as zipf:
                    zipf.write(report_full_path, arcname=old_file)
                os.remove(report_full_path)
                print(f"🗃️ Archived and deleted old drift report: {old_file}", flush=True)
            except Exception as e:
                print(f"⚠️ Failed to archive/delete report {old_file}: {e}", flush=True)

    return report_md


def get_drift_report_path(deployment_name):
    for file in sorted(os.listdir(DRIFT_REPORT_DIR), reverse=True):
        if file.startswith(deployment_name.replace('/', '_')):
            return os.path.join(DRIFT_REPORT_DIR, file)
    return "Report not found"


def load_deployment_snapshot(snapshot_path):
    """
    Load an existing deployment snapshot.
    """
    try:
        with open(snapshot_path, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.error(f"Snapshot file {snapshot_path} not found!")
        return None
    except json.JSONDecodeError:
        logging.error(f"Error reading snapshot file {snapshot_path}. Invalid JSON.")
        return None

def save_deployment_snapshot(deployment_id, deployment_name, repo_url, latest_commit, timestamp, branch, notification_config, flags):
    """
    Save or update the deployment snapshot JSON file including notification flags.
    """
    os.makedirs(DEPLOYMENT_SNAPSHOT_DIR, exist_ok=True)
    snapshot_path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, f"{deployment_id}.json")

    snapshot_data = {
        "deployment_id": deployment_id,
        "deployment_name": deployment_name,
        "repo_url": repo_url,
        "branch": branch,
        "latest_commit": latest_commit,
        "timestamp": timestamp,
        "DEPLOYMENT_SUCCESS": flags.get("DEPLOYMENT_SUCCESS", True),
        "DEPLOYMENT_FAILURE": flags.get("DEPLOYMENT_FAILURE", True),
        "CONFIG_DRIFT": flags.get("CONFIG_DRIFT", True),
        "AUTO_SYNC": flags.get("AUTO_SYNC", True),
        "POD_HEALTH": flags.get("POD_HEALTH", True),
        "send_notification": notification_config,
        "snapshot": {
            "enabled": True,
            "repo_url": repo_url,
            "deployment_name": deployment_name,
            "branch": branch
        }
    }

    try:
        with open(snapshot_path, "w") as f:
            json.dump(snapshot_data, f, indent=4)
        print(f"📁 Snapshot saved: {snapshot_path}")
    except Exception as e:
        print(f"❌ ERROR saving snapshot: {e}")


def deploy_application_on_master(master_ip, deployment_name, repo_url, branch):
    """
    Deploy the latest application version by cloning the latest repo and applying Kubernetes manifests.

    Args:
        master_ip (str): The IP of the Kubernetes master node.
        deployment_name (str): The name of the deployment.
        repo_url (str): The Git repository URL.
        branch (str): The Git branch to clone.

    Returns:
        bool: True if deployment succeeded, False otherwise.
    """
    logging.info(f"🚀 Deploying application '{deployment_name}' on master node {master_ip} (branch: {branch})...")

    deployment_dir = f"/tmp/{deployment_name}"

    # ✅ 1. Clone or pull the latest repo with branch
    deploy_tasks = get_deployment_tasks(repo_url, deployment_name, branch=branch)

    if not execute_tasks(deploy_tasks, master_ip=master_ip):
        logging.error(f"❌ ERROR: Failed to clone or pull latest repository for '{deployment_name}'")
        return False

    # ✅ 2. Check if the deployment directory exists
    check_dir_command = f"test -d {deployment_dir} && echo 'Directory exists' || echo 'Missing'"
    success, message = execute_command_on_server(master_ip, "root", check_dir_command)

    if "Missing" in message:
        logging.error(f"❌ ERROR: Deployment directory '{deployment_dir}' not found on master node!")
        return False

    # ✅ 3. Apply Kubernetes manifests
    deploy_command = f"kubectl apply -f {deployment_dir} --recursive"
    success, message = execute_command_on_server(master_ip, "root", deploy_command)

    if success:
        logging.info(f"✅ Application '{deployment_name}' deployed successfully!")
        return True
    else:
        logging.error(f"❌ ERROR: Deployment failed: {message}")
        return False


def get_deployment_tasks(repo_url, deployment_name, branch="master"):
    """
    Define the deployment tasks to clone a specific branch of a repository on the Kubernetes master node.

    Args:
        repo_url (str): The Git repository URL provided by the user.
        deployment_name (str): The name of the deployment.
        branch (str): The branch to checkout.

    Returns:
        list: A list of task dictionaries for execution on the master node.
    """
    clone_dir = f"/tmp/{deployment_name}"

    return [
        {
            "name": "Ensure Temporary Directory Exists on Master",
            "command": f"mkdir -p {clone_dir} && chmod 777 {clone_dir}",
            "category": "dks-master"
        },
        {
            "name": "Clone Deployment Repository on Master",
            "command": (
                f"git clone --branch {branch} {repo_url} {clone_dir} "
                f"|| (cd {clone_dir} && git pull origin {branch})"
            ),
            "category": "dks-master"
        }
    ]

def get_dks_master_ip():
    try:
        with open(DKS_HOSTS_FILE, "r") as file:
            lines = file.readlines()

        master_ip = None
        is_master_section = False

        for line in lines:
            if line.strip() == "[dks-master]":
                is_master_section = True
                continue

            if is_master_section:
                parts = line.strip().split()
                if len(parts) >= 2:
                    master_ip = parts[0]
                    break

        if not master_ip:
            raise ValueError("Master IP not found in DKS hosts file.")

        return master_ip

    except Exception as e:
        raise RuntimeError(f"Failed to get master IP: {e}")

def get_k8s_pod_json(master_ip):
    """
    Fetch all pods in JSON format from the Kubernetes cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.

    Returns:
        str: Raw JSON output of all pods.
    """
    fetch_command = "kubectl get pods --all-namespaces -o json"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes pod details.")
        return "{}"

    return output


def execute_command_on_server(ip, user, command, timeout=None, real_time_output=False):

    import subprocess
    try:
        ssh_cmd = ["ssh", f"{user}@{ip}", f"{command}; echo ''"]
        result = subprocess.run(ssh_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        stdout = result.stdout.decode().strip()
        stderr = result.stderr.decode().strip()

        if result.returncode == 0:
            return True, stdout
        else:
            return False, stderr or stdout

    except Exception as e:
        return False, str(e)

def compare_k8s_configs(expected_config, current_config):
    """
    Compare expected (repo) Kubernetes config vs. live cluster config.
    """
    mismatches = []

    if expected_config["spec"]["replicas"] != current_config["spec"]["replicas"]:
        mismatches.append(f"❌ Replica count mismatch: Expected {expected_config['spec']['replicas']}, Found {current_config['spec']['replicas']}")

    expected_images = [c["image"] for c in expected_config["spec"]["template"]["spec"]["containers"]]
    current_images = [c["image"] for c in current_config["spec"]["template"]["spec"]["containers"]]

    if set(expected_images) != set(current_images):
        mismatches.append(f"❌ Image mismatch: Expected {expected_images}, Found {current_images}")

    return mismatches

def get_live_k8s_config(master_ip, deployment_name):
    """
    Fetch the current live Kubernetes deployment YAML config from the cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.
        deployment_name (str): The name of the deployment.

    Returns:
        dict: Parsed YAML of the Kubernetes deployment.
    """
    logging.info(f"📥 Fetching live Kubernetes config for {deployment_name} from {master_ip}...")

    fetch_command = f"kubectl get deployment {deployment_name} -o yaml"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error(f"❌ ERROR: Failed to fetch Kubernetes deployment state for {deployment_name}.")
        return None

    try:
        return yaml.safe_load(output)
    except yaml.YAMLError as e:
        logging.error(f"❌ ERROR: Failed to parse Kubernetes state YAML: {e}")
        return None


def execute_tasks(tasks, master_ip=None, secondary_master_ips=None, worker_ips=None, retries=3, retry_delay=15):
    """
    Execute a list of tasks on the specified host(s), with retry logic for transient failures.

    Args:
        tasks (list): List of task dictionaries to execute.
        master_ip (str): IP of the master node (optional).
        secondary_master_ips (list): List of secondary control plane node IPs (optional).
        worker_ips (list): List of worker node IPs (optional).
        retries (int): Number of retry attempts for each task.
        retry_delay (int): Delay in seconds between retries.
    """
    for task in tasks:
        task_name = task.get('name', 'Unnamed Task')
        action = task.get('action', 'RUN').upper()  # Default action is 'RUN'
        task_command = task.get('command', None)
        category = task.get('category', None)  # Auto-assigned as 'dks-master', 'dks-worker', or 'dks-secondary-master'
        timeout = task.get('timeout', 600)

        click.echo(click.style(f"Processing task: {task_name}", fg="yellow"))

        # Determine the target IPs based on the category
        if category == "dks-master" and master_ip:
            target_ips = [master_ip]
        elif category == "dks-worker" and worker_ips:
            target_ips = worker_ips
        else:
            click.echo(click.style(f"Task '{task_name}' has an invalid category or no matching targets. Skipping.", fg="red"))
            continue

        # Execute the task on all target IPs
        for target_ip in target_ips:
            for attempt in range(1, retries + 1):
                click.echo(f"Executing task '{task_name}' on '{category}' ({target_ip}), Attempt {attempt}/{retries}...")
                if action == 'RUN' and task_command:
                    success, message = execute_command_on_server(
                        target_ip,
                        "root",
                        task_command,
                        timeout=timeout,
                        real_time_output=True  # Stream logs in real time
                    )
                    if success:
                        click.echo(click.style(f"Task '{task_name}' executed successfully on '{target_ip}'.", fg="green"))
                        break  # Task succeeded; exit retry loop
                    else:
                        click.echo(click.style(f"Task '{task_name}' failed on '{target_ip}': {message}", fg="red"))
                        if attempt < retries:
                            click.echo(click.style(f"Retrying in {retry_delay} seconds...", fg="yellow"))
                            time.sleep(retry_delay)  # Wait before retrying
                        else:
                            click.echo(click.style(f"Task '{task_name}' failed after {retries} attempts. Halting further task execution.", fg="red"))
                            return False  # Halt on repeated failure
                else:
                    click.echo(click.style(f"Task '{task_name}' has no valid action or command. Skipping.", fg="red"))
                    break

    return True  # Return success if all tasks pass

# Function to clone or update the Git repository
def clone_or_update_repo(repo_url, branch="master"):
    """
    Clone the repository if it does not exist, otherwise update it.
    """
    if not os.path.exists(CLONE_DIR):
        os.makedirs(CLONE_DIR, exist_ok=True)

    repo_name = repo_url.split("/")[-1].replace(".git", "")
    repo_path = os.path.join(CLONE_DIR, repo_name)

    if os.path.exists(repo_path):
        logging.info(f"🔄 Repository {repo_name} already exists. Pulling latest changes...")
        subprocess.run(["git", "-C", repo_path, "pull"], check=True)
    else:
        logging.info(f"📥 Cloning repository {repo_url}...")
        subprocess.run(["git", "clone", "-b", branch, repo_url, repo_path], check=True)

    return repo_path

def get_all_k8s_deployments(master_ip):
    logging.info(f"📥 Fetching deployments from {master_ip}...")

    fetch_command = "kubectl get deployments -o=jsonpath={.items[*].metadata.name}; echo ''"
    success, message = execute_command_on_server(master_ip, "root", fetch_command)

    logging.info(f"🌐 Raw output: success={success}, message='{message}'")

    if not success or not message.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes deployments.")
        return []

    # Fix: clean out any shell prompt garbage
    clean_output = message.strip().splitlines()[0].strip()
    deployments = clean_output.split()

    logging.info(f"✅ Parsed deployments: {deployments}")
    return deployments


def load_deployment_snapshot_by_name(deployment_name):
    """
    Load a deployment snapshot by name.
    """
    for file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
        path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, file)
        snapshot = load_deployment_snapshot(path)
        if snapshot and snapshot.get("deployment_name") == deployment_name:
            return snapshot
    return None



# Notification Sender
def send_notification(subject, body, recipients, channels=["email"]):
    """
    Send notifications via configured channels (email, slack).

    Args:
        subject (str): Notification subject/title.
        body (str): Notification message.
        recipients (dict): Dictionary with 'notification_recipients' and 'notification_channels' keys.
        channels (list): Optional override of channels to send to (default: ["email"])
    """
    config = load_notification_config()
    if not config:
        logging.warning("⚠️ Notification config not found. Skipping notification.")
        return

    emails = recipients.get("notification_recipients", {}).get("email", [])
    user_channels = recipients.get("notification_channels", ["email"])

    # Use passed channels if not overridden
    channels = channels or user_channels

    logging.info(f"📣 Preparing to send notifications - Channels: {channels}, Recipients: {emails}")

    # ✅ Email
    if "email" in channels and config.get("email") and emails:
        email_config = config["email"]
        smtp_server = email_config.get("smtp_server")
        smtp_port = email_config.get("smtp_port")
        sender_email = email_config.get("sender_email")
        sender_password = email_config.get("sender_password")

        if smtp_server and smtp_port and sender_email and sender_password:
            msg = MIMEMultipart()
            msg["From"] = sender_email
            msg["To"] = ', '.join(emails)
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            try:
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls()
                    server.login(sender_email, sender_password)
                    server.sendmail(sender_email, emails, msg.as_string())
                logging.info("✅ Email notification sent.")
            except Exception as e:
                logging.error(f"❌ Failed to send email notification: {e}")
        else:
            logging.warning("⚠️ Incomplete email SMTP config. Skipping email notification.")
    else:
        logging.debug("📪 Email channel not used or no valid recipients.")

    # ✅ Slack
    if "slack" in channels and config.get("slack", {}).get("webhook_url"):
        slack_webhook = config["slack"]["webhook_url"]
        try:
            payload = {"text": f"*{subject}*\n{body}"}
            response = requests.post(slack_webhook, json=payload)
            if response.status_code == 200:
                logging.info("✅ Slack notification sent.")
            else:
                logging.error(f"❌ Slack notification failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"❌ Exception during Slack notification: {e}")
    else:
        logging.debug("💬 Slack channel not used or not configured.")

# Pod Health Checker
def check_pod_health_issues(pods_json):
    issues = []
    try:
        data = json.loads(pods_json)
        for item in data.get("items", []):
            namespace = item.get("metadata", {}).get("namespace", "default")
            pod_name = item.get("metadata", {}).get("name", "unknown")
            phase = item.get("status", {}).get("phase", "Unknown")
            container_statuses = item.get("status", {}).get("containerStatuses", [])

            if phase not in ["Running", "Succeeded"]:
                issues.append({"namespace": namespace, "pod": pod_name, "issue": f"Pod is in phase '{phase}'"})

            for cs in container_statuses:
                name = cs.get("name", "unknown")
                state = cs.get("state", {})
                if "waiting" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container waiting - {state['waiting'].get('reason')}: {state['waiting'].get('message')}"
                    })
                elif "terminated" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container terminated - {state['terminated'].get('reason')}: {state['terminated'].get('message')}"
                    })
    except Exception as e:
        issues.append({"namespace": "N/A", "pod": "N/A", "issue": f"Error parsing pod health: {e}"})
    return issues

def get_k8s_manifest_from_repo(repo_path, deployment_name):
    """
    Find the correct Kubernetes manifest file from the repo.
    """
    for root, _, files in os.walk(repo_path):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                with open(os.path.join(root, file), "r") as f:
                    try:
                        content = yaml.safe_load(f)
                        if content.get("kind") == "Deployment" and content["metadata"]["name"] == deployment_name:
                            return content
                    except yaml.YAMLError as e:
                        logging.error(f"❌ ERROR: Invalid YAML in {file}: {e}")
    return None

def load_notification_config():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration file not found: {CONFIGS_FILE}. Please create it to enable notifications.", fg="red"))
        return None

    with open(CONFIGS_FILE, 'r') as file:
        config = yaml.safe_load(file)

    if not config:
        click.echo(click.style(f"Notification configuration file {CONFIGS_FILE} is empty or invalid. Please update it.", fg="red"))
        return None

    return config



import threading

if __name__ == "__main__":
    threading.Thread(target=monitor_kubernetes_cluster, daemon=True).start()
    app.run(host="127.0.0.1", port=4104, debug=False)
