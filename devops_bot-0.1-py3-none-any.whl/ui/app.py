# Standard Library Imports
import os
import sys
import time
import json
import yaml
import glob
import gzip
import shutil
import hashlib
import threading
import smtplib
import socket
import logging
import secrets
import random
import string
import uuid
import datetime
import subprocess
import paramiko
from collections import defaultdict
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pathlib import Path
from datetime import datetime, timedelta, timezone

# Third-Party Imports
from flask import Flask, render_template, request, redirect, url_for, flash, session, Response, stream_with_context, jsonify, g
from flask_bcrypt import Bcrypt
from flask_login import LoginManager, UserMixin, login_user, logout_user, current_user, login_required
from itsdangerous import URLSafeTimedSerializer as Serializer
from flask_socketio import SocketIO, emit
from flask_cors import CORS
from werkzeug.utils import secure_filename
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.hazmat.backends import default_backend
from prometheus_client import Counter, Gauge, generate_latest, CollectorRegistry, CONTENT_TYPE_LATEST
from requests import post
from jwt import encode, decode
import psutil
import click

import sqlite3

# Flask Application Initialization
app = Flask(__name__)
CORS(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
socketio = SocketIO(app)

# Prometheus Metrics
registry = CollectorRegistry()
http_requests_total = Counter('http_requests_total', 'Total HTTP Requests', ['endpoint'], registry=registry)
response_time_seconds = Gauge('response_time_seconds', 'Response Time', ['endpoint'], registry=registry)


app = Flask(__name__, static_folder='static')
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your-default-secret-key')  # Consistent secret key
socketio = SocketIO(app)
active_sessions = {}
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
CORS(app)

from flask_login import LoginManager


# Define the base directory for user data and other configurations
BASE_DIR = os.path.expanduser("~/.devops-bot")
CREDENTIALS_DIR = os.path.join(BASE_DIR, "credentials")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
# Define the directory for storing user data and keys
USER_DATA_DIR = os.path.join(CREDENTIALS_DIR, "users_data")
KEY_FILE = os.path.join(USER_DATA_DIR, "key.key")
CONFIGS_DIR = os.path.join(BASE_DIR, "configs")
PROXY_CREDENTIALS_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_credentials.json")
PROXY_KEY_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_key.key")
WEBHOOK_API_DIR = os.path.join(BASE_DIR, "webhook-api")
WEBHOOK_SECRET_FILE = os.path.join(BASE_DIR, "webhook-api.json")
EXECUTION_RESULTS_DIR = os.path.join(BASE_DIR, "webhook_results")
SNAPSHOT_DIR = os.path.join(BASE_DIR, "snapshots")
os.makedirs(SNAPSHOT_DIR, exist_ok=True)
DB_FILE = os.path.join(BASE_DIR, "persona_db.sqlite")
CLONE_DIR = os.path.join(BASE_DIR, "webhook_artifacts")
os.makedirs(CLONE_DIR, exist_ok=True)
os.makedirs(EXECUTION_RESULTS_DIR, exist_ok=True) 
os.makedirs(WEBHOOK_API_DIR, exist_ok=True)  # Ensure the directory exists
DATABASE = os.getenv("APPROVAL_DATABASE", None)  # Get database path from environment or config
approvals = {}  # In-memory storage fallback
KEY_FILE = os.path.join(CONFIGS_DIR, "key.key")
CONFIGS_FILE = os.path.join(BASE_DIR, "pigeon.dob")
# Logs
LOG_FILE = os.path.join(LOGS_DIR, "devops_bot.log")
LOG_FILE_PATH = os.path.join(LOGS_DIR, "devops_bot.log")
DEVOPS_BOT_LOGS = os.path.join(BASE_DIR, "devops_bot.log")
CLONE_DIR = "/tmp/k8s_monitoring_repo"
# Configuration
DEPLOYMENT_SNAPSHOT_DIR =  os.path.join(CONFIGS_DIR, "dks_deployment")
CHECK_INTERVAL = 30 # Now checking every 5 seconds
GIT_CHECK_INTERVAL = 60
DKS_HOSTS_FILE =  os.path.join(CONFIGS_DIR, "dks_hosts")
# Set up logging
HOST_FILE = os.path.expanduser("~/.devops-bot/hosts")
DKS_SNAPSHOT_DIR = "~/.devops-bot/dks_snapshots"
LATEST_SNAPSHOT = os.path.join(DKS_SNAPSHOT_DIR, "latest.json")
TEMP_DIR =  os.path.join(BASE_DIR, "/tmp/devops-bot-configs")
DRIFT_REPORT_DIR = os.path.join(CONFIGS_DIR, "drift-reports")
GITOPS_LOG_PATH = "~/.devops-bot/logs/gitops.log"
os.makedirs(TEMP_DIR, exist_ok=True)  # Ensure directory exists
os.makedirs(DKS_SNAPSHOT_DIR, exist_ok=True) 
# Ensure the directories exist
os.makedirs(USER_DATA_DIR, exist_ok=True)
UPLOAD_FOLDER = '/tmp/screenplay'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(GITOPS_LOG_PATH, exist_ok=True)
from logging.handlers import RotatingFileHandler

log_formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')

log_handler = RotatingFileHandler(LOG_FILE_PATH, maxBytes=5 * 1024 * 1024, backupCount=5)
log_handler.setFormatter(log_formatter)

logger = logging.getLogger("DevOpsBot")
logger.setLevel(logging.INFO)
logger.addHandler(log_handler)

logger.info("✅ Logging has been configured successfully.")

timestamp = datetime.utcnow().isoformat()

# Flask-Login User class definition
class User(UserMixin):
    def __init__(self, username):
        self.id = username  # Flask-Login requires the `id` attribute to identify the user.

    @staticmethod
    def get(username):
        """Retrieve user object from XML storage."""
        user_data = load_user_from_xml(username)
        if user_data:
            return User(username)
        return None

# Save user data to XML
def save_user_to_xml(username, password_hash, email, full_name):
    user_dir = os.path.join(USER_DATA_DIR, username)
    os.makedirs(user_dir, exist_ok=True)  # Create user directory if it doesn't exist

    # Create the XML structure
    user_data = ET.Element('user')
    ET.SubElement(user_data, 'username').text = username
    ET.SubElement(user_data, 'password').text = password_hash
    ET.SubElement(user_data, 'email').text = email
    ET.SubElement(user_data, 'full_name').text = full_name

    # Write the XML to a file
    tree = ET.ElementTree(user_data)
    tree.write(os.path.join(user_dir, 'config.xml'))

# Load user data from XML
def load_user_from_xml(username):
    user_dir = os.path.join(USER_DATA_DIR, username)
    config_file = os.path.join(user_dir, 'config.xml')

    if not os.path.exists(config_file):
        return None

    tree = ET.parse(config_file)
    root = tree.getroot()

    password_hash = root.find('password').text
    email = root.find('email').text
    full_name = root.find('full_name').text

    return {
        'username': username,
        'password': password_hash,
        'email': email,
        'full_name': full_name
    }

live_log_listeners = []

def broadcast_live_log(message: str):
    for listener in live_log_listeners:
        listener.put(message)

    # ✅ Also write to persistent file
    try:
        with open(GITOPS_LOG_PATH, "a") as f:
            f.write(message)
    except Exception as e:
        print(f"❌ Failed to write GitOps log to file: {e}")


def monitor_gitops():
    # ✅ Clear the GitOps log file on startup
    try:
        open(GITOPS_LOG_PATH, "w").close()
        print(f"[🧹] Cleared GitOps log at {GITOPS_LOG_PATH}")
    except Exception as e:
        print(f"❌ Failed to clear GitOps log: {e}")

    while True:
        try:
            broadcast_live_log("🔍 Checking Git repositories and K8s clusters...\n")

            # ✅ Run GitOps checks
            monitor_git_repositories()
            monitor_kubernetes_cluster()

            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            broadcast_live_log(f"❌ CRITICAL ERROR: {str(e)}\n")

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Check if the username already exists
        if os.path.exists(os.path.join(USER_DATA_DIR, username)):
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('register'))

        # Hash the password and save user data in XML
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        save_user_to_xml(username, password_hash, email, full_name)

        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Load user data from XML
        user_data = load_user_from_xml(username)
        if user_data and bcrypt.check_password_hash(user_data['password'], password):
            user = User(username)  # Create User instance for Flask-Login
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Login failed. Check your username and password.', 'danger')

    return render_template('login.html')

# Flask-Login loader to reload the user from the session
@login_manager.user_loader
def load_user(username):
    return User.get(username)

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/file-generator')
@login_required
def file_generator():
    return render_template('file_generator.html')



def get_db():
    """
    Get a database connection. Create the approvals table if it doesn't exist.
    """
    if 'db' not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.execute("""
            CREATE TABLE IF NOT EXISTS approvals (
                token TEXT PRIMARY KEY,
                status TEXT
            )
        """)
        g.db.commit()
    return g.db


@app.teardown_appcontext
def close_db(exception):
    """
    Close the database connection at the end of the request.
    """
    db = g.pop('db', None)
    if db is not None:
        db.close()


def save_approval(token, status):
    """
    Save approval status in the database or in-memory storage.
    """
    if DATABASE:
        db = get_db()
        db.execute("INSERT OR REPLACE INTO approvals (token, status) VALUES (?, ?)", (token, status))
        db.commit()
    else:
        approvals[token] = status


def get_approval_status(token):
    """
    Get approval status from the database or in-memory storage.
    """
    if DATABASE:
        db = get_db()
        result = db.execute("SELECT status FROM approvals WHERE token = ?", (token,)).fetchone()
        return result[0] if result else "pending"
    return approvals.get(token, "pending")


@app.route("/approve", methods=["GET"])
def approve():
    token = request.args.get("token")
    if not token:
        return "Invalid request: missing token.", 400

    save_approval(token, "approved")
    app.logger.info(f"Approval received for token: {token}")
    return "Thank you! The task has been approved."


@app.route("/status", methods=["GET"])
def status():
    token = request.args.get("token")
    if not token:
        return jsonify({"status": "invalid"}), 400

    status = get_approval_status(token)
    app.logger.info(f"Status check for token: {token}, status: {status}")
    return jsonify({"status": status})

@app.route('/generate-token', methods=['POST'])
@login_required
def generate_token():
    username = current_user.id

    try:
        # Use the installed 'dob' command instead of directly running cli.py
        result = subprocess.run(
            ['dob', 'generate-token', '--username', username],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            flash(f"Error: {result.stderr}", 'danger')
        else:
            flash(f"Token: {result.stdout.strip()}", 'success')
    except Exception as e:
        flash(f"Error generating token: {str(e)}", 'danger')

    return redirect(url_for('index'))


@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        if bcrypt.check_password_hash(current_user.password, current_password):
            current_user.update_password(new_password)
            flash('Password updated successfully!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Current password is incorrect.', 'danger')
    return render_template('change_password.html')

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        email = request.form['email']
        full_name = request.form['full_name']
        current_user.update(email=email, full_name=full_name)
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('settings.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))
@socketio.on('connect')
def handle_connect():
    print("Client connected")
    emit('webhook_logs', "Connected to the WebSocket server.")

@socketio.on('disconnect')
def handle_disconnect():
    print("Client disconnected")


@app.route('/ssh', methods=['POST'])
def ssh():
    data = request.get_json()
    hostname = data.get('hostname')
    username = data.get('username')
    password = data.get('password')
    command = data.get('command')

    session_id = f"{hostname}_{username}"  # Define a unique session identifier based on the host and username

    if session_id not in active_sessions:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            # Establish a new SSH connection
            client.connect(hostname, username=username, password=password)
            active_sessions[session_id] = client  # Store the SSH client in the global dictionary

        except paramiko.AuthenticationException:
            return jsonify({"error": "Authentication failed, please check your credentials"}), 401
        except paramiko.SSHException as e:
            return jsonify({"error": f"SSH error: {str(e)}"}), 500
        except Exception as e:
            return jsonify({"error": f"General error: {str(e)}"}), 500

    # Use the existing connection
    client = active_sessions[session_id]

    try:
        # Execute the command within the existing session
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode()
        error = stderr.read().decode()

        if output:
            return jsonify({"output": output})
        elif error:
            return jsonify({"error": error}), 400
    except paramiko.SSHException as e:
        return jsonify({"error": f"SSH error: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"General error: {str(e)}"}), 500



@app.route('/close_ssh', methods=['POST'])
def close_ssh():
    data = request.get_json()
    hostname = data.get('hostname')
    username = data.get('username')

    session_id = f"{hostname}_{username}"

    # Close and remove the SSH session
    if session_id in active_sessions:
        client = active_sessions.pop(session_id, None)
        if client:
            client.close()
        return jsonify({"message": "SSH session closed"}), 200
    return jsonify({"error": "No SSH session to close"}), 400

def authenticate_persona(request):
    """
    Authenticate a persona using headers: Persona-Name, Authorization (token), and Signature.
    """
    persona_name = request.headers.get("Persona-Name")
    token = request.headers.get("Authorization")
    signature = request.headers.get("Signature")

    if not persona_name or not token or not signature:
        return False, "Missing authentication headers."

    try:
        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT public_key FROM personas WHERE name = ?", (persona_name,))
        row = cursor.fetchone()
        conn.close()

        if not row:
            return False, "Persona not found."

        public_key_pem = row[0].encode()
        public_key = serialization.load_pem_public_key(public_key_pem)

        public_key.verify(
            bytes.fromhex(signature),
            token.encode(),
            padding.PKCS1v15(),
            hashes.SHA256()
        )

        conn = sqlite3.connect(DB_FILE)
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM tokens WHERE token = ? AND persona_id = (SELECT id FROM personas WHERE name = ?)", (token, persona_name))
        token_row = cursor.fetchone()
        conn.close()

        if not token_row:
            return False, "Invalid or expired token."

        return True, "Authenticated successfully."

    except Exception as e:
        return False, f"Authentication failed: {str(e)}"


@app.route('/execute_yaml', methods=['POST'])
def execute_yaml():
    """
    API for executing YAML-based configurations (InfraSet & InfraCycle).
    """
    executor = "unknown"  # Default value
    conn = sqlite3.connect(DB_FILE)

    try:
        # ✅ **Authenticate the request**
        is_authenticated, message = authenticate_persona(request)
        if not is_authenticated:
            log_execution("execute_yaml", "failure", executor, conn)
            conn.close()
            return jsonify({"error": message}), 403

        # ✅ **Retrieve Persona Name from Headers**
        executor = request.headers.get("Persona-Name", "unknown").strip()

        # ✅ **Extract request data**
        data = request.get_json()
        if not data or "command" not in data or "file_content" not in data:
            log_execution("execute_yaml", "failure", executor, conn)
            conn.close()
            return jsonify({"error": "Missing required fields: 'command' and 'file_content'"}), 400

        command_type = data["command"]
        file_content = data["file_content"]

        # ✅ **Check Persona Permissions**
        if not check_persona_role(executor, command_type):
            log_execution(command_type, "unauthorized", executor, conn)
            conn.close()
            return jsonify({"error": f"Unauthorized: Persona '{executor}' does not have the required role"}), 403

        # ✅ **Save YAML Content to a Temporary File**
        temp_file_path = f"/tmp/{uuid.uuid4()}.yaml"
        with open(temp_file_path, "w") as yaml_file:
            yaml_file.write(file_content)

        # ✅ **Modify Command to Include --file-path**
        command_with_path = f"{command_type} --file-path {temp_file_path}"

        # ✅ **Log and Execute the Final Command**
        log_execution(command_with_path, "started", executor, conn)
        response = Response(generate(command_with_path.split(), command_with_path, executor), mimetype='text/plain')
        log_execution(command_with_path, "success", executor, conn)
        return response

    except Exception as e:
        log_execution("execute_yaml", "failure", executor, conn)
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

    finally:
        conn.close()


@app.route('/execute_screenplay_command', methods=['POST'])
def execute_screenplay_command():
    """
    API for executing screenplay configurations.
    """
    executor = "unknown"  # Default persona name
    conn = sqlite3.connect(DB_FILE)

    try:
        # ✅ **Authenticate the request**
        is_authenticated, message = authenticate_persona(request)
        if not is_authenticated:
            log_execution("execute_screenplay", "failure", executor, conn)
            conn.close()
            return jsonify({"error": message}), 403

        # ✅ **Retrieve Persona Name from Headers**
        executor = request.headers.get("Persona-Name", "unknown").strip()

        # ✅ **Extract request data**
        data = request.get_json()
        if not data or "command" not in data or "file_content" not in data:
            log_execution("execute_screenplay", "failure", executor, conn)
            conn.close()
            return jsonify({"error": "Missing required fields: 'command' and 'file_content'"}), 400

        command_type = data["command"]  # ✅ Command now comes from frontend
        file_content = data["file_content"]

        # ✅ **Check Persona Permissions**
        if not check_persona_role(executor, command_type):
            log_execution(command_type, "unauthorized", executor, conn)
            conn.close()
            return jsonify({"error": f"Unauthorized: Persona '{executor}' does not have the required role"}), 403

        # ✅ **Save screenplay YAML content to a temporary file**
        temp_file_path = f"/tmp/{uuid.uuid4()}.yaml"
        with open(temp_file_path, "w") as yaml_file:
            yaml_file.write(file_content)

        # ✅ **Modify Command to Add File Location**
        command_with_path = f"{command_type} {temp_file_path}"  # No '--file-path' needed

        # ✅ **Log and Execute the Final Command**
        log_execution(command_with_path, "started", executor, conn)
        response = Response(generate(command_with_path.split(), command_with_path, executor), mimetype='text/plain')
        log_execution(command_with_path, "success", executor, conn)
        return response

    except Exception as e:
        log_execution("execute_screenplay", "failure", executor, conn)
        return jsonify({"error": f"Unexpected error: {str(e)}"}), 500

    finally:
        conn.close()
        

@app.route('/execute', methods=['POST'])
def execute():
    """
    Secure API: Authenticate remote requests while allowing local execution.
    """
    executor = "unknown"
    conn = sqlite3.connect(DB_FILE)

    try:
        if request.remote_addr in ["127.0.0.1", "::1"]:
            executor = "localhost"
        else:
            is_authenticated, message = authenticate_persona(request)
            if not is_authenticated:
                log_execution("execute", "failure", executor, conn)
                conn.close()
                return jsonify({"error": message}), 403

            executor = request.headers.get("Persona-Name", "unknown").strip()

        command_type = request.json.get('command')
        if not command_type:
            log_execution("execute", "failure", executor, conn)
            conn.close()
            return jsonify({"error": "Missing required command field"}), 400

        # ✅ Extract role and command
        cmd_parts = command_type.split()
        role = cmd_parts[0]
        command = " ".join(cmd_parts[1:])


        # ✅ **Step 1: Check if persona has permission to execute**
        if not check_persona_role(executor, command_type):
            log_execution(command_type, "unauthorized", executor, conn)
            conn.close()
            return jsonify({"error": "Unauthorized: Persona does not have the required role"}), 403

        # ✅ **Then Check Persona Role**
        if not check_persona_role(executor, command_type):
            log_execution(command_type, "unauthorized", executor, conn)
            conn.close()
            return jsonify({"error": "Unauthorized: Persona does not have the required role"}), 403

        # ✅ **Record Execution**
#        record_execution(executor, command_type, conn)

        return Response(generate(cmd_parts, command_type, executor), mimetype='text/plain')

    finally:
        conn.close()

def check_execution_limit(persona_name, role, command, conn):
    """
    TEMPORARY TEST FUNCTION: This will ALWAYS BLOCK execution.
    """

    print(f"⛔ TEST: Execution is being blocked for '{persona_name}' running '{command}'")
    sys.exit(1)  # 🚨 HARD STOP: Forcefully terminate execution.

def record_execution(persona_name, role, command, conn):
    """
    Record the execution of a command in the execution_records table.

    Args:
        persona_name (str): The persona executing the command.
        command (str): The full command being executed.
        conn (sqlite3.Connection): Active database connection.
    """
    cursor = conn.cursor()

    # ✅ Extract role and subcommand
    cmd_parts = command.split()
    role = cmd_parts[0] if len(cmd_parts) > 1 else None
    subcommand = " ".join(cmd_parts[1:]) if len(cmd_parts) > 1 else command

    if not role or not subcommand:
        print(f"⚠️ Error: Could not determine role/subcommand from '{command}'")
        return  # Exit early if there's a problem

    # ✅ Get persona ID
    cursor.execute("SELECT id FROM personas WHERE name = ?", (persona_name,))
    persona_row = cursor.fetchone()
    if not persona_row:
        print(f"⚠️ Error: Persona '{persona_name}' not found.")
        return

    persona_id = persona_row[0]

    # ✅ Insert execution record
    cursor.execute("""
        INSERT INTO execution_records (persona_id, role, command)
        VALUES (?, ?, ?)
    """, (persona_id, role, subcommand))
    conn.commit()

    print(f"✅ Execution recorded: {persona_name} executed {role} {subcommand}")




def check_limit_reset(last_reset, limit_type):
    """
    Check if the execution limit needs to be reset based on the limit type.

    Args:
        last_reset (str): The timestamp of the last reset (stored as string in DB).
        limit_type (str): The type of limit ('daily', 'weekly', 'monthly').

    Returns:
        bool: True if reset is needed, False otherwise.
    """
    if not last_reset:
        return True  # If no reset time is stored, assume reset is needed

    # ✅ Convert last_reset (string) to datetime object
    last_reset_dt = datetime.strptime(last_reset, "%Y-%m-%d %H:%M:%S")  # Convert to datetime

    now = datetime.now()

    if limit_type == "daily":
        return last_reset_dt.date() < now.date()  # Compare only the date
    elif limit_type == "weekly":
        return last_reset_dt.isocalendar()[1] < now.isocalendar()[1]  # Compare week numbers
    elif limit_type == "monthly":
        return last_reset_dt.month < now.month or last_reset_dt.year < now.year  # Compare months
    return False  # Default case: No reset needed

def generate(cmd_parts, command_type, executor):
    """
    Run the command and log execution status.
    Uses a new database connection to prevent "closed DB" issues.
    """
    conn = sqlite3.connect(DB_FILE)  # ✅ Open a fresh DB connection

    try:
        process = subprocess.Popen(
            cmd_parts,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            env=os.environ.copy()
        )

        for stdout_line in iter(process.stdout.readline, ""):
            yield stdout_line

        process.stdout.close()
        return_code = process.wait()

        if return_code:
            for stderr_line in process.stderr:
                yield f"ERROR: {stderr_line.strip()}\n"
            log_execution(command_type, "failure", executor, conn)
        else:
            log_execution(command_type, "success", executor, conn)

        process.stderr.close()

    except Exception as e:
        log_execution(command_type, "failure", executor, conn)
        yield f"ERROR: {str(e)}\n"

    finally:
        conn.close()  # ✅ Ensure the connection is closed properly
def log_execution(command, status, executor="unknown", conn=None):
    """
    Log the execution of a command and store it in `execution_records`.

    Args:
        command (str): The command being executed.
        status (str): The status of the command execution (success or failure).
        executor (str): The persona executing the command.
        conn (sqlite3.Connection, optional): Active database connection.
    """
    if not isinstance(executor, str) or not executor.strip():
        executor = "unknown"

    close_conn = False  # Track if we created a new connection

    if conn is None or isinstance(conn, str):
        conn = sqlite3.connect(DB_FILE)
        close_conn = True  # ✅ Only close if we created a new connection

    try:
        cursor = conn.cursor()

        # ✅ Remove "dob" prefix if present
        cmd_parts = command.split()
        if cmd_parts[0] == "dob":
            cmd_parts = cmd_parts[1:]  # Remove "dob"

        formatted_command = " ".join(cmd_parts)  # Ensure full command is logged

        print(f"LOGGING: Persona={executor}, Command={formatted_command}, Status={status}")  # Debugging

        # ✅ Insert properly formatted command into logs
        cursor.execute("""
            INSERT INTO logs (persona_name, command, status, timestamp)
            VALUES (?, ?, ?, datetime('now'))
        """, (executor, formatted_command, status))

        conn.commit()

        # ✅ ADDITION: If the execution was successful, record it in `execution_records`
        if status == "success":
            # Get persona ID
            cursor.execute("SELECT id FROM personas WHERE name = ?", (executor,))
            persona_row = cursor.fetchone()
            if persona_row:
                persona_id = persona_row[0]
                role = cmd_parts[0]  # First part is the role
                subcommand = " ".join(cmd_parts[1:]) if len(cmd_parts) > 1 else command

                cursor.execute("""
                    INSERT INTO execution_records (persona_id, role, command, execution_time)
                    VALUES (?, ?, ?, datetime('now'))
                """, (persona_id, role, subcommand))

        conn.commit()

    except sqlite3.Error as e:
        print(f"⚠️ Database logging error: {e}")  # Debugging
    finally:
        if close_conn:
            conn.close()  # ✅ Only close if we created it


def check_persona_role(persona_name, command):
    """
    Check if the persona has the required role for execution, including subcommands.

    Args:
        persona_name (str): The persona executing the command.
        command (str): The full command received.

    Returns:
        bool: True if the persona has permission, False otherwise.
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Extract the main command and subcommand
    cmd_parts = command.split()
    if len(cmd_parts) < 2 or cmd_parts[0] != "dob":
        print(f"DEBUG: Invalid command format: {command}")  # Debugging
        return False

    role = cmd_parts[1]  # Extract main role
    subcommand = cmd_parts[2] if len(cmd_parts) > 2 else None  # Extract subcommand if present

    print(f"DEBUG: Checking permissions for persona '{persona_name}' to execute '{role} {subcommand or ''}'")  

    # ✅ Fetch roles assigned to the persona
    cursor.execute("""
        SELECT command, subcommand FROM persona_roles
        WHERE persona_id = (SELECT id FROM personas WHERE name = ?)
    """, (persona_name,))
    persona_roles = cursor.fetchall()

    # ✅ Fetch roles assigned through namespaces
    cursor.execute("""
        SELECT pr.command, pr.subcommand 
        FROM persona_roles pr
        JOIN persona_namespaces pn ON pr.namespace_id = pn.namespace_id
        WHERE pn.persona_id = (SELECT id FROM personas WHERE name = ?)
    """, (persona_name,))
    namespace_roles = cursor.fetchall()

    all_roles = set(persona_roles + namespace_roles)  # Combine both role lists

    conn.close()

    print(f"DEBUG: Assigned roles for {persona_name}: {all_roles}")  

    # ✅ Ensure the persona has access to both command and subcommand (if applicable)
    if (role, subcommand) in all_roles or (role, None) in all_roles:
        print(f"DEBUG: ✅ Persona '{persona_name}' is authorized for '{role} {subcommand or ''}'")
        return True
    else:
        print(f"DEBUG: ❌ Persona '{persona_name}' is NOT authorized for '{role} {subcommand or ''}'")
        return False


@app.route('/metrics')
@login_required
def metrics():
    import psutil
    import datetime

    boot_time = datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

    metrics_data = {
        'cpu_percent': psutil.cpu_percent(interval=1),
        'cpu_user_time': psutil.cpu_times().user,
        'cpu_system_time': psutil.cpu_times().system,
        'cpu_idle_time': psutil.cpu_times().idle,
        'cpu_count': psutil.cpu_count(),
        'memory_percent': psutil.virtual_memory().percent,
        'memory_total': round(psutil.virtual_memory().total / (1024 * 1024 * 1024), 2),
        'memory_used': round(psutil.virtual_memory().used / (1024 * 1024 * 1024), 2),
        'memory_available': round(psutil.virtual_memory().available / (1024 * 1024 * 1024), 2),
        'disk_percent': psutil.disk_usage('/').percent,
        'disk_total': round(psutil.disk_usage('/').total / (1024 * 1024 * 1024), 2),
        'disk_used': round(psutil.disk_usage('/').used / (1024 * 1024 * 1024), 2),
        'disk_free': round(psutil.disk_usage('/').free / (1024 * 1024 * 1024), 2),
        'network_sent': round(psutil.net_io_counters().bytes_sent / (1024 * 1024), 2),
        'network_received': round(psutil.net_io_counters().bytes_recv / (1024 * 1024), 2),
        'network_packets_sent': psutil.net_io_counters().packets_sent,
        'network_packets_received': psutil.net_io_counters().packets_recv,
        'boot_time': boot_time
    }
    return jsonify(metrics_data)



@app.route('/remote_metrics', methods=['GET'])
def fetch_remote_metrics_endpoint():
    """Fetch remote system metrics through the proxy."""
    try:
        credentials = load_proxy_credentials()
        if not credentials:
            return jsonify({"error": "Proxy credentials not found. Please configure the proxy first."}), 400

        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/metrics"

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to DevOps Bot Proxy: {e}"}), 500

def generate_webhook_secret():
    """
    Generate a new webhook secret key and save it to a file.
    """
    secret_key = secrets.token_hex(32)
    secret_data = {"webhook_secret": secret_key}
    with open(WEBHOOK_SECRET_FILE, "w") as f:
        json.dump(secret_data, f)
        os.chmod(WEBHOOK_SECRET_FILE, 0o600)
    return secret_key

def load_webhook_secret():
    """
    Load the webhook secret key from the file. Generate a new one if it doesn't exist.
    """
    if not os.path.exists(WEBHOOK_SECRET_FILE):
        return generate_webhook_secret()
    with open(WEBHOOK_SECRET_FILE, "r") as f:
        secret_data = json.load(f)
    return secret_data.get("webhook_secret")

WEBHOOK_SECRET = load_webhook_secret()

def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        return False
    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        return False
    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    return hmac.compare_digest(mac.hexdigest(), signature)


def generate_random_string(length=16):
    """Generate a random alphanumeric string."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def generate_api_key():
    """
    Generate a random API key and save it to a file.
    """
    webhook_api_dir = os.path.join(BASE_DIR, "webhook-api")
    os.makedirs(webhook_api_dir, exist_ok=True)

    random_name = f"devops_bot_{secrets.token_hex(4)}"
    api_key = secrets.token_hex(32)
    file_path = os.path.join(webhook_api_dir, random_name)

    with open(file_path, "w") as f:
        f.write(api_key)
        os.chmod(file_path, 0o600)

    print(f"API key generated: {file_path}")  # Log the file path for debugging
    return {"name": random_name, "token": api_key}



def load_proxy_key():
    with open(PROXY_KEY_FILE, 'rb') as key_file:
        return key_file.read()

def decrypt_proxy_data(encrypted_data, key):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data

def load_proxy_credentials():
    """Load and decrypt proxy credentials."""
    try:
        with open(os.path.join(BASE_DIR, PROXY_CREDENTIALS_FILE), 'rb') as cred_file:
            encrypted_data = cred_file.read()

        key = load_proxy_key()  # Load encryption key
        decrypted_data = decrypt_proxy_data(encrypted_data, key)  # Decrypt data
        credentials = json.loads(decrypted_data)  # Convert JSON string to dictionary
        return credentials  # Return as dictionary
    except (FileNotFoundError, ValueError, KeyError) as e:
        click.echo(f"Failed to load proxy credentials: {e}")
        return None


def validate_api_key(api_name, api_token):
    """Validate the API key provided by the user."""
    file_path = os.path.join(WEBHOOK_API_DIR, api_name)
    if not os.path.exists(file_path):
        return False

    with open(file_path, "r") as f:
        stored_token = f.read().strip()

    return hmac.compare_digest(stored_token, api_token)

@app.route('/generate-api-key', methods=['POST'])
def generate_api_key_endpoint():
    """
    Generate a new API key via HTTP request.
    """
    try:
        api_key_data = generate_api_key()
        return jsonify({
            "status": "success",
            "name": api_key_data['name'],
            "token": api_key_data['token']
        }), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@click.command()
def regenerate_webhook_secret():
    """
    Command to regenerate the webhook secret key.
    """
    new_secret = generate_webhook_secret()
    print(f"New webhook secret generated: {new_secret}")


@app.route('/generate-webhook-secret', methods=['POST'])
def generate_webhook_secret_endpoint():
    """
    Generate a new webhook secret key via HTTP request.
    """
    try:
        new_secret = generate_webhook_secret()
        return jsonify({"status": "success", "webhook_secret": new_secret}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

def get_next_build_file_path(repo_name):
    """
    Generate the next build file path for the specified repository in the results directory.
    """
    results_dir = os.path.join(EXECUTION_RESULTS_DIR, repo_name)
    os.makedirs(results_dir, exist_ok=True)

    existing_files = glob.glob(os.path.join(results_dir, "build-no-*.json"))
    if not existing_files:
        return os.path.join(results_dir, "build-no-001.json")

    build_numbers = [
        int(os.path.basename(f).split("-")[2].split(".")[0]) for f in existing_files
    ]
    next_build_number = max(build_numbers) + 1

    if next_build_number > 100:
        raise Exception("Build limit exceeded: Maximum 100 builds allowed.")

    return os.path.join(results_dir, f"build-no-{next_build_number:03}.json")


def execute_dob_command(file_path, results_path):
    """
    Execute the dob command and save the results in a structured format.
    """
    try:
        result = subprocess.run(
            ["dob", "infracycle", "apply", "--file-path", file_path],
            capture_output=True,
            text=True,
        )

        # Parse stdout into structured lines
        stdout_lines = result.stdout.strip().split("\n")
        stderr_lines = result.stderr.strip().split("\n") if result.stderr else []

        # Build a detailed result structure
        execution_result = {
            "status": "success" if result.returncode == 0 else "failure",
            "summary": {
                "exit_code": result.returncode,
                "stdout_line_count": len(stdout_lines),
                "stderr_line_count": len(stderr_lines),
            },
            "stdout": stdout_lines,
            "stderr": stderr_lines,
        }

        # Save execution results to the specified path
        with open(results_path, "w") as f:
            json.dump(execution_result, f, indent=4)

        return True, f"Execution results saved to {results_path}"
    except subprocess.CalledProcessError as e:
        return False, str(e)

@app.route('/webhook', methods=['POST'])
def handle_webhook():
    event_type = request.headers.get("X-GitHub-Event", "unknown")
    signature = request.headers.get('X-Hub-Signature-256')
    payload = request.get_data(as_text=True)

    # LOG: Signature verification is currently disabled
    socketio.emit('webhook_logs', "Signature verification temporarily disabled")

    # Bypass signature verification
    # if not verify_signature(payload.encode(), signature, WEBHOOK_SECRET):
    #     error_message = "Invalid GitHub signature!"
    #     socketio.emit('webhook_logs', error_message)
    #     return jsonify({"error": error_message}), 403

    if event_type != "push":
        info_message = f"Ignored event: {event_type}"
        socketio.emit('webhook_logs', info_message)
        return jsonify({"status": "ignored", "event": event_type}), 200

    try:
        json_payload = request.json
        repo_name = json_payload["repository"]["full_name"]
        source_url = json_payload["repository"]["ssh_url"]
        branch = json_payload["ref"].split("/")[-1]
        modified_files = json_payload.get("head_commit", {}).get("modified", [])

        execution_file = "Dobbuild.yaml"

        # Check if the execution file is modified
        if execution_file not in modified_files:
            info_message = f"No changes detected in {execution_file}. Aborting process."
            socketio.emit('webhook_logs', info_message)
            return jsonify({"status": "aborted", "message": info_message}), 200

        # Prepare task details
        details = {
            "repositories": {
                repo_name: {
                    "source_url": source_url,
                    "branch": branch,
                    "repo_name": repo_name.split("/")[-1],
                    "execution_file": execution_file
                }
            }
        }
        log_message = "Prepared Details for Processing:\n" + json.dumps(details, indent=4)
        socketio.emit('webhook_logs', log_message)

        return process_repository(details)

    except Exception as e:
        error_message = f"Error processing payload: {str(e)}"
        socketio.emit('webhook_logs', error_message)
        return jsonify({"error": error_message}), 500

def process_repository(details):
    repo_details = next(iter(details["repositories"].values()))
    source_url = repo_details["source_url"]
    branch = repo_details["branch"]
    repo_name = repo_details["repo_name"]
    clone_dir = os.path.join(CLONE_DIR, repo_name)
    snapshot_file = os.path.join(SNAPSHOT_DIR, f"{repo_name}_snapshot.json")
    execution_file = os.path.join(clone_dir, repo_details["execution_file"])
    results_path = get_next_build_file_path(os.path.join(EXECUTION_RESULTS_DIR, repo_name))

    if source_url.startswith("git@github.com:"):
        source_url = source_url.replace("git@github.com:", "https://github.com/")

    try:
        if os.path.exists(clone_dir):
            log_message = f"Cleaning up existing directory: {clone_dir}"
            socketio.emit('webhook_logs', log_message)
            shutil.rmtree(clone_dir)

        log_message = f"Cloning repository {repo_name} from {source_url}..."
        socketio.emit('webhook_logs', log_message)
        subprocess.run(["git", "clone", "--branch", branch, source_url, clone_dir], check=True)
        socketio.emit('webhook_logs', f"Repository {repo_name} cloned successfully.")

        current_snapshot = generate_snapshot(clone_dir)

        if os.path.exists(snapshot_file):
            with open(snapshot_file, 'r') as f:
                previous_snapshot = json.load(f)
            if current_snapshot == previous_snapshot:
                message = "No changes detected since the last snapshot. Skipping execution."
                socketio.emit('webhook_logs', message)
                return jsonify({"status": "skipped", "message": message}), 200
        else:
            socketio.emit('webhook_logs', "No previous snapshot found. Proceeding with execution.")

        with open(snapshot_file, 'w') as f:
            json.dump(current_snapshot, f)
        socketio.emit('webhook_logs', "Snapshot saved successfully.")

        if os.path.exists(execution_file):
            log_message = f"Executing {execution_file}..."
            socketio.emit('webhook_logs', log_message)
            success, message = execute_dob_command(execution_file, results_path)
            socketio.emit('webhook_logs', message)
            if success:
                return jsonify({"status": "success", "message": message, "results_file": results_path}), 200
            else:
                return jsonify({"status": "error", "message": message}), 500
        else:
            error_message = f"{execution_file} not found. Aborting."
            socketio.emit('webhook_logs', error_message)
            return jsonify({"status": "error", "message": error_message}), 404

    except subprocess.CalledProcessError as e:
        error_message = f"Subprocess error: {e.stderr}"
        socketio.emit('webhook_logs', error_message)
        return jsonify({"status": "error", "message": error_message}), 500
    except Exception as e:
        error_message = f"Unexpected error: {str(e)}"
        socketio.emit('webhook_logs', error_message)
        return jsonify({"status": "error", "message": error_message}), 500

def generate_snapshot(directory):
    """
    Generate a snapshot of the directory by creating a hash of all file contents.

    Args:
        directory (str): The directory to snapshot.

    Returns:
        dict: A dictionary representing the snapshot (file paths and their hashes).
    """
    snapshot = {}
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            with open(file_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
            relative_path = os.path.relpath(file_path, directory)
            snapshot[relative_path] = file_hash
    return snapshot

def generate_snapshot(directory):
    """
    Generate a snapshot of the directory by creating a hash of all file contents.

    Args:
        directory (str): The directory to snapshot.

    Returns:
        dict: A dictionary representing the snapshot (file paths and their hashes).
    """
    snapshot = {}
    for root, _, files in os.walk(directory):
        for file in files:
            file_path = os.path.join(root, file)
            with open(file_path, 'rb') as f:
                file_hash = hashlib.sha256(f.read()).hexdigest()
            relative_path = os.path.relpath(file_path, directory)
            snapshot[relative_path] = file_hash
    return snapshot


def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        print("Missing signature header!")
        return False

    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        print(f"Unsupported hash type: {sha_name}")
        return False

    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    generated_signature = mac.hexdigest()
    print(f"Generated signature: sha256={generated_signature}")
    print(f"Received signature: {signature}")

    return hmac.compare_digest(generated_signature, signature)


@app.route('/execute_command', methods=['POST'])
@login_required
def execute_command():
    command_input = request.form.get('command_input')
    if not command_input:
        return f"<div style='color: red;'>Command not provided</div>", 400

    try:
        process = subprocess.Popen(
            command_input,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=UPLOAD_FOLDER  # Ensures safety by running commands in the working directory
        )

        def generate():
            for stdout_line in iter(process.stdout.readline, ""):
                yield f"<div>{stdout_line.strip()}</div>\n"
            process.stdout.close()
            return_code = process.wait()
            if return_code:
                for stderr_line in process.stderr:
                    yield f"<div style='color: red;'>{stderr_line.strip()}</div>\n"
            process.stderr.close()

        return Response(generate(), mimetype='text/html')
    except Exception as e:
        return f"<div style='color: red;'>Error: {str(e)}</div>", 500

@app.route('/execute_screenplay', methods=['POST'])
def execute_screenplay():
    """
    Endpoint for executing commands or YAML-based scripts.
    Supports both login-based and persona-based authentication.
    """
    # Check if the request is using persona-based authentication
    is_authenticated, message = authenticate_persona(request)

    if not is_authenticated:
        if not current_user.is_authenticated:
            return jsonify({"error": "Authentication required. Please log in or provide a valid persona token."}), 403

    command_type = request.json.get('command')
    yaml_content = request.json.get('yaml_content')

    if not command_type and not yaml_content:
        return jsonify({"error": "Missing required fields: either 'command' or 'yaml_content' must be provided"}), 400

    if command_type:
        def generate():
            cmd = command_type.split()
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ.copy()
            )
            for stdout_line in iter(process.stdout.readline, ""):
                yield stdout_line
            process.stdout.close()
            return_code = process.wait()
            if return_code:
                for stderr_line in process.stderr:
                    yield f"ERROR: {stderr_line.strip()}\n"
            process.stderr.close()

        return Response(generate(), mimetype='text/plain')

    elif yaml_content:
        temp_yaml_path = os.path.join(UPLOAD_FOLDER, 'temp_screenplay.yaml')
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)

        with open(temp_yaml_path, 'w') as temp_yaml_file:
            temp_yaml_file.write(yaml_content)

        def generate_yaml():
            cmd = ['dob', 'run', temp_yaml_path]
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ.copy()
            )
            for stdout_line in iter(process.stdout.readline, ""):
                yield stdout_line
            process.stdout.close()
            return_code = process.wait()
            if return_code:
                for stderr_line in process.stderr:
                    yield f"ERROR: {stderr_line.strip()}\n"
            process.stderr.close()

        return Response(generate_yaml(), mimetype='text/plain')


def initialize_db():
    """
    Initializes the SQLite database by creating required tables if they don't exist.
    """
    conn = sqlite3.connect(DB_FILE)
    cursor = conn.cursor()

    # Enable foreign key constraints
    cursor.execute("PRAGMA foreign_keys = ON;")

    # Create execution records table (✅ This was missing)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS execution_records (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        persona_id INTEGER NOT NULL,
        role TEXT NOT NULL,
        command TEXT NOT NULL,
        execution_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (persona_id) REFERENCES personas(id)
    )
    ''')

    conn.commit()
    conn.close()

#####################

def get_latest_commit(repo_url, branch="master"):
    """
    Get the latest commit hash from the remote repository for a specific branch using git.
    
    Args:
        repo_url (str): The URL of the Git repository.
        branch (str): The branch name (default is 'master').

    Returns:
        str: Latest commit hash or None if failed.
    """
    logging.info(f"Checking latest commit for repo: {repo_url}, branch: {branch}")
    try:
        command = ["git", "ls-remote", repo_url, branch]
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        latest_commit = result.stdout.split()[0]  # First field is the commit hash
        return latest_commit
    except Exception as e:
        logging.error(f"Failed to fetch latest commit using git: {e}")
        return None



def load_deployment_snapshot(snapshot_path):
    """
    Load an existing deployment snapshot.
    """
    try:
        with open(snapshot_path, "r") as file:
            return json.load(file)
    except FileNotFoundError:
        logging.error(f"Snapshot file {snapshot_path} not found!")
        return None
    except json.JSONDecodeError:
        logging.error(f"Error reading snapshot file {snapshot_path}. Invalid JSON.")
        return None

def save_deployment_snapshot(deployment_id, deployment_name, repo_url, latest_commit, timestamp, branch, notification_config, flags):
    """
    Save or update the deployment snapshot JSON file including notification flags.
    """
    os.makedirs(DEPLOYMENT_SNAPSHOT_DIR, exist_ok=True)
    snapshot_path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, f"{deployment_id}.json")

    snapshot_data = {
        "deployment_id": deployment_id,
        "deployment_name": deployment_name,
        "repo_url": repo_url,
        "branch": branch,
        "latest_commit": latest_commit,
        "timestamp": timestamp,
        "DEPLOYMENT_SUCCESS": flags.get("DEPLOYMENT_SUCCESS", True),
        "DEPLOYMENT_FAILURE": flags.get("DEPLOYMENT_FAILURE", True),
        "CONFIG_DRIFT": flags.get("CONFIG_DRIFT", True),
        "AUTO_SYNC": flags.get("AUTO_SYNC", True),
        "POD_HEALTH": flags.get("POD_HEALTH", True),
        "send_notification": notification_config,
        "snapshot": {
            "enabled": True,
            "repo_url": repo_url,
            "deployment_name": deployment_name,
            "branch": branch
        }
    }

    try:
        with open(snapshot_path, "w") as f:
            json.dump(snapshot_data, f, indent=4)
        print(f"📁 Snapshot saved: {snapshot_path}")
    except Exception as e:
        print(f"❌ ERROR saving snapshot: {e}")


def deploy_application_on_master(master_ip, deployment_name, repo_url, branch):
    """
    Deploy the latest application version by cloning the latest repo and applying Kubernetes manifests.

    Args:
        master_ip (str): The IP of the Kubernetes master node.
        deployment_name (str): The name of the deployment.
        repo_url (str): The Git repository URL.
        branch (str): The Git branch to clone.
    
    Returns:
        bool: True if deployment succeeded, False otherwise.
    """
    logging.info(f"🚀 Deploying application '{deployment_name}' on master node {master_ip} (branch: {branch})...")

    deployment_dir = f"/tmp/{deployment_name}"

    # ✅ 1. Clone or pull the latest repo with branch
    deploy_tasks = get_deployment_tasks(repo_url, deployment_name, branch=branch)

    if not execute_tasks(deploy_tasks, master_ip=master_ip):
        logging.error(f"❌ ERROR: Failed to clone or pull latest repository for '{deployment_name}'")
        return False

    # ✅ 2. Check if the deployment directory exists
    check_dir_command = f"test -d {deployment_dir} && echo 'Directory exists' || echo 'Missing'"
    success, message = execute_command_on_server(master_ip, "root", check_dir_command)

    if "Missing" in message:
        logging.error(f"❌ ERROR: Deployment directory '{deployment_dir}' not found on master node!")
        return False

    # ✅ 3. Apply Kubernetes manifests
    deploy_command = f"kubectl apply -f {deployment_dir} --recursive"
    success, message = execute_command_on_server(master_ip, "root", deploy_command)

    if success:
        logging.info(f"✅ Application '{deployment_name}' deployed successfully!")
        return True
    else:
        logging.error(f"❌ ERROR: Deployment failed: {message}")
        return False


def get_deployment_tasks(repo_url, deployment_name, branch="master"):
    """
    Define the deployment tasks to clone a specific branch of a repository on the Kubernetes master node.

    Args:
        repo_url (str): The Git repository URL provided by the user.
        deployment_name (str): The name of the deployment.
        branch (str): The branch to checkout.

    Returns:
        list: A list of task dictionaries for execution on the master node.
    """
    clone_dir = f"/tmp/{deployment_name}"

    return [
        {
            "name": "Ensure Temporary Directory Exists on Master",
            "command": f"mkdir -p {clone_dir} && chmod 777 {clone_dir}",
            "category": "dks-master"
        },
        {
            "name": "Clone Deployment Repository on Master",
            "command": (
                f"git clone --branch {branch} {repo_url} {clone_dir} "
                f"|| (cd {clone_dir} && git pull origin {branch})"
            ),
            "category": "dks-master"
        }
    ]

def get_dks_master_ip():
    try:
        with open(DKS_HOSTS_FILE, "r") as file:
            lines = file.readlines()

        master_ip = None
        is_master_section = False

        for line in lines:
            if line.strip() == "[dks-master]":
                is_master_section = True
                continue

            if is_master_section:
                parts = line.strip().split()
                if len(parts) >= 2:
                    master_ip = parts[0]
                    break

        if not master_ip:
            raise ValueError("Master IP not found in DKS hosts file.")

        return master_ip

    except Exception as e:
        raise RuntimeError(f"Failed to get master IP: {e}")

def execute_command_on_server(ip, user, command, timeout=None, real_time_output=False):

    import subprocess
    try:
        ssh_cmd = ["ssh", f"{user}@{ip}", f"{command}; echo ''"]
        result = subprocess.run(ssh_cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        stdout = result.stdout.decode().strip()
        stderr = result.stderr.decode().strip()

        if result.returncode == 0:
            return True, stdout
        else:
            return False, stderr or stdout

    except Exception as e:
        return False, str(e)

def execute_tasks(tasks, master_ip=None, secondary_master_ips=None, worker_ips=None, retries=3, retry_delay=15):
    """
    Execute a list of tasks on the specified host(s), with retry logic for transient failures.

    Args:
        tasks (list): List of task dictionaries to execute.
        master_ip (str): IP of the master node (optional).
        secondary_master_ips (list): List of secondary control plane node IPs (optional).
        worker_ips (list): List of worker node IPs (optional).
        retries (int): Number of retry attempts for each task.
        retry_delay (int): Delay in seconds between retries.
    """
    for task in tasks:
        task_name = task.get('name', 'Unnamed Task')
        action = task.get('action', 'RUN').upper()  # Default action is 'RUN'
        task_command = task.get('command', None)
        category = task.get('category', None)  # Auto-assigned as 'dks-master', 'dks-worker', or 'dks-secondary-master'
        timeout = task.get('timeout', 600)

        click.echo(click.style(f"Processing task: {task_name}", fg="yellow"))

        # Determine the target IPs based on the category
        if category == "dks-master" and master_ip:
            target_ips = [master_ip]
        elif category == "dks-worker" and worker_ips:
            target_ips = worker_ips
        else:
            click.echo(click.style(f"Task '{task_name}' has an invalid category or no matching targets. Skipping.", fg="red"))
            continue

        # Execute the task on all target IPs
        for target_ip in target_ips:
            for attempt in range(1, retries + 1):
                click.echo(f"Executing task '{task_name}' on '{category}' ({target_ip}), Attempt {attempt}/{retries}...")
                if action == 'RUN' and task_command:
                    success, message = execute_command_on_server(
                        target_ip,
                        "root",
                        task_command,
                        timeout=timeout,
                        real_time_output=True  # Stream logs in real time
                    )
                    if success:
                        click.echo(click.style(f"Task '{task_name}' executed successfully on '{target_ip}'.", fg="green"))
                        break  # Task succeeded; exit retry loop
                    else:
                        click.echo(click.style(f"Task '{task_name}' failed on '{target_ip}': {message}", fg="red"))
                        if attempt < retries:
                            click.echo(click.style(f"Retrying in {retry_delay} seconds...", fg="yellow"))
                            time.sleep(retry_delay)  # Wait before retrying
                        else:
                            click.echo(click.style(f"Task '{task_name}' failed after {retries} attempts. Halting further task execution.", fg="red"))
                            return False  # Halt on repeated failure
                else:
                    click.echo(click.style(f"Task '{task_name}' has no valid action or command. Skipping.", fg="red"))
                    break

    return True  # Return success if all tasks pass

@app.route("/status", methods=["GET"])
def check_status():
    """
    Check the status of all monitored repositories.
    """
    deployments = []
    for snapshot_file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
        snapshot_path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, snapshot_file)
        with open(snapshot_path, "r") as file:
            deployment_data = json.load(file)
            deployments.append(deployment_data)

    return jsonify({"deployments": deployments})

# Function to check and install Git if missing
def ensure_git_installed():
    """
    Check if Git is installed, and install it if not.
    """
    try:
        subprocess.run(["git", "--version"], check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        logging.info("✅ Git is already installed.")
        return True
    except FileNotFoundError:
        logging.warning("⚠️ Git is not installed. Attempting to install...")

    # Detect OS and install Git
    try:
        os_info = ""
        with open("/etc/os-release", "r") as f:
            os_info = f.read()

        if "Ubuntu" in os_info or "Debian" in os_info:
            logging.info("🔧 Detected Debian/Ubuntu system. Installing Git...")
            subprocess.run(["apt-get", "update"], check=True)
            subprocess.run(["apt-get", "install", "-y", "git"], check=True)

        elif "CentOS" in os_info or "Red Hat" in os_info or "Fedora" in os_info:
            logging.info("🔧 Detected RHEL-based system. Installing Git...")
            subprocess.run(["yum", "install", "-y", "git"], check=True)

        else:
            logging.error("❌ ERROR: Unsupported OS. Please install Git manually.")
            return False

        logging.info("✅ Git installed successfully.")
        return True

    except Exception as e:
        logging.error(f"❌ ERROR: Failed to install Git: {e}")
        return False

# Function to clone or update the Git repository
def clone_or_update_repo(repo_url, branch="master"):
    """
    Clone the repository if it does not exist, otherwise update it.
    """
    if not os.path.exists(CLONE_DIR):
        os.makedirs(CLONE_DIR, exist_ok=True)

    repo_name = repo_url.split("/")[-1].replace(".git", "")
    repo_path = os.path.join(CLONE_DIR, repo_name)

    if os.path.exists(repo_path):
        logging.info(f"🔄 Repository {repo_name} already exists. Pulling latest changes...")
        subprocess.run(["git", "-C", repo_path, "pull"], check=True)
    else:
        logging.info(f"📥 Cloning repository {repo_url}...")
        subprocess.run(["git", "clone", "-b", branch, repo_url, repo_path], check=True)

    return repo_path
def get_all_k8s_deployments(master_ip):
    """
    Fetch all Kubernetes deployments from the remote cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.

    Returns:
        list: A list of deployment names.
    """
    logging.info(f"📥 Fetching all Kubernetes deployments from {master_ip}...")

    fetch_command = "kubectl get deployments -o=jsonpath='{.items[*].metadata.name}'"
    success, message = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not message.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes deployments.")
        return []

    deployments = message.strip().split()
    logging.info(f"✅ Found deployments: {deployments}")

    return deployments


def get_k8s_manifest_from_repo(repo_path, deployment_name):
    """
    Find the correct Kubernetes manifest file from the repo.
    """
    for root, _, files in os.walk(repo_path):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                with open(os.path.join(root, file), "r") as f:
                    try:
                        content = yaml.safe_load(f)
                        if content.get("kind") == "Deployment" and content["metadata"]["name"] == deployment_name:
                            return content
                    except yaml.YAMLError as e:
                        logging.error(f"❌ ERROR: Invalid YAML in {file}: {e}")
    return None


def compare_k8s_configs(expected_config, current_config):
    """
    Compare expected (repo) Kubernetes config vs. live cluster config.
    """
    mismatches = []

    if expected_config["spec"]["replicas"] != current_config["spec"]["replicas"]:
        mismatches.append(f"❌ Replica count mismatch: Expected {expected_config['spec']['replicas']}, Found {current_config['spec']['replicas']}")

    expected_images = [c["image"] for c in expected_config["spec"]["template"]["spec"]["containers"]]
    current_images = [c["image"] for c in current_config["spec"]["template"]["spec"]["containers"]]

    if set(expected_images) != set(current_images):
        mismatches.append(f"❌ Image mismatch: Expected {expected_images}, Found {current_images}")

    return mismatches

def get_live_k8s_config(master_ip, deployment_name):
    """
    Fetch the current live Kubernetes deployment YAML config from the cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.
        deployment_name (str): The name of the deployment.

    Returns:
        dict: Parsed YAML of the Kubernetes deployment.
    """
    logging.info(f"📥 Fetching live Kubernetes config for {deployment_name} from {master_ip}...")

    fetch_command = f"kubectl get deployment {deployment_name} -o yaml"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error(f"❌ ERROR: Failed to fetch Kubernetes deployment state for {deployment_name}.")
        return None

    try:
        return yaml.safe_load(output)
    except yaml.YAMLError as e:
        logging.error(f"❌ ERROR: Failed to parse Kubernetes state YAML: {e}")
        return None


def load_deployment_snapshot_by_name(deployment_name):
    """
    Load a deployment snapshot by name.
    """
    for file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
        path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, file)
        snapshot = load_deployment_snapshot(path)
        if snapshot and snapshot.get("deployment_name") == deployment_name:
            return snapshot
    return None
            


# Notification Sender
def send_notification(subject, body, recipients, channels=["email"]):
    """
    Send notifications via configured channels (email, slack).

    Args:
        subject (str): Notification subject/title.
        body (str): Notification message.
        recipients (dict): Dictionary with 'notification_recipients' and 'notification_channels' keys.
        channels (list): Optional override of channels to send to (default: ["email"])
    """
    config = load_notification_config()
    if not config:
        logging.warning("⚠️ Notification config not found. Skipping notification.")
        return

    emails = recipients.get("notification_recipients", {}).get("email", [])
    user_channels = recipients.get("notification_channels", ["email"])

    # Use passed channels if not overridden
    channels = channels or user_channels

    logging.info(f"📣 Preparing to send notifications - Channels: {channels}, Recipients: {emails}")

    # ✅ Email
    if "email" in channels and config.get("email") and emails:
        email_config = config["email"]
        smtp_server = email_config.get("smtp_server")
        smtp_port = email_config.get("smtp_port")
        sender_email = email_config.get("sender_email")
        sender_password = email_config.get("sender_password")

        if smtp_server and smtp_port and sender_email and sender_password:
            msg = MIMEMultipart()
            msg["From"] = sender_email
            msg["To"] = ', '.join(emails)
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            try:
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls()
                    server.login(sender_email, sender_password)
                    server.sendmail(sender_email, emails, msg.as_string())
                logging.info("✅ Email notification sent.")
            except Exception as e:
                logging.error(f"❌ Failed to send email notification: {e}")
        else:
            logging.warning("⚠️ Incomplete email SMTP config. Skipping email notification.")
    else:
        logging.debug("📪 Email channel not used or no valid recipients.")

    # ✅ Slack
    if "slack" in channels and config.get("slack", {}).get("webhook_url"):
        slack_webhook = config["slack"]["webhook_url"]
        try:
            payload = {"text": f"*{subject}*\n{body}"}
            response = requests.post(slack_webhook, json=payload)
            if response.status_code == 200:
                logging.info("✅ Slack notification sent.")
            else:
                logging.error(f"❌ Slack notification failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"❌ Exception during Slack notification: {e}")
    else:
        logging.debug("💬 Slack channel not used or not configured.")

# Pod Health Checker
def check_pod_health_issues(pods_json):
    issues = []
    try:
        data = json.loads(pods_json)
        for item in data.get("items", []):
            namespace = item.get("metadata", {}).get("namespace", "default")
            pod_name = item.get("metadata", {}).get("name", "unknown")
            phase = item.get("status", {}).get("phase", "Unknown")
            container_statuses = item.get("status", {}).get("containerStatuses", [])

            if phase not in ["Running", "Succeeded"]:
                issues.append({"namespace": namespace, "pod": pod_name, "issue": f"Pod is in phase '{phase}'"})

            for cs in container_statuses:
                name = cs.get("name", "unknown")
                state = cs.get("state", {})
                if "waiting" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container waiting - {state['waiting'].get('reason')}: {state['waiting'].get('message')}"
                    })
                elif "terminated" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container terminated - {state['terminated'].get('reason')}: {state['terminated'].get('message')}"
                    })
    except Exception as e:
        issues.append({"namespace": "N/A", "pod": "N/A", "issue": f"Error parsing pod health: {e}"})
    return issues

def load_notification_config():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration file not found: {CONFIGS_FILE}. Please create it to enable notifications.", fg="red"))
        return None

    with open(CONFIGS_FILE, 'r') as file:
        config = yaml.safe_load(file)

    if not config:
        click.echo(click.style(f"Notification configuration file {CONFIGS_FILE} is empty or invalid. Please update it.", fg="red"))
        return None

    return config


def monitor_git_repositories():
    logger.info("🟢 monitor_git_repositories() function started!")
    broadcast_live_log("🟢 monitor_git_repositories() function started!\n")

    while True:
        try:
            logger.info("🔍 Checking repositories for new commits...")
            broadcast_live_log("🔍 Checking repositories for new commits...\n")

            if not os.path.exists(DEPLOYMENT_SNAPSHOT_DIR):
                msg = f"⚠️ Deployment snapshot directory {DEPLOYMENT_SNAPSHOT_DIR} does not exist."
                logger.warning(msg)
                broadcast_live_log(msg + "\n")
                time.sleep(CHECK_INTERVAL)
                continue

            for snapshot_file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
                snapshot_path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, snapshot_file)
                snapshot = load_deployment_snapshot(snapshot_path)

                if not snapshot:
                    msg = f"⚠️ Skipping {snapshot_file}: Could not load snapshot."
                    logger.warning(msg)
                    broadcast_live_log(msg + "\n")
                    continue

                deployment_id = snapshot.get("deployment_id", str(uuid.uuid4()))
                deployment_name = snapshot["deployment_name"]
                repo_url = snapshot["repo_url"]
                stored_commit = snapshot.get("latest_commit")
                branch = snapshot.get("branch", "master")

                msg = f"📂 Checking {deployment_name} on branch '{branch}'"
                logger.info(msg)
                broadcast_live_log(msg + "\n")

                latest_commit = get_latest_commit(repo_url, branch)
                if not latest_commit:
                    msg = f"❌ Could not fetch latest commit for {repo_url} (branch: {branch})"
                    logger.error(msg)
                    broadcast_live_log(msg + "\n")
                    continue

                if stored_commit != latest_commit:
                    msg = f"🚀 New commit detected on {deployment_name}@{branch}! Redeploying..."
                    logger.info(msg)
                    broadcast_live_log(msg + "\n")

                    master_ip = get_dks_master_ip()
                    if not master_ip:
                        msg = f"❌ Could not determine master IP for {deployment_name}"
                        logger.error(msg)
                        broadcast_live_log(msg + "\n")
                        continue

                    if deploy_application_on_master(master_ip, deployment_name, repo_url, branch=branch):
                        msg = f"✅ Successfully redeployed {deployment_name}!"
                        logger.info(msg)
                        broadcast_live_log(msg + "\n")

                        save_deployment_snapshot(
                            deployment_id,
                            deployment_name,
                            repo_url,
                            latest_commit,
                            datetime.utcnow().isoformat(),
                            branch,
                            snapshot.get("send_notification", {}),
                            {
                                "DEPLOYMENT_SUCCESS": snapshot.get("DEPLOYMENT_SUCCESS", True),
                                "DEPLOYMENT_FAILURE": snapshot.get("DEPLOYMENT_FAILURE", True),
                                "CONFIG_DRIFT": snapshot.get("CONFIG_DRIFT", True),
                                "AUTO_SYNC": snapshot.get("AUTO_SYNC", True),
                                "POD_HEALTH": snapshot.get("POD_HEALTH", True),
                            }
                        )
                    else:
                        msg = f"❌ ERROR: Deployment failed for {deployment_name}."
                        logger.error(msg)
                        broadcast_live_log(msg + "\n")
                else:
                    msg = f"✅ {deployment_name} is up-to-date."
                    logger.info(msg)
                    broadcast_live_log(msg + "\n")

            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            msg = f"❌ CRITICAL ERROR in monitor_git_repositories: {e}"
            logger.critical(msg)
            broadcast_live_log(msg + "\n")

def monitor_kubernetes_cluster():
    print("🔵 Robust Kubernetes config monitor started!", flush=True)

    while True:
        try:
            master_ip = get_dks_master_ip()
            if not master_ip:
                print("❌ No Kubernetes master IP found. Skipping check...", flush=True)
                time.sleep(CHECK_INTERVAL)
                continue

            print("🔍 Scanning deployments...", flush=True)
            deployments = get_all_k8s_deployments(master_ip)

            if not deployments:
                print("⚠️ No deployments found in cluster.", flush=True)
                time.sleep(CHECK_INTERVAL)
                continue

            for deployment_name in deployments:
                print(f"📂 Checking deployment: {deployment_name}", flush=True)

                live_config = get_live_k8s_config(master_ip, deployment_name)
                if not live_config:
                    print(f"❌ Failed to fetch live config for {deployment_name}", flush=True)
                    continue

                snapshot = load_deployment_snapshot_by_name(deployment_name)
                if not snapshot:
                    print(f"⚠️ No snapshot found for {deployment_name}", flush=True)
                    continue

                repo_url = snapshot["repo_url"]
                branch = snapshot.get("branch", "main")
                notification = snapshot.get("send_notification", {})

                repo_path = clone_or_update_repo(repo_url, branch=branch)
                expected_config = get_k8s_manifest_from_repo(repo_path, deployment_name)

                if not expected_config:
                    print(f"❌ Manifest for {deployment_name} not found in repo.", flush=True)
                    continue

                drift = detect_config_drift(expected_config, live_config, deployment_name)

                if drift:
                    print(f"🚨 Drift detected in {deployment_name}:\n{drift}", flush=True)

                    if snapshot.get("CONFIG_DRIFT") and notification.get("enabled"):
                        report_path = get_drift_report_path(deployment_name)
                        send_notification(
                            "Config Drift Detected",
                            f"Drift found in `{deployment_name}`.\n\nReport saved at:\n{report_path}",
                            notification
                        )

                    print("🔁 Re-syncing deployment from Git...", flush=True)
                    success = deploy_application_on_master(master_ip, deployment_name, repo_url, branch=branch)

                    if success:
                        print(f"✅ Deployment {deployment_name} successfully re-synced!", flush=True)
                        if snapshot.get("AUTO_SYNC") and notification.get("enabled"):
                            send_notification("Auto-sync Completed", f"{deployment_name} synced.", notification)
                        if snapshot.get("DEPLOYMENT_SUCCESS") and notification.get("enabled"):
                            send_notification("Deployment Successful", f"{deployment_name} synced.", notification)
                    else:
                        print(f"❌ Deployment sync failed for {deployment_name}", flush=True)
                        if snapshot.get("DEPLOYMENT_FAILURE") and notification.get("enabled"):
                            send_notification("Deployment Failed", f"{deployment_name} sync failed.", notification)
                else:
                    print(f"✅ {deployment_name} is fully in sync.", flush=True)

                # ✅ POD HEALTH CHECK
                if snapshot.get("POD_HEALTH") and notification.get("enabled"):
                    pod_json = get_k8s_pod_json(master_ip)
                    issues = check_pod_health_issues(pod_json)
                    if issues:
                        issue_text = "\n".join([f"[{i['namespace']}] {i['pod']} - {i['issue']}" for i in issues])
                        print(f"🚨 Pod issues found in {deployment_name}", flush=True)
                        send_notification("Pod Health Alert", issue_text, notification)
                    else:
                        print("✅ All pods are healthy.", flush=True)

            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            print(f"❌ CRITICAL ERROR in monitor_kubernetes_cluster: {e}", flush=True)


def detect_config_drift(expected_config, live_config, deployment_name=None):
    def strip_auto_fields(config):
        config = copy.deepcopy(config)
        for field in ["status"]:
            config.pop(field, None)
        if "metadata" in config:
            for meta_field in [
                "creationTimestamp", "resourceVersion", "selfLink",
                "uid", "annotations", "managedFields", "generation"
            ]:
                config["metadata"].pop(meta_field, None)
        return config

    expected = strip_auto_fields(expected_config)
    live = strip_auto_fields(live_config)

    diff = DeepDiff(expected, live, ignore_order=True)
    if not diff:
        return None

    # ✅ Fixed: use datetime.now() because it's already imported correctly
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    markdown_lines = [
        f"# 📦 Drift Report for `{deployment_name}`",
        f"**Timestamp**: `{timestamp}`",
        "",
        "```diff"
    ]
    for line in diff.pretty().splitlines():
        prefix = "-"
        if "dictionary_item_added" in line:
            prefix = "+"
        elif "dictionary_item_removed" in line:
            prefix = "-"
        markdown_lines.append(f"{prefix} {line}")
    markdown_lines.append("```")

    report_md = "\n".join(markdown_lines)

    # ✅ Fixed: use datetime.now() instead of datetime.datetime.now()
    if deployment_name:
        filename = f"{deployment_name.replace('/', '_')}_{datetime.now().strftime('%Y%m%d%H%M%S')}.md"
        report_path = os.path.join(DRIFT_REPORT_DIR, filename)
        with open(report_path, "w") as f:
            f.write(report_md)
        print(f"📁 Drift report saved: {report_path}", flush=True)

    return report_md

def get_drift_report_path(deployment_name):
    for file in sorted(os.listdir(DRIFT_REPORT_DIR), reverse=True):
        if file.startswith(deployment_name.replace('/', '_')):
            return os.path.join(DRIFT_REPORT_DIR, file)
    return "Report not found"


def collect_dks_live_data():
    master_ip = get_dks_master_ip()
    if not master_ip:
        return {"error": "Master IP not found"}

    data = {}

    # Pods
    success, pod_json = execute_command_on_server(master_ip, "root", "kubectl get pods --all-namespaces -o json")
    if success:
        import json
        parsed = json.loads(pod_json)
        pods = []
        for item in parsed.get("items", []):
            metadata = item.get("metadata", {})
            status = item.get("status", {})
            pod_info = {
                "name": metadata.get("name"),
                "namespace": metadata.get("namespace"),
                "status": status.get("phase"),
                "restarts": sum(c.get("restartCount", 0) for c in status.get("containerStatuses", [])),
                "age": calculate_age(metadata.get("creationTimestamp")),
            }
            pods.append(pod_info)
        data["pods"] = pods

    # ReplicaSets
    success, rs_json = execute_command_on_server(master_ip, "root", "kubectl get rs -o json")
    if success:
        import json
        parsed = json.loads(rs_json)
        rs_list = []
        for item in parsed.get("items", []):
            rs_list.append({
                "name": item["metadata"]["name"],
                "replicas": item["spec"].get("replicas", 0),
                "ready": item["status"].get("readyReplicas", 0),
            })
        data["replicaSets"] = rs_list

    # StatefulSets
    success, sts_json = execute_command_on_server(master_ip, "root", "kubectl get statefulsets -o json")
    if success:
        parsed = json.loads(sts_json)
        sts_list = []
        for item in parsed.get("items", []):
            sts_list.append({
                "name": item["metadata"]["name"],
                "replicas": item["spec"].get("replicas", 0),
                "ready": item["status"].get("readyReplicas", 0),
            })
        data["statefulSets"] = sts_list

    # DaemonSets
    success, ds_json = execute_command_on_server(master_ip, "root", "kubectl get daemonsets -o json")
    if success:
        parsed = json.loads(ds_json)
        ds_list = []
        for item in parsed.get("items", []):
            ds_list.append({
                "name": item["metadata"]["name"],
                "desired": item["status"].get("desiredNumberScheduled", 0),
                "ready": item["status"].get("numberReady", 0),
            })
        data["daemonSets"] = ds_list

    # Services
    success, svc_json = execute_command_on_server(master_ip, "root", "kubectl get svc -o json")
    if success:
        parsed = json.loads(svc_json)
        svc_list = []
        for item in parsed.get("items", []):
            ports = item["spec"].get("ports", [])
            port_str = ", ".join([f"{p.get('port')}:{p.get('nodePort', '')}" for p in ports])
            svc_list.append({
                "name": item["metadata"]["name"],
                "type": item["spec"].get("type"),
                "clusterIP": item["spec"].get("clusterIP"),
                "port": port_str
            })
        data["services"] = svc_list

    # Cluster status (dummy logic for now, can be enhanced)
    data["clusterStatus"] = "Healthy" if data.get("pods") else "Unknown"

    return data

def calculate_age(creation_timestamp):
    from datetime import datetime, timezone
    try:
        created = datetime.fromisoformat(creation_timestamp.replace("Z", "+00:00"))
        delta = datetime.now(timezone.utc) - created
        minutes = int(delta.total_seconds() / 60)
        if minutes < 60:
            return f"{minutes}m"
        hours = minutes // 60
        return f"{hours}h"
    except:
        return "N/A"

def get_pod_logs(pod_name, namespace="default", lines=100):
    """
    Fetch recent logs from a specific Kubernetes pod.
    """
    master_ip = get_dks_master_ip()
    if not master_ip:
        return "❌ Master IP not found"

    command = f"kubectl logs --tail={lines} -n {namespace} {pod_name}"
    success, output = execute_command_on_server(master_ip, "root", command)

    if not success:
        return f"❌ Failed to fetch logs for pod {pod_name}"
    
    return output

def execute_kubectl_command(command: str):
    """
    Executes a raw kubectl command on the DKS master node and returns the output.
    """

    if not command.startswith("kubectl "):
        command = "kubectl " + command

    master_ip = get_dks_master_ip()
    if not master_ip:
        return "❌ Could not resolve DKS master IP"

    success, output = execute_command_on_server(master_ip, "root", command)

    if not success:
        return f"❌ Command failed:\n{output}"

    return output

def collect_k8s_node_details():
    """
    Collect full Kubernetes node and control plane details.
    Returns a dictionary with structured node and control plane information.
    """
    master_ip = get_dks_master_ip()
    if not master_ip:
        return {"error": "Master IP not found"}

    data = {}

    # Nodes
    success, nodes_json = execute_command_on_server(master_ip, "root", "kubectl get nodes -o json")
    if success:
        parsed = json.loads(nodes_json)
        nodes = []
        for item in parsed.get("items", []):
            metadata = item.get("metadata", {})
            status = item.get("status", {})
            conditions = status.get("conditions", [])
            node_info = {
                "name": metadata.get("name"),
                "status": next((c["type"] for c in conditions if c["status"] == "True"), "Unknown"),
                "roles": metadata.get("labels", {}).get("kubernetes.io/role", "worker"),
                "os": status.get("nodeInfo", {}).get("operatingSystem", "unknown"),
                "kernel": status.get("nodeInfo", {}).get("kernelVersion", "unknown"),
                "containerRuntime": status.get("nodeInfo", {}).get("containerRuntimeVersion", "unknown"),
                "kubeletVersion": status.get("nodeInfo", {}).get("kubeletVersion", "unknown"),
                "cpu": status.get("capacity", {}).get("cpu", "?"),
                "memory": status.get("capacity", {}).get("memory", "?"),
                "internalIP": next((a["address"] for a in status.get("addresses", []) if a["type"] == "InternalIP"), "N/A")
            }
            nodes.append(node_info)
        data["nodes"] = nodes

    # Control Plane
    success, cp_json = execute_command_on_server(master_ip, "root", "kubectl get componentstatuses -o json")
    if success:
        parsed = json.loads(cp_json)
        components = []
        for item in parsed.get("items", []):
            components.append({
                "name": item.get("metadata", {}).get("name"),
                "status": item.get("conditions", [{}])[0].get("type", "Unknown"),
                "message": item.get("conditions", [{}])[0].get("message", "")
            })
        data["controlPlane"] = components

    return data

def collect_remote_instances():
    """
    Fetches data from each remote instance, including system resource usage and any running applications.
    """
    if not os.path.exists(HOST_FILE):
        return {"error": "Host file not found"}

    instances = []
    current_category = "default"

    with open(HOST_FILE, "r") as f:
        for line in f:
            line = line.strip()

            if not line or line.startswith("#"):
                continue

            if line.startswith("[") and line.endswith("]"):
                current_category = line[1:-1]
                continue

            parts = line.split()
            if len(parts) >= 2:
                ip, name = parts[0], parts[1]

                sysinfo = {
                    "cpu_model": "N/A",
                    "cpu_load": "N/A",
                    "mem_total": "N/A",
                    "mem_used": "N/A",
                    "mem_percent": "N/A",
                    "disk_total": "N/A",
                    "disk_used": "N/A",
                    "disk_percent": "N/A",
                    "uptime": "N/A",
                    "applications": []  # List to hold application details
                }

                try:
                    cmd = (
                        "uptime && "
                        "free -m && "
                        "df -h / | tail -1 && "
                        "lscpu | grep 'Model name' && "
                        "ps aux"  # Adding the ps aux command to get running processes
                    )
                    success, output = execute_command_on_server(ip, "root", cmd)

                    if success and output:
                        lines = output.strip().splitlines()

                        # Uptime & CPU Load
                        if len(lines) >= 1:
                            uptime_line = lines[0]
                            sysinfo["uptime"] = uptime_line.split(" up ")[-1].split(",")[0]
                            load_part = uptime_line.split("load average:")[-1].strip().split(",")[0]
                            sysinfo["cpu_load"] = float(load_part)

                        # Memory
                        for line in lines:
                            if line.startswith("Mem:") or line.startswith("Mem "):
                                parts = line.split()
                                if len(parts) >= 3:
                                    total = int(parts[1])
                                    used = int(parts[2])
                                    sysinfo["mem_total"] = f"{total} MB"
                                    sysinfo["mem_used"] = f"{used} MB"
                                    percent = round((used / total) * 100, 2)
                                    sysinfo["mem_percent"] = f"{percent}%"

                        # Disk
                        for line in lines:
                            if line.startswith("/"):
                                parts = line.split()
                                if len(parts) >= 5:
                                    sysinfo["disk_total"] = parts[1]
                                    sysinfo["disk_used"] = parts[2]
                                    sysinfo["disk_percent"] = parts[4]

                        # CPU Model
                        for line in lines:
                            if "Model name" in line:
                                sysinfo["cpu_model"] = line.split(":")[1].strip()
                                break

                        # Check for applications (e.g., nginx)
                        application_data = get_running_applications(lines)
                        sysinfo["applications"] = application_data

                except Exception as e:
                    success = False
                    sysinfo["error"] = str(e)

                instances.append({
                    "ip": ip,
                    "name": name,
                    "category": current_category,
                    "status": "up" if success else "down",
                    "details": sysinfo
                })

    return {"instances": instances}

def get_running_applications(processes_output):
    """
    Identifies running applications (e.g., nginx, apache) and retrieves basic details.
    """
    application_data = []
    
    # Example: Check for nginx processes
    for line in processes_output:
        if "nginx" in line:
            parts = line.split()
            pid = parts[1]
            app_info = {
                "name": "nginx",
                "pid": pid,
                "cpu_usage": get_process_cpu_usage(pid),
                "memory_usage": get_process_memory_usage(pid),
                "network_traffic": get_process_network_traffic(pid),
                "uptime": get_process_uptime(pid)
            }
            application_data.append(app_info)

    # You can extend this to check for other applications (e.g., apache, mysql)
    return application_data

def get_process_cpu_usage(pid):
    """Fetches the CPU usage of a process by PID."""
    process = psutil.Process(int(pid))
    return process.cpu_percent(interval=1)

def get_process_memory_usage(pid):
    """Fetches the memory usage of a process by PID."""
    process = psutil.Process(int(pid))
    return process.memory_info().rss / 1024 / 1024  # Memory in MB

def get_process_network_traffic(pid):
    """Fetches the network traffic for a process by PID."""
    process = psutil.Process(int(pid))
    net_io = process.net_io_counters()
    return {
        "bytes_sent": net_io.bytes_sent,
        "bytes_recv": net_io.bytes_recv
    }

def get_process_uptime(pid):
    """Fetches the uptime of a process by PID."""
    process = psutil.Process(int(pid))
    return process.create_time()  # Return the start time of the process

def collect_application_data():
    master_ip = get_dks_master_ip()
    if not master_ip:
        return {"error": "Kubernetes master IP not found"}

    # Fetching pod data from the Kubernetes cluster
    success, output = execute_command_on_server(master_ip, "root", "kubectl get pods -A -o json")
    if not success:
        return {"error": "Failed to retrieve pods from master"}

    pod_json = json.loads(output)
    applications = []

    for item in pod_json.get("items", []):
        metadata = item.get("metadata", {})
        spec = item.get("spec", {})
        status = item.get("status", {})
        namespace = metadata.get("namespace")
        pod_name = metadata.get("name")
        labels = metadata.get("labels", {})
        containers = spec.get("containers", [])
        container_statuses = status.get("containerStatuses", [])
        start_time = status.get("startTime")

        for i, container in enumerate(containers):
            container_status = container_statuses[i] if i < len(container_statuses) else {}
            state = container_status.get("state", {})
            running = state.get("running")
            waiting = state.get("waiting")
            terminated = state.get("terminated")

            uptime_minutes = None
            if start_time:
                try:
                    dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    uptime_minutes = round((datetime.now(timezone.utc) - dt).total_seconds() / 60, 2)
                except:
                    uptime_minutes = None

            # Collect additional resource usage information
            cpu_usage = get_container_cpu_usage(pod_name, container.get("name"))
            memory_usage = get_container_memory_usage(pod_name, container.get("name"))
            disk_usage = get_container_disk_usage(pod_name, container.get("name"))
            network_usage = get_container_network_usage(pod_name, container.get("name"))

            # Container health check information
            health_status = get_container_health_status(pod_name, container.get("name"))

            # Gather process list (if possible)
            processes_info = get_container_process_info(pod_name, container.get("name"))

            app_info = {
                "namespace": namespace,
                "pod_name": pod_name,
                "container_name": container.get("name"),
                "image": container.get("image"),
                "app_name": labels.get("app") or labels.get("app.kubernetes.io/name", "unknown"),
                "state": "Running" if running else "Waiting" if waiting else "Terminated",
                "uptime_minutes": uptime_minutes,
                "restarts": container_status.get("restartCount", 0),
                "exit_code": terminated.get("exitCode") if terminated else None,
                "cpu_usage": cpu_usage,
                "memory_usage": memory_usage,
                "disk_usage": disk_usage,
                "network_usage": network_usage,
                "health_status": health_status,
                "processes_info": processes_info,  # Add process-related information
                "cpu_limit": container.get("resources", {}).get("limits", {}).get("cpu"),
                "memory_limit": container.get("resources", {}).get("limits", {}).get("memory"),
                "cpu_request": container.get("resources", {}).get("requests", {}).get("cpu"),
                "memory_request": container.get("resources", {}).get("requests", {}).get("memory"),
                "service_account": spec.get("serviceAccountName"),
                "volumes": [v.get("name") for v in spec.get("volumes", [])],
                "ports": [p.get("containerPort") for p in container.get("ports", [])] if container.get("ports") else [],
                "env_secrets": [
                    e["valueFrom"]["secretKeyRef"]["name"]
                    for e in container.get("env", [])
                    if e.get("valueFrom") and e["valueFrom"].get("secretKeyRef")
                ],
                "env_configmaps": [
                    e["valueFrom"]["configMapKeyRef"]["name"]
                    for e in container.get("env", [])
                    if e.get("valueFrom") and e["valueFrom"].get("configMapKeyRef")
                ]
            }

            applications.append(app_info)

    return {"applications": applications}

# Example function for getting CPU usage
def get_container_cpu_usage(pod_name, container_name):
    # You can use `kubectl` to fetch real-time stats, or other ways to fetch CPU usage
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    # Parse CPU usage from the output (this is just an example)
    return parse_cpu_usage(output)

def get_container_memory_usage(pod_name, container_name):
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    # Parse memory usage from the output
    return parse_memory_usage(output)

def get_container_disk_usage(pod_name, container_name):
    # Logic to get disk usage, possibly using `df` or container-specific metrics
    return None

def get_container_network_usage(pod_name, container_name):
    # Logic to get network usage, using `kubectl` or container metrics
    return None

def get_container_health_status(pod_name, container_name):
    # Logic to get the health check status, possibly using kubectl get pod health
    return "Healthy"

def get_container_process_info(pod_name, container_name):
    # Logic to get process information, potentially by inspecting processes in the container
    return [{"pid": 1234, "cpu_usage": "0.5%", "memory_usage": "20MB"}]


def clone_or_update_repo(git_url, branch="main", token=None):
    if token:
        git_url = git_url.replace("https://", f"https://{token}@")

    repo_name = os.path.basename(git_url).replace(".git", "")
    repo_dir = os.path.join("/tmp/dks-repos", repo_name)
    os.makedirs("/tmp/dks-repos", exist_ok=True)

    if os.path.exists(repo_dir):
        cmd = f"cd {repo_dir} && git pull origin {branch}"
    else:
        cmd = f"git clone --branch {branch} {git_url} {repo_dir}"

    success, output = execute_command(cmd)
    if not success:
        raise Exception(f"Git clone failed: {output}")
    return repo_dir


def validate_manifest(manifest_path):
    return os.path.exists(manifest_path) and manifest_path.endswith(".yaml")


def post_rollout_health_check(master_ip):
    check_cmd = "kubectl get pods -A"
    return execute_command_on_server(master_ip, "root", check_cmd)


def diff_manifest(manifest_path):
    return execute_command_on_server(get_dks_master_ip(), "root", f"kubectl diff -f {manifest_path}")


def log_rollout_output(data):
    try:
        with open("/tmp/dks-rollout-status.json", "w") as f:
            json.dump(data, f)
    except Exception as e:
        logger.warning(f"⚠️ Failed to write rollout status: {e}")


def store_rollout_snapshot(snapshot):
    os.makedirs(DKS_SNAPSHOT_DIR, exist_ok=True)
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    filename = os.path.join(DKS_SNAPSHOT_DIR, f"snapshot-{timestamp}.json")
    with open(filename, "w") as f:
        json.dump(snapshot, f, indent=2)
    with open(LATEST_SNAPSHOT, "w") as f:
        json.dump(snapshot, f, indent=2)


def rollback_deployment(master_ip, manifest_path):
    rollback_cmd = f"kubectl rollout undo -f {manifest_path}"
    return execute_command_on_server(master_ip, "root", rollback_cmd)


def trigger_rollout(git_url, branch="main", token=None, manifest_path="deployment.yaml", max_retries=3):
    master_ip = get_dks_master_ip()
    if not master_ip:
        logger.error("❌ Master IP not found")
        return {"error": "Master IP not found"}, 500

    def retry_command(cmd, retries=3, delay=5):
        for attempt in range(1, retries + 1):
            logger.info(f"🔁 Executing command (Attempt {attempt}): {cmd}")
            success, output = execute_command_on_server(master_ip, "root", cmd)
            if success:
                return True, output
            logger.warning(f"❌ Attempt {attempt} failed. Retrying in {delay}s...")
            time.sleep(delay)
        return False, output

    try:
        logger.info("🚀 Starting rollout process")

        # Ensure Git is installed
        git_installed, _ = execute_command_on_server(master_ip, "root", "which git")
        if not git_installed:
            os_success, os_output = execute_command_on_server(master_ip, "root", "cat /etc/os-release")
            if not os_success:
                return {"error": "Unable to detect OS for Git installation"}, 500

            if "ubuntu" in os_output.lower() or "debian" in os_output.lower():
                install_cmd = "apt update && apt install -y git"
            elif any(x in os_output.lower() for x in ["centos", "rhel", "rocky"]):
                install_cmd = "yum install -y git"
            else:
                return {"error": "Unsupported OS for automatic Git installation"}, 500

            install_success, install_output = retry_command(install_cmd, retries=2)
            if not install_success:
                logger.error(f"❌ Git install failed: {install_output}")
                return {"error": "Failed to install Git", "details": install_output}, 500

        # Clone repo
        repo_path = clone_or_update_repo(git_url, branch=branch, token=token)
        manifest_full_path = os.path.join(repo_path, manifest_path)
        logger.info(f"📦 Manifest path resolved: {manifest_full_path}")

        if not validate_manifest(manifest_full_path):
            logger.error(f"❌ Invalid manifest: {manifest_full_path}")
            return {"error": f"Manifest file not found or invalid at {manifest_full_path}"}, 400

        # Diff check
        diff_success, diff_output = diff_manifest(manifest_full_path)
        logger.info(f"🔍 Diff output:\n{diff_output}")

        # Apply manifest
        apply_cmd = f"kubectl apply -f {manifest_full_path}"
        apply_success, apply_output = retry_command(apply_cmd, retries=max_retries)
        if not apply_success:
            logger.error(f"❌ Manifest apply failed:\n{apply_output}")
            return {"error": "Failed to apply manifest", "details": apply_output}, 500

        logger.info("✅ Manifest applied successfully")

        # Monitor rollout
        rollout_cmd = f"kubectl rollout status -f {manifest_full_path} --watch=true --timeout=60s"
        rollout_success, rollout_output = retry_command(rollout_cmd, retries=1)
        logger.info("📡 Rollout finished")

        # Health check
        health_success, health_output = post_rollout_health_check(master_ip)
        logger.info(f"🩺 Health Check Output:\n{health_output}")

        # Snapshot and logging
        status_payload = {
            "status": "success" if rollout_success else "failed",
            "apply_output": apply_output,
            "rollout_output": rollout_output,
            "health_check": health_output,
            "diff": diff_output,
            "repo": git_url,
            "branch": branch,
            "manifest": manifest_path,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }

        log_rollout_output(status_payload)
        store_rollout_snapshot(status_payload)
        send_notification("ROLL_OUT_COMPLETE", status_payload)

        # Optional rollback
        if not rollout_success:
            rollback_success, rollback_output = rollback_deployment(master_ip, manifest_full_path)
            logger.warning("🔙 Rollback triggered due to failed rollout")
            status_payload["rollback"] = rollback_output
            status_payload["status"] = "rolled_back" if rollback_success else "rollback_failed"

        return status_payload

    except Exception as e:
        logger.exception("💥 Unexpected error during rollout")
        return {"error": str(e)}, 500

def get_k8s_pod_json(master_ip):
    """
    Fetch all pods in JSON format from the Kubernetes cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.

    Returns:
        str: Raw JSON output of all pods.
    """
    fetch_command = "kubectl get pods --all-namespaces -o json"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes pod details.")
        return "{}"

    return output


# ======================= MAIN ============================



if __name__ == '__main__':
    initialize_db()
    monitor_kubernetes_cluster()
    logging.info("🚀 Starting DevOps Bot Backend...")
    socketio.run(app, debug=True)
