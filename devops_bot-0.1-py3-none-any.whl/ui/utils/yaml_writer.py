import os
import yaml
from pathlib import Path
from uuid import uuid4

BASE_DIR = Path(os.path.expanduser("~/.devops-bot"))
CONFIGS_DIR = BASE_DIR / "configs"
AI_CONFIGS_DIR = CONFIGS_DIR / "generated_configs"
AI_CONFIGS_DIR.mkdir(parents=True, exist_ok=True)

def write_ec2_config(memory):
    filename = f"ec2_{uuid4().hex[:8]}.yaml"
    filepath = AI_CONFIGS_DIR / filename

    config = {
        "version": "v1",
        "provider": "aws",
        "resources": {
            "ec2_instances": [
                {
                    "region": memory["region"],
                    "instance_type": memory["instance_type"],
                    "ami_id": memory["ami_id"],
                    "key_name": memory["key_name"],
                    "subnet_id": memory["subnet_id"],
                    "security_group": memory["security_group"],
                    "tags": memory.get("tags", [])
                }
            ]
        }
    }

    with open(filepath, "w") as f:
        yaml.dump(config, f)
    return filepath

def write_vpc_config(memory):
    filename = f"vpc_{uuid4().hex[:8]}.yaml"
    filepath = AI_CONFIGS_DIR / filename

    config = {
        "version": "v1",
        "provider": "aws",
        "resources": {
            "vpcs": [
                {
                    "name": memory["vpc_name"],
                    "cidr_block": memory["cidr_block"],
                    "region": memory["region"],
                    "tags": memory.get("tags", [])
                }
            ]
        }
    }

    with open(filepath, "w") as f:
        yaml.dump(config, f)
    return filepath

def write_subnet_config(memory):
    filename = f"subnet_{uuid4().hex[:8]}.yaml"
    filepath = AI_CONFIGS_DIR / filename

    config = {
        "version": "v1",
        "provider": "aws",
        "resources": {
            "subnets": [
                {
                    "cidr_block": memory["cidr_block"],
                    "availability_zone": memory["availability_zone"],
                    "vpc_id": memory["vpc_id"],
                    "region": memory["region"],
                    "auto_assign_public_ip": True,
                    "tags": memory.get("tags", [])
                }
            ]
        }
    }

    with open(filepath, "w") as f:
        yaml.dump(config, f)
    return filepath
