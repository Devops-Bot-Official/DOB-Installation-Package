
from flask import Flask, jsonify, request, send_file, Response, stream_with_context, Blueprint
import platform
import os
import time
import yaml
import socket
import paramiko 
import subprocess
import click
import shutil
import threading
import sys
import gzip
from datetime import datetime, timedelta
import jwt
import hashlib
import uuid
import glob
import logging
from functools import wraps
from flask_cors import CORS
from functools import wraps
from collections import defaultdict
from logging.handlers import RotatingFileHandler
from prometheus_client import Counter, Gauge, generate_latest, CollectorRegistry, CONTENT_TYPE_LATEST
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import rsa
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
from flask import Flask, request, jsonify, Response, stream_with_context
import json
import tempfile
from pathlib import Path
from queue import Queue
from starlette.requests import Request
import asyncio
from flask_cors import cross_origin
from ui.app import collect_remote_instances 
from ui.app import collect_application_data 
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, func
from sqlalchemy import Column, Integer, String, Text, Boolean, DateTime, Date, ForeignKey, func
from sqlalchemy.orm import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy import DateTime
from ui.agent_engine import process_conversation 

# ========== FLASK API ==========
app = Flask(__name__)
CORS(app)

# ========== CONFIG ==========
BASE_DIR = os.path.expanduser("~/.devops-bot")
CONFIGS_DIR = os.path.join(BASE_DIR, "configs")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
DKS_HOSTS_FILE =  os.path.join(CONFIGS_DIR, "dks_hosts")
ROLL_OUT_LOG = os.path.join(LOGS_DIR, "rollout.log")
SNAPSHOT_DIR = os.path.join(LOGS_DIR, "dks-snapshots")
DOBP_KEY_DIR = os.path.join(BASE_DIR, "dobp_key")
PRIVATE_KEY_PATH = os.path.join(DOBP_KEY_DIR, "private.pem")
PUBLIC_KEY_PATH = os.path.join(DOBP_KEY_DIR, "public.pem")
ARCHIVE_DIR = os.path.join(BASE_DIR, "log_archives")
DEPLOYMENT_SNAPSHOT_DIR = os.path.join(CONFIGS_DIR, "dks_deployment")
DKS_SNAPSHOT_DIR = "~/.devops-bot/dks_snapshots"
LATEST_SNAPSHOT = os.path.join(DKS_SNAPSHOT_DIR, "latest.json")
INFRACYCLE_DIR =  os.path.join(CONFIGS_DIR, "infracycle")
os.makedirs(SNAPSHOT_DIR, exist_ok=True)
os.makedirs(INFRACYCLE_DIR, exist_ok=True)
EXECUTION_LOG_FILE = os.path.join(INFRACYCLE_DIR, "executions.json")
INIFRASET_DIR = os.path.join(CONFIGS_DIR, "infraset")
os.makedirs(INIFRASET_DIR, exist_ok=True)
INIFRASET_LOG_FILE = os.path.join(INIFRASET_DIR, "executions.json")
HOST_FILE = os.path.expanduser("~/.devops-bot/hosts")
SCREENPLAY_DIR = os.path.join(CONFIGS_DIR, "screenplay")
os.makedirs(SCREENPLAY_DIR, exist_ok=True)
CURRENT_CLI_DIR = os.path.expanduser("~")  # Start in user's home directory
CLONE_DIR = "/tmp/k8s_monitoring_repo"
DB_URL = "postgresql://devopsbot:devopsbot@localhost:5432/devopsbot"


LIVE_STAGE_UPDATES = []

MAX_LOG_AGE_DAYS = 7
LOG_ROTATE_SIZE_MB = 5
LOG_RETENTION_DAYS = 30
LOG_FORMAT = "%Y-%m-%d %H:%M:%S"
CHECK_INTERVAL = 30 # Now checking every 5 seconds
GIT_CHECK_INTERVAL = 60

os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(ARCHIVE_DIR, exist_ok=True)
os.makedirs(DOBP_KEY_DIR, exist_ok=True)
os.makedirs(DEPLOYMENT_SNAPSHOT_DIR, exist_ok=True)
os.makedirs(DKS_SNAPSHOT_DIR, exist_ok=True)

agile_bp = Blueprint("agile", __name__)
scrum_bp = Blueprint("scrum", __name__)
kanban_bp = Blueprint("kanban", __name__)
def ensure_postgres_and_db():
    try:
        # Detect OS
        distro = ""
        try:
            with open('/etc/os-release') as f:
                for line in f:
                    if line.startswith('ID='):
                        distro = line.strip().split('=')[1].strip('"').lower()
                        break
        except Exception:
            pass

        print(f"🔍 Detected OS: {distro}")

        # Install PostgreSQL if missing
        if subprocess.run(["which", "psql"], capture_output=True).returncode != 0:
            print("📦 Installing PostgreSQL...")
            if "ubuntu" in distro or "debian" in distro:
                subprocess.run(["apt", "update"], check=True)
                subprocess.run(["apt", "install", "-y", "postgresql", "postgresql-contrib"], check=True)
            else:
                print(f"❌ Unsupported OS for auto-install: {distro}")
                return

        # Start PostgreSQL service
        print("🔄 Starting PostgreSQL service...")
        subprocess.run(["systemctl", "start", "postgresql"], check=False)

        # Ensure postgres user exists
        print("👤 Ensuring 'postgres' user exists...")
        subprocess.run("id -u postgres || adduser --disabled-password --gecos '' postgres", shell=True, check=False)

        # Create devopsbot database if missing
        db_check = subprocess.run(
            ["sudo", "-u", "postgres", "psql", "-tAc", "SELECT 1 FROM pg_database WHERE datname='devopsbot'"],
            capture_output=True, text=True
        )
        if db_check.stdout.strip() != "1":
            print("🛠 Creating 'devopsbot' database...")
            subprocess.run(["sudo", "-u", "postgres", "createdb", "devopsbot"], check=True)

        # Create user devopsbot if not exists
        print("👤 Ensuring 'devopsbot' user exists with privileges...")
        create_user_sql = """
        DO $$
        BEGIN
           IF NOT EXISTS (SELECT FROM pg_catalog.pg_roles WHERE rolname = 'devopsbot') THEN
              CREATE ROLE devopsbot LOGIN PASSWORD 'devopsbot';
           END IF;
        END
        $$;
        """
        grant_sql = "GRANT ALL PRIVILEGES ON DATABASE devopsbot TO devopsbot;"

        subprocess.run(["sudo", "-u", "postgres", "psql", "-c", create_user_sql], check=True)
        subprocess.run(["sudo", "-u", "postgres", "psql", "-c", grant_sql], check=True)

    except subprocess.CalledProcessError as e:
        print(f"❌ Error ensuring PostgreSQL database: {e}")
        exit(1)
# 🔃 Run setup before anything else
ensure_postgres_and_db()        

# ========== UTILS ==========
def log(msg):
    print(msg)
    with open(ROLL_OUT_LOG, "a") as f:
        f.write(f"{time.strftime('%Y-%m-%d %H:%M:%S')} | {msg}\n")

log_subscribers = []

def log_live_stream(line):
    log(line)
    for queue in log_subscribers:
        asyncio.create_task(queue.put(line))

# global variable that stores callbacks
live_log_listeners = []
def broadcast_live_log(message: str):
    for listener in live_log_listeners:
        listener.put(message)


def monitor_gitops():
    while True:
        try:
            broadcast_live_log("🔍 Checking Git repositories and K8s clusters...\n")

            # run GitOps
            monitor_git_repositories()
            monitor_kubernetes_cluster()


            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            broadcast_live_log(f"❌ CRITICAL ERROR: {str(e)}\n")


def execute_command_on_server(hostname, username, command, timeout=None, real_time_output=False):
    """
    Execute a command on a remote server via SSH or locally if the hostname is localhost.

    Args:
        hostname (str): The IP address or hostname of the server. Use 'localhost' for local execution.
        username (str): The username for remote execution.
        command (str): The command to execute.
        timeout (int, optional): Timeout for command execution.
        real_time_output (bool, optional): Whether to print real-time output.

    Returns:
        tuple: (bool, str) where bool indicates success, and str contains output or error message.
    """
    # Check if the hostname refers to the local machine
    if hostname in ["localhost", "127.0.0.1", socket.gethostname()]:
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout)
            if result.returncode == 0:
                return True, result.stdout.strip()
            else:
                return False, result.stderr.strip()
        except Exception as e:
            return False, str(e)

    # For remote execution, use SSH
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username)

        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)
        output, error = stdout.read().decode(), stderr.read().decode()

        exit_status = stdout.channel.recv_exit_status()
        client.close()

        return (True, output.strip()) if exit_status == 0 else (False, error.strip())

    except Exception as e:
        return False, str(e)

def get_dks_master_ip():
    try:
        with open(DKS_HOSTS_FILE, "r") as file:
            lines = file.readlines()

        master_ip = None
        is_master_section = False

        for line in lines:
            if line.strip() == "[dks-master]":
                is_master_section = True
                continue

            if is_master_section:
                parts = line.strip().split()
                if len(parts) >= 2:
                    master_ip = parts[0]
                    break

        if not master_ip:
            raise ValueError("Master IP not found in DKS hosts file.")

        return master_ip

    except Exception as e:
        raise RuntimeError(f"Failed to get master IP: {e}")

def execute_tasks(tasks, master_ip=None, secondary_master_ips=None, worker_ips=None, retries=3, retry_delay=15):
    """
    Execute a list of tasks on the specified host(s), with retry logic for transient failures.

    Args:
        tasks (list): List of task dictionaries to execute.
        master_ip (str): IP of the master node (optional).
        secondary_master_ips (list): List of secondary control plane node IPs (optional).
        worker_ips (list): List of worker node IPs (optional).
        retries (int): Number of retry attempts for each task.
        retry_delay (int): Delay in seconds between retries.
    """
    for task in tasks:
        task_name = task.get('name', 'Unnamed Task')
        action = task.get('action', 'RUN').upper()  # Default action is 'RUN'
        task_command = task.get('command', None)
        category = task.get('category', None)  # Auto-assigned as 'dks-master', 'dks-worker', or 'dks-secondary-master'
        timeout = task.get('timeout', 600)

        click.echo(click.style(f"Processing task: {task_name}", fg="yellow"))

        # Determine the target IPs based on the category
        if category == "dks-master" and master_ip:
            target_ips = [master_ip]
        elif category == "dks-worker" and worker_ips:
            target_ips = worker_ips
        else:
            click.echo(click.style(f"Task '{task_name}' has an invalid category or no matching targets. Skipping.", fg="red"))
            continue

        # Execute the task on all target IPs
        for target_ip in target_ips:
            for attempt in range(1, retries + 1):
                click.echo(f"Executing task '{task_name}' on '{category}' ({target_ip}), Attempt {attempt}/{retries}...")
                if action == 'RUN' and task_command:
                    success, message = execute_command_on_server(
                        target_ip,
                        "root",
                        task_command,
                        timeout=timeout,
                        real_time_output=True  # Stream logs in real time
                    )
                    if success:
                        click.echo(click.style(f"Task '{task_name}' executed successfully on '{target_ip}'.", fg="green"))
                        break  # Task succeeded; exit retry loop
                    else:
                        click.echo(click.style(f"Task '{task_name}' failed on '{target_ip}': {message}", fg="red"))
                        if attempt < retries:
                            click.echo(click.style(f"Retrying in {retry_delay} seconds...", fg="yellow"))
                            time.sleep(retry_delay)  # Wait before retrying
                        else:
                            click.echo(click.style(f"Task '{task_name}' failed after {retries} attempts. Halting further task execution.", fg="red"))
                            return False  # Halt on repeated failure
                else:
                    click.echo(click.style(f"Task '{task_name}' has no valid action or command. Skipping.", fg="red"))
                    break

    return True  # Return success if all tasks pass                       

def execute_command(command):
    try:
        import subprocess
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        return result.returncode == 0, result.stdout + result.stderr
    except Exception as e:
        return False, str(e)


def get_rollout_snapshots():
    return sorted(os.listdir(SNAPSHOT_DIR), reverse=True)

# Function to save the configuration file with a unique execution ID
def save_configuration_file(file):
    try:
        # Create a unique execution ID (UUID)
        execution_id = str(uuid.uuid4())
        file_name = f"{execution_id}.yaml"
        file_path = os.path.join(INFRACYCLE_DIR, file_name)

        # Save the file with the generated name
        file.save(file_path)

        # Take a snapshot of the configuration (you could also add logic to save metadata)
        snapshot = {
            "execution_id": execution_id,
            "file_path": file_path,
            "file_name": file_name
        }

        # Save the snapshot or log for reference (optional)
        # Example: Save to a database or log file if needed

        return execution_id, file_path
    except Exception as e:
        return None, str(e)

# Stream generator for live CLI output
def execute_infracyle_command(file_path):
    command = f"dob infracycle apply --file-path {file_path}"
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)

    for line in iter(process.stdout.readline, ''):
        yield f"data: {line.rstrip()}\n\n"  # SSE format

    process.stdout.close()
    process.wait()
    yield f"data: ✅ Execution complete.\n\n"


# 📌 Log executions
def log_screenplay_snapshot(execution_id, file_path):
    snapshot = {
        "execution_id": execution_id,
        "file_name": os.path.basename(file_path),
        "file_path": file_path,
        "created_at": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    }
    log_file = os.path.join(SCREENPLAY_DIR, "executions.json")
    try:
        entries = []
        if os.path.exists(log_file):
            with open(log_file, "r") as f:
                entries = json.load(f)
        entries.append(snapshot)
        with open(log_file, "w") as f:
            json.dump(entries, f, indent=2)
    except Exception as e:
        print(f"[❌] Failed to log screenplay execution: {e}")


def log_infraset_execution(execution_id, file_path):
    snapshot = {
        "execution_id": execution_id,
        "file_name": os.path.basename(file_path),
        "file_path": file_path,
        "timestamp": datetime.utcnow().isoformat()
    }
    try:
        if os.path.exists(INIFRASET_LOG_FILE):
            with open(INIFRASET_LOG_FILE, "r") as f:
                logs = json.load(f)
        else:
            logs = []
        logs.append(snapshot)
        with open(INIFRASET_LOG_FILE, "w") as f:
            json.dump(logs, f, indent=2)
    except Exception as e:
        print(f"[❌] Failed to log infraset execution: {e}")


def log_execution_snapshot(execution_id, file_path):
    os.makedirs(INFRACYCLE_DIR, exist_ok=True)
    snapshot = {
        "execution_id": execution_id,
        "file_name": os.path.basename(file_path),
        "file_path": file_path,
        "timestamp": datetime.utcnow().isoformat()
    }
    try:
        if os.path.exists(EXECUTION_LOG_FILE):
            with open(EXECUTION_LOG_FILE, 'r') as f:
                logs = json.load(f)
        else:
            logs = []

        logs.append(snapshot)
        with open(EXECUTION_LOG_FILE, 'w') as f:
            json.dump(logs, f, indent=2)

    except Exception as e:
        print(f"[❌] Failed to log execution: {e}")

# ===================== HELPERS ============================
def get_log_files():
    return glob.glob(os.path.join(LOGS_DIR, "*.log"))

def hash_line(line):
    return hashlib.md5(line.strip().encode()).hexdigest()

def load_deployment_snapshot(path):
    try:
        with open(path, "r") as file:
            return json.load(file)
    except Exception:
        return None

def load_deployment_snapshot_by_name(name):
    for file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
        snap = load_deployment_snapshot(os.path.join(DEPLOYMENT_SNAPSHOT_DIR, file))
        if snap and snap.get("deployment_name") == name:
            return snap
    return None

# ======================= RSA KEY ==========================
def generate_keys_if_missing():
    if not os.path.exists(DOBP_KEY_DIR):
        os.makedirs(DOBP_KEY_DIR)

    if not os.path.exists(PRIVATE_KEY_PATH) or not os.path.exists(PUBLIC_KEY_PATH):
        log("🔐 Keys not found. Generating RSA key pair...")
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048, backend=default_backend())
        with open(PRIVATE_KEY_PATH, "wb") as f:
            f.write(private_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            ))
        public_key = private_key.public_key()
        with open(PUBLIC_KEY_PATH, "wb") as f:
            f.write(public_key.public_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PublicFormat.SubjectPublicKeyInfo
            ))
        log("✅ RSA key pair generated.")
    else:
        log("🔑 RSA keys already exist.")

generate_keys_if_missing()

# ====================== MAINTENANCE =======================
def remove_duplicate_lines():
    for log_file in get_log_files():
        seen = set()
        temp_file = log_file + ".tmp"
        with open(log_file, "r") as infile, open(temp_file, "w") as outfile:
            for line in infile:
                h = hash_line(line)
                if h not in seen:
                    seen.add(h)
                    outfile.write(line)
        shutil.move(temp_file, log_file)

def rotate_large_logs():
    for log_file in get_log_files():
        size_mb = os.path.getsize(log_file) / (1024 * 1024)
        if size_mb > LOG_ROTATE_SIZE_MB:
            archive_name = os.path.join(
                ARCHIVE_DIR,
                f"{os.path.basename(log_file)}.{datetime.now().strftime('%Y%m%d%H%M%S')}.gz"
            )
            with open(log_file, 'rb') as f_in, gzip.open(archive_name, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
            open(log_file, 'w').close()

def delete_old_logs():
    cutoff = datetime.now() - timedelta(days=LOG_RETENTION_DAYS)
    for archived in glob.glob(os.path.join(ARCHIVE_DIR, "*.gz")):
        if datetime.fromtimestamp(os.path.getmtime(archived)) < cutoff:
            os.remove(archived)

def scrub_sensitive_data():
    keywords = ["password", "token", "secret", "key"]
    for log_file in get_log_files():
        with open(log_file, "r") as f:
            lines = f.readlines()
        with open(log_file, "w") as f:
            for line in lines:
                if any(k in line.lower() for k in keywords):
                    line = "[REDACTED SENSITIVE DATA]\n"
                f.write(line)

# ===================== TOKEN SECURITY =====================
def load_private_key():
    with open(PRIVATE_KEY_PATH, "rb") as f:
        return serialization.load_pem_private_key(f.read(), password=None, backend=default_backend())

def load_public_key():
    with open(PUBLIC_KEY_PATH, "rb") as f:
        return serialization.load_pem_public_key(f.read(), backend=default_backend())

def validate_token(token):
    try:
        decoded = jwt.decode(token, load_public_key(), algorithms=["RS256"])
        return decoded
    except jwt.ExpiredSignatureError:
        return {"error": "Token expired"}
    except jwt.InvalidTokenError:
        return {"error": "Invalid token"}

def token_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if request.remote_addr == "127.0.0.1":
            return f(*args, **kwargs)
        token = request.headers.get("Authorization")
        if not token:
            return jsonify({"error": "Token missing"}), 401
        if token.startswith("Bearer "):
            token = token.split(" ")[1]
        result = validate_token(token)
        if isinstance(result, dict) and result.get("error"):
            return jsonify(result), 401
        return f(*args, **kwargs)
    return decorated

# ========== ROLLOUT STAGE ACTIONS ==========
def apply_manifest(path):
    master_ip = get_dks_master_ip()
    cmd = f"kubectl apply -f {path}"
    log(f"📦 Applying manifest: {path}")
    success, output = execute_command_on_server(master_ip, "root", cmd)
    log(output)
    return success

def canary_step(weight, pause):
    log(f"🧪 Canary Step: Set traffic weight to {weight}%")
    time.sleep(pause)
    log(f"⏸️ Paused for {pause} seconds")
    return True

def rollout_status(path):
    master_ip = get_dks_master_ip()
    cmd = f"kubectl rollout status -f {path} --timeout=60s"
    log(f"📈 Checking rollout status for {path}")
    success, output = execute_command_on_server(master_ip, "root", cmd)
    log(output)
    return success

def health_check():
    master_ip = get_dks_master_ip()
    cmd = "kubectl get pods -A"
    log("🩺 Performing cluster health check...")
    success, output = execute_command_on_server(master_ip, "root", cmd)
    log(output)
    return success

def notify(message):
    log(f"🔔 Notification: {message}")
    return True

def save_snapshot(data):
    timestamp = time.strftime("%Y%m%d-%H%M%S")
    path = os.path.join(SNAPSHOT_DIR, f"rollout-{timestamp}.json")
    with open(path, "w") as f:
        json.dump(data, f, indent=2)
    log(f"📸 Snapshot saved: {path}")

# ========== ROLLOUT MAIN EXECUTOR ==========
def copy_manifest_to_remote(config_text, remote_filename="rollout.yaml"):
    """
    Copies only the Kubernetes manifest portion of the config to the remote DKS server.
    The 'stages' section is stripped out before transfer.
    """
    try:
        # Parse YAML and remove 'stages'
        parsed_yaml = yaml.safe_load(config_text)
        manifest_only = dict(parsed_yaml)
        manifest_only.pop("stages", None)

        # Convert back to YAML
        manifest_yaml = yaml.dump(manifest_only)

        # Define remote target path
        remote_path = f"/tmp/{remote_filename}"
        master_ip = get_dks_master_ip()

        # Heredoc for remote file creation
        heredoc = f"cat <<'EOF' > {remote_path}\n{manifest_yaml}\nEOF"

        log(f"📤 Transferring manifest to {remote_path} on {master_ip}")
        success, output = execute_command_on_server(master_ip, "root", heredoc)

        if not success:
            return False, output

        return True, remote_path

    except Exception as e:
        return False, str(e)

def collect_k8s_node_details():
    """
    Collect full Kubernetes node and control plane details.
    Returns a dictionary with structured node and control plane information.
    """
    master_ip = get_dks_master_ip()
    if not master_ip:
        return {"error": "Master IP not found"}

    data = {}

    # Nodes
    success, nodes_json = execute_command_on_server(master_ip, "root", "kubectl get nodes -o json")
    if success:
        parsed = json.loads(nodes_json)
        nodes = []
        for item in parsed.get("items", []):
            metadata = item.get("metadata", {})
            status = item.get("status", {})
            conditions = status.get("conditions", [])
            node_info = {
                "name": metadata.get("name"),
                "status": next((c["type"] for c in conditions if c["status"] == "True"), "Unknown"),
                "roles": metadata.get("labels", {}).get("kubernetes.io/role", "worker"),
                "os": status.get("nodeInfo", {}).get("operatingSystem", "unknown"),
                "kernel": status.get("nodeInfo", {}).get("kernelVersion", "unknown"),
                "containerRuntime": status.get("nodeInfo", {}).get("containerRuntimeVersion", "unknown"),
                "kubeletVersion": status.get("nodeInfo", {}).get("kubeletVersion", "unknown"),
                "cpu": status.get("capacity", {}).get("cpu", "?"),
                "memory": status.get("capacity", {}).get("memory", "?"),
                "internalIP": next((a["address"] for a in status.get("addresses", []) if a["type"] == "InternalIP"), "N/A")
            }
            nodes.append(node_info)
        data["nodes"] = nodes

    # Control Plane
    success, cp_json = execute_command_on_server(master_ip, "root", "kubectl get componentstatuses -o json")
    if success:
        parsed = json.loads(cp_json)
        components = []
        for item in parsed.get("items", []):
            components.append({
                "name": item.get("metadata", {}).get("name"),
                "status": item.get("conditions", [{}])[0].get("type", "Unknown"),
                "message": item.get("conditions", [{}])[0].get("message", "")
            })
        data["controlPlane"] = components

    return data


def test_deploy(path):
    log(f"🧪 Deploying test manifest: {path}")

    # Apply test deployment
    success = apply_manifest(path)
    if not success:
        log("❌ Failed to apply test deployment")
        return False

    # Run health check
    log("🩺 Checking test deployment health...")
    healthy = health_check()
    if not healthy:
        log("❌ Test deployment failed health check")
        return False

    # Cleanup test
    log("🧹 Cleaning up test deployment...")
    delete_manifest(path)
    time.sleep(3)  # Optional pause to allow termination

    return True

def stream_rollout_from_config(config, manifest_path):
    try:
        stages = config.get("stages", [])
        completed_stages = []
        live_log_lines = []

        yield "🌀 Starting Rollout Execution\n"

        for stage in stages:
            name = stage.get("name")
            action = stage.get("action")
            args = stage.get("args", {})

            log_line = f"\n🚀 Stage: {name} | Action: {action}"
            yield log_line + "\n"
            live_log_lines.append(log_line)

            traffic_weight = args.get("weight", 0) if action == "canary_step" else 0

            visual = generate_rollout_log_view(
                current_stage=name,
                completed_stages=completed_stages,
                stages=stages,
                traffic_weight=traffic_weight,
                live_logs=live_log_lines,
                status="in_progress"
            )
            yield visual + "\n"

            if action == "apply_manifest":
                success = apply_manifest(args["path"])
            elif action == "canary_step":
                success = canary_step(args["weight"], args["pause"])
            elif action == "rollout_status":
                success = rollout_status(args["path"])
            elif action == "health_check":
                success = health_check()
            elif action == "notify":
                success = notify(args.get("message", ""))
            elif action == "cleanup":
                success = cleanup_deployment(args["name"])    

            elif action == "test_deploy":
                success = test_deploy(args["path"])
            else:
                yield f"❌ Unknown action: {action}\n"
                success = False

            if not success:
                yield f"❌ Stage '{name}' failed. Aborting rollout.\n"
                visual = generate_rollout_log_view(
                    current_stage=name,
                    completed_stages=completed_stages,
                    stages=stages,
                    traffic_weight=traffic_weight,
                    live_logs=live_log_lines,
                    status="failed"
                )
                yield visual + "\n"
                break

            completed_stages.append(name)

        else:
            yield "✅ Rollout completed successfully!\n"
            visual = generate_rollout_log_view(
                current_stage="",
                completed_stages=completed_stages,
                stages=stages,
                traffic_weight=100,
                live_logs=live_log_lines,
                status="complete"
            )
            yield visual + "\n"

    except Exception as e:
        yield f"�� Rollout failed: {str(e)}\n"

def cleanup_deployment(deployment_name):
    master_ip = get_dks_master_ip()
    cmd = f"kubectl delete deployment {deployment_name} -n default"
    log(f"🧹 Cleaning up old deployment: {deployment_name}")
    success, output = execute_command_on_server(master_ip, "root", cmd)
    log(output)
    return success

def generate_rollout_log_view(current_stage, completed_stages, stages, traffic_weight, live_logs, status="in_progress"):
    """
    CLI visual representation of rollout progress.
    """
    stage_lines = []
    for stage in stages:
        name = stage.get("name", "Unknown Stage")
        if name in completed_stages:
            marker = "[✓]"
        elif name == current_stage:
            marker = "[⏳]"
        else:
            marker = "[ ]"
        stage_lines.append(f"| {marker} {name.ljust(22)} |")

    # Calculate traffic weight
    new_weight = max(0, min(100, traffic_weight))
    old_weight = 100 - new_weight

    log = "\n"
    log += "+" + "-" * 50 + "+\n"
    log += "|             DKS Rollout Live View          |\n"
    log += "+" + "-" * 27 + "+" + "-" * 22 + "+\n"

    max_lines = max(len(stage_lines), 5)
    for i in range(max_lines):
        left = stage_lines[i] if i < len(stage_lines) else "| " + " " * 25 + " |"
        right = ""
        if i == 0:
            right = f" Old: {old_weight}%".ljust(22)
        elif i == 1:
            right = f" New: {new_weight}%".ljust(22)
        elif i == 2:
            right = " 🔁 Traffic Flow".ljust(22)
        log += left + right + "|\n"

    log += "+" + "-" * 27 + "+" + "-" * 22 + "+\n"
    log += "|          �� Live Logs (last 5 lines)        |\n"
    log += "+" + "-" * 50 + "+\n"

    for line in live_logs[-5:]:
        log += f"| {line.ljust(48)} |\n"

    log += "+" + "-" * 50 + "+\n"
    if status == "complete":
        log += "| ✅ Rollout Complete | 🔁 Retry | ⛔ Cancel        |\n"
    elif status == "failed":
        log += "| ❌ Rollout Failed   | 🔁 Retry | ⛔ Cancel        |\n"
    else:
        log += "| ⏳ Rollout In Progress...                     |\n"
    log += "+" + "-" * 50 + "+\n"

    return log    


# ===================== PROMETHEUS ========================
registry = CollectorRegistry()
log_entries_total = Counter("log_entries_total", "Total log entries", registry=registry)
duplicate_lines_removed_total = Counter("duplicate_lines_removed", "Duplicate log lines removed", registry=registry)
log_file_size_bytes = Gauge("log_file_size_bytes", "Size of log files", ["filename"], registry=registry)

def update_all_log_metrics():
    for path in get_log_files():
        try:
            name = os.path.basename(path)
            size = os.path.getsize(path)
            log_file_size_bytes.labels(filename=name).set(size)

            with open(path, "r") as f:
                lines = f.readlines()
                log_entries_total.inc(len(lines))
        except Exception as e:
            logger.warning(f"⚠️ Metrics error: {e}")

@app.route("/dks/rollout/stream", methods=["POST"])
def stream_rollout():
    data = request.get_json()

    if not data or "config" not in data:
        return jsonify({"error": "Missing rollout config"}), 400

    config_text = data["config"]
    parsed_config = yaml.safe_load(config_text)

    stages = parsed_config.get("stages", [])
    if not stages:
        return jsonify({"error": "No rollout stages defined in config"}), 400

    remote_filename = stages[0].get("args", {}).get("path", "rollout.yaml")
    success, remote_path = copy_manifest_to_remote(config_text, remote_filename)

    if not success:
        return jsonify({"error": f"Manifest transfer failed: {remote_path}"}), 500

    # Patch all path fields
    for stage in stages:
        if stage.get("args") and "path" in stage["args"]:
            stage["args"]["path"] = remote_path

    def generate():
        for line in stream_rollout_from_config(parsed_config, remote_path):
            yield f"data: {line.strip()}\n\n"
            time.sleep(0.5)  # Optional slow down for realism

    return Response(generate(), mimetype='text/event-stream')


@app.route("/dks/snapshots", methods=["GET"])
@token_required
def list_snapshots():
    try:
        snapshots = get_rollout_snapshots()
        return jsonify({"snapshots": snapshots})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/stream/rollout", methods=["GET"])
@token_required
def stream_rollout_logs():
    def generate():
        while not os.path.exists(ROLL_OUT_LOG):
            time.sleep(1)

        with open(ROLL_OUT_LOG, "r") as f:
            f.seek(0, os.SEEK_END)
            while True:
                line = f.readline()
                if line:
                    yield f"data: {line.rstrip()}\n\n"
                else:
                    time.sleep(0.5)
    return Response(stream_with_context(generate()), mimetype="text/event-stream")

@app.route("/dks/rollback", methods=["POST"])
@token_required
def rollback_from_snapshot():
    data = request.get_json()
    snapshot_file = data.get("snapshot")

    if not snapshot_file:
        return jsonify({"error": "Snapshot filename is required"}), 400

    snapshot_path = os.path.join(SNAPSHOT_DIR, snapshot_file)
    if not os.path.exists(snapshot_path):
        return jsonify({"error": f"Snapshot not found: {snapshot_file}"}), 404

    try:
        with open(snapshot_path, "r") as f:
            snapshot_data = json.load(f)

        master_ip = get_dks_master_ip()
        manifest_path = snapshot_data.get("manifest_path") or snapshot_data.get("manifest")

        if not manifest_path:
            return jsonify({"error": "Manifest path not found in snapshot"}), 400

        rollback_cmd = f"kubectl rollout undo -f {manifest_path}"
        success, output = execute_command_on_server(master_ip, "root", rollback_cmd)

        log(f"🔙 Rollback output: {output}")
        return jsonify({
            "status": "rolled_back" if success else "rollback_failed",
            "output": output
        })

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/gitops/stream", methods=["GET"])
def stream_gitops_logs():
    mode = request.args.get("mode", "live")

    if mode == "file":
        def generate_file():
            with open(GITOPS_LOG_PATH, "r") as f:
                for line in f:
                    yield f"data: {line.strip()}\n\n"
        return Response(stream_with_context(generate_file()), mimetype="text/event-stream")

    # Live stream
    q = Queue()
    live_log_listeners.append(q)

    def generate_live():
        try:
            while True:
                line = q.get()
                if line:
                    yield f"data: {line.strip()}\n\n"
        finally:
            if q in live_log_listeners:
                live_log_listeners.remove(q)

    return Response(stream_with_context(generate_live()), mimetype="text/event-stream")


@app.route("/test-log", methods=["GET"])
def test_log():
    broadcast_live_log("✅ Test message from /test-log\n")
    return "Message sent to live log"

@app.route("/stream-infracyle")
@token_required
def stream_infracyle():
    def generate():
        log_path = "/tmp/infra-{}.log".format(request.args.get("execution_id"))
        while True:
            if os.path.exists(log_path):
                with open(log_path, "r") as f:
                    for line in f:
                        yield f"data: {line.strip()}\n\n"
            time.sleep(1)

    return Response(generate(), mimetype='text/event-stream')

@app.route("/infra/executions", methods=["GET"])
@token_required
def list_infra_executions():
    try:
        entries = []
        for fname in os.listdir(INFRACYCLE_DIR):
            if fname.endswith(".yaml"):
                fpath = os.path.join(INFRACYCLE_DIR, fname)
                stat = os.stat(fpath)
                entries.append({
                    "execution_id": fname.replace(".yaml", ""),
                    "file_path": fpath,
                    "file_name": fname,
                    "created_at": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_ctime))
                })
        return jsonify(sorted(entries, key=lambda x: x['created_at'], reverse=True))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/infra/executions", methods=["DELETE"])
@token_required
def delete_infracyle_executions():
    try:
        data = request.get_json()
        execution_ids = data.get("execution_ids")

        if not execution_ids:
            return jsonify({"error": "Missing execution_ids"}), 400

        deleted = []
        for fname in os.listdir(INFRACYCLE_DIR):
            if fname.endswith(".yaml"):
                execution_id = fname.replace(".yaml", "")
                if execution_ids == "ALL" or execution_id in execution_ids:
                    os.remove(os.path.join(INFRACYCLE_DIR, fname))
                    deleted.append(execution_id)

        return jsonify({"deleted": deleted})

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/infra/stages", methods=["POST"])
@token_required
def get_infracyle_stages_from_config():
    try:
        data = request.get_json()
        yaml_config = data.get("yaml_config")
        if not yaml_config:
            return jsonify({"error": "Missing yaml_config"}), 400

        config = yaml.safe_load(yaml_config)
        jobs = config.get("jobs", [])
        return jsonify({"jobs": jobs})
    except Exception as e:
        print(f"[❌] Failed to parse YAML from FastAPI: {e}")
        return jsonify({"error": str(e)}), 500


@app.route("/infra/execution/<execution_id>", methods=["GET"])
@token_required
def get_execution_yaml(execution_id):
    try:
        target_file = os.path.join(INFRACYCLE_DIR, f"{execution_id}.yaml")
        print(f"[🔍] Looking for config: {target_file}")

        if not os.path.exists(target_file):
            return jsonify({"error": "Configuration not found"}), 404

        with open(target_file, "r") as f:
            content = f.read()
        return jsonify({"yaml_config": content})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/execute-infraset", methods=["POST"])
@token_required
def execute_infraset():
    try:
        data = request.get_json()
        yaml_config = data.get("yaml_config")
        if not yaml_config:
            return jsonify({"error": "Missing yaml_config"}), 400

        execution_id = str(uuid.uuid4())
        file_path = os.path.join(INIFRASET_DIR, f"{execution_id}.yaml")
        with open(file_path, "w") as f:
            f.write(yaml_config)

        log_infraset_execution(execution_id, file_path)

        command = f"dob infraset apply --file-path {file_path}"
        os.system(f"{command} > /tmp/infraset-{execution_id}.log 2>&1 &")

        return jsonify({"execution_id": execution_id})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/stream-infraset")
@token_required
def stream_infraset():
    def generate():
        log_path = f"/tmp/infraset-{request.args.get('execution_id')}.log"
        while True:
            if os.path.exists(log_path):
                with open(log_path, "r") as f:
                    for line in f:
                        yield f"data: {line.strip()}\n\n"
            time.sleep(1)
    return Response(generate(), mimetype="text/event-stream")

@app.route("/infraset/executions", methods=["GET"])
@token_required
def list_infraset_executions():
    try:
        entries = []
        for fname in os.listdir(INIFRASET_DIR):
            if fname.endswith(".yaml"):
                fpath = os.path.join(INIFRASET_DIR, fname)
                stat = os.stat(fpath)
                entries.append({
                    "execution_id": fname.replace(".yaml", ""),
                    "file_path": fpath,
                    "file_name": fname,
                    "created_at": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_ctime))
                })
        return jsonify(sorted(entries, key=lambda x: x['created_at'], reverse=True))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/infraset/execution/<execution_id>", methods=["GET"])
@token_required
def get_infraset_yaml(execution_id):
    try:
        path = os.path.join(INIFRASET_DIR, f"{execution_id}.yaml")
        if not os.path.exists(path):
            return jsonify({"error": "Config not found"}), 404
        with open(path, "r") as f:
            return jsonify({"yaml_config": f.read()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/remote/servers", methods=["GET"])
@token_required
def get_remote_server_status():
    try:
        data = collect_remote_instances()
        return jsonify(data)
    except Exception as e:
        logger.error(f"❌ Failed to collect remote server status: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/dks/applications", methods=["GET"])
@token_required
def get_dks_application_info():
    try:
        return jsonify(collect_application_data())
    except Exception as e:
        logger.error(f"❌ Failed to collect application monitoring data: {e}")
        return jsonify({"error": str(e)}), 500

def collect_application_data():
    master_ip = get_dks_master_ip()
    if not master_ip:
        return {"error": "Kubernetes master IP not found"}

    success, output = execute_command_on_server(master_ip, "root", "kubectl get pods -A -o json")
    if not success:
        return {"error": "Failed to retrieve pods from master"}

    pod_json = json.loads(output)
    applications = []

    for item in pod_json.get("items", []):
        metadata = item.get("metadata", {})
        spec = item.get("spec", {})
        status = item.get("status", {})
        namespace = metadata.get("namespace")
        pod_name = metadata.get("name")
        labels = metadata.get("labels", {})
        containers = spec.get("containers", [])
        container_statuses = status.get("containerStatuses", [])
        start_time = status.get("startTime")

        for i, container in enumerate(containers):
            container_status = container_statuses[i] if i < len(container_statuses) else {}
            state = container_status.get("state", {})
            running = state.get("running")
            waiting = state.get("waiting")
            terminated = state.get("terminated")

            uptime_minutes = None
            if start_time:
                try:
                    dt = datetime.strptime(start_time, "%Y-%m-%dT%H:%M:%SZ").replace(tzinfo=timezone.utc)
                    uptime_minutes = round((datetime.now(timezone.utc) - dt).total_seconds() / 60, 2)
                except:
                    uptime_minutes = None

            # ✅ Pass master_ip to all helpers
            cpu_usage = get_container_cpu_usage(pod_name, container.get("name"), master_ip)
            memory_usage = get_container_memory_usage(pod_name, container.get("name"), master_ip)
            disk_usage = get_container_disk_usage(pod_name, container.get("name"), master_ip)
            network_usage = get_container_network_usage(pod_name, container.get("name"), master_ip)
            health_status = get_container_health_status(pod_name, container.get("name"), master_ip)
            processes_info = get_container_process_info(pod_name, container.get("name"), master_ip)

            app_info = {
                "namespace": namespace,
                "pod_name": pod_name,
                "container_name": container.get("name"),
                "image": container.get("image"),
                "app_name": labels.get("app") or labels.get("app.kubernetes.io/name", "unknown"),
                "state": "Running" if running else "Waiting" if waiting else "Terminated",
                "uptime_minutes": uptime_minutes,
                "restarts": container_status.get("restartCount", 0),
                "exit_code": terminated.get("exitCode") if terminated else None,
                "cpu_usage": cpu_usage,
                "memory_usage": memory_usage,
                "disk_usage": disk_usage,
                "network_usage": network_usage,
                "health_status": health_status,
                "processes_info": processes_info,
                "cpu_limit": container.get("resources", {}).get("limits", {}).get("cpu"),
                "memory_limit": container.get("resources", {}).get("limits", {}).get("memory"),
                "cpu_request": container.get("resources", {}).get("requests", {}).get("cpu"),
                "memory_request": container.get("resources", {}).get("requests", {}).get("memory"),
                "service_account": spec.get("serviceAccountName"),
                "volumes": [v.get("name") for v in spec.get("volumes", [])],
                "ports": [p.get("containerPort") for p in container.get("ports", [])] if container.get("ports") else [],
                "env_secrets": [
                    e["valueFrom"]["secretKeyRef"]["name"]
                    for e in container.get("env", [])
                    if e.get("valueFrom") and e["valueFrom"].get("secretKeyRef")
                ],
                "env_configmaps": [
                    e["valueFrom"]["configMapKeyRef"]["name"]
                    for e in container.get("env", [])
                    if e.get("valueFrom") and e["valueFrom"].get("configMapKeyRef")
                ]
            }

            applications.append(app_info)

    return {"applications": applications}


# ✅ Updated helper functions to accept master_ip
def get_container_cpu_usage(pod_name, container_name, master_ip):
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    return parse_cpu_usage(output)

def get_container_memory_usage(pod_name, container_name, master_ip):
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    return parse_memory_usage(output)

def get_container_disk_usage(pod_name, container_name, master_ip):
    return None  # Stub for future enhancement

def get_container_network_usage(pod_name, container_name, master_ip):
    return None  # Stub for future enhancement

def get_container_health_status(pod_name, container_name, master_ip):
    return "Healthy"  # Stub for future logic

def get_container_process_info(pod_name, container_name, master_ip):
    return [{"pid": 1234, "cpu_usage": "0.5%", "memory_usage": "20MB"}]  # Example only

def get_container_cpu_usage(pod_name, container_name, master_ip):
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    return parse_cpu_usage(output)

def get_container_memory_usage(pod_name, container_name, master_ip):
    success, output = execute_command_on_server(master_ip, "root", f"kubectl top pod {pod_name} -c {container_name} --containers")
    if not success:
        return None
    return parse_memory_usage(output)

def get_container_disk_usage(pod_name, container_name, master_ip):
    return None

def get_container_network_usage(pod_name, container_name, master_ip):
    return None

def get_container_health_status(pod_name, container_name, master_ip):
    return "Healthy"

def get_container_process_info(pod_name, container_name, master_ip):
    return [{"pid": 1234, "cpu_usage": "0.5%", "memory_usage": "20MB"}]
##############################

# Function to clone or update the Git repository
def clone_or_update_repo(repo_url, branch="master"):
    """
    Clone the repository if it does not exist, otherwise update it.
    """
    if not os.path.exists(CLONE_DIR):
        os.makedirs(CLONE_DIR, exist_ok=True)

    repo_name = repo_url.split("/")[-1].replace(".git", "")
    repo_path = os.path.join(CLONE_DIR, repo_name)

    if os.path.exists(repo_path):
        logging.info(f"🔄 Repository {repo_name} already exists. Pulling latest changes...")
        subprocess.run(["git", "-C", repo_path, "pull"], check=True)
    else:
        logging.info(f"📥 Cloning repository {repo_url}...")
        subprocess.run(["git", "clone", "-b", branch, repo_url, repo_path], check=True)

    return repo_path
def get_all_k8s_deployments(master_ip):
    """
    Fetch all Kubernetes deployments from the remote cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.

    Returns:
        list: A list of deployment names.
    """
    logging.info(f"📥 Fetching all Kubernetes deployments from {master_ip}...")

    fetch_command = "kubectl get deployments -o=jsonpath='{.items[*].metadata.name}'"
    success, message = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not message.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes deployments.")
        return []

    deployments = message.strip().split()
    logging.info(f"✅ Found deployments: {deployments}")

    return deployments


def get_k8s_manifest_from_repo(repo_path, deployment_name):
    """
    Find the correct Kubernetes manifest file from the repo.
    """
    for root, _, files in os.walk(repo_path):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                with open(os.path.join(root, file), "r") as f:
                    try:
                        content = yaml.safe_load(f)
                        if content.get("kind") == "Deployment" and content["metadata"]["name"] == deployment_name:
                            return content
                    except yaml.YAMLError as e:
                        logging.error(f"❌ ERROR: Invalid YAML in {file}: {e}")
    return None


def compare_k8s_configs(expected_config, current_config):
    """
    Compare expected (repo) Kubernetes config vs. live cluster config.
    """
    mismatches = []

    if expected_config["spec"]["replicas"] != current_config["spec"]["replicas"]:
        mismatches.append(f"❌ Replica count mismatch: Expected {expected_config['spec']['replicas']}, Found {current_config['spec']['replicas']}")

    expected_images = [c["image"] for c in expected_config["spec"]["template"]["spec"]["containers"]]
    current_images = [c["image"] for c in current_config["spec"]["template"]["spec"]["containers"]]

    if set(expected_images) != set(current_images):
        mismatches.append(f"❌ Image mismatch: Expected {expected_images}, Found {current_images}")

    return mismatches

def get_live_k8s_config(master_ip, deployment_name):
    """
    Fetch the current live Kubernetes deployment YAML config from the cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.
        deployment_name (str): The name of the deployment.

    Returns:
        dict: Parsed YAML of the Kubernetes deployment.
    """
    logging.info(f"📥 Fetching live Kubernetes config for {deployment_name} from {master_ip}...")

    fetch_command = f"kubectl get deployment {deployment_name} -o yaml"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error(f"❌ ERROR: Failed to fetch Kubernetes deployment state for {deployment_name}.")
        return None

    try:
        return yaml.safe_load(output)
    except yaml.YAMLError as e:
        logging.error(f"❌ ERROR: Failed to parse Kubernetes state YAML: {e}")
        return None


def load_deployment_snapshot_by_name(deployment_name):
    """
    Load a deployment snapshot by name.
    """
    for file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
        path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, file)
        snapshot = load_deployment_snapshot(path)
        if snapshot and snapshot.get("deployment_name") == deployment_name:
            return snapshot
    return None



# Notification Sender
def send_notification(subject, body, recipients, channels=["email"]):
    """
    Send notifications via configured channels (email, slack).

    Args:
        subject (str): Notification subject/title.
        body (str): Notification message.
        recipients (dict): Dictionary with 'notification_recipients' and 'notification_channels' keys.
        channels (list): Optional override of channels to send to (default: ["email"])
    """
    config = load_notification_config()
    if not config:
        logging.warning("⚠️ Notification config not found. Skipping notification.")
        return

    emails = recipients.get("notification_recipients", {}).get("email", [])
    user_channels = recipients.get("notification_channels", ["email"])

    # Use passed channels if not overridden
    channels = channels or user_channels

    logging.info(f"📣 Preparing to send notifications - Channels: {channels}, Recipients: {emails}")

    # ✅ Email
    if "email" in channels and config.get("email") and emails:
        email_config = config["email"]
        smtp_server = email_config.get("smtp_server")
        smtp_port = email_config.get("smtp_port")
        sender_email = email_config.get("sender_email")
        sender_password = email_config.get("sender_password")

        if smtp_server and smtp_port and sender_email and sender_password:
            msg = MIMEMultipart()
            msg["From"] = sender_email
            msg["To"] = ', '.join(emails)
            msg["Subject"] = subject
            msg.attach(MIMEText(body, "plain"))

            try:
                with smtplib.SMTP(smtp_server, smtp_port) as server:
                    server.starttls()
                    server.login(sender_email, sender_password)
                    server.sendmail(sender_email, emails, msg.as_string())
                logging.info("✅ Email notification sent.")
            except Exception as e:
                logging.error(f"❌ Failed to send email notification: {e}")
        else:
            logging.warning("⚠️ Incomplete email SMTP config. Skipping email notification.")
    else:
        logging.debug("📪 Email channel not used or no valid recipients.")

    # ✅ Slack
    if "slack" in channels and config.get("slack", {}).get("webhook_url"):
        slack_webhook = config["slack"]["webhook_url"]
        try:
            payload = {"text": f"*{subject}*\n{body}"}
            response = requests.post(slack_webhook, json=payload)
            if response.status_code == 200:
                logging.info("✅ Slack notification sent.")
            else:
                logging.error(f"❌ Slack notification failed with status code: {response.status_code}")
        except Exception as e:
            logging.error(f"❌ Exception during Slack notification: {e}")
    else:
        logging.debug("💬 Slack channel not used or not configured.")

# Pod Health Checker
def check_pod_health_issues(pods_json):
    issues = []
    try:
        data = json.loads(pods_json)
        for item in data.get("items", []):
            namespace = item.get("metadata", {}).get("namespace", "default")
            pod_name = item.get("metadata", {}).get("name", "unknown")
            phase = item.get("status", {}).get("phase", "Unknown")
            container_statuses = item.get("status", {}).get("containerStatuses", [])

            if phase not in ["Running", "Succeeded"]:
                issues.append({"namespace": namespace, "pod": pod_name, "issue": f"Pod is in phase '{phase}'"})

            for cs in container_statuses:
                name = cs.get("name", "unknown")
                state = cs.get("state", {})
                if "waiting" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container waiting - {state['waiting'].get('reason')}: {state['waiting'].get('message')}"
                    })
                elif "terminated" in state:
                    issues.append({
                        "namespace": namespace,
                        "pod": pod_name,
                        "container": name,
                        "issue": f"Container terminated - {state['terminated'].get('reason')}: {state['terminated'].get('message')}"
                    })
    except Exception as e:
        issues.append({"namespace": "N/A", "pod": "N/A", "issue": f"Error parsing pod health: {e}"})
    return issues

def load_notification_config():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration file not found: {CONFIGS_FILE}. Please create it to enable notifications.", fg="red"))
        return None

    with open(CONFIGS_FILE, 'r') as file:
        config = yaml.safe_load(file)

    if not config:
        click.echo(click.style(f"Notification configuration file {CONFIGS_FILE} is empty or invalid. Please update it.", fg="red"))
        return None

    return config


def monitor_git_repositories():
    logger.info("🟢 monitor_git_repositories() function started!")
    broadcast_live_log("🟢 monitor_git_repositories() function started!\n")

    while True:
        try:
            logger.info("🔍 Checking repositories for new commits...")
            broadcast_live_log("🔍 Checking repositories for new commits...\n")

            if not os.path.exists(DEPLOYMENT_SNAPSHOT_DIR):
                msg = f"⚠️ Deployment snapshot directory {DEPLOYMENT_SNAPSHOT_DIR} does not exist."
                logger.warning(msg)
                broadcast_live_log(msg + "\n")
                time.sleep(CHECK_INTERVAL)
                continue

            for snapshot_file in os.listdir(DEPLOYMENT_SNAPSHOT_DIR):
                snapshot_path = os.path.join(DEPLOYMENT_SNAPSHOT_DIR, snapshot_file)
                snapshot = load_deployment_snapshot(snapshot_path)

                if not snapshot:
                    msg = f"⚠️ Skipping {snapshot_file}: Could not load snapshot."
                    logger.warning(msg)
                    broadcast_live_log(msg + "\n")
                    continue

                deployment_id = snapshot.get("deployment_id", str(uuid.uuid4()))
                deployment_name = snapshot["deployment_name"]
                repo_url = snapshot["repo_url"]
                stored_commit = snapshot.get("latest_commit")
                branch = snapshot.get("branch", "master")

                msg = f"📂 Checking {deployment_name} on branch '{branch}'"
                logger.info(msg)
                broadcast_live_log(msg + "\n")

                latest_commit = get_latest_commit(repo_url, branch)
                if not latest_commit:
                    msg = f"❌ Could not fetch latest commit for {repo_url} (branch: {branch})"
                    logger.error(msg)
                    broadcast_live_log(msg + "\n")
                    continue

                if stored_commit != latest_commit:
                    msg = f"🚀 New commit detected on {deployment_name}@{branch}! Redeploying..."
                    logger.info(msg)
                    broadcast_live_log(msg + "\n")

                    master_ip = get_dks_master_ip()
                    if not master_ip:
                        msg = f"❌ Could not determine master IP for {deployment_name}"
                        logger.error(msg)
                        broadcast_live_log(msg + "\n")
                        continue

                    if deploy_application_on_master(master_ip, deployment_name, repo_url, branch=branch):
                        msg = f"✅ Successfully redeployed {deployment_name}!"
                        logger.info(msg)
                        broadcast_live_log(msg + "\n")

                        save_deployment_snapshot(
                            deployment_id,
                            deployment_name,
                            repo_url,
                            latest_commit,
                            datetime.utcnow().isoformat(),
                            branch,
                            snapshot.get("send_notification", {}),
                            {
                                "DEPLOYMENT_SUCCESS": snapshot.get("DEPLOYMENT_SUCCESS", True),
                                "DEPLOYMENT_FAILURE": snapshot.get("DEPLOYMENT_FAILURE", True),
                                "CONFIG_DRIFT": snapshot.get("CONFIG_DRIFT", True),
                                "AUTO_SYNC": snapshot.get("AUTO_SYNC", True),
                                "POD_HEALTH": snapshot.get("POD_HEALTH", True),
                            }
                        )
                    else:
                        msg = f"❌ ERROR: Deployment failed for {deployment_name}."
                        logger.error(msg)
                        broadcast_live_log(msg + "\n")
                else:
                    msg = f"✅ {deployment_name} is up-to-date."
                    logger.info(msg)
                    broadcast_live_log(msg + "\n")

            time.sleep(CHECK_INTERVAL)

        except Exception as e:
            msg = f"❌ CRITICAL ERROR in monitor_git_repositories: {e}"
            logger.critical(msg)
            broadcast_live_log(msg + "\n")

def get_k8s_manifest_from_repo(repo_path, deployment_name):
    """
    Find the correct Kubernetes manifest file from the repo.
    """
    for root, _, files in os.walk(repo_path):
        for file in files:
            if file.endswith(".yaml") or file.endswith(".yml"):
                with open(os.path.join(root, file), "r") as f:
                    try:
                        content = yaml.safe_load(f)
                        if content.get("kind") == "Deployment" and content["metadata"]["name"] == deployment_name:
                            return content
                    except yaml.YAMLError as e:
                        logging.error(f"❌ ERROR: Invalid YAML in {file}: {e}")
    return None

def load_notification_config():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration file not found: {CONFIGS_FILE}. Please create it to enable notifications.", fg="red"))
        return None

    with open(CONFIGS_FILE, 'r') as file:
        config = yaml.safe_load(file)

    if not config:
        click.echo(click.style(f"Notification configuration file {CONFIGS_FILE} is empty or invalid. Please update it.", fg="red"))
        return None

    return config

def get_k8s_pod_json(master_ip):
    """
    Fetch all pods in JSON format from the Kubernetes cluster.

    Args:
        master_ip (str): The IP address of the Kubernetes master node.

    Returns:
        str: Raw JSON output of all pods.
    """
    fetch_command = "kubectl get pods --all-namespaces -o json"
    success, output = execute_command_on_server(master_ip, "root", fetch_command)

    if not success or not output.strip():
        logging.error("❌ ERROR: Failed to fetch Kubernetes pod details.")
        return "{}"

    return output


@app.route("/screenplay/live", methods=["GET"])
def get_screenplay_live_status():
    db = SessionLocal()
    try:
        entries = db.query(ScreenplayResource).order_by(ScreenplayResource.updated_at).all()
        return jsonify([
            {
                "execution_id": e.execution_id,
                "provider": e.provider,
                "resource_type": e.resource_type,
                "resource_name": e.resource_name,
                "region": e.region,
                "status": e.status,
                "tags": yaml.safe_load(e.tags) if e.tags else []
            } for e in entries
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@app.route("/execute-screenplay", methods=["POST"])
@cross_origin()
def execute_screenplay():
    try:
        data = request.get_json()
        yaml_config = data.get("yaml_config")
        provider = data.get("provider")
        flags = data.get("flags", [])

        if not yaml_config or not provider:
            return jsonify({"error": "Missing yaml_config or provider"}), 400

        os.makedirs(SCREENPLAY_DIR, exist_ok=True)
        execution_id = str(uuid.uuid4())
        file_path = os.path.join(SCREENPLAY_DIR, f"{execution_id}.yaml")

        with open(file_path, "w") as f:
            f.write(yaml_config)

        log_screenplay_snapshot(execution_id, file_path)
        flag_str = " ".join(flags)
        command = f"dob {provider} screenplay {file_path} {flag_str}"
        print(f"[🧪] Running command: {command}")

        # ✅ Use subprocess to stream logs properly (not detached!)
        def generate():
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in iter(process.stdout.readline, ''):
                yield f"data: {line.rstrip()}\n\n"
            process.stdout.close()
            process.wait()

        return Response(stream_with_context(generate()), content_type="text/event-stream")

    except Exception as e:
        print(f"[❌] execute-screenplay failed: {e}")
        return jsonify({"error": str(e)}), 500

# 🧹 DELETE /screenplay/executions
@app.route("/screenplay/executions", methods=["DELETE"])
@token_required
def delete_screenplay_executions():
    try:
        data = request.get_json()
        ids = data.get("execution_ids", [])

        if not ids:
            return jsonify({"error": "Missing execution_ids"}), 400

        deleted = []

        if isinstance(ids, str) and ids.upper() == "ALL":
            for fname in os.listdir(SCREENPLAY_DIR):
                if fname.endswith(".yaml"):
                    os.remove(os.path.join(SCREENPLAY_DIR, fname))
                    deleted.append(fname.replace(".yaml", ""))
        else:
            for exec_id in ids:
                path = os.path.join(SCREENPLAY_DIR, f"{exec_id}.yaml")
                if os.path.exists(path):
                    os.remove(path)
                    deleted.append(exec_id)

        return jsonify({"deleted": deleted})

    except Exception as e:
        return jsonify({"error": str(e)}), 500


@app.route("/stream-screenplay")
@token_required
def stream_screenplay():
    execution_id = request.args.get("execution_id")  # ✅ move this out here
    if not execution_id:
        return jsonify({"error": "Missing execution_id"}), 400

    log_path = f"/tmp/screenplay-{execution_id}.log"

    def generate():
        while True:
            if os.path.exists(log_path):
                with open(log_path, "r") as f:
                    for line in f:
                        yield f"data: {line.strip()}\n\n"
            time.sleep(1)

    return Response(generate(), mimetype='text/event-stream')


@app.route("/screenplay/executions", methods=["GET"])
@token_required
def list_screenplay_executions():
    try:
        entries = []
        for fname in os.listdir(SCREENPLAY_DIR):
            if fname.endswith(".yaml"):
                fpath = os.path.join(SCREENPLAY_DIR, fname)
                stat = os.stat(fpath)
                entries.append({
                    "execution_id": fname.replace(".yaml", ""),
                    "file_path": fpath,
                    "file_name": fname,
                    "created_at": time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(stat.st_ctime))
                })
        return jsonify(sorted(entries, key=lambda x: x['created_at'], reverse=True))
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# 📂 GET /screenplay/execution/<execution_id>
@app.route("/screenplay/execution/<execution_id>", methods=["GET"])
@token_required
def get_screenplay_yaml(execution_id):
    try:
        target_file = os.path.join(SCREENPLAY_DIR, f"{execution_id}.yaml")
        if not os.path.exists(target_file):
            return jsonify({"error": "Configuration not found"}), 404
        with open(target_file, "r") as f:
            return jsonify({"yaml_config": f.read()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/cli", methods=["POST"])
def execute_cli_command():
    global CURRENT_CLI_DIR
    try:
        data = request.get_json()
        command = data.get("command")
        if not command:
            return jsonify({"error": "Missing command"}), 400

        # Handle 'cd' separately to change directory
        if command.startswith("cd "):
            path = command[3:].strip()
            new_dir = os.path.abspath(os.path.join(CURRENT_CLI_DIR, path))
            if os.path.isdir(new_dir):
                CURRENT_CLI_DIR = new_dir
                return jsonify({
                    "cwd": CURRENT_CLI_DIR,
                    "output": f"📁 Changed directory to {CURRENT_CLI_DIR}"
                })
            else:
                return jsonify({
                    "cwd": CURRENT_CLI_DIR,
                    "error": f"❌ Directory '{path}' does not exist"
                }), 400

        # Execute other shell commands in the current directory
        process = subprocess.Popen(
            command,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            cwd=CURRENT_CLI_DIR,
            text=True
        )
        output, _ = process.communicate()

        return jsonify({
            "cwd": CURRENT_CLI_DIR,
            "output": output
        })

    except Exception as e:
        return jsonify({
            "cwd": CURRENT_CLI_DIR,
            "error": f"❌ Exception occurred: {str(e)}"
        }), 500

@app.route("/cli/cwd", methods=["GET"])
def get_current_directory():
    return jsonify({"cwd": CURRENT_CLI_DIR})

# ===================== ROUTES ============================
@app.route("/status")
@token_required
def log_status():
    files = []
    for f in get_log_files():
        files.append({
            "name": os.path.basename(f),
            "size_mb": round(os.path.getsize(f) / (1024 * 1024), 2),
            "modified": datetime.fromtimestamp(os.path.getmtime(f)).strftime(LOG_FORMAT)
        })
    return jsonify(files)

@app.route("/metrics")
@token_required
def metrics():
    update_all_log_metrics()
    return Response(generate_latest(registry), mimetype=CONTENT_TYPE_LATEST)

@app.route("/clean", methods=["POST"])
@token_required
def clean_logs():
    remove_duplicate_lines()
    return jsonify({"status": "duplicates removed"})

@app.route("/rotate", methods=["POST"])
@token_required
def rotate_logs():
    rotate_large_logs()
    return jsonify({"status": "rotation done"})

@app.route("/delete-old", methods=["POST"])
@token_required
def delete_old():
    delete_old_logs()
    return jsonify({"status": "old logs deleted"})

@app.route("/scrub", methods=["POST"])
@token_required
def scrub():
    scrub_sensitive_data()
    return jsonify({"status": "scrubbed"})

@app.route("/stream/<logfile>")
@token_required
def stream_log(logfile):
    log_path = os.path.join(LOGS_DIR, logfile)
    if not os.path.exists(log_path):
        return jsonify({"error": "Log file not found"}), 404

    @stream_with_context
    def generate():
        with open(log_path, "r") as f:
            f.seek(0, os.SEEK_END)
            while True:
                line = f.readline()
                if line:
                    yield f"data: {line.strip()}\n\n"
                    sys.stdout.flush()
                else:
                    time.sleep(0.5)

    return Response(generate(), mimetype="text/event-stream")

@app.route("/auth/ping", methods=["GET"])
@token_required
def ping():
    return jsonify({"status": "connected"})

@app.route("/dks/live", methods=["GET"])
@token_required
def get_dks_live_data():
    try:
        from ui.app import collect_dks_live_data  # Import only when endpoint is hit
        data = collect_dks_live_data()
        return jsonify(data)
    except Exception as e:
        logger.error(f"❌ Failed to fetch live DKS data: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/dks/logs", methods=["GET"])
@token_required
def get_dks_logs():
    try:
        from ui.app import get_pod_logs  # ✅ All internal logic handled inside

        pod = request.args.get("pod")
        namespace = request.args.get("namespace", "default")
        lines = int(request.args.get("lines", 100))

        if not pod:
            return jsonify({"error": "Missing pod name"}), 400

        logs = get_pod_logs(pod, namespace, lines)
        return jsonify({"logs": logs})

    except Exception as e:
        logger.error(f"❌ Failed to fetch pod logs: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/dks/cli", methods=["POST"])
@token_required
def run_kubectl_cli():
    try:
        from ui.app import execute_kubectl_command
        cmd = request.json.get("command", "").strip()

        if not cmd:
            return jsonify({"error": "Missing command"}), 400

        result = execute_kubectl_command(cmd)
        return jsonify({"output": result})

    except Exception as e:
        logger.error(f"❌ Failed to run kubectl CLI command: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/metrics-json", methods=["GET"])
@token_required
def get_json_metrics():
    try:
        result = []
        for f in get_log_files():
            stat = os.stat(f)
            filename = os.path.basename(f)
            size_mb = round(stat.st_size / (1024 * 1024), 2)
            modified = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
            # Dummy values for entries and duplicates for now
            result.append({
                "filename": filename,
                "sizeMB": size_mb,
                "entries": 1000 + len(filename),  # Replace with actual count if available
                "duplicates": 10 + len(filename) % 10,  # Replace with real logic
                "lastRotated": modified
            })
        return jsonify(result)
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route("/dks/nodes", methods=["GET"])
@token_required
def get_dks_nodes_info():
    try:
        data = collect_k8s_node_details()
        return jsonify(data)
    except Exception as e:
        logger.error(f"❌ Failed to fetch DKS node details: {e}")
        return jsonify({"error": str(e)}), 500



# ─────────────────────────────────────────────────────
# ✅ Database Setup (PostgreSQL)
# ─────────────────────────────────────────────────────

engine = create_engine(DB_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()


# ─────────────────────────────────────────────────────
# ✅ SQLAlchemy Model for Screenplay Resources
# ─────────────────────────────────────────────────────
class ScreenplayResource(Base):
    __tablename__ = "screenplay_resources"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String, nullable=False)
    provider = Column(String, default="aws")
    resource_type = Column(String, nullable=False)
    resource_name = Column(String, nullable=False)
    region = Column(String, nullable=False)
    status = Column(String, nullable=False, default="pending")
    tags = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

def upsert_screenplay_resource(execution_id, provider, resource_type, resource_name, region, status, tags=None):
    db = SessionLocal()
    try:
        existing = db.query(ScreenplayResource).filter_by(
            execution_id=execution_id,
            resource_type=resource_type,
            resource_name=resource_name
        ).first()

        if existing:
            existing.status = status
            existing.region = region
            existing.tags = yaml.dump(tags) if tags else None
        else:
            db.add(ScreenplayResource(
                execution_id=execution_id,
                provider=provider,
                resource_type=resource_type,
                resource_name=resource_name,
                region=region,
                status=status,
                tags=yaml.dump(tags) if tags else None
            ))
        db.commit()
    except Exception as e:
        print(f"[ERROR] Failed to upsert screenplay resource: {e}")
    finally:
        db.close()


# ─────────────────────────────────────────────────────
# ✅ SQLAlchemy Model for Live Updates
# ─────────────────────────────────────────────────────
class JobStage(Base):
    __tablename__ = "job_stages"
    __table_args__ = {'extend_existing': True}  # ✅ this line fixes the duplicate error

    id = Column(Integer, primary_key=True, index=True)
    job_name = Column(String, nullable=False)
    stage_name = Column(String, nullable=False)
    task_name = Column(String, nullable=False)
    status = Column(String, nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())


class InfraCycleExecution(Base):
    __tablename__ = "infra_executions"

    id = Column(Integer, primary_key=True, index=True)
    execution_id = Column(String, unique=True, nullable=False)
    yaml_config = Column(Text, nullable=False)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

# ─────────────────────────────────────────────────────
# ✅ DB Helpers
# ─────────────────────────────────────────────────────
def upsert_job_stage(job, stage, task, status):
    db = SessionLocal()
    try:
        existing = db.query(JobStage).filter_by(job_name=job, stage_name=stage, task_name=task).first()
        if existing:
            existing.status = status
        else:
            db.add(JobStage(job_name=job, stage_name=stage, task_name=task, status=status))
        db.commit()
    except Exception as e:
        print(f"[ERROR] DB upsert failed: {e}")
    finally:
        db.close()

def upsert_infracyle_execution(execution_id, yaml_config):
    db = SessionLocal()
    try:
        existing = db.query(InfraCycleExecution).filter_by(execution_id=execution_id).first()
        if existing:
            existing.yaml_config = yaml_config
        else:
            db.add(InfraCycleExecution(execution_id=execution_id, yaml_config=yaml_config))
        db.commit()
    except Exception as e:
        print(f"[ERROR] InfraCycle DB upsert failed: {e}")
    finally:
        db.close()
# ─────────────────────────────────────────────────────
# ✅ Initialize DB Schema
# ─────────────────────────────────────────────────────
Base.metadata.create_all(bind=engine)

@app.route("/infra/delete-job", methods=["DELETE"])
@token_required
def delete_job_execution():
    try:
        data = request.get_json()
        job_name = data.get("job_name")

        if not job_name:
            return jsonify({"error": "Missing job_name"}), 400

        db = SessionLocal()
        try:
            deleted_count = db.query(JobStage).filter_by(job_name=job_name).delete()
            db.commit()

            if deleted_count == 0:
                return jsonify({"message": f"⚠️ No records found for job: {job_name}"}), 404

            return jsonify({"message": f"🗑️ Deleted {deleted_count} stages for job: {job_name}"}), 200

        except Exception as e:
            db.rollback()
            return jsonify({"error": f"DB deletion error: {str(e)}"}), 500

        finally:
            db.close()

    except Exception as e:
        return jsonify({"error": f"❌ Server error: {str(e)}"}), 500

@app.route("/screenplay/delete", methods=["DELETE"])
@token_required
def delete_screenplay_execution():
    try:
        data = request.get_json()
        execution_id = data.get("execution_id")

        if not execution_id:
            return jsonify({"error": "Missing execution_id"}), 400

        db = SessionLocal()
        try:
            deleted = db.query(ScreenplayResource).filter_by(execution_id=execution_id).delete()
            db.commit()

            if deleted == 0:
                return jsonify({"message": f"⚠️ No resources found for execution: {execution_id}"}), 404

            return jsonify({"message": f"🗑️ Deleted {deleted} resources for execution ID: {execution_id}"}), 200

        except Exception as e:
            db.rollback()
            return jsonify({"error": f"Database error: {str(e)}"}), 500

        finally:
            db.close()

    except Exception as e:
        return jsonify({"error": f"❌ Server error: {str(e)}"}), 500

@app.route("/execute-infracyle", methods=["POST"])
@cross_origin()
@token_required
def execute_infracyle():
    try:
        data = request.get_json()
        yaml_config = data.get("yaml_config")
        execution_id = data.get("execution_id", str(uuid.uuid4()))

        if not yaml_config:
            return jsonify({"error": "Missing 'yaml_config'"}), 400

        os.makedirs(INFRACYCLE_DIR, exist_ok=True)
        file_path = os.path.join(INFRACYCLE_DIR, f"{execution_id}.yaml")

        # ✅ Save config file (overwrite if re-execution)
        with open(file_path, "w") as f:
            f.write(yaml_config)

        # ✅ Store or update in PostgreSQL
        upsert_infracyle_execution(execution_id, yaml_config)

        # ✅ Run execution command
        command = f"dob infracycle apply --file-path {file_path}"

        def generate():
            process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
            for line in iter(process.stdout.readline, ''):
                yield f"data: {line.rstrip()}\n\n"
            process.stdout.close()
            process.wait()

        return Response(stream_with_context(generate()), content_type="text/event-stream")

    except Exception as e:
        print(f"[❌] execute-infracyle failed: {e}")
        return jsonify({"error": str(e)}), 500


# ─────────────────────────────────────────────────────
# ✅ Stage Update API
# ─────────────────────────────────────────────────────
@app.route("/infra/update", methods=["POST"])
@token_required
def receive_stage_update():
    try:
        data = request.get_json()
        job = data.get("job")
        stage = data.get("stage")
        task = data.get("task")
        status = data.get("status")
        if not all([job, stage, task, status]):
            return jsonify({"error": "Missing fields"}), 400
        upsert_job_stage(job, stage, task, status)
        return jsonify({"message": "✅ Update received"}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# ─────────────────────────────────────────────────────
# ✅ Screenplay Update API
# ─────────────────────────────────────────────────────
@app.route("/screenplay/update", methods=["POST"])
@token_required
def receive_screenplay_update():
    try:
        data = request.get_json()

        execution_id = data.get("execution_id")
        provider = data.get("provider", "aws")
        resource_type = data.get("resource_type")
        resource_name = data.get("resource_name")
        region = data.get("region")
        status = data.get("status")
        tags = data.get("tags", [])

        if not all([execution_id, resource_type, resource_name, region, status]):
            return jsonify({"error": "Missing required fields"}), 400

        upsert_screenplay_resource(
            execution_id=execution_id,
            provider=provider,
            resource_type=resource_type,
            resource_name=resource_name,
            region=region,
            status=status,
            tags=tags
        )

        return jsonify({"message": "✅ Screenplay update received"}), 200

    except Exception as e:
        print(f"[❌] Error in /screenplay/update: {e}")
        return jsonify({"error": str(e)}), 500

@app.route("/infra/live", methods=["GET"])
@token_required
def get_live_status():
    db = SessionLocal()
    try:
        entries = db.query(JobStage).order_by(JobStage.updated_at).all()
        return jsonify([
            {
                "job": e.job_name,
                "stage": e.stage_name,
                "task": e.task_name,
                "status": e.status
            } for e in entries
        ])
    except Exception as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()



@app.route('/ai-agent/chat', methods=['POST'])
@token_required  # ✅ Optional if you're securing the route
def ai_agent_chat():
    try:
        data = request.get_json()
        prompt = data.get('prompt')

        if not prompt:
            return jsonify({"error": "Prompt is required"}), 400

        response = process_conversation(prompt)
        return jsonify(response)

    except Exception as e:
        print(f"❌ Agent Chat Error: {e}")
        return jsonify({"error": str(e)}), 500

@app.route('/dks/provision', methods=['POST'])
def provision_dks_cluster():
    try:
        data = request.get_json()

        # ✅ Extract fields
        master = {
            "instance_type": data.get("master_instance_type"),
            "key_name": data.get("master_key_name"),
            "security_group": data.get("master_security_group"),
            "name": data.get("master_name")
        }

        workers = {
            "instance_type": data.get("worker_instance_type"),
            "key_name": data.get("worker_key_name"),
            "security_group": data.get("worker_security_group"),
            "name": data.get("worker_name"),
            "count": int(data.get("worker_count", 1))
        }

        config_data = {
            "master": master,
            "workers": workers
        }

        # ✅ Save to temp YAML file
        config_id = str(uuid.uuid4())[:8]
        file_path = f"/tmp/dks_config_{config_id}.yaml"

        with open(file_path, 'w') as f:
            yaml.dump(config_data, f, default_flow_style=False)

        # ✅ Run provisioning command
        cmd = f"dob aws dks config -f {file_path}"
        result = subprocess.run(cmd, shell=True, capture_output=True, text=True)

        if result.returncode != 0:
            return jsonify({
                "success": False,
                "error": result.stderr,
                "output": result.stdout
            }), 500

        return jsonify({
            "success": True,
            "message": f"DKS cluster provisioning started using {file_path}",
            "output": result.stdout
        })

    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

# ─────────────────────────────────────────────────────
# ✅ Run the App (Port 4104 or custom)
# ─────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────
# ✅ Agile Models
# ─────────────────────────────────────────────────────

class Epic(Base):
    __tablename__ = "agile_epics"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="open")
    start_date = Column(Date)
    end_date = Column(Date)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Feature(Base):
    __tablename__ = "agile_features"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    epic_id = Column(Integer, ForeignKey("agile_epics.id", ondelete="CASCADE"))
    title = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="open")
    priority = Column(String)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Story(Base):
    __tablename__ = "agile_stories"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    feature_id = Column(Integer, ForeignKey("agile_features.id", ondelete="CASCADE"))
    title = Column(String, nullable=False)
    description = Column(Text)
    status = Column(String, default="todo")
    assignee = Column(String)
    story_points = Column(Integer, default=1)
    sprint_id = Column(Integer, ForeignKey("agile_sprints.id", ondelete="SET NULL"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Sprint(Base):
    __tablename__ = "agile_sprints"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    goal = Column(Text)
    start_date = Column(Date)
    end_date = Column(Date)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())



# ─────────────────────────────────────────────────────
# ✅ EPICS
# ─────────────────────────────────────────────────────

@agile_bp.route("/epics", methods=["GET"])
def get_epics():
    db = SessionLocal()
    try:
        epics = db.query(Epic).all()
        return jsonify([
            {
                "id": e.id,
                "title": e.title,
                "description": e.description,
                "status": e.status,
                "start_date": str(e.start_date) if e.start_date else None,
                "end_date": str(e.end_date) if e.end_date else None
            } for e in epics
        ])
    finally:
        db.close()

@agile_bp.route("/epics", methods=["POST"])
def create_epic():
    db = SessionLocal()
    data = request.get_json()
    try:
        new_epic = Epic(
            title=data["title"],
            description=data.get("description", ""),
            status=data.get("status", "open"),
            start_date=data.get("start_date"),
            end_date=data.get("end_date")
        )
        db.add(new_epic)
        db.commit()
        return jsonify({"message": "Epic created", "id": new_epic.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@agile_bp.route("/epics/<int:epic_id>", methods=["DELETE"])
def delete_epic(epic_id):
    db = SessionLocal()
    try:
        epic = db.query(Epic).filter_by(id=epic_id).first()
        if not epic:
            return jsonify({"error": "Epic not found"}), 404
        db.delete(epic)
        db.commit()
        return jsonify({"message": "Epic deleted"})
    finally:
        db.close()

# ─────────────────────────────────────────────────────
# ✅ FEATURES
# ─────────────────────────────────────────────────────

@agile_bp.route("/features", methods=["GET"])
def get_features():
    db = SessionLocal()
    try:
        features = db.query(Feature).all()
        return jsonify([
            {
                "id": f.id,
                "epic_id": f.epic_id,
                "title": f.title,
                "description": f.description,
                "status": f.status,
                "priority": f.priority
            } for f in features
        ])
    finally:
        db.close()

@agile_bp.route("/features", methods=["POST"])
def create_feature():
    db = SessionLocal()
    data = request.get_json()
    try:
        new_feature = Feature(
            epic_id=data["epic_id"],
            title=data["title"],
            description=data.get("description", ""),
            status=data.get("status", "open"),
            priority=data.get("priority", "medium")
        )
        db.add(new_feature)
        db.commit()
        return jsonify({"message": "Feature created", "id": new_feature.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@agile_bp.route("/features/<int:feature_id>", methods=["DELETE"])
def delete_feature(feature_id):
    db = SessionLocal()
    try:
        feature = db.query(Feature).filter_by(id=feature_id).first()
        if not feature:
            return jsonify({"error": "Feature not found"}), 404
        db.delete(feature)
        db.commit()
        return jsonify({"message": "Feature deleted"})
    finally:
        db.close()

# ─────────────────────────────────────────────────────
# ✅ STORIES
# ─────────────────────────────────────────────────────

@agile_bp.route("/stories", methods=["GET"])
def get_stories():
    db = SessionLocal()
    try:
        stories = db.query(Story).all()
        return jsonify([
            {
                "id": s.id,
                "feature_id": s.feature_id,
                "title": s.title,
                "description": s.description,
                "status": s.status,
                "assignee": s.assignee,
                "story_points": s.story_points,
                "sprint_id": s.sprint_id
            } for s in stories
        ])
    finally:
        db.close()

@agile_bp.route("/stories", methods=["POST"])
def create_story():
    db = SessionLocal()
    data = request.get_json()
    try:
        new_story = Story(
            feature_id=data["feature_id"],
            title=data["title"],
            description=data.get("description", ""),
            status=data.get("status", "todo"),
            assignee=data.get("assignee"),
            story_points=data.get("story_points", 1),
            sprint_id=data.get("sprint_id")
        )
        db.add(new_story)
        db.commit()
        return jsonify({"message": "Story created", "id": new_story.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@agile_bp.route("/stories/<int:story_id>", methods=["DELETE"])
def delete_story(story_id):
    db = SessionLocal()
    try:
        story = db.query(Story).filter_by(id=story_id).first()
        if not story:
            return jsonify({"error": "Story not found"}), 404
        db.delete(story)
        db.commit()
        return jsonify({"message": "Story deleted"})
    finally:
        db.close()

# ─────────────────────────────────────────────────────
# ✅ SPRINTS
# ─────────────────────────────────────────────────────

@agile_bp.route("/sprints", methods=["GET"])
def get_sprints():
    db = SessionLocal()
    try:
        sprints = db.query(Sprint).all()
        return jsonify([
            {
                "id": s.id,
                "name": s.name,
                "goal": s.goal,
                "start_date": str(s.start_date) if s.start_date else None,
                "end_date": str(s.end_date) if s.end_date else None,
                "is_active": s.is_active
            } for s in sprints
        ])
    finally:
        db.close()

@agile_bp.route("/sprints", methods=["POST"])
def create_sprint():
    db = SessionLocal()
    data = request.get_json()
    try:
        new_sprint = Sprint(
            name=data["name"],
            goal=data.get("goal", ""),
            start_date=data.get("start_date"),
            end_date=data.get("end_date"),
            is_active=data.get("is_active", True)
        )
        db.add(new_sprint)
        db.commit()
        return jsonify({"message": "Sprint created", "id": new_sprint.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ─────────────────────────────────────────────────────
# ✅ Scrum Models
# ─────────────────────────────────────────────────────

class ScrumUser(Base):
    __tablename__ = "scrum_users"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    role = Column(String, nullable=False)  # product_owner, scrum_master, dev
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ScrumStandup(Base):
    __tablename__ = "scrum_standups"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("scrum_users.id", ondelete="CASCADE"))
    sprint_id = Column(Integer, ForeignKey("agile_sprints.id", ondelete="CASCADE"))
    date = Column(Date)
    yesterday = Column(Text)
    today = Column(Text)
    blockers = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ScrumReview(Base):
    __tablename__ = "scrum_reviews"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    sprint_id = Column(Integer, ForeignKey("agile_sprints.id", ondelete="CASCADE"))
    notes = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ScrumRetrospective(Base):
    __tablename__ = "scrum_retrospectives"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    sprint_id = Column(Integer, ForeignKey("agile_sprints.id", ondelete="CASCADE"))
    what_went_well = Column(Text)
    what_didnt_go_well = Column(Text)
    actions = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ScrumDefinitionOfDone(Base):
    __tablename__ = "scrum_definition_of_done"
    __table_args__ = {'extend_existing': True}
    id = Column(Integer, primary_key=True, index=True)
    scope = Column(String, default="project")  # global, project, sprint
    checklist = Column(Text)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class KanbanBoard(Base):
    __tablename__ = "kanban_boards"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    description = Column(String)

class KanbanColumn(Base):
    __tablename__ = "kanban_columns"
    id = Column(Integer, primary_key=True)
    board_id = Column(Integer, ForeignKey("kanban_boards.id"))
    title = Column(String)
    position = Column(Integer)

class KanbanCard(Base):
    __tablename__ = "kanban_cards"
    id = Column(Integer, primary_key=True)
    column_id = Column(Integer, ForeignKey("kanban_columns.id"))
    title = Column(String)
    description = Column(String)
    assignee = Column(String)
    status = Column(String)  # todo, in_progress, testing, done
    position = Column(Integer)

class SafePortfolio(Base):
    __tablename__ = "safe_portfolios"
    id = Column(Integer, primary_key=True)
    name = Column(String)
    description = Column(Text)

class SafeValueStream(Base):
    __tablename__ = "safe_value_streams"
    id = Column(Integer, primary_key=True)
    portfolio_id = Column(Integer, ForeignKey("safe_portfolios.id"))
    name = Column(String)
    description = Column(Text)

class SafeART(Base):
    __tablename__ = "safe_arts"
    id = Column(Integer, primary_key=True)
    value_stream_id = Column(Integer, ForeignKey("safe_value_streams.id"))
    name = Column(String)
    description = Column(Text)

class SafeTeam(Base):
    __tablename__ = "safe_teams"
    id = Column(Integer, primary_key=True)
    art_id = Column(Integer, ForeignKey("safe_arts.id"))
    name = Column(String)
    members = Column(Text)

class SafeProgramIncrement(Base):
    __tablename__ = "safe_program_increments"
    id = Column(Integer, primary_key=True)
    art_id = Column(Integer, ForeignKey("safe_arts.id"))
    name = Column(String)
    start_date = Column(Date)
    end_date = Column(Date)

class SafeEpic(Base):
    __tablename__ = "safe_epics"
    id = Column(Integer, primary_key=True)
    portfolio_id = Column(Integer, ForeignKey("safe_portfolios.id"))
    title = Column(String)
    description = Column(Text)
    okr = Column(Text)

class SafeFeature(Base):
    __tablename__ = "safe_features"
    id = Column(Integer, primary_key=True)
    epic_id = Column(Integer, ForeignKey("safe_epics.id"))
    title = Column(String)
    description = Column(Text)

class SafeStory(Base):
    __tablename__ = "safe_stories"
    id = Column(Integer, primary_key=True)
    feature_id = Column(Integer, ForeignKey("safe_features.id"))
    title = Column(String)
    description = Column(Text)
    status = Column(String)

Base.metadata.create_all(bind=engine)


# ─────────────────────────────────────────────────────
# ✅ Scrum API Endpoints
# ─────────────────────────────────────────────────────

@scrum_bp.route("/users", methods=["POST"])
def create_user():
    db = SessionLocal()
    data = request.get_json()
    try:
        user = ScrumUser(
            name=data["name"],
            email=data["email"],
            role=data["role"]
        )
        db.add(user)
        db.commit()
        return jsonify({"message": "User created", "id": user.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@scrum_bp.route("/users", methods=["GET"])
def list_users():
    db = SessionLocal()
    try:
        users = db.query(ScrumUser).all()
        return jsonify([
            {
                "id": u.id,
                "name": u.name,
                "email": u.email,
                "role": u.role
            } for u in users
        ])
    finally:
        db.close()


@scrum_bp.route("/standups", methods=["POST"])
def log_standup():
    db = SessionLocal()
    data = request.get_json()
    try:
        log = ScrumStandup(
            user_id=data["user_id"],
            sprint_id=data["sprint_id"],
            date=data["date"],
            yesterday=data.get("yesterday", ""),
            today=data.get("today", ""),
            blockers=data.get("blockers", "")
        )
        db.add(log)
        db.commit()
        return jsonify({"message": "Standup logged", "id": log.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@scrum_bp.route("/reviews", methods=["POST"])
def create_review():
    db = SessionLocal()
    data = request.get_json()
    try:
        review = ScrumReview(
            sprint_id=data["sprint_id"],
            notes=data["notes"]
        )
        db.add(review)
        db.commit()
        return jsonify({"message": "Review added", "id": review.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@scrum_bp.route("/retros", methods=["POST"])
def create_retro():
    db = SessionLocal()
    data = request.get_json()
    try:
        retro = ScrumRetrospective(
            sprint_id=data["sprint_id"],
            what_went_well=data.get("what_went_well", ""),
            what_didnt_go_well=data.get("what_didn’t_go_well", ""),
            actions=data.get("actions", "")
        )
        db.add(retro)
        db.commit()
        return jsonify({"message": "Retrospective saved", "id": retro.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@scrum_bp.route("/definition-of-done", methods=["POST"])
def save_definition_of_done():
    db = SessionLocal()
    data = request.get_json()
    try:
        dod = ScrumDefinitionOfDone(
            scope=data.get("scope", "project"),
            checklist=data["checklist"]
        )
        db.add(dod)
        db.commit()
        return jsonify({"message": "Definition of Done saved", "id": dod.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@scrum_bp.route("/definition-of-done", methods=["GET"])
def get_definition_of_done():
    db = SessionLocal()
    try:
        items = db.query(ScrumDefinitionOfDone).all()
        return jsonify([
            {
                "id": i.id,
                "scope": i.scope,
                "checklist": i.checklist,
                "created_at": str(i.created_at)
            } for i in items
        ])
    except SQLAlchemyError as e:
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


# ────────────────────────────────
# ✅ BOARDS
# ────────────────────────────────
@app.route("/kanban/boards", methods=["POST"])
def create_board():
    db = SessionLocal()
    data = request.get_json()
    try:
        board = KanbanBoard(
            name=data["name"],
            description=data.get("description", "")
        )
        db.add(board)
        db.commit()  # Required to get board.id

        # Auto-create columns
        default_columns = ["To Do", "In Progress", "Testing", "Done"]
        for idx, title in enumerate(default_columns):
            db.add(KanbanColumn(board_id=board.id, title=title, position=idx))

        db.commit()
        return jsonify({"message": "Board created", "id": board.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@app.route("/kanban/boards", methods=["GET"])
def get_boards():
    db = SessionLocal()
    try:
        boards = db.query(KanbanBoard).all()
        return jsonify([{
            "id": b.id,
            "name": b.name,
            "description": b.description
        } for b in boards])
    finally:
        db.close()

# ────────────────────────────────
# ✅ COLUMNS
# ────────────────────────────────
@app.route("/kanban/columns", methods=["POST"])
def create_column():
    db = SessionLocal()
    data = request.get_json()
    try:
        column = KanbanColumn(
            board_id=data["board_id"],
            title=data["title"],
            position=data.get("position", 0)
        )
        db.add(column)
        db.commit()
        return jsonify({"message": "Column created", "id": column.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@app.route("/kanban/columns", methods=["GET"])
def get_columns():
    db = SessionLocal()
    try:
        columns = db.query(KanbanColumn).all()
        return jsonify([{
            "id": c.id,
            "board_id": c.board_id,
            "title": c.title,
            "position": c.position
        } for c in columns])
    finally:
        db.close()

# ────────────────────────────────
# ✅ CARDS
# ────────────────────────────────
@app.route('/kanban/cards', methods=['POST'])
def create_card():
    db = SessionLocal()
    data = request.get_json()
    try:
        card = KanbanCard(
            column_id=data['column_id'],
            title=data['title'],
            description=data.get('description', ''),
            assignee=data.get('assignee'),
            status=data.get('status', 'To Do'),
            position=data.get('position', 0)
        )
        db.add(card)
        db.commit()
        return jsonify({'message': 'Card created', 'id': card.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({'error': str(e)}), 500
    finally:
        db.close()

@app.route("/kanban/cards", methods=["GET"])
def get_cards():
    db = SessionLocal()
    try:
        cards = db.query(KanbanCard).all()
        return jsonify([{
            "id": c.id,
            "column_id": c.column_id,
            "title": c.title,
            "description": c.description,
            "assignee": c.assignee,
            "status": c.status,
            "position": c.position
        } for c in cards])
    finally:
        db.close()

@app.route("/kanban/cards/<int:card_id>", methods=["PUT"])
def update_card(card_id):
    db = SessionLocal()
    data = request.get_json()
    try:
        card = db.query(KanbanCard).get(card_id)
        if not card:
            return jsonify({"error": "Card not found"}), 404

        if "title" in data:
            card.title = data["title"]
        if "description" in data:
            card.description = data["description"]
        if "status" in data:
            card.status = data["status"]
        if "position" in data:
            card.position = data["position"]
        if "column_id" in data:
            card.column_id = data["column_id"]  # ✅ Add this for drag-and-drop

        db.commit()
        return jsonify({"message": "Card updated"})
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()


@app.route("/kanban/cards/<int:card_id>", methods=["DELETE"])
def delete_card(card_id):
    db = SessionLocal()
    try:
        card = db.query(KanbanCard).get(card_id)
        if not card:
            return jsonify({"error": "Card not found"}), 404

        db.delete(card)
        db.commit()
        return jsonify({"message": "Card deleted"})
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── PORTFOLIOS ────────────────
@app.route("/safe/portfolios", methods=["GET", "POST"])
def manage_portfolios():
    db = SessionLocal()
    try:
        if request.method == "GET":
            portfolios = db.query(SafePortfolio).all()
            return jsonify([{"id": p.id, "name": p.name, "description": p.description} for p in portfolios])
        else:
            data = request.get_json()
            portfolio = SafePortfolio(name=data["name"], description=data.get("description", ""))
            db.add(portfolio)
            db.commit()
            return jsonify({"message": "Portfolio created", "id": portfolio.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── VALUE STREAMS ────────────────
@app.route("/safe/value-streams", methods=["GET", "POST"])
def manage_value_streams():
    db = SessionLocal()
    try:
        if request.method == "GET":
            streams = db.query(SafeValueStream).all()
            return jsonify([{"id": s.id, "portfolio_id": s.portfolio_id, "name": s.name, "description": s.description} for s in streams])
        else:
            data = request.get_json()
            stream = SafeValueStream(
                portfolio_id=data["portfolio_id"],
                name=data["name"],
                description=data.get("description", "")
            )
            db.add(stream)
            db.commit()
            return jsonify({"message": "Value Stream created", "id": stream.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── ARTS ────────────────
@app.route("/safe/arts", methods=["GET", "POST"])
def manage_arts():
    db = SessionLocal()
    try:
        if request.method == "GET":
            arts = db.query(SafeART).all()
            return jsonify([{"id": a.id, "value_stream_id": a.value_stream_id, "name": a.name, "description": a.description} for a in arts])
        else:
            data = request.get_json()
            art = SafeART(
                value_stream_id=data["value_stream_id"],
                name=data["name"],
                description=data.get("description", "")
            )
            db.add(art)
            db.commit()
            return jsonify({"message": "ART created", "id": art.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── TEAMS ────────────────
@app.route("/safe/teams", methods=["GET", "POST"])
def manage_teams():
    db = SessionLocal()
    try:
        if request.method == "GET":
            teams = db.query(SafeTeam).all()
            return jsonify([{"id": t.id, "art_id": t.art_id, "name": t.name, "members": t.members} for t in teams])
        else:
            data = request.get_json()
            team = SafeTeam(art_id=data["art_id"], name=data["name"], members=data.get("members", ""))
            db.add(team)
            db.commit()
            return jsonify({"message": "Team created", "id": team.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── PROGRAM INCREMENTS ────────────────
@app.route("/safe/pis", methods=["GET", "POST"])
def manage_pis():
    db = SessionLocal()
    try:
        if request.method == "GET":
            pis = db.query(SafeProgramIncrement).all()
            return jsonify([{"id": pi.id, "art_id": pi.art_id, "name": pi.name, "start_date": str(pi.start_date), "end_date": str(pi.end_date)} for pi in pis])
        else:
            data = request.get_json()
            pi = SafeProgramIncrement(
                art_id=data["art_id"],
                name=data["name"],
                start_date=data["start_date"],
                end_date=data["end_date"]
            )
            db.add(pi)
            db.commit()
            return jsonify({"message": "Program Increment created", "id": pi.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ──────────────── EPICS, FEATURES, STORIES ────────────────
@app.route("/safe/epics", methods=["GET", "POST"])
def manage_epics():
    db = SessionLocal()
    try:
        if request.method == "GET":
            epics = db.query(SafeEpic).all()
            return jsonify([{"id": e.id, "portfolio_id": e.portfolio_id, "title": e.title, "description": e.description, "okr": e.okr} for e in epics])
        else:
            data = request.get_json()
            epic = SafeEpic(
                portfolio_id=data["portfolio_id"],
                title=data["title"],
                description=data.get("description", ""),
                okr=data.get("okr", "")
            )
            db.add(epic)
            db.commit()
            return jsonify({"message": "Epic created", "id": epic.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@app.route("/safe/features", methods=["GET", "POST"])
def manage_features():
    db = SessionLocal()
    try:
        if request.method == "GET":
            features = db.query(SafeFeature).all()
            return jsonify([{"id": f.id, "epic_id": f.epic_id, "title": f.title, "description": f.description} for f in features])
        else:
            data = request.get_json()
            feature = SafeFeature(
                epic_id=data["epic_id"],
                title=data["title"],
                description=data.get("description", "")
            )
            db.add(feature)
            db.commit()
            return jsonify({"message": "Feature created", "id": feature.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

@app.route("/safe/stories", methods=["GET", "POST"])
def manage_stories():
    db = SessionLocal()
    try:
        if request.method == "GET":
            stories = db.query(SafeStory).all()
            return jsonify([{"id": s.id, "feature_id": s.feature_id, "title": s.title, "description": s.description, "status": s.status} for s in stories])
        else:
            data = request.get_json()
            story = SafeStory(
                feature_id=data["feature_id"],
                title=data["title"],
                description=data.get("description", ""),
                status=data.get("status", "To Do")
            )
            db.add(story)
            db.commit()
            return jsonify({"message": "Story created", "id": story.id}), 201
    except SQLAlchemyError as e:
        db.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        db.close()

# ✔ Setup and register blueprints once
app.register_blueprint(agile_bp, url_prefix="/agile")
app.register_blueprint(scrum_bp, url_prefix="/scrum")
app.register_blueprint(kanban_bp, url_prefix="/kanban")
# =================== BACKGROUND WORK =====================
def background_log_maintenance():
    while True:
        try:
            remove_duplicate_lines()
            rotate_large_logs()
            delete_old_logs()
            scrub_sensitive_data()
        except Exception as e:
            logger.error(f"❌ Background job error: {e}")
        time.sleep(300)

def start_background_thread():
    t = threading.Thread(target=background_log_maintenance, daemon=True)
    t.start()

# ======================= MAIN ============================
if __name__ == "__main__":
    from logger import logger  # if you use it
    start_background_thread()
    app.run(host="0.0.0.0", port=4103, debug=False)
