import logging
import random
import re
import subprocess
from uuid import uuid4
from utils.yaml_writer import write_subnet_config
from datetime import datetime, timezone
from utils.yaml_writer import write_ec2_config, write_vpc_config
from sqlalchemy import create_engine, Column, Integer, String, DateTime, Text, func, Boolean, event
from sqlalchemy.orm import declarative_base, sessionmaker
import psycopg2

DB_URL = "postgresql://devopsbot:devopsbot@localhost:5432/devopsbot"
engine = create_engine(DB_URL)
SessionLocal = sessionmaker(bind=engine, autoflush=False, autocommit=False)
Base = declarative_base()

@event.listens_for(engine, "connect")
def set_postgres_utc(dbapi_connection, connection_record):
    if isinstance(dbapi_connection, psycopg2.extensions.connection):
        cursor = dbapi_connection.cursor()
        cursor.execute("SET TIME ZONE 'UTC'")
        cursor.close()

class AIAgentCase(Base):
    __tablename__ = "ai_agent_cases"
    __table_args__ = {'extend_existing': True}

    id = Column(Integer, primary_key=True, index=True)
    case_id = Column(String, unique=True, nullable=False)
    created_at = Column(DateTime(timezone=False), server_default=func.now())
    active = Column(Boolean, default=True)
    task_type = Column(String, nullable=True)

Base.metadata.create_all(bind=engine)

logger = logging.getLogger(__name__)

def detect_affirmative(text: str):
    return any(word in text.lower() for word in ["yes", "yep", "yeah", "sure", "go ahead", "of course", "please do"])

def detect_negative(text: str):
    return any(word in text.lower() for word in ["no", "nope", "not yet", "don't", "cancel"])

REQUIRED_PARAMS = ["region", "instance_type", "ami_id", "key_name", "subnet_id", "security_group"]
VPC_PARAMS = ["vpc_name", "cidr_block", "region"]
SUBNET_PARAMS = ["cidr_block", "availability_zone", "vpc_id", "region"]

VALID_REGIONS = [
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "eu-west-1", "eu-west-2", "eu-west-3", "eu-central-1",
    "ap-south-1", "ap-northeast-1", "ap-northeast-2", "ap-southeast-1", "ap-southeast-2",
    "ca-central-1", "sa-east-1"
]
VALID_INSTANCE_TYPES = [
    "t2.micro", "t2.small", "t2.medium", "t3.micro", "t3.small", "m5.large", "m5.xlarge"
]
AMI_ID_REGEX = r"^ami-[a-f0-9]{8,}$"
KEY_NAME_REGEX = r"^[a-zA-Z0-9\-_]+$"
SUBNET_ID_REGEX = r"^subnet-[a-f0-9]{8,}$"
SECURITY_GROUP_REGEX = r"^sg-[a-f0-9]{8,}$"
GREETINGS = [
    "👋 Hey there! How can I assist you today?",
    "🚀 Hello! Ready to create something awesome?",
    "😊 Hi! What can I help you with?",
    "🌟 Welcome! Let's get started.",
    "🌞 Good morning! How can I assist you?",
    "🌤️ Good afternoon! What's on your mind?",
    "🌙 Good evening! How can I help you?"
]
FAREWELLS = [
    "👋 Goodbye! Feel free to come back anytime.",
    "🚀 Thanks for using me! See you soon.",
    "😊 Take care! Let me know if you need anything else.",
    "🌟 Until next time! Have a great day.",
    "🙌 Thank you! It was a pleasure helping you."
]
SESSION_MEMORY = {}

def create_ai_case():
    db = SessionLocal()
    try:
        case_id = f"case-{uuid4().hex[:8]}"
        new_case = AIAgentCase(case_id=case_id, active=True)
        db.add(new_case)
        db.commit()
        return case_id
    finally:
        db.close()

def close_ai_case(case_id: str):
    db = SessionLocal()
    try:
        case = db.query(AIAgentCase).filter_by(case_id=case_id, active=True).first()
        if case:
            case.active = False
            db.commit()
            return True
        return False
    finally:
        db.close()

def get_active_ai_case():
    db = SessionLocal()
    try:
        case = db.query(AIAgentCase).filter_by(active=True).order_by(AIAgentCase.created_at.desc()).first()
        if case:
            created = case.created_at
            if created.tzinfo is None or created.tzinfo.utcoffset(created) is None:
                created = created.replace(tzinfo=timezone.utc)
            now = datetime.now(timezone.utc)
            if (now - created).total_seconds() < 300:
                return case.case_id
            else:
                case.active = False
                db.commit()
        return None
    finally:
        db.close()

def process_conversation(prompt: str):
    session_id = get_active_ai_case()

    if not session_id:
        if any(greet in prompt.lower() for greet in ["hi", "hello", "hey", "good morning", "good afternoon", "good evening"]):
            return {"response": random.choice(GREETINGS)}
        session_id = create_ai_case()
        SESSION_MEMORY[session_id] = {}
        return {
            "response": f"📂 I've opened a new case for you: {session_id}.\nPlease tell me what you'd like to do. For example, 'create EC2 instance' or 'create VPC'.\n📝 When you're done, type dob ai close case to close it."
        }

    memory = SESSION_MEMORY.setdefault(session_id, {})

    if any(word in prompt.lower() for word in ["thanks", "thank you", "bye", "goodbye"]):
        return {"response": random.choice(FAREWELLS)}

    if "dob ai close case" in prompt.lower():
        if session_id and close_ai_case(session_id):
            return {"response": f"✅ Your case {session_id} has been closed. Let me know if you need anything else!"}
        return {"response": "⚠️ No active case found to close."}

    if "ec2" in prompt.lower() and "task" not in memory:
        memory["task"] = "ec2"
        memory["ec2_stage"] = "collecting_params"
        return {"response": "🚀 Got it. You're creating an EC2 instance. What's your region?"}

    if "vpc" in prompt.lower() and "task" not in memory:
        memory["task"] = "vpc"
        memory["vpc_stage"] = "collecting_params"
        return {"response": "🧩 Got it. You're creating a VPC. What's your VPC name?"}

    if "subnet" in prompt.lower() and "task" not in memory:
        memory["task"] = "subnet"
        memory["subnet_stage"] = "collecting_params"
        return {"response": "🧩 Got it. You're creating a Subnet. What's the CIDR block?"}
    

    if "pending_correction" in memory:
        if detect_affirmative(prompt):
            corrected_value = memory.pop("pending_correction")
            current_param = get_next_param(memory)
            memory[current_param] = corrected_value
            next_param = get_next_param(memory)
            if next_param:
                return {"response": f"✅ Got {current_param}. What's your {next_param}?"}
        elif detect_negative(prompt):
            memory.pop("pending_correction")
            return {"response": "ℹ️ Please provide the correct value again."}
        else:
            return {"response": "ℹ️ Please confirm the correction with a yes or no."}

    # ───── EC2 Flow ─────
    if memory.get("task") == "ec2":
        # Parameter collection stage
        if memory.get("ec2_stage") == "collecting_params":
            current_param = get_next_param(memory)
            if current_param:
                value = extract_dynamic_value(prompt)
                if not value:
                    return {"response": f"ℹ️ Please provide a valid value for {current_param}."}
                
                validation_result = validate_parameter(current_param, value)
                if validation_result is True:
                    memory[current_param] = value
                elif isinstance(validation_result, str):
                    memory["pending_correction"] = validation_result
                    return {"response": f"❓ Did you mean {validation_result}? (yes/no)"}
                else:
                    return {"response": f"❌ Invalid value for {current_param}. Please try again."}

                next_param = get_next_param(memory)
                if next_param:
                    return {"response": f"✅ Got {current_param}. What's your {next_param}?"}
            
            # All parameters collected - move to tag decision
            if all(param in memory for param in REQUIRED_PARAMS):
                memory["ec2_stage"] = "asking_tags"
                return {"response": "🔗 Would you like to add tags to this EC2 instance?"}

        # Tag decision stage
        elif memory.get("ec2_stage") == "asking_tags":
            if detect_affirmative(prompt):
                memory["ec2_stage"] = "collecting_tags"
                memory["pending_tags"] = []
                return {"response": "🧷 Great! Please provide a tag in key=value format (e.g., env=production)."}
            elif detect_negative(prompt):
                memory["ec2_stage"] = "ready_for_yaml"
                memory["tags"] = []
                return handle_ec2_yaml_generation(memory)
            else:
                return {"response": "❌ Please answer with 'yes' or 'no'."}

        # Tag collection stage
        elif memory.get("ec2_stage") == "collecting_tags":
            if prompt.strip().lower() == "done":
                memory["ec2_stage"] = "ready_for_yaml"
                memory["tags"] = memory.get("pending_tags", [])
                return handle_ec2_yaml_generation(memory)
            
            tag_parts = prompt.strip().split("=")
            if len(tag_parts) == 2:
                memory.setdefault("pending_tags", []).append({
                    "Key": tag_parts[0].strip(),
                    "Value": tag_parts[1].strip()
                })
                return {"response": "✅ Tag added. Add more or type 'done' when finished."}
            else:
                return {"response": "❌ Invalid tag format. Please use key=value (e.g., env=production)."}

    # ───── VPC Flow ─────
    elif memory.get("task") == "vpc":
        # Parameter collection stage
        if memory.get("vpc_stage") == "collecting_params":
            for param in VPC_PARAMS:
                if param not in memory:
                    memory[param] = prompt.strip()
                    next_param = next((p for p in VPC_PARAMS if p not in memory), None)
                    if next_param:
                        return {"response": f"✅ Got {param}. What's your {next_param}?"}
                    else:
                        memory["vpc_stage"] = "asking_tags"
                        return {"response": "🔗 Would you like to add tags to this VPC?"}

        # Tag decision stage
        elif memory.get("vpc_stage") == "asking_tags":
            if detect_affirmative(prompt):
                memory["vpc_stage"] = "collecting_tags"
                memory["pending_tags"] = []
                return {"response": "🧷 Great! Please provide a tag in key=value format (e.g., env=production)."}
            elif detect_negative(prompt):
                memory["vpc_stage"] = "ready_for_yaml"
                memory["tags"] = []
                return handle_vpc_yaml_generation(memory)
            else:
                return {"response": "❌ Please answer with 'yes' or 'no'."}

        # Tag collection stage
        elif memory.get("vpc_stage") == "collecting_tags":
            if prompt.strip().lower() == "done":
                memory["vpc_stage"] = "ready_for_yaml"
                memory["tags"] = memory.get("pending_tags", [])
                return handle_vpc_yaml_generation(memory)
            
            tag_parts = prompt.strip().split("=")
            if len(tag_parts) == 2:
                memory.setdefault("pending_tags", []).append({
                    "Key": tag_parts[0].strip(),
                    "Value": tag_parts[1].strip()
                })
                return {"response": "✅ Tag added. Add more or type 'done' when finished."}
            else:
                return {"response": "❌ Invalid tag format. Please use key=value (e.g., env=production)."}

    elif memory.get("task") == "subnet":
        if memory.get("subnet_stage") == "collecting_params":
            for param in SUBNET_PARAMS:
                if param not in memory:
                    memory[param] = prompt.strip()
                    next_param = next((p for p in SUBNET_PARAMS if p not in memory), None)
                    if next_param:
                        return {"response": f"✅ Got {param}. What's your {next_param}?"}
                    else:
                        memory["subnet_stage"] = "asking_tags"
                        return {"response": "🔗 Would you like to add tags to this Subnet?"}
    
        elif memory.get("subnet_stage") == "asking_tags":
            if detect_affirmative(prompt):
                memory["subnet_stage"] = "collecting_tags"
                memory["pending_tags"] = []
                return {"response": "🧷 Great! Please provide a tag in key=value format (e.g., env=production)."}
            elif detect_negative(prompt):
                memory["subnet_stage"] = "ready_for_yaml"
                memory["tags"] = []
                return handle_subnet_yaml_generation(memory)
            else:
                return {"response": "❌ Please answer with 'yes' or 'no'."}
    
        elif memory.get("subnet_stage") == "collecting_tags":
            if prompt.strip().lower() == "done":
                memory["subnet_stage"] = "ready_for_yaml"
                memory["tags"] = memory.get("pending_tags", [])
                return handle_subnet_yaml_generation(memory)
    
            tag_parts = prompt.strip().split("=")
            if len(tag_parts) == 2:
                memory.setdefault("pending_tags", []).append({
                    "Key": tag_parts[0].strip(),
                    "Value": tag_parts[1].strip()
                })
                return {"response": "✅ Tag added. Add more or type 'done' when finished."}
            else:
                return {"response": "❌ Invalid tag format. Please use key=value (e.g., env=production)."}


    # ───── YAML Execution ─────
    if detect_affirmative(prompt) and "yaml_path" in memory:
        yaml_path = memory["yaml_path"]
        execution_result = execute_yaml_file(yaml_path)
        SESSION_MEMORY.pop(session_id)
        close_ai_case(session_id)
        return {"response": f"⏳ This may take a moment, please be patient...\n\n✅ Execution completed:\n{execution_result}"}

    if detect_negative(prompt) and "yaml_path" in memory:
        SESSION_MEMORY.pop(session_id)
        close_ai_case(session_id)
        return {"response": random.choice(FAREWELLS)}

    return {"response": "🤖 I'm here to help! Could you please clarify your request?"}

def handle_ec2_yaml_generation(memory):
    if "yaml_path" not in memory:
        yaml_path = write_ec2_config(memory)
        memory["yaml_path"] = yaml_path
        yaml_content = read_yaml_file(yaml_path)
        return {
            "response": f"✅ EC2 configuration complete. Here's your YAML:\n\n"
                       f"```yaml\n{yaml_content}\n```\n\n"
                       f"Would you like me to execute it now?"
        }

def handle_vpc_yaml_generation(memory):
    if "yaml_path" not in memory:
        yaml_path = write_vpc_config(memory)
        memory["yaml_path"] = yaml_path
        yaml_content = read_yaml_file(yaml_path)
        return {
            "response": f"✅ VPC configuration complete. Here's your YAML:\n\n"
                       f"```yaml\n{yaml_content}\n```\n\n"
                       f"Would you like me to execute it now?"
        }

def handle_subnet_yaml_generation(memory):
    if "yaml_path" not in memory:
        yaml_path = write_subnet_config(memory)
        memory["yaml_path"] = yaml_path
        yaml_content = read_yaml_file(yaml_path)
        return {
            "response": f"✅ Subnet configuration complete. Here's your YAML:\n\n"
                       f"```yaml\n{yaml_content}\n```\n\n"
                       f"Would you like me to execute it now?"
        }
def extract_dynamic_value(prompt: str) -> str:
    return prompt.strip() or None

def get_next_param(memory: dict):
    for param in REQUIRED_PARAMS:
        if param not in memory:
            return param
    return None

def validate_parameter(param: str, value: str):
    if param == "region":
        result = validate_and_correct_region(value)
        if result is True:
            return True
        elif isinstance(result, str):
            return result
        return False
    if param == "instance_type":
        if value in VALID_INSTANCE_TYPES:
            return True
        suggestions = [inst for inst in VALID_INSTANCE_TYPES if value.replace(".", "") in inst.replace(".", "")]
        return suggestions[0] if suggestions else False
    if param == "ami_id":
        return bool(re.match(AMI_ID_REGEX, value))
    if param == "key_name":
        return bool(re.match(KEY_NAME_REGEX, value))
    if param == "subnet_id":
        return bool(re.match(SUBNET_ID_REGEX, value))
    if param == "security_group":
        return bool(re.match(SECURITY_GROUP_REGEX, value))
    return False

def validate_and_correct_region(user_input: str):
    user_input = user_input.strip().lower()
    if user_input in VALID_REGIONS:
        return True
    normalized_input = user_input.replace("-", "")
    for region in VALID_REGIONS:
        if normalized_input == region.replace("-", ""):
            return region
    return None

def execute_yaml_file(yaml_path: str) -> str:
    try:
        result = subprocess.run(
            ["dob", "aws", "screenplay", yaml_path, "-y"],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True
        )
        return result.stdout
    except subprocess.CalledProcessError as e:
        return (
            f"❌ Execution failed: {e.stderr}\n"
            "💡 Troubleshooting Tips:\n"
            "- Ensure the YAML file is correct.\n"
            "- Check your AWS credentials and permissions.\n"
            "- Try running the command manually: `dob aws screenplay {yaml_path} -y`."
        )

def read_yaml_file(yaml_path: str) -> str:
    try:
        with open(yaml_path, "r") as file:
            return file.read()
    except Exception as e:
        return f"❌ Failed to read YAML file: {str(e)}"

