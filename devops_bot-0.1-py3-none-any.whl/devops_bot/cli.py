#first section

########################################
import os
import psutil
import json
import click
import platform
import sys
import traceback
import base64
import uuid
import boto3
import paramiko
import yaml
import logging
import re
import time
import requests
import subprocess
import copy
import crypt
import random
import string
import threading
import shutil
import smtplib
import concurrent.futures
import sqlite3
import zipfile
import importlib.util
import xml.etree.ElementTree as ET
import secrets
import botocore.exceptions


from flask import Flask

from xml.dom import minidom

from datetime import datetime, timedelta
from tabulate import tabulate
from botocore.exceptions import ClientError
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives.kdf.pbkdf2 import PBKDF2HMAC
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.ciphers import Cipher, algorithms, modes
from cryptography.hazmat.primitives import padding
from cryptography.hazmat.primitives.hashes import SHA256
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from botocore.exceptions import NoCredentialsError, PartialCredentialsError
from twilio.rest import Client
from croniter import croniter
from concurrent.futures import ThreadPoolExecutor, as_completed
from cryptography.fernet import Fernet
from click import echo, command, option
from requests.auth import HTTPBasicAuth
from kubernetes import client, config  # Kubernetes API interactions
from kubernetes.client.exceptions import ApiException
from xml.etree.ElementTree import Element, SubElement, ElementTree, parse

try:
    from importlib.resources import files  # For Python 3.9 and above
except ImportError:
    from importlib_resources import files 
@click.group()
def cli():
    pass


#second section 

BASE_DIR = os.path.expanduser("/etc/devops-bot")
AWS_CREDENTIALS_FILE = os.path.join(BASE_DIR, "aws_credentials.json")
KEY_FILE = os.path.join(BASE_DIR, "key.key")

###################################################
         ##aws screenplay #####

BUILD_FILE = os.path.join(BASE_DIR, "build_credentials.xml")
STATE_DIR = os.path.join(BASE_DIR, "state_files")
OUTPUT_STATE_DIR = os.path.join(BASE_DIR, "output_vars")
HOSTS_FILE = "/etc/hosts"
SSH_KEY_FILE = os.path.expanduser("~/.ssh/id_rsa.pub")
VARIABLES_FILE = os.path.join(BASE_DIR, "roost.dob")
DKS_TOKEN = os.path.join(BASE_DIR, "falcon.dob")
SWARM_TOKEN = os.path.join(BASE_DIR, "goose.dob")
TOKEN_FILE = os.path.join(BASE_DIR, "token")
REMOTE_METRICS_FILE = os.path.join(BASE_DIR, "turkey.dob")
ATTEMPTS_FILE = os.path.join(BASE_DIR, "password_attempts.json")
REMOTE_SSH_TRANSIT = os.path.join(BASE_DIR, "ostrich.dob")
CONTROL_PLANE_TOKEN = os.path.join(BASE_DIR, "crow.dob")
MASTER_CERTIFICATE = os.path.join(BASE_DIR, "macaw.dob")
ENC_KEY_FILE = os.path.join(BASE_DIR, "enc_key.key")
CONFIGS_FILE = os.path.join(BASE_DIR, "pigeon.dob")
ATTEMPTS_FILE = os.path.join(BASE_DIR, "password_attempts.json")
REMOTE_SSH_TRANSIT = os.path.join(BASE_DIR, "ostrich.dob")
JENKINS_CRUMB_URL = '/crumbIssuer/api/json'
JENKINS_TOKEN_URL = '/me/descriptorByName/jenkins.security.ApiTokenProperty/generateNewToken'
JENKINS_KEY_FILE = os.path.join(BASE_DIR, 'jenkins_key.key')
JENKINS_CREDENTIALS_FILE = os.path.join(BASE_DIR, 'jenkins_credentials.enc')
ALERT_CONFIG_FILE = os.path.join(BASE_DIR, "alert_config.json")
USER_DATA_DIR = os.path.join(BASE_DIR, "users_data")
KEY_FILE = os.path.join(BASE_DIR, "key.key")
K8S_CONFIG_FILE = os.path.join(BASE_DIR, "k8s_config.yaml")
K8S_KEY_FILE = os.path.join(BASE_DIR, "k8s_key.key")
DEVOPS_BOT_LOGS = os.path.join(BASE_DIR, "logs")
KEY_FILE_PATH = os.path.join(BASE_DIR, "enc_key.key")
LOG_FILE_PATH = os.path.join(DEVOPS_BOT_LOGS, "devops_bot.log")
SUBNET_OUTPUT = os.path.join(BASE_DIR, "subnet.dob")
#######################################

GCP_CREDENTIALS_FILE = os.path.join(BASE_DIR, "gcp_credentials.json")
AZURE_CREDENTIALS_FILE = os.path.join(BASE_DIR, "azure_credentials.json")
DO_CREDENTIALS_FILE = os.path.join(BASE_DIR, "do_credentials.json")
######################################################################
###################  extras  ###################

# Ensure the logs directory exists
os.makedirs(DEVOPS_BOT_LOGS, exist_ok=True)

# Define the log file path
LOG_FILE_PATH = os.path.join(DEVOPS_BOT_LOGS, "devops_bot.log")

# Configure logging
logging.basicConfig(
    filename=LOG_FILE_PATH,
    level=logging.DEBUG,  # Adjust log level for more detail
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)


# Get logger and add the handler
logger = logging.getLogger("DevOpsBot")
logger.info("Logging has been configured successfully.")
SALT_SIZE = 16  # Salt size in bytes
ITERATIONS = 100000  # Number of iterations for the key derivation

def ensure_folder(path):
    if not os.path.exists(path):
        os.makedirs(path)

# Ensure folders are created at startup
ensure_folder(BASE_DIR)





#section 3

#############################################################################################
                                     ##aws section###

# Generate a 32-byte encryption key
key = base64.urlsafe_b64encode(os.urandom(32)).decode('utf-8')
#print("Encryption Key:", key)

def save_key(key):
    ensure_folder(BASE_DIR)
    with open(KEY_FILE, 'w') as key_file:
        key_file.write(key)
    os.chmod(KEY_FILE, 0o600)  # Set file permissions to be readable and writable only by the owner

def get_key(password, salt):
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=100000,
        backend=default_backend()
    )
    return urlsafe_b64encode(kdf.derive(password.encode()))


def generate_key():
    key = base64.urlsafe_b64encode(os.urandom(32)).decode('utf-8')
    save_key(key)
    return key

# Ensure the key file is present or generate a new key if not
if not os.path.exists(KEY_FILE):
    generate_key()

def load_key():
    if not os.path.exists(KEY_FILE):
        raise FileNotFoundError("Encryption key not found.")
    with open(KEY_FILE, 'r') as key_file:
        return key_file.read()


def encrypt_data(data, key):
    fernet = Fernet(key.encode('utf-8'))
    encrypted = fernet.encrypt(data.encode('utf-8'))
    return encrypted

def decrypt_data(encrypted_data, key):
    fernet = Fernet(key.encode('utf-8'))
    decrypted = fernet.decrypt(encrypted_data)
    return decrypted.decode('utf-8')

def load_aws_credentials():
    if os.path.exists(AWS_CREDENTIALS_FILE):
        key = load_key()
        with open(AWS_CREDENTIALS_FILE, 'rb') as cred_file:
            encrypted_credentials = cred_file.read()
        decrypted_credentials = decrypt_data(encrypted_credentials, key)
        credentials = json.loads(decrypted_credentials)
        
        # Look for 'region_name' (since that's how it's saved) instead of 'region'
        if 'region_name' not in credentials:
            raise KeyError("'region_name' not found in AWS credentials. Please ensure the region is specified.")

        return {
            'aws_access_key_id': credentials['aws_access_key_id'],
            'aws_secret_access_key': credentials['aws_secret_access_key'],
            'region_name': credentials['region_name']  # Ensure region is loaded properly
        }
    else:
        # Request credentials from the user if not found
        click.echo("AWS credentials not found. Please provide them.")
        access_key = click.prompt('AWS Access Key ID')
        secret_key = click.prompt('AWS Secret Access Key')
        region = click.prompt('AWS Region')
        save_aws_credentials(access_key, secret_key, region)
        return load_aws_credentials()



def save_aws_credentials(access_key, secret_key, region):
    ensure_folder(BASE_DIR)
    key = load_key()
    credentials = {
        'aws_access_key_id': access_key,
        'aws_secret_access_key': secret_key,
        'region_name': region
    }
    encrypted_credentials = encrypt_data(json.dumps(credentials), key)
    with open(AWS_CREDENTIALS_FILE, 'wb') as cred_file:
        cred_file.write(encrypted_credentials)
    os.chmod(AWS_CREDENTIALS_FILE, 0o600)
    click.echo("AWS credentials encrypted and saved locally.")


def get_all_identifiers_in_category(category, data):
    """Retrieve all identifiers of servers in the given category."""
    identifiers = []
    for server in data.get('remote-server', []):
        if server.get('category') == category:
            identifiers.append(server.get('identifiers'))

    if not identifiers:
        raise ValueError(f"No servers found in category '{category}'")

    return identifiers


def add_host_entry(user_id, private_ip, category=None):
    """
    Adds a host entry with an optional category to the hosts file.
    
    :param user_id: The identifier for the user (e.g., instance name).
    :param private_ip: The private IP of the remote instance.
    :param category: The category or section where the entry should be saved (e.g., dev, prod). Defaults to None.
    """
    # Ensure the hosts file exists
    if not os.path.exists(HOSTS_FILE):
        with open(HOSTS_FILE, 'w') as f:
            f.write("# Hosts file created by DevOps tool\n")

    entry = f"{private_ip} {user_id}\n"
    
    # Read the existing content from the hosts file
    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    category_section_found = False
    new_lines = []

    # If a category is specified, find the section or create it
    if category:
        for line in lines:
            new_lines.append(line)
            if line.strip() == f"[{category}]":
                category_section_found = True

        if not category_section_found:
            # Add category section header if not found
            new_lines.append(f"\n[{category}]\n")
        
        # Ensure no duplicate entry is added
        if entry not in new_lines:
            new_lines.append(entry)
    else:
        # If no category is provided, add entry to the default section
        if entry not in lines:
            new_lines.append(entry)

    # Write the updated content back to the hosts file
    with open(HOSTS_FILE, 'w') as file:
        file.writelines(new_lines)

    click.echo(f"Added {user_id} with IP {private_ip} to {HOSTS_FILE} under {'default' if not category else category} category.")

def add_remote_metrics_entry(user_id, private_ip):
    """
    Adds an entry to the remote metrics file in plain text format.

    :param user_id: The identifier for the instance (e.g., instance name).
    :param private_ip: The private IP of the instance.
    """

    # Ensure the file exists
    if not os.path.exists(REMOTE_METRICS_FILE):
        with open(REMOTE_METRICS_FILE, 'w') as f:
            f.write("")  # Create an empty file if it doesn't exist

    # Read existing entries
    with open(REMOTE_METRICS_FILE, 'r') as file:
        lines = file.readlines()

    # Check for duplicates
    entry = f"{private_ip} {user_id}\n"
    if entry not in lines:
        lines.append(entry)
        # Write back updated entries in the desired order
        with open(REMOTE_METRICS_FILE, 'w') as file:
            file.writelines(lines)

        click.echo(f"Added {user_id} with IP {private_ip} to {REMOTE_METRICS_FILE}.")
    else:
        click.echo(f"Entry for {user_id} with IP {private_ip} already exists.")

def ssh_connect_test(hostname, username):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username)
        client.close()
        return True, "Connection successful"
    except Exception as e:
        return False, str(e)

def ensure_ssh_key():
    if not os.path.exists(SSH_KEY_FILE):
        click.echo(
            click.style(
                "SSH key not found. Generating SSH key...",
                fg="yellow"))
        os.system("ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ''")
        click.echo(click.style("SSH key generated.", fg="green"))


def generate_ssh_key():
    if not os.path.exists(SSH_KEY_FILE):
        subprocess.run(["ssh-keygen", "-t", "rsa", "-b", "2048", "-f", SSH_KEY_FILE[:-4], "-q", "-N", ""])

# Function to retrieve the SSH key content
def get_ssh_key():
    with open(SSH_KEY_FILE, 'r') as file:
        return file.read().strip()

# Function to execute the remote script
def prepare_user_data_script(ssh_key):
    return f"""#!/bin/bash
        # Define the SSH public key to be injected
        SSH_KEY="{ssh_key}"

        # Ensure the .ssh directory exists for the root user
        mkdir -p /root/.ssh

        # Add the SSH key to the root user's authorized_keys
        echo "$SSH_KEY" >> /root/.ssh/authorized_keys

        # Set appropriate permissions
        chmod 700 /root/.ssh
        chmod 600 /root/.ssh/authorized_keys
    """

def fetch_instance_details(instance_ids, credentials):
    ec2 = boto3.client('ec2', **credentials)
    max_retries = 10
    wait_time = 60

    for _ in range(max_retries):
        try:
            response = ec2.describe_instances(InstanceIds=instance_ids)
            all_running = True
            for reservation in response['Reservations']:
                for instance in reservation['Instances']:
                    if instance['State']['Name'] != 'running':
                        all_running = False
                        break
                if not all_running:
                    break
            if all_running:
                return response['Reservations']
            else:
                time.sleep(wait_time)  # Wait before retrying
        except ClientError as e:
            if e.response['Error']['Code'] == 'InvalidInstanceID.NotFound':
                time.sleep(wait_time)  # Wait before retrying
            else:
                raise e
    raise Exception(
        f"Instances {instance_ids} did not reach running state within the allotted time.")

def ensure_ssh_key():
    if not os.path.exists(SSH_KEY_FILE):
        click.echo(
            click.style(
                "SSH key not found. Generating SSH key...",
                fg="yellow"))
        os.system("ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ''")
        click.echo(click.style("SSH key generated.", fg="green"))

def save_subnet_info(subnet_name, subnet_id):
    """
    Save subnet information with the subnet name as the key and the subnet ID as the value.

    Args:
        subnet_name (str): The name of the subnet.
        subnet_id (str): The ID of the subnet.
    """
    if not os.path.exists(SUBNET_OUTPUT):
        with open(SUBNET_OUTPUT, 'w') as f:
            json.dump({}, f)  # Create an empty JSON file if it doesn't exist

    with open(SUBNET_OUTPUT, 'r') as f:
        existing_data = json.load(f)

    # Save the subnet information
    existing_data[subnet_name] = subnet_id

    with open(SUBNET_OUTPUT, 'w') as f:
        json.dump(existing_data, f, indent=4)
    click.echo(f"Subnet information saved: {subnet_name} -> {subnet_id}")


# Function to Retrieve Subnet Information
def get_subnet_info(subnet_name):
    """
    Retrieve subnet information by name from the file.

    Args:
        subnet_name (str): Name of the subnet to retrieve.

    Returns:
        str: Subnet ID if found, otherwise None.
    """
    if not os.path.exists(SUBNET_OUTPUT):
        click.echo(f"No subnet information file found at {SUBNET_OUTPUT}.")
        return None

    with open(SUBNET_OUTPUT, 'r') as f:
        existing_data = json.load(f)

    return existing_data.get(subnet_name)






###############################################################################################################

#section4

@click.group(invoke_without_command=True)
@click.option('--v', '--version', is_flag=True, help="Show version of the devops-bot tool.")
@click.option('--debug', is_flag=True, help="Enable debug mode to show full error tracebacks.")
@click.pass_context
def cli(ctx, v, debug):
    ctx.ensure_object(dict)
    ctx.obj['DEBUG'] = debug  # Store debug mode in the context

    if v:
        # Collect version details
        tool_version = "devops-bot, version 0.1"
        python_version = platform.python_version()
        os_info = platform.system()
        os_version = platform.release()

        # Display robust version information
        click.echo(f"{tool_version}\nPython Version: {python_version}\nOperating System: {os_info} {os_version}")
        ctx.exit()

    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())


@cli.command(name="run-ui", help="Run the UI for the screenplay.")
@click.option('--port', default=4102, help="Port to run the UI on.")
def run_ui(port):
    # Locate the app.py file dynamically
    try:
        ui_path = files("ui").joinpath("app.py")
        if not ui_path.exists():
            raise FileNotFoundError(f"UI entry point not found at: {ui_path}")
    except Exception as e:
        click.echo(f"Error locating UI: {e}", err=True)
        return

    os.environ["FLASK_APP"] = str(ui_path)
    click.echo(f"Starting the UI on port {port}...")
    subprocess.run(["flask", "run", "--host=0.0.0.0", f"--port={port}"], env=os.environ)


@cli.command(name="brood", help="Manage DevOps bot files.")
@click.option('--init', is_flag=True, help="Initialize the file structure.")
def brood(init):
    if init:
        initialize_files()  # Initialize files like pigeon.dob, etc.
        init_config_file()  # Initialize the pigeon.dob config file
    else:
        click.echo("No action specified. Use --init to initialize files.")

# List of filenames to be created
FILES = [
    "molt.dob", "roost.dob", "peacock.dob",
    "ostrich.dob", "crow.dob", "parrot.dob", 
    "pelican.dob", "falcon.dob", "pigeon.dob", "macaw.dob",
    "eagle.dob", "goose.dob", "turkey.dob"
]


def initialize_files():
    """
    Initialize necessary files in the BASE_DIR directory.
    """
    # Ensure the base directory exists
    os.makedirs(BASE_DIR, exist_ok=True)

    # Create each file in the base directory
    for file_name in FILES:
        file_path = os.path.join(BASE_DIR, file_name)
        if not os.path.exists(file_path):
            with open(file_path, 'w') as f:
                f.write("")  # Create an empty file
            click.echo(click.style(f"Created file: {file_path}", fg="green"))
        else:
            click.echo(click.style(f"File already exists: {file_path}", fg="yellow"))

def init_config_file():
    """
    Check if pigeon.dob configuration file exists. If not, create it with default values.
    If the file is empty or incomplete, write the template as well.
    """
    # Define the configuration file path
    CONFIGS_FILE = os.path.join(BASE_DIR, "pigeon.dob")

    # Check if the file exists and is non-empty
    if not os.path.exists(CONFIGS_FILE) or os.path.getsize(CONFIGS_FILE) == 0:
        click.echo(click.style(f"Configuration file {CONFIGS_FILE} not found or empty. Creating default template.", fg="yellow"))

        # Default configuration template
        config_template = """
# pigeon.dob

# Email Configuration (Gmail)
# Uncomment and update this section to enable email notifications
# email:
#   smtp_server: "smtp.gmail.com"  # SMTP server for Gmail
#   smtp_port: 587                 # SMTP port (default for Gmail)
#   sender_email: "your-email@gmail.com"  # Your Gmail address
#   sender_password: "your-app-password"  # App-specific password for security
#   default_recipients:             # Default recipients if not passed in tasks
#     - "recipient1@example.com"
#     - "recipient2@example.com"

# Email Configuration (Hotmail/Outlook)
# Uncomment and update this section to enable email notifications for Hotmail/Outlook
# email_hotmail:
#   smtp_server: "smtp-mail.outlook.com"  # SMTP server for Hotmail/Outlook
#   smtp_port: 587                       # SMTP port for Hotmail/Outlook
#   sender_email: "your-email@hotmail.com"  # Your Hotmail/Outlook address
#   sender_password: "your-password"       # Password for Hotmail/Outlook
#   default_recipients:                   # Default recipients if not passed in tasks
#     - "recipient1@example.com"
#     - "recipient2@example.com"

# AWS SNS Configuration
# Uncomment and update this section to enable SMS notifications via AWS SNS
# aws_sns:
#   default_recipients:             # Add your phone numbers here
#     - "+1234567890"               # Phone numbers must be in E.164 format

# Slack Notification Configuration
# Uncomment and update this section to enable Slack notifications
# slack:
#   webhook_url: "https://hooks.slack.com/services/your/slack/webhook/url"  # Replace with your actual webhook URL

# Twilio Configuration for SMS (Optional, uncomment if using Twilio for SMS)
# twilio:
#   account_sid: "your_twilio_account_sid"
#   auth_token: "your_twilio_auth_token"
#   from_number: "+1234567890"       # Your Twilio number
#   default_recipients:              # Phone numbers for SMS notifications
#     - "+1234567890"                # Add numbers in E.164 format
        """

        # Write the template to the configuration file
        with open(CONFIGS_FILE, 'w') as config_file:
            config_file.write(config_template.strip())

        click.echo(click.style(f"Default configuration file created at {CONFIGS_FILE}. Please update it.", fg="green"))
    else:
        click.echo(click.style(f"Configuration file {CONFIGS_FILE} already exists and is not empty.", fg="green"))


@cli.command(name="check-nodes", help="Check if the DevOps bot can connect to the node.")
@click.argument('identifier')
@click.option('--username', '-u', required=True, help="SSH username for the instance (short: -u).")
def check_nodes(identifier, username):
    """
    This command checks if the DevOps bot can successfully connect to a node using SSH.
    """
    try:
        private_ip, _ = get_host_entry(identifier)
        success, message = ssh_connect_test(private_ip, username)
        if success:
            click.echo(f"Connection to {identifier} ({private_ip}) is successful.")
        else:
            click.echo(f"Failed to connect to {identifier} ({private_ip}): {message}")
    except ValueError as ve:
        click.echo(str(ve))

###################################################################

def execute_imperative_command(provider, command_name, *args):
    """Execute a command from the imperative bytecode package."""
    pyc_path = os.path.join(BASE_DIR, "imperative_packages", provider, "__pycache__", f"{command_name}.cpython-310.pyc")

    if not os.path.exists(pyc_path):
        click.echo(f"Command {command_name} not found for provider {provider}.")
        return

    # Load and execute the bytecode
    module_name = f"{provider}_{command_name}_module"
    spec = importlib.util.spec_from_file_location(module_name, pyc_path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    # Call the main function within the bytecode command
    if hasattr(module, 'main'):
        module.main(*args)
    else:
        click.echo(f"Command {command_name} does not have a 'main' function.")

def ensure_aws_credentials():
    """Ensure AWS credentials are available, else prompt the user to configure them."""
    if not os.path.exists(AWS_CREDENTIALS_FILE):
        click.echo("AWS credentials not found. Let's configure them.")
        aws_access_key = click.prompt('AWS Access Key ID')
        aws_secret_key = click.prompt('AWS Secret Access Key')
        region = click.prompt('AWS Region')
        save_aws_credentials(aws_access_key, aws_secret_key, region)
    else:
        return load_aws_credentials()



########################################################################################################################
                                             ##aws section##


@cli.group(help="Commands to manage AWS resources.")
def aws():
    pass

# Add the config subcommand to the AWS group
@aws.command(name="config", help="Configure AWS credentials for the DevOps-bot tool.")
@click.option('--ak', '--access_key', 'aws_access_key_id', required=True, help="AWS Access Key ID")
@click.option('--sk', '--secret_key', 'aws_secret_access_key', required=True, help="AWS Secret Access Key")
@click.option('--r', '--region', 'region', required=True, help="AWS Region")
@click.pass_context
def aws_config(ctx, aws_access_key_id, aws_secret_access_key, region):
    try:
        save_aws_credentials(aws_access_key_id, aws_secret_access_key, region)
        click.echo("AWS credentials configured successfully.")
    except Exception as e:
        handle_error(ctx, e)

@aws.command(name="configure-ssh", help="Configure SSH access on the remote instance and save the host entry.")
@click.option('--ip', '-i', required=True, help="Private IP address of the remote instance (short: -i).")
@click.option('--user', '-u', required=True, help="SSH username for the instance (short: -u).")
@click.argument('ssh_key_path', type=click.Path(exists=True))
@click.option('--identifier', '-id', required=True, help="Identifier for the instance to save in hosts (short: -id).")
def configure_ssh(ip, user, ssh_key_path, identifier):
    """
    Configure SSH access and save the host entry for the instance.
    """
    try:
        # Call the function to configure SSH access using provided key and user
        success, message = configure_ssh_access(ip, user, ssh_key_path)
        if success:
            click.echo(f"SSH configuration on {identifier} ({ip}) is successful: {message}")

            # Save the host entry after successful SSH configuration
            add_host_entry(identifier, ip)
            click.echo(f"Host entry for {identifier} ({ip}) added successfully.")
        else:
            click.echo(f"Failed to configure SSH on {identifier} ({ip}): {message}")
    except Exception as e:
        click.echo(f"Error occurred during SSH configuration: {str(e)}")

def configure_ssh_access(hostname, username, ssh_key_path):
    try:
        ssh_key = open(ssh_key_path).read().strip()
        permission_script = f"""
        #!/bin/bash
        USERNAME="{username}"
        SSH_KEY="{ssh_key}"
        SSHD_CONFIG="/etc/ssh/sshd_config"
        sudo sed -i 's/^#\\?\\(PermitRootLogin\\s*\\).*$/\\1 yes/' $SSHD_CONFIG
        sudo sed -i 's/^#\\?\\(PasswordAuthentication\\s*\\).*$/\\1 yes/' $SSHD_CONFIG
        sudo sed -i 's/^#\\?\\(PubkeyAuthentication\\s*\\).*$/\\1 yes/' $SSHD_CONFIG
        if systemctl status sshd >/dev/null 2>&1; then
            sudo systemctl restart sshd
        elif systemctl status ssh >/dev/null 2>&1; then
            sudo systemctl restart ssh
        else:
            echo "Failed to restart SSH service: Unit sshd or ssh not found."
        fi
        AUTHORIZED_KEYS="$HOME/.ssh/authorized_keys"
        mkdir -p $HOME/.ssh
        if ! grep -Fxq "$SSH_KEY" $AUTHORIZED_KEYS; then
            echo "$SSH_KEY" >> $AUTHORIZED_KEYS
            echo "SSH key added to $AUTHORIZED_KEYS"
        else:
            echo "Provided SSH key already exists in $AUTHORIZED_KEYS"
        fi
        chmod 700 $HOME/.ssh
        chmod 600 $AUTHORIZED_KEYS
        echo "Configuration complete. {username} can now SSH into this account using the provided key."
        """

        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username, key_filename=ssh_key_path)

        stdin, stdout, stderr = client.exec_command(permission_script)
        stdout.channel.recv_exit_status()

        output = stdout.read().decode()
        error = stderr.read().decode()

        client.close()

        if error:
            return False, error
        else:
            return True, output

    except Exception as e:
        return False, str(e)


def replace_placeholders(data, outputs):
    """
    Replace placeholders in the YAML configuration with actual values.
    :param data: Original YAML data with placeholders.
    :param outputs: Dictionary of actual values to replace placeholders.
    :return: Updated YAML data with placeholders replaced.
    """
    if isinstance(data, dict):
        return {k: replace_placeholders(v, outputs) for k, v in data.items()}
    elif isinstance(data, list):
        return [replace_placeholders(item, outputs) for item in data]
    elif isinstance(data, str) and data.startswith("${") and data.endswith("}"):
        # Extract the placeholder name (e.g., ${vpc_id} -> vpc_id)
        placeholder = data[2:-1]
        # Replace with actual value if exists in outputs
        return outputs.get(placeholder, data)
    else:
        return data

def execute_task(task, loop_item=None):
    # Implement the logic to execute tasks, handling loops and conditions
    pass


def resolve_dependencies_and_outputs(data, execution_id, credentials):
    """
    Resolve dependencies between resources and dynamically substitute output values.

    :param data: The entire resource configuration data from the YAML file.
    :param execution_id: The execution ID for this configuration.
    :param credentials: AWS credentials for creating resources.
    :return: Updated data with substituted values for dependencies.
    """
    # Initialize a dictionary to hold resource outputs (e.g., VPC ID, Subnet ID)
    resource_outputs = {}

# Initialize summary tracker
summary = {
    'installed': 0,
    'already_installed': 0,
    'created': 0,
    'already_exists': 0,
    'deleted': 0,
    'moved': 0,
    'copied': 0,
    'downloaded': 0,
    'started_service': 0,
    'stopped_service': 0,
    'service_status_checked': 0,
    'transferred': 0,
    'attached': 0,
    'aborted': 0,
    'detached': 0,
    'completed': 0,
    'failed': 0,
    'uploaded': 0,
    'other': 0,
    'skipped': 0
}

                                       ###############aws screenplay#####################
@aws.command(name="screenplay", help="Create EC2 instances, S3 buckets, and/or execute tasks on remote instances listed in /etc/hosts.")
@click.argument('screenplay', type=click.Path(exists=True), required=False)
@click.option('--identifier', '-id', required=False, help="Instance identifier (short: -id)")
@click.option('--username', '-u', required=False, help="SSH username for the instance (short: -u)")
@click.option('--create-remote', '--cr', is_flag=True, help="Inject SSH key into the newly created EC2 instance (short: --cr).")
@click.option('--add-remote', '--ar', is_flag=True, help="Save instance IPs and names to /etc/hosts (short: --ar)")
@click.option('--command', '-c', required=False, help="Command to execute on the instance (short: -c)")
@click.option('--yes', '-y', is_flag=True, help="Automatic yes to prompts (short: -y)")
@click.pass_context  # Pass the Click context object
@click.option('--ver', '-v', required=False, type=click.Path(exists=True), help="Path to an alternate variables file (short: -v)")
@click.option('--environment', '-e', required=False, help="Specify the environment (e.g., dev, test, prod) (short: -e)")
@click.option('--remote-ver', '--rv', required=False, help="URL to an alternate variables file (short: --rv)")
@click.option('--password', '-p', required=False, help="Password for decrypting sensitive variables (short: -p)")
@click.option('--show', '-s', is_flag=True, help="Show sensitive variable values during execution for debugging (short: -s).")
@click.option('--required-keys-file', '--rk', required=False, type=click.Path(exists=True), help="Path to a file containing a list of required keys for validation (short: --rk)")
@click.option('--add-remote-category', '--arc', required=False, help="Specify the category where the host entry should be added (e.g., dev, prod). Defaults to general.")
@click.option('--remote-config', '--rc', required=False, help="URL to a remote YAML config file (short: --rc)")
@click.option('--add-remote-metrics', '--arm', is_flag=True, 
              help="Add instance details to the remote metrics file (short: --arm)")
@click.option('--set', '-s', multiple=True, help="Override variables directly from the command line in the format key=value. Example: --set region=us-west-2 instance_type=t2.micro (short: -s)")
def screenplay(ctx, screenplay, identifier, add_remote_metrics,  username, command, create_remote, ver, remote_ver, show, password, remote_config, add_remote_category, required_keys_file, environment, set, add_remote, reuse_id=None, yes=False):
    global output_variables
    resource_outputs = {}

    execution_id = reuse_id if reuse_id else str(uuid.uuid4())
    state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')
    state_exicution_path = os.path.join(STATE_DIR, f'{execution_id}.yml')
    table_data = []

    if remote_config:
        data = load_remote_yaml(remote_config)
    elif screenplay:
        if screenplay.endswith('.yaml') or screenplay.endswith('.yml'):
            with open(screenplay, 'r') as yaml_file:
                data = yaml.safe_load(yaml_file)

        if remote_ver:
            variables = load_remote_variables(remote_ver)
        else:
            variables_file = ver if ver else VARIABLES_FILE
            variables = load_variables(variables_file)

        if password:
            variables = decrypt_sensitive_variables(variables, password, show_sensitive=show)

        if environment:
            variables = load_environment_variables(variables, environment)
        else:
            environment_variables = {}

        command_line_overrides = parse_command_line_overrides(set)
        variables = override_variables(variables, environment_variables, command_line_overrides)
        variables = interpolate_variables(variables)

        required_keys = None
        if required_keys_file:
            with open(required_keys_file, 'r') as file:
                required_keys = yaml.safe_load(file)

        if not validate_and_lint(variables, required_keys):
            print("Validation or linting failed. Please resolve the errors and try again.")
            return

        if 'conditions' in data:
            for condition_name, condition in data['conditions'].items():
                result = eval_condition(condition)
                data['conditions'][condition_name]['result'] = result

        if 'resources' in data:
            for resource_type, resources in data['resources'].items():
                data['resources'][resource_type] = process_loops_and_conditions(resources, variables)

        if 'tasks' in data:
            for task in data['tasks']:
                if 'loop' in task:
                    for item in task['loop']:
                        execute_task(task, item)
                else:
                    execute_task(task)

        data = resolve_variables(data, variables)
#####################################final review table  #################################
    
        # Handle VPC creation
        if 'resources' in data and 'vpcs' in data['resources']:
            for idx, vpc in enumerate(data['resources']['vpcs']):
                #click.echo(f"Processing VPC: {vpc}")
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="blue"), "VPC", f"VPC {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="blue"), "CIDR Block", vpc['cidr_block']],
                    [click.style("+", fg="blue"), "Region", vpc.get('region', 'Not specified')],
                ])
                if 'tags' in vpc:
                    table_data.append([click.style("+", fg="blue"), "Tags", vpc['tags']])
    
        # Handle subnet creation
        if 'resources' in data and 'subnets' in data['resources']:
            for idx, subnet in enumerate(data['resources']['subnets']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "Subnet", f"Subnet {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "VPC ID", subnet['vpc_id']],
                    [click.style("+", fg="cyan"), "CIDR Block", subnet['cidr_block']],
                    [click.style("+", fg="cyan"), "Availability Zone", subnet['availability_zone']],
                    [click.style("+", fg="cyan"), "Tags", subnet.get('tags', [])],
                ])
                
    
                # Ensure the region is provided
                region = subnet.get('region')
                if not region:
                    raise ValueError("Region is required for creating a subnet.")
                    
    
        # Handle internet gateway creation
        if 'resources' in data and 'internet_gateways' in data['resources']:
            for idx, ig in enumerate(data['resources']['internet_gateways']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="cyan"), "Internet Gateway", f"Internet Gateway {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "VPC ID", ig['vpc_id']],
                    [click.style("+", fg="cyan"), "Region", ig.get('region', 'Not specified')],
                ])
                for tag in ig.get('tags', []):
                    table_data.append([click.style("+", fg="cyan"), "Tag", f"{tag['Key']} = {tag['Value']}"])
                    
    
         # Route table creation section
        if 'resources' in data and 'route_tables' in data['resources']:
            credentials = load_aws_credentials()
            for idx, route_table in enumerate(data['resources']['route_tables']):
                region = route_table.get('region')
                if not region:
                    raise ValueError("Region is required for creating a route table.")
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "Route Table", f"Route Table {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "VPC ID", route_table['vpc_id']],
                    [click.style("+", fg="magenta"), "Routes", route_table['routes']],
                    [click.style("+", fg="magenta"), "Tags", route_table.get('tags', [])]
                ])
                
    
    
    
        # Handle security group creation
        if 'resources' in data and 'security_groups' in data['resources']:
            for idx, sg in enumerate(data['resources']['security_groups']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "Security Group", f"Security Group {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Group Name", sg['name']],
                    [click.style("+", fg="magenta"), "Description", sg['description']],
                    [click.style("+", fg="magenta"), "VPC ID", sg['vpc_id']],
                    [click.style("+", fg="magenta"), "Region", sg.get('region', 'Not specified')],
                ])
                for rule in sg.get('inbound_rules', []):
                    table_data.append([click.style("+", fg="magenta"), "Inbound Rule", f"{rule['protocol']} {rule['port_range']} {rule['cidr_blocks']}"])
                    
    
        # Elastic IP creation section
        if 'resources' in data and 'elastic_ips' in data['resources']:
            for idx, eip in enumerate(data['resources']['elastic_ips']):
                table_data.append([click.style("+", fg="magenta"), "Elastic IP", f"Elastic IP {idx+1}"])
    
                # Prepare the details for the Elastic IP
                table_data.extend([
                    [click.style("+", fg="magenta"), "Domain", eip['domain']],
                    [click.style("+", fg="magenta"), "Region", eip.get('region', 'Not specified')],
                    [click.style("+", fg="magenta"), "Tags", eip.get('tags', [])]
                ])
                
                # Add Instance ID if it exists
                if 'instance_id' in eip:
                    eip_details.insert(1, [click.style("+", fg="magenta"), "Instance ID", eip['instance_id']])
    
        # NAT Gateway creation section (collecting data for final review)
        if 'resources' in data and 'nat_gateways' in data['resources']:
            for idx, nat_gw in enumerate(data['resources']['nat_gateways']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "NAT Gateway", f"NAT Gateway {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Subnet ID", nat_gw['subnet_id']],
                    [click.style("+", fg="magenta"), "Allocation ID", nat_gw['allocation_id']],
                    [click.style("+", fg="magenta"), "Tags", nat_gw.get('tags', [])]
                ])
    
    
        # EC2 creation section
        if 'resources' in data and 'ec2_instances' in data['resources']:
            for idx, resource in enumerate(data['resources']['ec2_instances']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="green"), "EC2 Instance", f"Instance {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "Instance Type", resource['instance_type']],
                    [click.style("+", fg="green"), "AMI ID", resource['ami_id']],
                    [click.style("+", fg="green"), "Key Name", resource['key_name']],
                    [click.style("+", fg="green"), "Security Group", resource['security_group']],
                    [click.style("+", fg="green"), "Region", resource.get('region', 'us-east-1')]
                ])
                
                optional_params = [
                    ('Tags', 'tags'),
                    ('Subnet ID', 'subnet_id'),
                    ('IAM Role', 'iam_instance_profile'),
                    ('Block Device Mappings', 'block_device_mappings'),
                    ('Monitoring', 'monitoring'),
                    ('Instance Initiated Shutdown Behavior', 'instance_initiated_shutdown_behavior'),
                    ('Private IP Address', 'private_ip_address'),
                    ('Elastic IP Allocation ID', 'elastic_ip_allocation_id'),
                    ('Count', 'count'),
                    ('User Data', 'user_data')
                ]
                
                for label, key in optional_params:
                    if key in resource:
                        table_data.append([click.style("+", fg="green"), label, resource[key]])
    
         # Load Balancers (depends on Subnets, Security Groups)
        if 'resources' in data and 'load_balancers' in data['resources']:
            for idx, lb_data in enumerate(data['resources']['load_balancers']):
                table_data.append(["", "", ""])
                # Append load balancer details to table_data for final review
                table_data.append([click.style("+", fg="green"), "Load Balancer", f"Load Balancer {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "Name", lb_data['name']],
                    [click.style("+", fg="green"), "Type", lb_data.get('type', 'application')],
                    [click.style("+", fg="green"), "Subnets", lb_data.get('subnets', [])],
                    [click.style("+", fg="green"), "Security Groups", lb_data.get('security_groups', [])],
                    [click.style("+", fg="green"), "Scheme", lb_data.get('scheme', 'internet-facing')],
                    [click.style("+", fg="green"), "Region", lb_data.get('region', 'Not specified')],
                    [click.style("+", fg="green"), "Tags", lb_data.get('tags', [])],
                ])
                
    
        # Process EKS Clusters
        if 'resources' in data and 'eks_clusters' in data['resources']:
            credentials = load_aws_credentials()
            for idx, eks_cluster in enumerate(data['resources']['eks_clusters']):
                region = eks_cluster.get('region')
                if not region:
                    raise ValueError("Region is required for creating an EKS cluster.")
    
                kubernetes_version = eks_cluster.get('version', '1.24')  # Default to 1.24 or another supported version
    
                # Check if 'resources_vpc_config' and necessary keys exist
                vpc_config = eks_cluster.get('resources_vpc_config')
                if not vpc_config or not vpc_config.get('subnetIds'):
                    raise ValueError(f"'subnetIds' key is missing for EKS Cluster {eks_cluster.get('name', 'Unnamed Cluster')}.")
    
                subnets = vpc_config.get('subnetIds')
                security_groups = vpc_config.get('securityGroupIds', [])
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="cyan"), "EKS Cluster", f"EKS Cluster {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "Name", eks_cluster['name']],
                    [click.style("+", fg="cyan"), "Role ARN", eks_cluster['role_arn']],
                    [click.style("+", fg="cyan"), "Kubernetes Version", kubernetes_version],
                    [click.style("+", fg="cyan"), "Subnets", subnets],
                    [click.style("+", fg="cyan"), "Security Groups", security_groups],
                ])
                
    
        # Process EKS Node Groups
        if 'resources' in data and 'eks_nodegroups' in data['resources']:
            credentials = load_aws_credentials()
            for idx, eks_node_group in enumerate(data['resources']['eks_nodegroups']):
                region = eks_node_group.get('region', eks_node_group.get('region', 'us-east-1'))
                eks_client = boto3.client('eks', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                table_data.append(["", "", ""])
                # Displaying Node Group details for final review
                table_data.append([click.style("+", fg="cyan"), "EKS Node Group", f"Node Group {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "Cluster Name", eks_node_group['clusterName']],
                    [click.style("+", fg="cyan"), "Node Role", eks_node_group['nodeRole']],
                    [click.style("+", fg="cyan"), "Subnets", eks_node_group['subnets']],
                    [click.style("+", fg="cyan"), "Instance Types", eks_node_group['instanceTypes']],
                    [click.style("+", fg="cyan"), "Scaling Config", eks_node_group['scalingConfig']],
                    [click.style("+", fg="cyan"), "Tags", eks_node_group.get('tags', [])],
                ])
                
        # RDS Subnet Group creation and review table section
        if 'resources' in data and 'rds_subnet_groups' in data['resources']:
            for idx, rds_subnet_group in enumerate(data['resources']['rds_subnet_groups']):
                # Collect data for the final review table
                table_data.append([click.style("+", fg="green"), "RDS Subnet Group", f"RDS Subnet Group {idx + 1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "DB Subnet Group Name", rds_subnet_group.get('db_subnet_group_name', 'Not specified')],
                    [click.style("+", fg="green"), "Description", rds_subnet_group.get('description', 'Not specified')],
                    [click.style("+", fg="green"), "Subnets", ', '.join(rds_subnet_group.get('subnet_ids', [])) or 'Not specified'],
                    [click.style("+", fg="green"), "Region", rds_subnet_group.get('region', 'Not specified')],
                ])
                table_data.append(["", "", ""])
    
                # Tags handling (if defined)
                if 'tags' in rds_subnet_group:
                    tags = ', '.join([f"{tag['Key']}={tag['Value']}" for tag in rds_subnet_group['tags']])
                    table_data.append([click.style("+", fg="green"), "Tags", tags])
    
        # RDS instance creation section
        if 'resources' in data and 'rds_instances' in data['resources']:
            for idx, rds_instance in enumerate(data['resources']['rds_instances']):
                # Collect data for the final review
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="green"), "RDS Instance", f"RDS Instance {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "DB Instance Identifier", rds_instance.get('db_instance_identifier', 'Not specified')],
                    [click.style("+", fg="green"), "DB Instance Class", rds_instance.get('db_instance_class', 'Not specified')],
                    [click.style("+", fg="green"), "Engine", rds_instance.get('engine', 'Not specified')],
                    [click.style("+", fg="green"), "Engine Version", rds_instance.get('engine_version', 'Not specified')],
                    [click.style("+", fg="green"), "Master Username", rds_instance.get('master_username', 'Not specified')],
                    [click.style("+", fg="green"), "Master User Password", '******' if 'master_user_password' in rds_instance else 'Not specified'],
                    [click.style("+", fg="green"), "Allocated Storage", rds_instance.get('allocated_storage', 'Not specified')],
                    [click.style("+", fg="green"), "DB Name", rds_instance.get('db_name', 'Not specified')],
                    [click.style("+", fg="green"), "Multi-AZ", rds_instance.get('multi_az', 'Not specified')],
                    [click.style("+", fg="green"), "Backup Retention Period", rds_instance.get('backup_retention_period', 'Not specified')],
                    [click.style("+", fg="green"), "Publicly Accessible", rds_instance.get('publicly_accessible', 'Not specified')],
                    [click.style("+", fg="green"), "Security Groups", ', '.join(rds_instance.get('vpc_security_group_ids', [])) or 'Not specified'],
                    [click.style("+", fg="green"), "Subnet Group Name", rds_instance.get('db_subnet_group_name', 'Not specified')],
                    [click.style("+", fg="green"), "Region", rds_instance.get('region', 'Not specified')],
                ])
                # Tags handling
                if 'tags' in rds_instance:
                    tags = ', '.join([f"{tag['Key']}={tag['Value']}" for tag in rds_instance['tags']])
                    table_data.append([click.style("+", fg="green"), "Tags", tags])
    
                # Endpoint (optional, if available)
                if 'endpoint' in rds_instance:
                    endpoint = rds_instance['endpoint']
                    table_data.append([click.style("+", fg="green"), "Endpoint", endpoint])
    
                # Storage Type (optional, if available)
                if 'storage_type' in rds_instance:
                    storage_type = rds_instance['storage_type']
                    table_data.append([click.style("+", fg="green"), "Storage Type", storage_type])
    
                # Ensure the region is provided
                region = rds_instance.get('region')
                if not region:
                    raise ValueError("Region is required for creating an RDS instance.")
    
    
        # Network Interface creation section (collecting data for final review)
        if 'resources' in data and 'network_interfaces' in data['resources']:
            for idx, network_interface in enumerate(data['resources']['network_interfaces']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="cyan"), "Network Interface", f"Network Interface {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "Subnet ID", network_interface['subnet_id']],
                    [click.style("+", fg="cyan"), "Description", network_interface.get('description', 'Not specified')],
                    [click.style("+", fg="cyan"), "Security Groups", network_interface.get('groups', [])],
                    [click.style("+", fg="cyan"), "Tags", network_interface.get('tags', [])],
                ])
                
    
        # Listener creation section
        if 'resources' in data and 'listeners' in data['resources']:
            credentials = load_aws_credentials()
            for idx, listener in enumerate(data['resources']['listeners']):
                region = listener.get('region')
                if not region:
                    raise ValueError("Region is required for creating a Listener.")
    
                # Append listener details to table_data for final review
                table_data.append([click.style("+", fg="cyan"), "Listener", f"Listener {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="cyan"), "Load Balancer ARN", listener['load_balancer_arn']],
                    [click.style("+", fg="cyan"), "Protocol", listener['protocol']],
                    [click.style("+", fg="cyan"), "Port", listener['port']],
                    [click.style("+", fg="cyan"), "Target Group ARN", listener.get('target_group_arn')],
                    [click.style("+", fg="cyan"), "SSL Certificate ARN", listener.get('ssl_certificate_arn')],
                    [click.style("+", fg="cyan"), "Action Type", listener.get('action_type', 'forward')],
                    [click.style("+", fg="cyan"), "Region", listener.get('region', 'Not specified')],
                ])
                table_data.append(["", "", ""])
    
    
        #target group
        if 'resources' in data and 'target_groups' in data['resources']:
            credentials = load_aws_credentials()
            for idx, tg in enumerate(data['resources']['target_groups']):
                name = tg.get('name')
                vpc_id = tg.get('vpc_id')
                protocol = tg.get('protocol', 'HTTP')  # Default to HTTP if not provided
                port = tg.get('port', 80)  # Default to port 80 if not provided
                target_type = tg.get('target_type', 'instance')  # Default to 'instance' if not provided
                health_check_protocol = tg.get('health_check_protocol', protocol)
                health_check_port = tg.get('health_check_port', port)
                tags = tg.get('tags', [])
                region = tg.get('region')
                if not name or not vpc_id or not region:
                    raise ValueError("Target Group name, VPC ID, and Region are required parameters.")
                table_data.append(["", "", ""])
    
                # Append target group details to table_data for final review
                table_data.append([click.style("+", fg="green"), "Target Group", f"Target Group {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "Name", tg['name']],
                    [click.style("+", fg="green"), "Protocol", tg['protocol']],
                    [click.style("+", fg="green"), "Port", tg['port']],
                    [click.style("+", fg="green"), "VpcId", tg['vpc_id']],
                    [click.style("+", fg="green"), "Health Check Protocol", tg['health_check_protocol']],
                    [click.style("+", fg="green"), "Health Check Port", tg['health_check_port']],
                    [click.style("+", fg="green"), "Target Type", tg.get('target_type', 'instance')],  # Default to 'instance'
                    [click.style("+", fg="green"), "Region", region],
                    [click.style("+", fg="green"), "Tags", tg.get('tags', [])],
                ])
                
    
        # Register targets section
        if 'resources' in data and 'target_registrations' in data['resources']:
            credentials = load_aws_credentials()
            for idx, target_registration in enumerate(data['resources']['target_registrations']):
    
    
                # Append registration details to table_data for final review
                table_data.append([click.style("+", fg="green"), "Target Registration", f"Registration {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "Target Group ARN", target_registration['target_group_arn']],
                    [click.style("+", fg="green"), "Targets", ', '.join(target_registration['targets'])],
                    [click.style("+", fg="green"), "Region", target_registration.get('region', 'Not specified')],
                ])
                table_data.append(["", "", ""])
    
        #s3 bucket
        if 'resources' in data and 's3_buckets' in data['resources']:
            for idx, bucket in enumerate(data['resources']['s3_buckets']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="yellow"), "S3 Bucket", f"Bucket {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="yellow"), "Bucket Name", bucket['bucket_name']],  # Required
                    [click.style("+", fg="yellow"), "Region", bucket.get('region', 'Not specified')],  # Optional
                    [click.style("+", fg="yellow"), "Public Access Block", bucket.get('public_access_block', True)],  # Optional
                    [click.style("+", fg="yellow"), "Versioning", bucket.get('versioning', False)],  # Optional
                    [click.style("+", fg="yellow"), "Lifecycle Rules", bucket.get('lifecycle_rules', 'None')],  # Optional
                    [click.style("+", fg="yellow"), "Logging", bucket.get('logging', 'None')],  # Optional
                    [click.style("+", fg="yellow"), "Encryption", bucket.get('encryption', 'None')],  # Optional
                ])
                
    
        # Wait for instance to become active (collecting data for final review)
        if 'resources' in data and 'instance_waits' in data['resources']:
            for idx, instance_wait in enumerate(data['resources']['instance_waits']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="yellow"), "Instance Wait", f"Instance Wait {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="yellow"), "Instance ID", instance_wait['instance_id']],
                    [click.style("+", fg="yellow"), "Region", instance_wait['region']]
                ])
                
    
    
        # SSL Certificate creation section (collecting data for final review)
        if 'resources' in data and 'ssl_certificates' in data['resources']:
            for idx, cert in enumerate(data['resources']['ssl_certificates']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="blue"), "SSL Certificate", f"SSL Certificate {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="blue"), "Domain Name", cert['domain_name']],
                    [click.style("+", fg="blue"), "Validation Method", cert['validation_method']],
                    [click.style("+", fg="blue"), "Subject Alternative Names", ", ".join(cert.get('subject_alternative_names', []))],
                    [click.style("+", fg="blue"), "Tags", cert.get('tags', [])],
                ])
                
    
        # Section 1: Add DynamoDB Table Data to the Review Table
        if 'resources' in data and 'dynamodb_tables' in data['resources']:
            for idx, ddb_table in enumerate(data['resources']['dynamodb_tables']):
                click.echo(f"Processing DynamoDB Table: {ddb_table}")
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="green"), "DynamoDB Table", f"Table {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="green"), "Table Name", ddb_table['table_name']],
                    [click.style("+", fg="green"), "Key Schema", ddb_table['key_schema']],
                    [click.style("+", fg="green"), "Provisioned Throughput", ddb_table['provisioned_throughput']]
                ])
                
    
    
        # CodeBuild creation section (collecting data for final review)
        if 'resources' in data and 'codebuild_projects' in data['resources']:
            for idx, cb_project in enumerate(data['resources']['codebuild_projects']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "CodeBuild Project", f"CodeBuild Project {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Name", cb_project['name']],
                    [click.style("+", fg="magenta"), "Source", cb_project['source']],
                    [click.style("+", fg="magenta"), "Environment", cb_project['environment']],
                    [click.style("+", fg="magenta"), "Service Role", cb_project['service_role']],
                    [click.style("+", fg="magenta"), "Artifacts", cb_project['artifacts']],
                    [click.style("+", fg="magenta"), "Tags", cb_project.get('tags', [])]
                ])
                
    
        # CodeBuild Start Build section (collecting data for final review)
        if 'resources' in data and 'codebuild_builds' in data['resources']:
            for idx, cb_build in enumerate(data['resources']['codebuild_builds']):
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), "CodeBuild Start Build", f"CodeBuild Start Build {idx+1}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Project Name", cb_build['project_name']],
                    [click.style("+", fg="magenta"), "Source Version", cb_build.get('sourceVersion', 'N/A')],
                    [click.style("+", fg="magenta"), "Environment Variables", cb_build.get('environmentVariables', 'None')]
                ])
                
    
        # Execute wait intervals
        if 'resources' in data and 'wait_intervals' in data['resources']:
            for wait in data['resources']['wait_intervals']:
                seconds = wait.get('seconds', 0)
                wait_for_interval(seconds)
    
       # Inject SSH key if create_remote is True
        if 'resources' in data and 'ec2_instances' in data['resources']:
            for idx, resource in enumerate(data['resources']['ec2_instances']):
                if create_remote:
                    generate_ssh_key()
                    ssh_key = get_ssh_key()
                    user_data_script = prepare_user_data_script(ssh_key)
                    resource['user_data'] = user_data_script
                    # Assuming this resource dictionary is used directly in the instance creation API call
    
        # Remote server and task execution
        if 'remote-server' in data:
            for server in data['remote-server']:
                task_identifier = server.get('identifiers', 'N/A')
                task_user = server.get('username', None)
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="blue"), "Remote Server", task_identifier])
                table_data.append([click.style("+", fg="blue"), "Username", task_user if task_user else "N/A"])
    
    
        if 'tasks' in data:
            for idx, task in enumerate(data['tasks']):
                task_name = task.get('name', 'Unnamed Task')
                action = task.get('action', 'N/A')
                image_name = task.get("image_name", "N/A")
                identifiers = task.get('identifiers', [])
                category = task.get('category', 'N/A')
                command = task.get('command', 'N/A')
                retries = task.get('retries', 'N/A')
                deployment = task.get('deployment', 'N/A')
                timeout = task.get('timeout', 'N/A')
                loop_config = task.get('for_each', 'N/A') or task.get('count', 'N/A')
                notify_on_failure = task.get('notify_on_failure', 'N/A')
                condition = task.get('condition', 'N/A')
                depends_on = task.get('depends_on', 'N/A')
                dynamic_variables = task.get('dynamic_variables', 'N/A')
                parallel_execution = task.get('parallel_execution', False)
                rollback_on_failure = task.get('rollback_on_failure', False)
                health_checks = task.get('health_checks', 'N/A')
                task_group = task.get('task_group', 'N/A')
                docker_hub = task.get("docker_hub", {})
                task_schedule = task.get('schedule', 'N/A')
                custom_action = task.get('custom_action', 'N/A')
                environment_detection = task.get('environment_detection', False)
                resource_quota = task.get('resource_quota', 'N/A')
                fail_safe = task.get('fail_safe', False)
                deploy_type = task.get("deploy_type", "s3")
                enhanced_summary = task.get('enhanced_summary', False)
                notify_on_completion = task.get('notify_on_completion', False)
                notification_recipients = ', '.join(task.get('notification_recipients', {}).get('email', []))
                notification_channels = task.get('notification_channels', None)
                source_url = task.get('source_url', 'N/A')
                dest_path = task.get('dest_path', 'N/A')
                repo_config = task.get("repository", {})
               # Task-specific variables for build action
                credential_name = task.get('credential_name', 'N/A')
                artifact_dir = task.get('artifact_dir', 'N/A')
                sonar = task.get("sonar", {})
                maven_config = task.get("maven", {})
                trivy_config = task.get("trivy", {})
                load_balancer_config = task.get("load_balancer", {})
                clean_old_build = task.get('clean_old_build', False)
    
                # Handle identifiers being either a string or list
                if isinstance(identifiers, str):
                    identifiers = [identifiers]
                identifiers_str = ', '.join(identifiers)
    
                # Start by appending task-specific information
                table_data.append(["", "", ""])
                table_data.append([click.style("+", fg="magenta"), f"Task {idx+1}", f"Task: {task_name}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Action", action],
                    [click.style("+", fg="magenta"), "Identifiers", identifiers_str],
                    [click.style("+", fg="magenta"), "Category", category]
                ])
    
                # Only append rows if their value is not None or N/A
                if retries != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Retries", retries])
                if trivy_config != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Trivy", trivy_config])
    
                if timeout != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Timeout", timeout])
                if loop_config != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Loop Configuration", loop_config])
                if notify_on_failure :
                    table_data.append([click.style("+", fg="magenta"), "Notify on Failure", "Yes" if notify_on_failure else "No"])
               
                if docker_hub :
                    table_data.append([click.style("+", fg="magenta"), "Dockerhub", docker_hub])
    
                if maven_config :
                    table_data.append([click.style("+", fg="magenta"), "Maven", maven_config])
    
                if deployment != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Deployment", deployment])
    
                if command != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Command", command])
    
                if repo_config :
                    table_data.append([click.style("+", fg="magenta"), "Repository", repo_config])
                 
                if clean_old_build :
                    table_data.append([click.style("+", fg="magenta"), "Clean Old Build", clean_old_build])
                if  load_balancer_config :
                    table_data.append([click.style("+", fg="magenta"), "Load_balancer", load_balancer_config])
    
                if condition != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Condition", condition])
                if depends_on != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Depends On", depends_on])
                if dynamic_variables != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Dynamic Variables", dynamic_variables])
                if parallel_execution:
                    table_data.append([click.style("+", fg="magenta"), "Parallel Execution", "Yes" if parallel_execution else "No"])
                if rollback_on_failure:
                    table_data.append([click.style("+", fg="magenta"), "Rollback on Failure", "Yes" if rollback_on_failure else "No"])
                if health_checks != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Health Checks", health_checks])
                if task_group != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Task Group", task_group])
                if task_schedule != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Task Schedule", task_schedule])
                if custom_action != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Custom Actions", custom_action])
                if  environment_detection:
                    table_data.append([click.style("+", fg="magenta"), "Environment Detection", "Yes" if environment_detection else "No"])
                if resource_quota != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Resource Quota", resource_quota])
                if fail_safe:
                    table_data.append([click.style("+", fg="magenta"), "Fail Safe", "Yes" if fail_safe else "No"])
                if enhanced_summary:
                    table_data.append([click.style("+", fg="magenta"), "Enhanced Summary", "Yes" if enhanced_summary else "No"])
                if notify_on_completion:
                    table_data.append([click.style("+", fg="magenta"), "Notify on Completion", "Yes" if notify_on_completion else "No"])
                if notification_recipients:
                    table_data.append([click.style("+", fg="magenta"), "Notification Recipients", notification_recipients])
                if notification_channels:
                    table_data.append([click.style("+", fg="magenta"), "Notification Channels", notification_channels])
    
    
    
               # Append the new source_url, credential_name, artifact_dir, s3_bucket_name, use_sonar, and clean_old_build fields
                if credential_name != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Credential Name", credential_name])
                if artifact_dir != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Artifact Directory", artifact_dir])
    
    
                if sonar :
                    table_data.append([click.style("+", fg="magenta"), "Sonar", sonar])
                if clean_old_build :
                    table_data.append([click.style("+", fg="magenta"), "Clean Old Build", "Yes" if clean_old_build else "No"])
    
                # Append the new source_url and dest_path fields
                if source_url != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Source URL", source_url])
                if dest_path != 'N/A':
                    table_data.append([click.style("+", fg="magenta"), "Destination Path", dest_path])
    
        if 'create_user' in data:
            for idx, user in enumerate(data['create_user']):
                user_name = user.get('username', 'N/A')
                category = user.get('category', 'N/A')
                task_identifier = user.get('identifiers', 'N/A')
                create_user_ssh_key = user.get('create_user_ssh_key', False)
                permissions = user.get('permissions', 'N/A')
                password = "*****"
                table_data.append(["", "", ""])
                # Append user information in the formatted table style
                table_data.append([click.style("+", fg="magenta"), f"User {idx+1}", f"User: {user_name}"])
                table_data.extend([
                    [click.style("+", fg="magenta"), "Category", category],
                    [click.style("+", fg="magenta"), "Identifiers", task_identifier],
                    [click.style("+", fg="magenta"), "Create SSH Key", "Yes" if create_user_ssh_key else "No"],
                    [click.style("+", fg="magenta"), "Permissions", permissions],
                    [click.style("+", fg="magenta"), "Password", password]
                ])
    
    ########################################final review ###########################
    
    ########################################final review ###########################
    
        # Phase 2: Display the Final Review
        click.echo("\nFinal Review of All Actions:")
        if table_data:
            click.echo(tabulate(table_data, headers=["", "Category", "Value"], tablefmt="grid"))
        else:
            click.echo("No resources defined in the screenplay.")
    
        # Phase 3: Confirm to proceed
        if not yes:
            if not click.confirm(click.style("Do you want to proceed with executing these actions?", fg="green"), default=True):
                click.echo("Execution aborted by the user.")
                return
        click.echo(f"Proceeding with the actions... (Execution ID: {execution_id})\n")
    
    
         # VPC creation (example section)
        if 'resources' in data and 'vpcs' in data['resources']:
            credentials = load_aws_credentials()
            for vpc in data['resources']['vpcs']:
                region = vpc.get('region')
                if not region:
                    raise ValueError("Region is required for creating a VPC.")
    
                # Update to unpack three values from is_task_completed function
                completed, resource_id, status = is_task_completed(execution_id, 'vpc_creation')
    
                if not completed:
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    vpc_id = create_vpc(vpc, ec2, execution_id)
                    click.echo(f"VPC created with ID: {vpc_id}")
                   # record_task_state(execution_id, 'vpc_creation', 'success', resource_id=vpc_id)
                else:
                    click.echo(f"VPC creation skipped, already completed. Existing VPC ID: {resource_id}")
                resource_outputs['vpc_id'] = vpc_id
    
        data = replace_placeholders(data, resource_outputs)
        # Subnet Creation Script
        if 'resources' in data and 'subnets' in data['resources']:
            credentials = load_aws_credentials()
            for subnet in data['resources']['subnets']:
                region = subnet.get('region')
                if not region:
                    raise ValueError("Region is required for creating a subnet.")
        
                # Use the VPC ID from resource outputs or configuration
                vpc_id = resource_outputs.get('vpc_id') or subnet.get('vpc_id')
                if not vpc_id:
                    raise ValueError("VPC ID is required for creating a subnet.")
        
                # Subnet name (ensure it's provided in the YAML)
                subnet_name = None
                for tag in subnet.get('tags', []):
                    if tag['Key'] == 'Name':
                        subnet_name = tag['Value']
                        break
                if not subnet_name:
                    raise ValueError("Subnet name is required (as a 'Name' tag).")
        
                # Check if the Subnet was already created
                task_key = f'subnet_{subnet.get("cidr_block")}'
                completed, resource_id, _ = is_task_completed(execution_id, task_key)
        
                if not completed:
                    try:
                        ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                        response = ec2.create_subnet(
                            VpcId=vpc_id,
                            CidrBlock=subnet['cidr_block'],
                            AvailabilityZone=subnet['availability_zone']
                        )
                        subnet_id = response['Subnet']['SubnetId']
                        click.echo(f"Subnet created with ID: {subnet_id}")
        
                        # Add tags to the subnet
                        if 'tags' in subnet:
                            ec2.create_tags(Resources=[subnet_id], Tags=subnet['tags'])
                            click.echo(f"Tags added to Subnet {subnet_id}")
        
                        # Enable auto-assign public IP if specified
                        if subnet.get('auto_assign_public_ip', False):
                            ec2.modify_subnet_attribute(
                                SubnetId=subnet_id,
                                MapPublicIpOnLaunch={'Value': True}
                            )
                            click.echo(f"Auto-assign public IP enabled for Subnet {subnet_id}")
        
                        # Record the task completion
                        record_task_state(execution_id, task_key, 'success', resource_id=subnet_id)
        
                        # Save Subnet Information
                        save_subnet_info(subnet_name, subnet_id)
        
                    except botocore.exceptions.ClientError as e:
                        click.echo(click.style(f"Failed to create Subnet: {e}", fg="red"))
                        record_task_state(execution_id, task_key, 'failed')
                        continue
                else:
                    subnet_id = resource_id  # Use the existing subnet ID
                    click.echo(f"Subnet creation skipped, already completed. Existing Subnet ID: {subnet_id}")
        
                resource_outputs[f'subnet_id_{subnet_name}'] = subnet_id
        
                # Save Subnet ID for use in other resources
                resource_outputs['subnet_id'] = subnet_id        
            
        # Internet Gateway creation
        if 'resources' in data and 'internet_gateways' in data['resources']:
            credentials = load_aws_credentials()
            for igw in data['resources']['internet_gateways']:
                region = igw.get('region')
                if not region:
                    raise ValueError("Region is required for creating an Internet Gateway.")
    
                # Use the VPC ID from resource outputs if not explicitly specified
                vpc_id = resource_outputs.get('vpc_id') or igw.get('vpc_id')
                if not vpc_id:
                    raise ValueError("VPC ID is required for creating an Internet Gateway but was not found in the configuration or resource outputs.")
    
                # Check if the Internet Gateway was already created
                completed, resource_id, status = is_task_completed(execution_id, 'internet_gateway')
                if not completed:
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    igw_id = create_internet_gateway(vpc_id, igw, ec2, execution_id, resource_outputs)
                    click.echo(f"Internet Gateway created with ID: {igw_id}")
                    #record_task_state(execution_id, 'internet_gateway', 'success', resource_id=igw_id)
                else:
                    click.echo(f"Internet Gateway creation skipped, already completed. Existing Internet Gateway ID: {resource_id}")
                # Save the Internet Gateway ID for other dependencies
                resource_outputs['internet_gateway_id'] = igw_id
    
        # Route Table Script
        if 'resources' in data and 'route_tables' in data['resources']:
            credentials = load_aws_credentials()
            for route_table in data['resources']['route_tables']:
                region = route_table.get('region')
                if not region:
                    raise ValueError("Region is required for creating a route table.")
        
                # Use the VPC ID from resource outputs if not explicitly specified
                vpc_id = resource_outputs.get('vpc_id') or route_table.get('vpc_id')
                if not vpc_id:
                    raise ValueError("VPC ID is required for creating a Route Table but was not found in the configuration or resource outputs.")
        
                # Check if the Route Table was already created
                completed, resource_id, status = is_task_completed(execution_id, 'route_table')
                if not completed:
                    # Create the route table using boto3
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    route_table_id = create_route_table(vpc_id, route_table, ec2, execution_id, resource_outputs)
                    click.echo(f"Route Table created with ID: {route_table_id}")
                else:
                    route_table_id = resource_id  # Use the existing route table ID
                    click.echo(f"Route Table creation skipped, already completed. Existing Route Table ID: {route_table_id}")
        
                resource_outputs['route_table_id'] = route_table_id
        
                # Section 4: Associate Route Table with Subnets
                for association in route_table.get('associations', []):
                    subnet_name = association.get('subnet')
                    if not subnet_name:
                        click.echo(click.style("Subnet name is missing for association.", fg="red"))
                        continue
        
                    # First, try retrieving the subnet ID from saved data
                    subnet_id = get_subnet_info(subnet_name)
                    if not subnet_id:
                        # Fall back to resource outputs if not found in the saved file
                        subnet_id = resource_outputs.get(f'subnet_id_{subnet_name}')
                        if not subnet_id:
                            click.echo(click.style(f"Subnet ID for {subnet_name} not found in resource outputs or saved file. Skipping association.", fg="red"))
                            continue
        
                    try:
                        ec2.associate_route_table(RouteTableId=route_table_id, SubnetId=subnet_id)
                        click.echo(f"Route Table {route_table_id} associated with Subnet {subnet_id}")
                    except botocore.exceptions.ClientError as e:
                        click.echo(click.style(f"Failed to associate Route Table {route_table_id} with Subnet {subnet_id}: {e}", fg="red"))
            
                    
        # Security Group creation
        if 'resources' in data and 'security_groups' in data['resources']:
            credentials = load_aws_credentials()
            for sg in data['resources']['security_groups']:
                region = sg.get('region')
                if not region:
                    raise ValueError("Region is required for creating a Security Group.")
    
                # Use the VPC ID from resource_outputs if it exists, otherwise, use the defined VPC ID in the YAML
                vpc_id = resource_outputs.get('vpc_id') or sg.get('vpc_id')
                if not vpc_id:
                    raise ValueError("VPC ID is required for creating a Security Group but was not found in the configuration or resource outputs.")
    
                # Check if the Security Group was already created
                completed, resource_id, status = is_task_completed(execution_id, 'security_group')
                if not completed:
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    sg_id = create_security_group(vpc_id, sg, ec2, execution_id)
                    click.echo(f"Security Group created with ID: {sg_id}")
    
                    # Record the security group creation in the state file
                    #record_task_state(execution_id, 'security_group', 'success', resource_id=sg_id)
                else:
                    click.echo(f"Security Group creation skipped, already completed. Existing Security Group ID: {resource_id}")
    
                # Save the Security Group ID for use in other resources
                resource_outputs['security_group_id'] = sg_id
    
    
    
        # Elastic IP creation
        if 'resources' in data and 'elastic_ips' in data['resources']:
            credentials = load_aws_credentials()
            for eip in data['resources']['elastic_ips']:
                region = eip.get('region')
                if not region:
                    raise ValueError("Region is required for creating an Elastic IP.")
    
                allocation_id_key = f'elastic_ip_{eip.get("domain", "vpc")}_{region}'
                # Check if the Elastic IP was already created
                completed, resource_id, status = is_task_completed(execution_id, 'elastic_ip')
                if not completed:
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    allocation_id, public_ip = create_elastic_ip(eip, ec2, execution_id)
                    click.echo(f"Elastic IP created with Allocation ID: {allocation_id} and Public IP: {public_ip}")
                else:
                    click.echo(f"Elastic IP creation skipped, already completed. Existing Allocation ID: {resource_id}")
    
                resource_outputs['elastic_ip_id'] = allocation_id
    
    
        # NAT Gateway creation
        if 'resources' in data and 'nat_gateways' in data['resources']:
            credentials = load_aws_credentials()
            for nat_gw in data['resources']['nat_gateways']:
                region = nat_gw.get('region')
                if not region:
                    raise ValueError("Region is required for creating a NAT Gateway.")
    
                # Use the Subnet ID and Elastic IP from resource_outputs if they exist, otherwise use the defined ones
                subnet_id = resource_outputs.get('subnet_id') or nat_gw.get('subnet_id')
                allocation_id = resource_outputs.get('elastic_ip_id') or nat_gw.get('allocation_id')
    
                # Check if the required dependencies are available
                if not subnet_id:
                    raise ValueError("Subnet ID is required for creating a NAT Gateway but was not found in the configuration or resource outputs.")
                if not allocation_id:
                    raise ValueError("Allocation ID is required for creating a NAT Gateway but was not found in the configuration or resource outputs.")
    
                # Check if the NAT Gateway was already created
                nat_gw_key = f'nat_gateway_{subnet_id}'
    
    
                # Check if the NAT Gateway was already created
                completed, resource_id, status = is_task_completed(execution_id, 'nat_gateway')
                if not completed:
                    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    nat_gw_id = create_nat_gateway({'subnet_id': subnet_id, 'allocation_id': allocation_id}, ec2, execution_id)
                    click.echo(f"NAT Gateway created with ID: {nat_gw_id}")
                else:
                    click.echo(f"NAT Gateway creation skipped, already completed. Existing NAT Gateway ID: {resource_id}")
    
                resource_outputs['nat_gateway_id'] = nat_gw_id
    
        # EC2 Instance creation
        if 'resources' in data and 'ec2_instances' in data['resources']:
            try:
                instances = []
                credentials = load_aws_credentials()
                for idx, resource in enumerate(data['resources']['ec2_instances']):  # Add an index to distinguish instances
    
                    # Use the Subnet ID and Security Group from resource_outputs if they exist, otherwise use the defined ones
                    subnet_id = resource_outputs.get('subnet_id') or resource.get('subnet_id')
                    security_group_id = resource_outputs.get('security_group_id') or resource.get('security_group')
    
                    # Check if the required dependencies are available
                    if not subnet_id:
                        raise ValueError("Subnet ID is required for creating an EC2 instance but was not found.")
                    if not security_group_id:
                        raise ValueError("Security Group ID is required for creating an EC2 instance but was not found.")
    
                    # Check if this EC2 instance has already been created
                    task_name = f'ec2_instance_{idx}'  # Make task name unique for each instance
                    completed, resource_id, status = is_task_completed(execution_id, task_name)
    
                    if completed:
                        click.echo(f"EC2 creation for {resource['name']} skipped, already completed. Existing EC2 ID: {resource_id}")
                        continue
    
                    region = resource.get('region', 'us-east-1')
                    instance_type = resource.get('instance_type', 't2.micro')
    
                    name = resource.get('name', 'instance')
                    interpolated_name = name.replace('{{region}}', region).replace('{{instance_type}}', instance_type)
                    tags = resource.get('tags', [])
                    # Validate and format tags
                    if isinstance(tags, dict):
                        # Convert a dictionary of tags into the required list of dictionaries
                        formatted_tags = [{'Key': k, 'Value': v} for k, v in tags.items()]
                    elif isinstance(tags, list) and all(isinstance(tag, dict) and 'Key' in tag and 'Value' in tag for tag in tags):
                        # Use the tags directly if they are a valid list of dictionaries
                        formatted_tags = tags
                    else:
                        # If tags are not in the correct format, raise an error
                        raise ValueError("Tags must be a dictionary or a list of dictionaries, and each dictionary must have 'Key' and 'Value'.")
    
                    # Ensure the 'Name' tag is present
                    if not any(tag['Key'] == 'Name' for tag in formatted_tags):
                        formatted_tags.append({'Key': 'Name', 'Value': interpolated_name})
     
    
                    # Define EC2 parameters based on resource configuration
                    ec2_params = {
                        'InstanceType': instance_type,
                        'ImageId': resource['ami_id'],
                        'KeyName': resource['key_name'],
                        'SecurityGroupIds': [security_group_id],  # Use SecurityGroupIds instead of groupName
                        'SubnetId': subnet_id,
                        'MinCount': resource.get('count', 1),
                        'MaxCount': resource.get('count', 1),
                        'TagSpecifications': [{
                            'ResourceType': 'instance',
                            'Tags': formatted_tags
                        }]
                    }
        
                    # Add optional parameters if they are present
                    if resource.get('iam_instance_profile'):
                        ec2_params['IamInstanceProfile'] = {'Name': resource['iam_instance_profile']}
                    if resource.get('block_device_mappings'):
                        ec2_params['BlockDeviceMappings'] = resource['block_device_mappings']
                    if resource.get('monitoring') is not None:
                        ec2_params['Monitoring'] = {'Enabled': resource['monitoring']}
                    if resource.get('instance_initiated_shutdown_behavior'):
                        ec2_params['InstanceInitiatedShutdownBehavior'] = resource['instance_initiated_shutdown_behavior']
                    if resource.get('private_ip_address'):
                        ec2_params['PrivateIpAddress'] = resource['private_ip_address']
                    if resource.get('user_data'):
                        ec2_params['UserData'] = resource['user_data']
        
                    # Create EC2 client and launch instances
                    if 'region_name' in credentials:
                        ec2 = boto3.client('ec2', **credentials)
                    else:
                        ec2 = boto3.client('ec2', region_name=region, **credentials)
        
                    response = ec2.run_instances(**ec2_params)
                    instance_ids = [instance['InstanceId'] for instance in response['Instances']]
                    instances.extend(instance_ids)
        
                    for instance_id in instance_ids:
                        record_task_state(execution_id, task_name, 'success', resource_id=instance_id)
        
                    # Handle the --add-remote-metrics flag
                    if add_remote_metrics:
                        for i, instance in enumerate(response['Instances']):
                            instance_id = instance['InstanceId']
                            private_ip = instance['PrivateIpAddress']
                            instance_name = next(
                                (tag['Value'] for tag in resource['tags'] if tag['Key'] == 'Name'),
                                f"Instance_{i+1}"
                            )
                    
                            # Add the entry to the remote metrics file
                            add_remote_metrics_entry(instance_name, private_ip)        
    
                # New addition: Add host entries after instances are created
                    if add_remote or add_remote_category:
                        for i, instance in enumerate(response['Instances']):
                            instance_id = instance['InstanceId']
                            private_ip = instance['PrivateIpAddress']
                            instance_name = next((tag['Value'] for tag in resource['tags'] if tag['Key'] == 'Name'), f"Instance_{i+1}")
    
                            if add_remote_category:
                                add_host_entry(instance_name, private_ip, add_remote_category)
                            else:
                                add_host_entry(instance_name, private_ip)
    
                click.echo(f"Instances created with IDs: {', '.join(instances)}")
                click.echo("Waiting for instances to be in running state...")
                reservations = fetch_instance_details(instance_ids, credentials)
                click.echo("Instances are now running.")
            
            except ClientError as e:
                click.echo(click.style(f"Failed to create and configure instances: {e}", fg="red"))
        
    
        
    
        if 'create_user' in data:
            for user in data['create_user']:
                user_name = user.get('username')
                user_password = user.get('password', None)
                user_permissions = user.get('permissions', None)
                create_user_ssh_key = user.get('create_user_ssh_key', False)
                task_identifier = user.get('identifiers', 'ALL')
                category = user.get('category', None)
    
                if not user_name:
                    click.echo(click.style(f"Error: 'username' is required for 'create_user' action.", fg="red"))
                    continue
    
                # Determine the target identifiers based on category and task
                target_identifiers = []
                if task_identifier.lower() == 'all':
                    if category:
                        target_identifiers = get_all_identifiers_in_category(category)
                    else:
                        target_identifiers = [server.get('identifiers') for server in data['remote-server']]
                else:
                    try:
                        if category:
                            target_identifiers = [get_host_entry(task_identifier, category)[1]]
                        else:
                            target_identifiers = [get_host_entry(task_identifier)[1]]
                    except ValueError as e:
                        click.echo(click.style(f"Error: {e}", fg="red"))
                        continue
    
                # Loop through the target identifiers and create the user on each server
                for identifier in target_identifiers:
                    try:
                        success, message = create_user_on_server(
                            identifier=identifier,
                            username=user_name,
                            password=user_password,
                            permissions=user_permissions,
                            create_user_ssh_key=create_user_ssh_key,
                            category=category
                        )
                        if success:
                           click.echo(message)
                        else:
                            click.echo(click.style(message, fg="red"))
                    except ValueError as ve:
                        click.echo(str(ve))
    
    
    
        # Load Balancer creation
        if 'resources' in data and 'load_balancers' in data['resources']:
            credentials = load_aws_credentials()
            for lb_data in data['resources']['load_balancers']:
                region = lb_data.get('region')
                if not region:
                    raise ValueError("Region is required for creating a Load Balancer.")
    
                # Use Subnet IDs and Security Group IDs from resource_outputs if they exist, otherwise use the defined ones in YAML
                subnet_ids = resource_outputs.get('subnet_id') or lb_data.get('subnets')
                security_groups = resource_outputs.get('security_group_id') or lb_data.get('security_groups')
    
                # Ensure that Subnets and Security Groups are lists
                if isinstance(subnet_ids, str):
                    subnet_ids = [subnet_ids]  # Convert single subnet_id string to a list
                if isinstance(security_groups, str):
                    security_groups = [security_groups]  # Convert single security_group_id string to a list
    
                click.echo(f"Using Subnets: {subnet_ids}")
                click.echo(f"Using Security Groups: {security_groups}")
    
                # Check if the required dependencies are available
                if not subnet_ids or not isinstance(subnet_ids, list):
                    raise ValueError("Subnet IDs are required for creating a Load Balancer and must be a list.")
                if not security_groups or not isinstance(security_groups, list):
                    raise ValueError("Security Group IDs are required for creating a Load Balancer and must be a list.")
    
                # Check if the Load Balancer was already created
                completed, resource_id, status = is_task_completed(execution_id, 'load_balancer')
                if not completed:
                    elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                    # Handle Tags based on their type (list or dict)
                    tags = lb_data.get('tags', [])
                    if isinstance(tags, dict):  # Convert dict to list format expected by boto3
                        tags = [{'Key': k, 'Value': v} for k, v in tags.items()]
                    elif not isinstance(tags, list):  # If it's neither list nor dict, set to empty list
                        tags = []
    
                    # Define Load Balancer Parameters
                    elb_params = {
                        'Name': lb_data['name'],
                        'Subnets': subnet_ids,            # Subnets parameter should be a list of Subnet IDs
                        'SecurityGroups': security_groups,  # SecurityGroups parameter should be a list of Security Group IDs
                        'Scheme': lb_data.get('scheme', 'internet-facing'),
                        'Type': lb_data.get('type', 'application'),
                        'IpAddressType': lb_data.get('ip_address_type', 'ipv4'),
                        'Tags': tags  # Use the tags that have been formatted correctly
                    }
    
                    click.echo(f"Creating Load Balancer with parameters: {elb_params}")
    
                    try:
                        # Create the Load Balancer
                        response = elb_client.create_load_balancer(**elb_params)
                        lb_arn = response['LoadBalancers'][0]['LoadBalancerArn']
                        click.echo(f"Load Balancer created with ARN: {lb_arn}")
    
                        # Record Load Balancer creation in the state file
                        record_task_state(execution_id, 'load_balancer', 'success', resource_id=lb_arn)
                        resource_outputs['load_balancer_arn'] = lb_arn  # Store ARN in resource outputs
    
                    except ClientError as e:
                        click.echo(click.style(f"Failed to create load balancer: {e}", fg="red"))
                        #record_task_state(execution_id, f'load_balancer_{lb_data["name"]}', 'failed')
                else:
                    click.echo(f"Load Balancer creation skipped, already completed. Existing Load Balancer ARN: {resource_id}")
    
    
        # EKS Cluster creation
        if 'resources' in data and 'eks_clusters' in data['resources']:
            credentials = load_aws_credentials()
            for eks_cluster in data['resources']['eks_clusters']:
                region = eks_cluster.get('region')
                if not region:
                    raise ValueError("Region is required for creating an EKS cluster.")
    
                # Use Subnet IDs and Security Groups from resource_outputs if they exist, otherwise use the defined ones in YAML
                subnet_ids = resource_outputs.get('subnet_ids') or eks_cluster.get('resources_vpc_config', {}).get('subnetIds')
                security_group_ids = resource_outputs.get('security_group_ids') or eks_cluster.get('resources_vpc_config', {}).get('securityGroupIds')
    
                # Check if the required dependencies are available
                if not subnet_ids:
                    raise ValueError("Subnet IDs are required for creating an EKS cluster but were not found in the configuration or resource outputs.")
                if not security_group_ids:
                    raise ValueError("Security Group IDs are required for creating an EKS cluster but were not found in the configuration or resource outputs.")
    
                 # Check if this EKS Cluster has already been created
                completed, resource_id, status = is_task_completed(execution_id, 'eks_cluster')
                if completed:
                    click.echo(f"EKS Cluster creation skipped, already completed. Existing Cluster ID: {resource_id}")
                    continue
    
                # Create the EKS client
                eks_client = boto3.client('eks', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                kubernetes_version = get_valid_kubernetes_version(eks_cluster.get('version'))
                # Create the EKS Cluster
                eks_cluster_id = create_eks_cluster(eks_cluster, eks_client, execution_id, kubernetes_version)
                if eks_cluster_id:
                    click.echo(f"EKS Cluster created with ID: {eks_cluster_id}")
                    # Wait for the cluster to be active
                    wait_for_cluster_active(eks_client, eks_cluster_id)
    
                resource_outputs['eks_cluster_id'] = eks_cluster_id
    
        # EKS Nodegroup creation
        if 'resources' in data and 'eks_nodegroups' in data['resources']:
            credentials = load_aws_credentials()
            for eks_node_group in data['resources']['eks_nodegroups']:
                region = eks_node_group.get('region')
                if not region:
                    raise ValueError("Region is required for creating an EKS Node Group.")
    
                # Use EKS Cluster ID and Subnet IDs from resource_outputs if they exist, otherwise use the defined ones in YAML
                cluster_name = resource_outputs.get('eks_cluster_id') or eks_node_group.get('clusterName')
                subnet_ids = resource_outputs.get('subnet_ids') or eks_node_group.get('subnets')
    
                # Check if the required dependencies are available
                if not cluster_name:
                    raise ValueError("EKS Cluster ID is required for creating an EKS Node Group but was not found in the configuration or resource outputs.")
                if not subnet_ids:
                    raise ValueError("Subnet IDs are required for creating an EKS Node Group but were not found in the configuration or resource outputs.")
    
    
                # Check if this EKS Node Group has already been created
                completed, resource_id, status = is_task_completed(execution_id, 'eks_nodegroup')
                if completed:
                    click.echo(f"EKS Node Group creation skipped, already completed. Existing Node Group Name: {resource_id}")
                    continue
    
                # Create the EKS client
                eks_client = boto3.client('eks', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                # Create the EKS Node Group
                node_group_name = create_eks_nodegroup(eks_node_group, eks_client, execution_id)
                if node_group_name:
                    click.echo(f"EKS Node Group created with name: {node_group_name}")
    
                resource_outputs['eks_nodegroup_id'] = node_group_name
    
    
        # RDS Subnet Group creation section
        if 'resources' in data and 'rds_subnet_groups' in data['resources']:
            credentials = load_aws_credentials()
            for rds_subnet_group in data['resources']['rds_subnet_groups']:
                region = rds_subnet_group.get('region')
                if not region:
                    raise ValueError("Region is required for creating an RDS Subnet Group.")
    
                # Use direct Subnet IDs if provided, otherwise use the ones in resource_outputs
                subnet_ids = rds_subnet_group.get('subnets')
    
                if not subnet_ids:
                    # Retrieve subnets from resource_outputs if not provided directly in YAML
                    subnet_ids = [
                        resource_outputs.get(f'subnet_id_{subnet_name}')
                        for subnet_name in rds_subnet_group.get('subnet_names', [])
                    ]
    
                # Ensure that subnet_ids is a list of valid IDs
                if isinstance(subnet_ids, str):
                    subnet_ids = [subnet_ids]  # Convert a single string into a list
                elif not isinstance(subnet_ids, list):
                    raise ValueError("Subnet IDs must be provided as a list or a single string.")
    
                # Ensure that all subnets are valid and not None
                if not all(subnet_ids) or not isinstance(subnet_ids, list):
                    raise ValueError("Valid Subnet IDs are required for creating an RDS Subnet Group but were not found in the configuration or resource outputs.")
    
                click.echo(f"Using Subnets: {subnet_ids} for RDS Subnet Group")
    
                # Create RDS client
                rds_client = boto3.client('rds', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                # Prepare RDS Subnet Group parameters
                rds_subnet_group_params = {
                    'DBSubnetGroupName': rds_subnet_group['name'],
                    'SubnetIds': subnet_ids,
                    'DBSubnetGroupDescription': rds_subnet_group.get('description', 'No description provided'),
                    'Tags': rds_subnet_group.get('tags', [])
                }
    
                try:
                    click.echo(f"Creating RDS Subnet Group with parameters: {rds_subnet_group_params}")
                    response = rds_client.create_db_subnet_group(**rds_subnet_group_params)
                    rds_subnet_group_name = response['DBSubnetGroup']['DBSubnetGroupName']
                    click.echo(f"RDS Subnet Group created with Name: {rds_subnet_group_name}")
    
                    # Record the creation of the RDS Subnet Group
                    #record_task_state(execution_id, 'rds_subnet_group', 'success', resource_id=rds_subnet_group_name)
                    resource_outputs[f'rds_subnet_group_name_{rds_subnet_group["name"]}'] = rds_subnet_group_name
    
                except ClientError as e:
                    click.echo(click.style(f"Failed to create RDS Subnet Group: {e}", fg="red"))
                    #record_task_state(execution_id, f'rds_subnet_group_{rds_subnet_group["name"]}', 'failed')
    
        # RDS Instance creation section
        if 'resources' in data and 'rds_instances' in data['resources']:
            credentials = load_aws_credentials()
            for rds_instance in data['resources']['rds_instances']:
                region = rds_instance.get('region')
                if not region:
                    raise ValueError("Region is required for creating an RDS instance.")
    
                # Use direct Security Group IDs if provided, otherwise use those in resource_outputs
                vpc_security_group_ids = rds_instance.get('vpc_security_group_ids') or resource_outputs.get('security_group_ids')
                if isinstance(vpc_security_group_ids, str):
                    vpc_security_group_ids = [vpc_security_group_ids]  # Convert single string to list
    
                click.echo(f"Using Security Group IDs for RDS: {vpc_security_group_ids}")
    
                # Use direct Subnet Group Name if provided, otherwise use those in resource_outputs
                db_subnet_group_name = rds_instance.get('db_subnet_group_name') or resource_outputs.get(f'rds_subnet_group_name_{rds_instance.get("subnet_group_name_ref")}')
    
                click.echo(f"Using Subnet Group Name for RDS: {db_subnet_group_name}")
    
                # Prepare the RDS instance parameters
                rds_params = {
                    'DBInstanceIdentifier': rds_instance['db_instance_identifier'],
                    'AllocatedStorage': rds_instance.get('allocated_storage', 20),
                    'DBInstanceClass': rds_instance['db_instance_class'],
                    'Engine': rds_instance['engine'],
                    'MasterUsername': rds_instance['master_username'],
                    'MasterUserPassword': rds_instance['master_user_password'],
                    'VpcSecurityGroupIds': vpc_security_group_ids,
                    'DBSubnetGroupName': db_subnet_group_name,
                    'MultiAZ': rds_instance.get('multi_az', False),
                    'PubliclyAccessible': rds_instance.get('publicly_accessible', False),
                    'StorageType': rds_instance.get('storage_type', 'gp2'),
                    'Tags': rds_instance.get('tags', [])
                }
    
                click.echo(f"Creating RDS Instance with parameters: {rds_params}")
    
                try:
                    # Create RDS client and create the instance
                    rds_client = boto3.client('rds', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                    response = rds_client.create_db_instance(**rds_params)
                    db_instance_id = response['DBInstance']['DBInstanceIdentifier']
                    click.echo(f"RDS Instance created with ID: {db_instance_id}")
    
                    # Record the creation of the RDS instance
                    record_task_state(execution_id, 'rds_instance', 'success', resource_id=db_instance_id)
                    resource_outputs[f'rds_instance_id_{rds_instance["db_instance_identifier"]}'] = db_instance_id
    
                except ClientError as e:
                    click.echo(click.style(f"Failed to create RDS instance: {e}", fg="red"))
                    #record_task_state(execution_id, f'rds_instance_{rds_instance["db_instance_identifier"]}', 'failed')
    
        # Network Interface creation
        if 'resources' in data and 'network_interfaces' in data['resources']:
            credentials = load_aws_credentials()
            for network_interface in data['resources']['network_interfaces']:
                region = network_interface.get('region')
                if not region:
                    raise ValueError("Region is required for creating a network interface.")
    
                # Use Subnet ID and Security Group IDs from resource_outputs if they exist, otherwise use the defined ones in YAML
                subnet_id = resource_outputs.get('subnet_id') or network_interface.get('subnet_id')
                security_group_ids = resource_outputs.get('security_group_ids') or network_interface.get('groups', [])
    
                # Check if the required dependencies are available
                if not subnet_id:
                    raise ValueError("Subnet ID is required for creating a Network Interface but was not found in the configuration or resource outputs.")
                if not security_group_ids:
                    raise ValueError("Security Group IDs are required for creating a Network Interface but were not found in the configuration or resource outputs.")
    
    
                # Check if the network interface has already been created
                completed, resource_id, status = is_task_completed(execution_id, 'network_interface')
                if completed:
                    click.echo(f"Network Interface creation skipped, already completed. Existing Network Interface ID: {resource_id}")
                    continue
    
                ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                network_interface_id = create_network_interface(network_interface, ec2, execution_id)
                click.echo(f"Network Interface created with ID: {network_interface_id}")
    
                resource_outputs['network_interface_id'] = network_interface_id
    
        # Listener creation
        if 'resources' in data and 'listeners' in data['resources']:
            credentials = load_aws_credentials()
            for listener in data['resources']['listeners']:
                region = listener.get('region')
                if not region:
                    raise ValueError("Region is required for creating a Listener.")
    
                # Use Load Balancer ARN and Target Group ARN from resource_outputs if they exist, otherwise use the defined ones in YAML
                load_balancer_arn = resource_outputs.get('load_balancer_arn') or listener.get('load_balancer_arn')
                target_group_arn = resource_outputs.get('target_group_arn') or listener.get('target_group_arn')
    
                # Check if the required dependencies are available
                if not load_balancer_arn:
                    raise ValueError("Load Balancer ARN is required for creating a Listener but was not found in the configuration or resource outputs.")
                if listener.get('action_type') == 'forward' and not target_group_arn:
                    raise ValueError("Target Group ARN is required for 'forward' action type but was not found in the configuration or resource outputs.")
    
                # Check if the Listener has already been created
                completed, resource_id, status = is_task_completed(execution_id, 'listener')
                if completed:
                    click.echo(f"Listener creation skipped, already completed. Existing Listener ARN: {resource_id}")
                    continue
    
                elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                listener_arn = create_listener(
                    elb_client,
                    listener['load_balancer_arn'],
                    listener['protocol'],
                    listener['port'],
                    listener.get('target_group_arn'),
                    listener.get('ssl_certificate_arn'),
                    listener.get('action_type', 'forward'),
                    execution_id
    
                )
                click.echo(f"Listener created with ARN: {listener_arn}")
    
                resource_outputs['listener_arn'] = listener_arn
    
        # Target Group creation
        if 'resources' in data and 'target_groups' in data['resources']:
            credentials = load_aws_credentials()
            for tg in data['resources']['target_groups']:
                region = tg.get('region')
                if not region:
                    raise ValueError("Region is required for creating a Target Group.")
    
                # Use VPC ID from resource_outputs if it exists, otherwise use the defined VPC ID in YAML
                vpc_id = resource_outputs.get('vpc_id') or tg.get('vpc_id')
                if not vpc_id:
                    raise ValueError("VPC ID is required for creating a Target Group but was not found in the configuration or resource outputs.")
    
                # Check if the Target Group has already been created
                completed, resource_id, status = is_task_completed(execution_id, 'target_group')
                if completed:
                    click.echo(f"Target Group creation skipped, already completed. Existing Target Group ARN: {resource_id}")
                    continue
    
                elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                tg['vpc_id'] = vpc_id
                tg_arn = create_target_group(
                        elb_client,
                        tg['name'],
                        tg['vpc_id'],
                        tg['protocol'],
                        tg['port'],
                        tg['target_type'],
                        tg['health_check_protocol'],
                        tg['health_check_port'],
                        tg.get('tags', []),
                        execution_id
                )
                click.echo(f"Target Group created with ARN: {tg_arn}")
                resource_outputs['target_group_arn'] = tg_arn
    
    
        # Register targets
        if 'resources' in data and 'target_registrations' in data['resources']:
            credentials = load_aws_credentials()
            for target_registration in data['resources']['target_registrations']:
                region = target_registration.get('region')
                if not region:
                    raise ValueError("Region is required for registering targets.")
    
                # Use Target Group ARN from resource_outputs if it exists, otherwise use the defined Target Group ARN in YAML
                target_group_arn = resource_outputs.get('target_group_arn') or target_registration.get('target_group_arn')
                if not target_group_arn:
                    raise ValueError("Target Group ARN is required for registering targets but was not found in the configuration or resource outputs.")
    
    
                # Check if the targets have already been registered for the target group
                completed, resurces_id, status = is_task_completed(execution_id, 'target_registration')
                if completed:
                    click.echo(f"Targets for Target Group {target_registration['target_group_arn']} already registered, skipping.")
                    continue
    
                elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
                response = register_targets(elb_client, target_registration['target_group_arn'], target_registration['targets'])
                target_registration['target_group_arn'] = target_group_arn
                click.echo(f"Targets registered to Target Group: {target_registration['target_group_arn']}")
    
        # S3 Bucket Creation
        if 'resources' in data and 's3_buckets' in data['resources']:
            credentials = load_aws_credentials()
            for s3_bucket in data['resources']['s3_buckets']:
                region = s3_bucket.get('region')
                if not region:
                    raise ValueError("Region is required for creating an S3 Bucket.")
    
                # Check if the S3 bucket has already been created
                completed, resource_id, status = is_task_completed(execution_id, 's3_bucket')
                if completed:
                    click.echo(f"S3 Bucket creation skipped, already completed. Existing Bucket Name: {resource_id}")
                    continue
    
                # Initialize the S3 client with the given region
                s3_client = boto3.client('s3', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                # Call the create_s3_bucket function with the appropriate parameters
                bucket_name = s3_bucket.get('bucket_name')
                public_access_block = s3_bucket.get('public_access_block', True)
                versioning = s3_bucket.get('versioning', False)
                lifecycle_rules = s3_bucket.get('lifecycle_rules', [])
                logging = s3_bucket.get('logging', None)
                encryption = s3_bucket.get('encryption', None)
    
                click.echo(f"Creating S3 Bucket: {bucket_name} in region {region}")
                create_s3_bucket(
                    bucket_name=bucket_name,
                    region=region,
                    public_access_block=public_access_block,
                    versioning=versioning,
                    lifecycle_rules=lifecycle_rules,
                    logging=logging,
                    encryption=encryption,
                    execution_id=execution_id
                )
                click.echo(f"S3 Bucket '{bucket_name}' created successfully.")
    
                resource_outputs['s3_bucket_name'] = bucket_name
    
    
    
        
        # CodeBuild creation
        if 'resources' in data and 'codebuild_projects' in data['resources']:
            credentials = load_aws_credentials()  # Load AWS credentials from a defined source
    
            for cb_project in data['resources']['codebuild_projects']:
                region = cb_project.get('region')
                if not region:
                    raise ValueError("Region is required for creating a CodeBuild project.")
    
                # Check if a service role is provided or retrieve from resource outputs
                service_role = resource_outputs.get('service_role') or cb_project.get('service_role')
                if not service_role:
                    raise ValueError("Service Role is required for creating a CodeBuild project but was not found in the configuration or resource outputs.")
    
                # Check if the CodeBuild project was already created
                completed, resource_id, status = is_task_completed(execution_id, 'codebuild_project')
                if not completed:
                    # Initialize the CodeBuild client
                    cb_client = boto3.client('codebuild', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                    # Create the CodeBuild project
                    cb_project_id = create_codebuild_project(cb_project, cb_client, execution_id)
                    click.echo(f"CodeBuild Project created with ID: {cb_project_id}")
    
                    # Record the created project's ID for future reference
                    resource_outputs['codebuild_project_id'] = cb_project_id
    
                else:
                    click.echo(f"CodeBuild Project creation skipped, already completed. Existing CodeBuild Project ID: {resource_id}")
                    resource_outputs['codebuild_project_id'] = resource_id  # Update resource outputs with the existing ID
    
        # Execution section for starting builds for CodeBuild projects
        if 'resources' in data and 'codebuild_builds' in data['resources']:
            # Load AWS credentials and create CodeBuild client
            credentials = load_aws_credentials()
            for cb_build in data['resources']['codebuild_builds']:
                region = cb_build.get('region')
                if not region:
                    raise ValueError("Region is required for starting a CodeBuild build.")
    
                # Initialize the CodeBuild client for the specified region
                cb_client = boto3.client('codebuild', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                # Retrieve the project name from the configuration
                project_name = cb_build.get('project_name')
                if not project_name:
                    raise ValueError("Project name is required to start a build.")
    
                # Optional: Collect environment variables from the configuration
                environment_variables = cb_build.get('environmentVariables', [])
    
                # Optional: Check for source version (branch, tag, or commit)
                source_version = cb_build.get('sourceVersion', 'main')  # Default to 'main' branch if not specified
    
                # Check if the build has already been started for this execution
                completed, build_id, status = is_task_completed(execution_id, 'codebuild_build')
                if not completed:
                    # Start the build for the CodeBuild project
                    build_id, build_status = start_build(cb_client, project_name, environment_variables, source_version, execution_id)
                    click.echo(f"CodeBuild Build started with ID: {build_id} and Status: {build_status}")
                else:
                    click.echo(f"CodeBuild Build already completed. Existing Build ID: {build_id}")
    
    
        # Section 2: Create the DynamoDB Table
        if 'resources' in data and 'dynamodb_tables' in data['resources']:
            credentials = load_aws_credentials()
            dynamodb = boto3.client('dynamodb', **credentials)
            for ddb_table in data['resources']['dynamodb_tables']:
                table_name = create_dynamodb_table(ddb_table,execution_id, dynamodb)
                click.echo(f"DynamoDB Table created: {table_name}")
    
        # Section 3: Update DynamoDB Table Throughput with Waiter
        if 'resources' in data and 'dynamodb_tables' in data['resources']:
            credentials = load_aws_credentials()
            dynamodb = boto3.client('dynamodb', **credentials)
    
            for ddb_table in data['resources']['dynamodb_tables']:
                # Wait for the table to be in ACTIVE state before updating
                try:
                    click.echo(f"Waiting for table {ddb_table['table_name']} to be ACTIVE...")
                    waiter = dynamodb.get_waiter('table_exists')
                    waiter.wait(TableName=ddb_table['table_name'])
                    click.echo(f"Table {ddb_table['table_name']} is now ACTIVE. Proceeding with throughput update.")
                except Exception as e:
                    click.echo(f"Failed to wait for table creation: {e}")
                    continue
    
                # Get the current table description
                table_desc = dynamodb.describe_table(TableName=ddb_table['table_name'])
                current_throughput = table_desc['Table']['ProvisionedThroughput']
    
                requested_throughput = ddb_table['provisioned_throughput']
    
                # Check if there is any change in throughput
                if (current_throughput['ReadCapacityUnits'] == requested_throughput['ReadCapacityUnits'] and
                    current_throughput['WriteCapacityUnits'] == requested_throughput['WriteCapacityUnits']):
                    click.echo(f"No changes in provisioned throughput for {ddb_table['table_name']}. Skipping update.")
                else:
    
                   # Now update the throughput
                    dynamodb.update_table(
                       TableName=ddb_table['table_name'],
                       ProvisionedThroughput=ddb_table['provisioned_throughput']
                    )
                    click.echo(f"Updated DynamoDB Table Throughput for: {ddb_table['table_name']}")
    
    
    
        # SSL Certificate creation
        if 'resources' in data and 'ssl_certificates' in data['resources']:
            credentials = load_aws_credentials()
            for cert in data['resources']['ssl_certificates']:
                region = cert.get('region')
                if not region:
                    raise ValueError("Region is required for requesting an SSL certificate.")
    
                # Initialize the ACM client
                acm_client = boto3.client('acm', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
                # Process the certificate request
                certificate_arn = ssl_certificate_request(
                    acm_client,
                    cert['domain_name'],
                    cert['validation_method'],
                    cert.get('subject_alternative_names', []),
                    cert.get('tags', [])
                )
                click.echo(f"SSL Certificate requested with ARN: {certificate_arn}")
    
    
        if 'tasks' in data:
            for task in data['tasks']:
                # Extract task details
                task_name = task.get('name', 'Unnamed Task')
                action = task['action']
                task_command = task.get('command', None)
                package = task.get('package', None)
                service = task.get('service', None)
                task_identifier = task.get('identifiers', 'ALL')
                category = task.get('category', None)
                loop_config = task.get('for_each', None) or task.get('count', None)
                when_config = task.get('when', None)
                # New function parameters
                tool = task.get('tool', None)
                credential_name = task.get('credential_name', None)
                artifact_dir = task.get('artifact_dir', None)
                s3_bucket_name = task.get('s3_bucket_name', None)
                sonar = task.get('sonar', False)
                clean_old_build = task.get('clean_old_build', False)
                image_name = task.get('image_name', "default-artifact-image:latest")
                if ':' not in image_name:
                    image_name += ":latest"
                archive_format = task.get('archive_format', 'zip')
                source_url = task.get('source_url', None)
                retries = task.get('retries', 0)
                timeout = task.get('timeout', None)
                notify_on_failure = task.get('notify_on_failure', False)
                condition = task.get('condition', None)
                depends_on = task.get('depends_on', None)
                dynamic_variables = task.get('dynamic_variables', None)  # Dynamic Variables
                parallel_execution = task.get('parallel_execution', False)  # Parallel Execution
                rollback_on_failure = task.get('rollback_on_failure', False)  # Rollback Mechanism
                custom_prompt = task.get('custom_prompt', None)  # Custom User Prompts
                health_checks = task.get('health_checks', None)  # Health Checks
                task_group = task.get('task_group', None)  # Task Grouping
                task_schedule = task.get('schedule', None)  # Task Scheduling
                custom_action = task.get('custom_action', None)  # Custom Actions
                environment_detection = task.get('environment_detection', False)  # Environment Detection
                resource_quota = task.get('resource_quota', None)  # Resource Management and Quotas
                fail_safe = task.get('fail_safe', False)  # Fail-Safe Mechanism
                import_tasks = task.get('import_tasks', None)  # Task Import
                enhanced_summary = task.get('enhanced_summary', False)  # Enhanced Summary Reporting
                notify_on_completion = task.get('notify_on_completion', False)  # Check for notification flag
                notification_recipients = task.get('notification_recipients', {})  # {'email': [], 'slack': []}
                notification_channels = task.get('notification_channels', ['email'])  # Support multiple channels
                schedule = task.get('schedule', None) 
                source_file = task.get('source_file', None)
                dest_path = task.get('dest_path', None)
    
                success = False
                message = ""
    
                click.echo(f"Action detected for task '{task_name}': {action}")
                
    
                if schedule:
                  if not should_run_task(schedule):
                      click.echo(f"Skipping task '{task_name}' as it is not scheduled to run at this time.")
                      continue
    
                # Handle user prompt (custom_prompt)
                if custom_prompt:
                    user_confirmation = click.confirm(custom_prompt, abort=False)
                    if not user_confirmation:
                        click.echo(click.style(f"Skipping task '{task_name}' due to user prompt response.", fg="yellow"))
                        summary['skipped'] += 1
                        continue
    
                # Determine the target identifiers based on category and task
                if task_identifier.lower() == 'all':
                    if category:
                        target_identifiers = get_all_identifiers_in_category(category, data)
                    else:
                        target_identifiers = [server.get('identifiers') for server in data['remote-server']]
                else:
                    try:
                        if category:
                            target_identifiers = [get_host_entry(task_identifier, category)[1]]
                        else:
                            target_identifiers = [get_host_entry(task_identifier)[1]]
                    except ValueError as e:
                        click.echo(click.style(f"Error: {e}", fg="red"))
                        continue
    
                for identifier in target_identifiers:
                    task_user = username
                    if not task_user:
                        for server in data['remote-server']:
                            if server.get('identifiers') == identifier:
                                task_user = server.get('username')
                                break
    
                    # Prepare context for condition evaluation
                    context = {
                        "os_type": "centos" if shutil.which('rpm') else "debian",  # Example of detecting OS type
                        "file_exists": file_exists,
                        "package_installed": package_installed,
                    }
    
                    # Handle loop functionality
                    loop_items = []
                    if loop_config:
                        if 'for_each' in loop_config:
                            loop_items = loop_config['for_each']
                        elif 'count' in loop_config:
                            loop_items = range(1, loop_config['count'] + 1)
    
                    if not loop_items:
                        loop_items = [None]
    
                    # Execute task for each identifier and loop item
                    for item in loop_items:
                        # Execute in parallel if parallel_execution is enabled
    
                        # Prepare loop-specific values
                        task_command_final = task_command
                        package_final = package
                        path_final = task.get('path', None)
      
                        # Replace placeholders in task parameters
                        if item is not None:
                            if isinstance(item, int):
                                task_command_final = task_command.replace('{{ count }}', str(item)) if task_command else None
                                path_final = path_final.replace('{{ count }}', str(item)) if path_final else None
                            else:
                                task_command_final = task_command.replace('{{ item }}', str(item)) if task_command else None
                                package_final = package.replace('{{ item }}', str(item)) if package else None
                                path_final = path_final.replace('{{ item }}', str(item)) if path_final else None
    
                        # Task dependency management
                        if depends_on:
                            if not check_task_completion(depends_on):
                                click.echo(f"Skipping task '{task_name}' as it depends on '{depends_on}' which hasn't completed.")
                                summary['skipped'] += 1
                                continue
    
                        # Check condition before executing the task
                        if when_config:
                            condition = when_config.get('condition')
                            if condition and not evaluate_condition(condition, context):
                                click.echo(click.style(f"Skipping task '{task_name}' as condition '{condition}' is false.", fg="yellow"))
                                summary['skipped'] += 1
                                continue
    
                            # Retry mechanism with backoff
                        if parallel_execution:
                            from multiprocessing import Process
                            process = Process(target=execute_task, args=(task, identifier, item))
                            process.start()
                            process.join()
    
                        else:
                            attempts = 0
    
                            while attempts <= retries:
    
                                try:
                                    # Execute appropriate action based on task type
                                    private_ip, _ = get_host_entry(identifier, category) if category else get_host_entry(identifier)
    
                                    if action == 'RUN' and task_command_final:
                                        success, message = execute_command_on_server(private_ip, task_user, task_command_final, timeout=timeout)
                                    elif action == 'CREATE' and path_final:
                                        success, message = execute_command_on_server(private_ip, task_user, f"mkdir -p {path_final}", timeout=timeout)
                                    elif action == 'INSTALL' and package_final:
                                    
                                        try:
                                            # Detect package manager based on the OS
                                            package_manager, update_command, install_command = get_package_manager()
    
                                            # Update package list (if applicable for the detected package manager)
                                            if update_command:
                                                success, message = execute_command_on_server(private_ip, task_user, update_command, timeout=timeout)
                                                if not success:
                                                    click.echo(click.style(f"Failed to update package list on {identifier} ({private_ip}). Continuing with installation.", fg="yellow"))
    
                                             # Check if the package is already installed
                                            if package_installed(package_final):
                                                 click.echo(f"Package {package_final} is already installed on {identifier} ({private_ip}).")
                                                 summary['already_installed'] += 1
                                                 success = True
                                            else:
                                                # Retry logic for package installation
                                                attempts = 0
                                                retries = task.get('retries', 2)
                                                while attempts <= retries:
                                                    success, message = execute_command_on_server(private_ip, task_user, f"{install_command} {package_final}", timeout=timeout)
                                                    if success:
                                                        click.echo(click.style(f"Package {package_final} installed successfully on {identifier} ({private_ip}).", fg="green"))
                                                        summary['installed'] += 1
                                                        break
                                                    else:
                                                           click.echo(click.style(f"Failed to install package {package_final} on {identifier} ({private_ip}) (Attempt {attempts + 1}/{retries + 1}). Error: {message}", fg="red"))
                                                           attempts += 1
    
                                                    if not success:
                                                          click.echo(click.style(f"Failed to install package {package_final} on {identifier} ({private_ip}) after {retries + 1} attempts.", fg="red"))
                                                          summary['skipped'] += 1
    
                                        except ValueError as e:
                                            click.echo(click.style(str(e), fg="red"))
                                            summary['skipped'] += 1
    
    
                                    elif action == 'START_SERVICE' and service:
                                        # Pre-check if the service exists before starting
                                        service_check_command = f"systemctl list-units --type=service --all | grep -Fq '{service}.service'"
                                        service_exists, _ = execute_command_on_server(private_ip, task_user, service_check_command)
    
                                        if not service_exists:
                                            click.echo(click.style(f"Service '{service}' not found on {identifier} ({private_ip}). Skipping start command.", fg="yellow"))
                                            summary['skipped'] += 1
                                        else:
                                            # Retry logic for starting the service
                                            attempts = 0
                                            retries = task.get('retries', 2)
                                            while attempts <= retries:
                                                success, message = execute_command_on_server(private_ip, task_user, f"systemctl start {service}", timeout=timeout)
                                                if success:
                                                    click.echo(click.style(f"Service '{service}' started successfully on {identifier} ({private_ip}).", fg="green"))
                                                    summary['started_service'] += 1
                                                    break
                                                else:
                                                    click.echo(click.style(f"Failed to start service '{service}' on {identifier} ({private_ip}) (Attempt {attempts + 1}/{retries + 1}). Error: {message}", fg="red"))
                                                    attempts += 1
    
                                            if not success:
                                                click.echo(click.style(f"Failed to start service '{service}' on {identifier} ({private_ip}) after {retries + 1} attempts.", fg="red"))
                                                summary['skipped'] += 1
    
                                    elif action == 'STOP_SERVICE' and service:
                                        # Pre-check if the service exists before stopping
                                        service_check_command = f"systemctl list-units --type=service --all | grep -Fq '{service}.service'"
                                        service_exists, _ = execute_command_on_server(private_ip, task_user, service_check_command)
    
                                        if not service_exists:
                                            click.echo(click.style(f"Service '{service}' not found on {identifier} ({private_ip}). Skipping stop command.", fg="yellow"))
                                            summary['skipped'] += 1
                                        else:
                                            # Retry logic for stopping the service
                                            attempts = 0
                                            retries = task.get('retries', 2)
                                            while attempts <= retries:
                                                success, message = execute_command_on_server(private_ip, task_user, f"systemctl stop {service}", timeout=timeout)
                                                if success:
                                                    click.echo(click.style(f"Service '{service}' stopped successfully on {identifier} ({private_ip}).", fg="green"))
                                                    summary['stopped_service'] += 1
                                                    break
                                                else:
                                                    click.echo(click.style(f"Failed to stop service '{service}' on {identifier} ({private_ip}) (Attempt {attempts + 1}/{retries + 1}). Error: {message}", fg="red"))
                                                    attempts += 1
    
                                                    if not success:
                                                        click.echo(click.style(f"Failed to stop service '{service}' on {identifier} ({private_ip}) after {retries + 1} attempts.", fg="red"))
                                                        summary['skipped'] += 1
                                    
    
    
                                    elif action == 'BUILD':
                                        click.echo(f"Starting trial for cloning in task '{task_name}' on {identifier} ({private_ip})...")
                                        # Essential Dependency Check
                                        essential_dependencies = {
                                            "docker": "docker --version",
                                            "aws": "aws --version",
                                            "zip": "zip --version"
                                            
                                        }
    
                                        optional_dependencies = {
                                            "tar": "tar --version",
                                            "java": "java -version"
                                        }
    
    
                                      
                                        # Check essential dependencies and install if missing
                                        for dep, check_cmd in essential_dependencies.items():
                                            click.echo(f"Checking if {dep} is installed on {identifier} ({private_ip})...")
                                            success, message = execute_command_on_server(private_ip, task_user, check_cmd)
                                            if not success:
                                                click.echo(click.style(f"{dep} is not installed. Attempting to install...", fg="yellow"))
                                                install_command = f"apt-get update && apt-get install -y {dep}"
                                                success, message = execute_command_on_server(private_ip, task_user, install_command)
                                                if not success:
                                                    click.echo(click.style(f"Failed to install {dep}: {message}", fg="red"))
                                                    summary['failed'] += 1
                                                    continue
    
                                        # Step 1: Clear and create the clone directory on the remote instance
                                        clone_dir = "/tmp/clone_repo_trial"
                                        click.echo(f"Setting up clone directory {clone_dir} on {identifier} ({private_ip})...")
                                        clear_clone_command = f"rm -rf {clone_dir} && mkdir -p {clone_dir}"
                                        success, message = execute_command_on_server(private_ip, task_user, clear_clone_command)
    
                                        if not success:
                                            click.echo(click.style(f"Failed to set up clone directory on {identifier} ({private_ip}): {message}", fg="red"))
                                            summary['failed'] += 1
                                            continue
    
                                        # Step 2: Clone the public repository
                                        clone_command = f"git clone {source_url} {clone_dir}"
                                        click.echo(click.style(f"Cloning public repository from {source_url} to {clone_dir} on {identifier} ({private_ip})...", fg="blue"))
                                        success, message = execute_command_on_server(private_ip, task_user, clone_command)
    
                                        if success:
                                            click.echo(click.style(f"Successfully cloned repository to {clone_dir} on {identifier} ({private_ip}).", fg="green"))
                                            summary['completed'] += 1
                                        else:
                                            click.echo(click.style(f"Failed to clone repository: {message}", fg="red"))
                                            summary['failed'] += 1
                                            continue
    
    
    
                                            # Determine the OS and select appropriate package manager
                                            os_check_command = "cat /etc/os-release"
                                            success, os_info = execute_command_on_server(private_ip, task_user, os_check_command)
                                            if success:
                                                if "ubuntu" in os_info.lower():
                                                    package_manager = "apt-get"
                                                    install_options = "-y"
                                                elif "centos" in os_info.lower() or "amzn" in os_info.lower():
                                                    package_manager = "yum"
                                                    install_options = "-y"
                                                else:
                                                    click.echo(click.style("Unsupported OS for automatic tool installation.", fg="red"))
                                                    summary['failed'] += 1
                                                    package_manager = None
                                            else:
                                                click.echo(click.style(f"Failed to determine OS type: {os_info}", fg="red"))
                                                summary['failed'] += 1
                                                package_manager = None
    
                                            # Install tools if package manager is available
                                            if package_manager:
                                                tool_install_commands = {
                                                    "docker": ("docker --version", [f"sudo {package_manager} install {install_options} docker"]),
                                                    "aws": ("aws --version", [f"sudo {package_manager} install {install_options} awscli"]),
                                                    "zip": ("zip --version", [f"sudo {package_manager} install {install_options} zip"]),
                                                    "unzip": ("unzip --version", [f"sudo {package_manager} install {install_options} unzip"]),
                                                    "wget": ("wget --version", [f"sudo {package_manager} install {install_options} wget"]),
                                                }
    
                                                def check_and_install_tool(tool_name, check_command, install_commands):
                                                    success, message = execute_command_on_server(private_ip, task_user, check_command)
                                                    if not success:
                                                        click.echo(click.style(f"{tool_name} not found. Installing {tool_name}...", fg="yellow"))
                                                        for command in install_commands:
                                                            success, message = execute_command_on_server(private_ip, task_user, command)
                                                            if success:
                                                                click.echo(click.style(f"{tool_name} installed successfully.", fg="green"))
                                                                return True
                                                        click.echo(click.style(f"Failed to install {tool_name} after multiple attempts: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                        return False
                                                    return True
    
                                                for tool, (check_command, install_commands) in tool_install_commands.items():
                                                    check_and_install_tool(tool, check_command, install_commands)
    
                                        # SonarQube scanner installation
                                        sonar_check_command = "sonar-scanner --version"
                                        success, message = execute_command_on_server(private_ip, task_user, sonar_check_command)
                                        if not success:
                                            click.echo(click.style("SonarQube scanner not found. Installing SonarQube scanner...", fg="yellow"))
                                            download_command = (
                                                "wget -q https://binaries.sonarsource.com/Distribution/sonar-scanner-cli/"
                                                "sonar-scanner-cli-4.6.2.2472-linux.zip -O /tmp/sonar-scanner.zip"
                                            )
                                            success, message = execute_command_on_server(private_ip, task_user, download_command)
                                            if not success:
                                                click.echo(click.style(f"Failed to download SonarQube scanner: {message}", fg="red"))
                                                summary['failed'] += 1
                                            else:
                                                unzip_command = "unzip -o /tmp/sonar-scanner.zip -d /opt/"
                                                success, message = execute_command_on_server(private_ip, task_user, unzip_command)
                                                if success:
                                                    move_command = "mv /opt/sonar-scanner-4.6.2.2472-linux /opt/sonar-scanner"
                                                    success, message = execute_command_on_server(private_ip, task_user, move_command)
                                                    if success:
                                                        link_command = "ln -sf /opt/sonar-scanner/bin/sonar-scanner /usr/local/bin/sonar-scanner"
                                                        success, message = execute_command_on_server(private_ip, task_user, link_command)
                                                        if success:
                                                            click.echo(click.style("SonarQube scanner installed and linked successfully.", fg="green"))
                                                            summary['completed'] += 1
                                                        else:
                                                            click.echo(click.style(f"Failed to create symlink for SonarQube scanner: {message}", fg="red"))
                                                            summary['failed'] += 1
                                                    else:
                                                        click.echo(click.style(f"Failed to move SonarQube scanner directory: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                else:
                                                    click.echo(click.style(f"Failed to unzip SonarQube scanner: {message}", fg="red"))
                                                    summary['failed'] += 1
    
                                        # Execute SonarQube analysis
                                       # Step 3: SonarQube Analysis (if enabled)
                                        sonar_config = task.get("sonar", {})
                                        if sonar_config.get("enabled"):
                                            click.echo("Running SonarQube analysis...")
                                        
    
    
                                            # Retrieve SonarQube configuration details
                                            sonar_url = sonar_config.get("server_url")
                                            project_key = sonar_config.get("project_key")
                                            sonar_token = sonar_config.get("token")
                                            scm_provider = sonar_config.get("scm_provider", "git")
                                            scm_disabled = sonar_config.get("scm_disabled", False)
                                        
                                            # Construct SonarQube analysis command
                                            sonar_command = (
                                                f"sonar-scanner "
                                                f"-Dsonar.projectKey={project_key} "
                                                f"-Dsonar.sources={clone_dir} "
                                                f"-Dsonar.host.url={sonar_url} "
                                                f"-Dsonar.login={sonar_token} "
                                            )
                                        
                                            # Optionally disable SCM if configured
                                            if scm_disabled:
                                                sonar_command += "-Dsonar.scm.disabled=true"
                                        
                                            # Execute SonarQube analysis
                                            success, message = execute_command_on_server(private_ip, task_user, sonar_command)
                                        
                                            # Display SonarQube logs based on success
                                            if success:
                                                click.echo(click.style("SonarQube analysis completed successfully. Here are the logs:", fg="green"))
                                                click.echo(message)  # Display full log output from SonarQube analysis
                                            else:
                                                click.echo(click.style(f"SonarQube analysis failed: {message}", fg="red"))
                                                summary['failed'] += 1
                                        else:
                                            click.echo(click.style("SonarQube analysis is not enabled; skipping this step.", fg="yellow"))
    
    
                                        
                                        # Continue with build steps...
                                        maven_config = task.get("maven", {})
                                        if maven_config.get("enabled"):
                                            click.echo("Starting Maven build...")
                                        
                                            # Essential dependencies for Maven build
                                            essential_dependencies = {
                                                "java": "java -version",
                                                "maven": "mvn -version"
                                            }
                                        
                                            # Check and install essential dependencies if missing
                                            for dep, check_cmd in essential_dependencies.items():
                                                click.echo(f"Checking if {dep} is installed on {identifier} ({private_ip})...")
                                                success, message = execute_command_on_server(private_ip, task_user, check_cmd)
                                                if not success:
                                                    click.echo(click.style(f"{dep} is not installed. Attempting to install...", fg="yellow"))
                                                    
                                                    # Dependency-specific install commands
                                                    if dep == "maven":
                                                        install_command = (
                                                            "apt-get update && apt-get install -y maven" if "ubuntu" in os_info.lower()
                                                            else "yum install -y maven"
                                                        )
                                                    else:
                                                        install_command = (
                                                            "apt-get update && apt-get install -y default-jdk" if "ubuntu" in os_info.lower()
                                                            else "yum install -y java-1.8.0-openjdk"
                                                        )
                                                    
                                                    success, message = execute_command_on_server(private_ip, task_user, install_command)
                                                    if not success:
                                                        click.echo(click.style(f"Failed to install {dep}: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                        continue
                                            
                                            # Get Maven-specific configuration values
                                            project_pom = maven_config.get("project_pom", "pom.xml")
                                            maven_goals = maven_config.get("goals", "clean install")
                                            profiles = maven_config.get("profiles", "")
                                            profile_option = f"-P{profiles}" if profiles else ""
                                            artifact_output_dir = maven_config.get("artifact_output_dir", "/tmp/maven_artifacts")
                                        
                                            # Ensure the artifact directory exists
                                            create_artifact_dir_command = f"mkdir -p {artifact_output_dir}"
                                            success, message = execute_command_on_server(private_ip, task_user, create_artifact_dir_command)
                                            if success:
                                                click.echo(click.style(f"Artifact directory '{artifact_output_dir}' created or already exists.", fg="green"))
                                            else:
                                                click.echo(click.style(f"Failed to create artifact directory '{artifact_output_dir}': {message}", fg="red"))
                                                summary['failed'] += 1
                                                return
                                        
                                            # Construct Maven build command
                                            maven_build_command = (
                                                f"cd {clone_dir} && mvn -f {project_pom} {maven_goals} {profile_option} "
                                                f"--batch-mode -DoutputDirectory={artifact_output_dir}"
                                            )
                                        
                                            # Execute Maven build command with real-time output
                                            success, message = execute_command_on_server(
                                                private_ip, task_user, maven_build_command, real_time_output=True
                                            )
                                        
                                            # Handle success or failure of the Maven build
                                            if success:
                                                click.echo(click.style(f"Maven build completed successfully. Artifacts stored in: {artifact_output_dir}", fg="green"))
                                                summary['completed'] += 1
                                            else:
                                                click.echo(click.style(f"Failed to build project with Maven: {message}", fg="red"))
                                                summary['failed'] += 1
                                                continue
    
    
                                        # Retrieve Trivy configuration
                                        trivy_config = task.get("trivy", {})
                                        if trivy_config.get("enabled"):
                                            click.echo("Preparing to run Trivy scan as part of the build stage...")
                                        
                                            # Define severity levels and target details from configuration
                                            severity_levels = trivy_config.get("severity", "HIGH,CRITICAL")
                                            target_type = trivy_config.get("target_type", "image")  # Default to image
                                            docker_image = "default_image_name"
                                            target_path = trivy_config.get("target_path", docker_image)  # Use Docker image by default
                                        
                                            # Check if Trivy is installed
                                            trivy_check_command = "trivy --version"
                                            success, message = execute_command_on_server(private_ip, task_user, trivy_check_command)
                                        
                                            # Install Trivy if missing
                                            if not success:
                                                click.echo(click.style("Trivy not found. Installing...", fg="yellow"))
                                                os_check_command = "cat /etc/os-release"
                                                success, os_info = execute_command_on_server(private_ip, task_user, os_check_command)
                                        
                                                if success:
                                                    if "ubuntu" in os_info.lower():
                                                        trivy_install_command = (
                                                            "apt-get install -y wget apt-transport-https gnupg lsb-release && "
                                                            "wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | apt-key add - && "
                                                            "echo 'deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main' | "
                                                            "tee -a /etc/apt/sources.list.d/trivy.list && "
                                                            "apt-get update && "
                                                            "apt-get install -y trivy"
                                                        )
                                                    elif "centos" in os_info.lower() or "amzn" in os_info.lower():
                                                        trivy_install_command = (
                                                            "echo '[trivy]\nname=Trivy repository\n"
                                                            "baseurl=https://aquasecurity.github.io/trivy-repo/rpm/releases/$releasever/$basearch/\n"
                                                            "gpgcheck=0\nenabled=1' | tee /etc/yum.repos.d/trivy.repo && "
                                                            "yum -y update && "
                                                            "yum -y install trivy"
                                                        )
                                                    else:
                                                        click.echo(click.style("Unsupported OS for Trivy installation.", fg="red"))
                                                        summary['failed'] += 1
                                                        continue
                                        
                                                    # Execute Trivy installation command
                                                    success, message = execute_command_on_server(private_ip, task_user, trivy_install_command)
                                                    if success:
                                                        click.echo(click.style("Trivy installed successfully.", fg="green"))
                                                    else:
                                                        click.echo(click.style(f"Failed to install Trivy: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                        continue
                                        
                                            # Construct Trivy scan command based on target type
                                            if target_type == "image":
                                                trivy_scan_command = f"trivy image --severity {severity_levels} {target_path}"
                                            elif target_type == "fs":
                                                trivy_scan_command = f"trivy fs --severity {severity_levels} {target_path}"
                                            elif target_type == "config":
                                                trivy_scan_command = f"trivy config --severity {severity_levels} {target_path}"
                                            elif target_type == "k8s":
                                                trivy_scan_command = f"trivy k8s --severity {severity_levels} --namespace {target_path}"  # Use namespace for Kubernetes scans
                                            else:
                                                click.echo(click.style("Unsupported Trivy scan target type specified.", fg="red"))
                                                summary['failed'] += 1
                                                continue
                                        
                                            # Run Trivy scan
                                            success, message = execute_command_on_server(private_ip, task_user, trivy_scan_command)
                                            if success:
                                                click.echo(click.style("Trivy scan completed successfully. Here are the results:", fg="green"))
                                                click.echo(message)  # Display scan results for review
                                            else:
                                                click.echo(click.style(f"Trivy scan failed: {message}", fg="red"))
                                                summary['failed'] += 1
     
                                                                            
                                        # Step 4: Archive the artifact
                                        artifact_dir = task.get("artifact_dir", "/tmp/artifacts")
                                        image_name = task.get("image_name", "trial-image:latest").split(":")[0] 
                                        make_artifact_dir_command = f"mkdir -p {artifact_dir}"
                                        archive_format = task.get("archive_format", "zip")  # Default to zip
    
                                        archive_path = os.path.join(artifact_dir, f"{image_name}.{archive_format}")
                                        execute_command_on_server(private_ip, task_user, make_artifact_dir_command)
    
                                        # Docker build process (if enabled)
                                        # Docker build process (if enabled)
                                        if task.get("docker_build", False):  # Default to False if not specified
                                            build_tag = task.get("build_tag", "latest")  # Dynamic build tag
                                            image_name = task.get("image_name", "website")  # Default image name
                                            built_image_name = f"{image_name}:{build_tag}"
                                        
                                            docker_build_command = f"cd {clone_dir} && docker build -t {built_image_name} ."
                                            click.echo(f"Building Docker image '{built_image_name}' from {clone_dir} on {identifier} ({private_ip})...")
                                        
                                            # Execute Docker build command with real-time output
                                            success, message = execute_command_on_server(
                                                private_ip,
                                                task_user,
                                                docker_build_command,
                                                real_time_output=True  # Enable real-time output for live logging
                                            )
                                        
                                            if success:
                                                click.echo(click.style(f"Docker image '{built_image_name}' built successfully on {identifier} ({private_ip}).", fg="green"))
                                                summary['completed'] += 1
                                            else:
                                                click.echo(click.style(f"Failed to build Docker image: {message}", fg="red"))
                                                summary['failed'] += 1
                                        else:
                                            click.echo("Docker build skipped as per configuration.")
                                        
    
                                        # Step 4: Archive the artifact (if enabled)
                                        if task.get("archive_artifact", False):  # Default to False if not specified
                                            archive_format = task.get("archive_format", "zip")  # Default to zip if not provided
                                            artifact_dir = task.get("artifact_dir", "/tmp/artifacts")
                                            image_name = task.get("image_name", "trial-image:latest").split(":")[0]  # Get the image name without the tag
                                            archive_path = os.path.join(artifact_dir, f"{image_name}.{archive_format.split(':')[0]}")  # Strip any tag if present
                                        
                                            # Ensure artifact directory exists
                                            make_artifact_dir_command = f"mkdir -p {artifact_dir}"
                                            click.echo(f"Creating artifact directory at '{artifact_dir}' on {identifier} ({private_ip})...")
                                            execute_command_on_server(private_ip, task_user, make_artifact_dir_command, real_time_output=True)
                                        
                                            # Construct archive command based on the format
                                            if archive_format == "zip":
                                                archive_command = f"cd {clone_dir} && zip -r {archive_path} ."
                                            else:
                                                archive_command = f"cd {clone_dir} && tar -czf {archive_path} ."
                                        
                                            # Execute the archive command with real-time logging
                                            click.echo(f"Archiving artifact as '{archive_path}' on {identifier} ({private_ip})...")
                                            success, message = execute_command_on_server(
                                                private_ip,
                                                task_user,
                                                archive_command,
                                                real_time_output=True  # Enable real-time output to view logs immediately
                                            )
                                        
                                            # Check for successful archiving
                                            if success:
                                                click.echo(click.style(f"Artifact archived successfully as '{archive_path}' on {identifier} ({private_ip}).", fg="green"))
                                                summary['completed'] += 1
                                            else:
                                                click.echo(click.style(f"Failed to archive artifact: {message}", fg="red"))
                                                summary['failed'] += 1
                                        else:
                                            click.echo("Artifact archiving skipped as per configuration.")
    
    
    
                                        # Step 5: Uploading to S3 if specified
    
                                        # Step 5: Uploading to S3 if specified
                                        s3_config = task.get("s3", {})
                                        s3_bucket_name = s3_config.get("bucket_name", "")
                                        
                                        if s3_config.get("enabled") and s3_bucket_name:
                                            click.echo(click.style(f"Uploading '{archive_path}' to S3 bucket '{s3_bucket_name}'...", fg="blue"))
                                        
                                            # Execute S3 upload command on the remote instance with real-time logging
                                            s3_upload_command = f"aws s3 cp {archive_path} s3://{s3_bucket_name}/{os.path.basename(archive_path)}"
                                            success, message = execute_command_on_server(
                                                private_ip, 
                                                task_user, 
                                                s3_upload_command, 
                                                real_time_output=True  # Enable real-time output for live logging
                                            )
                                        
                                            # Check for successful upload
                                            if success:
                                                click.echo(click.style(f"Artifact successfully uploaded to S3 bucket '{s3_bucket_name}'.", fg="green"))
                                                summary['uploaded'] += 1
                                            else:
                                                click.echo(click.style(f"Failed to upload to S3: {message}", fg="red"))
                                                summary['failed'] += 1
                                        else:
                                            click.echo("S3 upload skipped as per configuration.")
    
                                        # Docker Hub push logic under the BUILD action
                                        docker_hub = task.get("docker_hub", {})
                                        if docker_hub.get("enabled"):
                                            docker_username = docker_hub.get("username")
                                            docker_password = docker_hub.get("password")
                                            repository_name = docker_hub.get("repository")
                                            image_tag = docker_hub.get("image_tag", "latest")  # Image tag to push
                                            full_image_name = f"{docker_username}/{repository_name}:{image_tag}"
                                        
                                            click.echo(f"Preparing to push Docker image '{full_image_name}' to Docker Hub...")
                                        
                                            # Step 1: Check if Docker is installed
                                            docker_check_command = "docker --version"
                                            success, message = execute_command_on_server(private_ip, task_user, docker_check_command)
                                            if not success:
                                                click.echo(click.style("Docker not found. Aborting Docker Hub push.", fg="red"))
                                                summary['failed'] += 1
                                            else:
                                                # Step 2: Log in to Docker Hub
                                                login_command = f"echo {docker_password} | docker login -u {docker_username} --password-stdin"
                                                success, message = execute_command_on_server(private_ip, task_user, login_command)
                                                if not success:
                                                    click.echo(click.style(f"Failed to log in to Docker Hub: {message}", fg="red"))
                                                    summary['failed'] += 1
                                                else:
                                                    # Step 3: Tag and Push Docker Image
                                                    click.echo(f"Tagging Docker image '{built_image_name}' as '{full_image_name}'...")
                                                    tag_command = f"docker tag {built_image_name} {full_image_name}"
                                                    success, message = execute_command_on_server(private_ip, task_user, tag_command)
                                                    if not success:
                                                        click.echo(click.style(f"Failed to tag Docker image: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                    else:
                                                        click.echo(f"Pushing Docker image '{full_image_name}' to Docker Hub...")
                                                        push_command = f"docker push {full_image_name}"
                                                        success, message = execute_command_on_server(private_ip, task_user, push_command)
                                                        if success:
                                                            click.echo(click.style(f"Docker image '{full_image_name}' pushed to Docker Hub successfully.", fg="green"))
                                                            summary['completed'] += 1
                                                        else:
                                                            click.echo(click.style(f"Failed to push Docker image to Docker Hub: {message}", fg="red"))
                                                            summary['failed'] += 1
                                                            continue
                                        # Cleanup clone directory automatically
                                        click.echo(f"Cleaning up clone directory {clone_dir} on {identifier} ({private_ip})...")
                                        cleanup_clone_command = f"rm -rf {clone_dir}"
                                        execute_command_on_server(private_ip, task_user, cleanup_clone_command)
    
                                        # Optional Docker system prune if user requests full cleanup
    
                                        if task.get("clean_old_build", False):  # Corrected typo here
                                            click.echo(f"Pruning Docker system on {identifier} ({private_ip}) to remove unused data...")
                                            docker_prune_command = "docker system prune -f"
                                            success, message = execute_command_on_server(private_ip, task_user, docker_prune_command)
                                            if success:
                                                click.echo(click.style(f"Docker system pruned successfully on {identifier} ({private_ip}).", fg="green"))
                                            else:
                                                click.echo(click.style(f"Failed to prune Docker system: {message}", fg="red"))
                                                summary['failed'] += 1
    
                                    elif action == 'DEPLOYMENT':
                                        click.echo(f"Starting deployment for task '{task_name}' on {identifier} ({private_ip})...")
    
    
                                        # Step 4: Archive the artifact
                                        artifact_dir = task.get("artifact_dir", "/tmp/artifacts")
                                        image_name = task.get("image_name", "trial-image:latest").split(":")[0]
                                        make_artifact_dir_command = f"mkdir -p {artifact_dir}"
                                        archive_format = task.get("archive_format", "zip")  # Default to zip
    
                                        archive_path = os.path.join(artifact_dir, f"{image_name}.{archive_format}")
    
    
                                        # Define deployment artifacts and settings
                                        deploy_type = task.get("deploy_type", "s3")  # Default to 's3'
                                        destination_path = task.get("destination_path", "/var/www/html")
                                        expose_port = task.get("expose_port", 80)
    
                                        # Detect OS and choose package manager
                                        os_check_command = "cat /etc/os-release"
                                        success, os_info = execute_command_on_server(private_ip, task_user, os_check_command)
                                        if success:
                                            if "ubuntu" in os_info.lower():
                                                package_manager = "apt-get"
                                                install_options = "-y"
                                            elif "centos" in os_info.lower() or "amzn" in os_info.lower():
                                                package_manager = "yum"
                                                install_options = "-y"
                                            else:
                                                click.echo(click.style("Unsupported OS for automatic tool installation.", fg="red"))
                                                summary['failed'] += 1
                                                package_manager = None
                                        else:
                                            click.echo(click.style(f"Failed to determine OS type: {os_info}", fg="red"))
                                            summary['failed'] += 1
                                            package_manager = None
    
                                        # Install prerequisites based on deployment type
                                        prerequisites = {
                                            "docker": "docker --version" if deploy_type == "docker_hub" else None,
                                            "nginx": "nginx -v",
                                            "aws": "aws --version" if deploy_type == "s3" else None,
                                            "zip": "zip --version" if deploy_type == "s3" and task.get("artifact_key", "").endswith(".zip") else None,
                                            "unzip": "unzip --version" if deploy_type == "s3" and task.get("artifact_key", "").endswith(".zip") else None
                                        }
    
                                        for tool, check_command in prerequisites.items():
                                            if check_command:
                                                success, message = execute_command_on_server(private_ip, task_user, check_command)
                                                if not success:
                                                    click.echo(click.style(f"{tool} is not installed. Attempting to install...", fg="yellow"))
                                                    install_command = f"sudo {package_manager} install {install_options} {tool}"
                                                    success, message = execute_command_on_server(private_ip, task_user, install_command)
                                                    if success:
                                                        click.echo(click.style(f"{tool} installed successfully.", fg="green"))
                                                    else:
                                                        click.echo(click.style(f"Failed to install {tool}: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                        continue
    
                                        # Deployment Process
                                        # Deployment Process
                                        if deploy_type == "s3":
                                            s3_config = task.get("s3", {})
                                            s3_bucket_name = s3_config.get("bucket_name")
                                            artifact_key = s3_config.get("artifact_key", os.path.basename(archive_path))  # Default to file name if no key is provided
                                            destination_path = task.get("destination_path", "/var/www/html")  # Default deployment path
                                        
                                            if s3_bucket_name and artifact_key:
                                                click.echo(click.style(f"Downloading artifact '{artifact_key}' from S3 bucket '{s3_bucket_name}'...", fg="blue"))
                                        
                                                # Download artifact using IAM role permissions
                                                download_command = f"aws s3 cp s3://{s3_bucket_name}/{artifact_key} /tmp/{os.path.basename(artifact_key)}"
                                                success, message = execute_command_on_server(
                                                    private_ip,
                                                    task_user,
                                                    download_command,
                                                    real_time_output=True  # Enable real-time output for live logging
                                                )
                                        
                                                if success:
                                                    click.echo(click.style("Artifact downloaded successfully from S3.", fg="green"))
                                        
                                                    # Extract and deploy based on file type
                                                    if artifact_key.endswith(".zip"):
                                                        extract_command = f"unzip -o /tmp/{os.path.basename(artifact_key)} -d {destination_path}"
                                                    else:
                                                        extract_command = f"tar -xzf /tmp/{os.path.basename(artifact_key)} -C {destination_path}"
                                        
                                                    success, message = execute_command_on_server(
                                                        private_ip, task_user, extract_command, real_time_output=True  # Real-time log for extraction
                                                    )
                                                    if success:
                                                        click.echo(click.style(f"Artifact deployed successfully to {destination_path}.", fg="green"))
                                                        summary['completed'] += 1
                                                    else:
                                                        click.echo(click.style(f"Failed to extract artifact: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                else:
                                                    click.echo(click.style(f"Failed to download artifact from S3: {message}", fg="red"))
                                                    summary['failed'] += 1
                                            else:
                                                click.echo(click.style("S3 bucket name or artifact key not specified for deployment.", fg="red"))
                                                summary['failed'] += 1
     
                                                                             
                                        elif deploy_type == "docker_hub":
                                            docker_hub_config = task.get("docker_hub", {})
                                            host_port = docker_hub_config.get("host_port" )
                                            container_port = docker_hub_config.get("container_port", 80)
                                            docker_image = docker_hub_config.get("image")
                                            container_name = docker_hub_config.get("container_name", "web_app")
                                            trivy_config = task.get("trivy", {})
    
                                            # Check if Docker is installed
                                            docker_check_command = "docker --version"
                                            success, message = execute_command_on_server(private_ip, task_user, docker_check_command)
                                            if not success:
                                                click.echo(click.style("Docker not found. Aborting deployment.", fg="red"))
                                                summary['failed'] += 1
                                                continue
                                        
                                            # Trivy scan if enabled
                                            if trivy_config.get("enabled"):
                                                click.echo(f"Running Trivy scan for Docker image '{docker_image}'...")
                                                severity_levels = trivy_config.get("severity", "HIGH,CRITICAL")
                                                trivy_check_command = "trivy --version"
                                                success, message = execute_command_on_server(private_ip, task_user, trivy_check_command)
                                        
                                                # Check and install Trivy if missing
                                                if not success:
                                                    click.echo(click.style("Trivy not found. Installing...", fg="yellow"))
                                                    os_check_command = "cat /etc/os-release"
                                                    success, os_info = execute_command_on_server(private_ip, task_user, os_check_command)
                                        
                                                    if success:
                                                        if "ubuntu" in os_info.lower():
                                                            trivy_install_command = (
                                                                "apt-get install -y wget apt-transport-https gnupg lsb-release && "
                                                                "wget -qO - https://aquasecurity.github.io/trivy-repo/deb/public.key | apt-key add - && "
                                                                "echo 'deb https://aquasecurity.github.io/trivy-repo/deb $(lsb_release -sc) main' | "
                                                                "tee -a /etc/apt/sources.list.d/trivy.list && "
                                                                "apt-get update && "
                                                                "apt-get install -y trivy"
                                                            )
                                                        elif "centos" in os_info.lower() or "amzn" in os_info.lower():
                                                            trivy_install_command = (
                                                                "echo '[trivy]\nname=Trivy repository\n"
                                                                "baseurl=https://aquasecurity.github.io/trivy-repo/rpm/releases/$releasever/$basearch/\n"
                                                                "gpgcheck=0\nenabled=1' | tee /etc/yum.repos.d/trivy.repo && "
                                                                "yum -y update && "
                                                                "yum -y install trivy"
                                                            )
                                                        else:
                                                            click.echo(click.style("Unsupported OS for Trivy installation.", fg="red"))
                                                            summary['failed'] += 1
                                                            continue
                                        
                                                        # Execute Trivy installation command
                                                        success, message = execute_command_on_server(private_ip, task_user, trivy_install_command)
                                                        if success:
                                                            click.echo(click.style("Trivy installed successfully.", fg="green"))
                                                        else:
                                                            click.echo(click.style(f"Failed to install Trivy: {message}", fg="red"))
                                                            summary['failed'] += 1
                                                            continue
                                        
                                                # Run Trivy scan on the Docker image
                                                trivy_scan_command = f"trivy image --severity {severity_levels} {docker_image}"
                                                success, message = execute_command_on_server(private_ip, task_user, trivy_scan_command)
                                                if success:
                                                    click.echo(click.style("Trivy scan completed successfully. Here are the results:", fg="green"))
                                                    click.echo(message)  # Display scan results for review
                                                else:
                                                    click.echo(click.style(f"Trivy scan failed: {message}", fg="red"))
                                                    summary['failed'] += 1
                                                    continue
                                        
                                            # Docker deployment steps if image specified
                                            if docker_image:
                                                click.echo(click.style(f"Pulling Docker image '{docker_image}' from Docker Hub...", fg="blue"))
                                                pull_command = f"docker pull {docker_image}"
                                                success, message = execute_command_on_server(private_ip, task_user, pull_command)
                                        
                                                if success:
                                                    click.echo(click.style(f"Docker image '{docker_image}' pulled successfully.", fg="green"))
                                        
                                                    # Stop and remove any existing container with the same name
                                                    check_container_command = f"docker ps -a -q -f name={container_name}"
                                                    container_id, _ = execute_command_on_server(private_ip, task_user, check_container_command)
                                                    if container_id:
                                                        click.echo(click.style(f"Stopping and removing existing container '{container_name}'...", fg="yellow"))
                                                        stop_command = f"docker stop {container_name}"
                                                        remove_command = f"docker rm {container_name}"
                                                        execute_command_on_server(private_ip, task_user, stop_command)
                                                        execute_command_on_server(private_ip, task_user, remove_command)
                                        
                                                    # Run Docker container with specified ports
                                                    run_command = f"docker run -d -p {host_port}:{container_port} --name {container_name} {docker_image}"
                                                    click.echo(f"Running Docker container '{container_name}' with host port {host_port} mapped to container port {container_port}...")
                                                    success, message = execute_command_on_server(private_ip, task_user, run_command)
                                                    if success:
                                                        click.echo(click.style(f"Docker container '{container_name}' deployed successfully on port {host_port}.", fg="green"))
                                                        summary['completed'] += 1
                                                    else:
                                                        click.echo(click.style(f"Failed to start Docker container: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                else:
                                                    click.echo(click.style(f"Failed to pull Docker image from Docker Hub: {message}", fg="red"))
                                                    summary['failed'] += 1
                                            else:
                                                click.echo(click.style("Docker image not specified for deployment.", fg="red"))
                                                summary['failed'] += 1
    
    
    
                                    elif action == "PIPELINE":
                                        click.echo(f"Starting Continuous Integration Pipeline for task '{task_name}' on {identifier} ({private_ip})...")
                                    
                                        # Repository configuration
                                        repo_config = task.get("repository", {})
                                        repo_url = repo_config.get("url")
                                        repo_branch = repo_config.get("branch", "main")
                                        auto_pull = repo_config.get("auto_pull", True)
                                    
                                        # Docker, SonarQube, and Trivy configuration
                                        docker_hub_config = task.get("docker_hub", {})
                                        sonar_config = task.get("sonar", {})
                                        trivy_config = task.get("trivy", {})
                                        approval_config = task.get("approval", {})
                                        deployment_config = task.get("deployment", {})
                                        container_count = deployment_config.get("count", 1)
                                        # Define container and image configuration
                                        image_name = docker_hub_config.get("image_name", "local_image")
                                        image_tag = docker_hub_config.get("image_tag", "latest")
                                        full_image_name = f"{image_name}:{image_tag}"
                                        container_name = docker_hub_config.get("container_name", "pipeline_container")
                                        host_port = docker_hub_config.get("host_port", 8080)
                                        container_port = docker_hub_config.get("container_port", 80)
                                    
                                        # Set up clone directory on the remote instance
                                        clone_dir = "/tmp/clone_repo_pipeline"
                                        click.echo(f"Setting up clone directory {clone_dir} on {identifier} ({private_ip})...")
                                        clear_clone_command = f"rm -rf {clone_dir} && mkdir -p {clone_dir}"
                                        success, message = execute_command_on_server(private_ip, task_user, clear_clone_command)
                                    
                                        if not success:
                                            click.echo(click.style(f"Failed to set up clone directory on {identifier} ({private_ip}): {message}", fg="red"))
                                            summary['failed'] += 1
                                            continue
                                    
                                        # Step 2: Clone the public repository
                                        if auto_pull:
                                            # If auto_pull is enabled, pull updates if the repo exists; else clone
                                            pull_command = f"cd {clone_dir} && git pull origin {repo_branch}" if os.path.isdir(clone_dir) else f"git clone -b {repo_branch} {repo_url} {clone_dir}"
                                            clone_command = f"git clone -b {repo_branch} {repo_url} {clone_dir}"
                                        else:
                                            clone_command = f"git clone -b {repo_branch} {repo_url} {clone_dir}"
                                    
                                        click.echo(click.style(f"Cloning public repository from {repo_url} to {clone_dir} on {identifier} ({private_ip})...", fg="blue"))
                                        success, message = execute_command_on_server(private_ip, task_user, clone_command)
                                    
                                        if success:
                                            click.echo(click.style(f"Successfully cloned repository to {clone_dir} on {identifier} ({private_ip}).", fg="green"))
                                            summary['completed'] += 1
                                        else:
                                            click.echo(click.style(f"Failed to clone repository: {message}", fg="red"))
                                            summary['failed'] += 1
                                            continue                               
    
                                        # Step 3: SonarQube Analysis (if enabled)
                                        if sonar_config.get("enabled"):
                                            click.echo("Running SonarQube analysis...")
                                            sonar_url = sonar_config.get("server_url")
                                            project_key = sonar_config.get("project_key")
                                            sonar_token = sonar_config.get("token")
                                            scm_provider = sonar_config.get("scm_provider", "git")
                                            scm_disabled = sonar_config.get("scm_disabled", False)
                                            sonar_command = (
                                                f"sonar-scanner "
                                                f"-Dsonar.projectKey={project_key} "
                                                f"-Dsonar.sources={clone_dir} "
                                                f"-Dsonar.host.url={sonar_url} "
                                                f"-Dsonar.login={sonar_token}"
                                            )
                                            if scm_disabled:
                                                sonar_command += "-Dsonar.scm.disabled=true"
    
                                            success, message = execute_command_on_server(private_ip, task_user, sonar_command)
    
                                            # Display SonarQube logs in detail
                                            if success:
                                                click.echo(click.style("SonarQube analysis completed successfully. Here are the logs:", fg="green"))
                                                click.echo(message)  # Show full log output from SonarQube analysis
                                            else:
                                                click.echo(click.style(f"SonarQube analysis failed: {message}", fg="red"))
                                                summary['failed'] += 1
    
    
                                                continue
                                    
                                        # Step 4: Build Docker Image
                                        dockerfile_path = f"{clone_dir}/Dockerfile"
                                        build_command = f"cd {clone_dir} && docker build -t {full_image_name} -f {dockerfile_path} ."
                                        click.echo(f"Building Docker image '{full_image_name}' from {dockerfile_path}...")
                                        success, message = execute_command_on_server(private_ip, task_user, build_command)
                                    
                                        if success:
                                            click.echo(click.style(f"Docker image '{full_image_name}' built successfully.", fg="green"))
                                        else:
                                            click.echo(click.style(f"Failed to build Docker image: {message}", fg="red"))
                                            summary['failed'] += 1
                                            continue
                                    
                                        # Step 4: Trivy Security Scan
                                        if trivy_config.get("enabled"):
                                            click.echo(f"Running Trivy scan for Docker image '{full_image_name}'...")
                                            severity_levels = trivy_config.get("severity", "HIGH,CRITICAL")
                                            trivy_scan_command = f"trivy image --severity {severity_levels} {full_image_name}"
                                            success, message = execute_command_on_server(private_ip, task_user, trivy_scan_command)
                                            
                                            # Display Trivy logs in detail
                                            if success:
                                                click.echo(click.style("Trivy scan completed successfully. Here are the logs:", fg="green"))
                                                click.echo(message)  # Show full log output from Trivy scan
                                            else:
                                                click.echo(click.style(f"Trivy scan failed: {message}", fg="red"))
                                                summary['failed'] += 1
                                                continue
                          
                                        # Step 5: Approval Step
                                        if approval_config.get("enabled"):
                                            approval = input("Build completed. Do you want to proceed with deployment? [Y/n]: ")
                                            if approval.lower() != 'y':
                                                click.echo(click.style("Deployment aborted by user.", fg="yellow"))
                                                summary['aborted'] += 1
                                                continue
                                    
                                       # Step 7: Deployment with Options
                                        if deployment_config.get("enable_deployment", True):
                                            for i in range(container_count):
                                                instance_name = f"{container_name}_{i + 1}"
                                    
                                                # Stop and remove old containers if enabled
                                                if deployment_config.get("enable_delete_old", True):
                                                    check_container_command = f"docker ps -a -q -f name={instance_name}"
                                                    container_id, _ = execute_command_on_server(private_ip, task_user, check_container_command)
                                                    if container_id:
                                                        click.echo(f"Stopping and removing existing container '{instance_name}'...")
                                                        stop_command = f"docker stop {instance_name}"
                                                        remove_command = f"docker rm {instance_name}"
                                                        execute_command_on_server(private_ip, task_user, stop_command)
                                                        execute_command_on_server(private_ip, task_user, remove_command)
                                    
                                                # Blue-Green Deployment (if enabled)
                                                if deployment_config.get("enable_blue_green", False):
                                                    green_instance_name = f"{instance_name}_green"
                                                    click.echo(f"Starting Blue-Green deployment for '{instance_name}'...")
                                    
                                                    # Deploy Green container
                                                    run_green_command = f"docker run -d -p {host_port}:{container_port} --name {green_instance_name} {full_image_name}"
                                                    success, message = execute_command_on_server(private_ip, task_user, run_green_command)
                                    
                                                    if success:
                                                        click.echo(click.style(f"Green container '{green_instance_name}' deployed successfully.", fg="green"))
                                    
                                                        # Health Check for Green container (assuming a /health endpoint)
                                                        health_check_command = f"curl -f http://localhost:{host_port}/health"
                                                        health_success, _ = execute_command_on_server(private_ip, task_user, health_check_command)
                                    
                                                        if health_success:
                                                            # Stop and remove Blue container
                                                            click.echo(f"Switching traffic to Green container '{green_instance_name}' and removing Blue container '{instance_name}'...")
                                                            stop_command = f"docker stop {instance_name}"
                                                            remove_command = f"docker rm {instance_name}"
                                                            execute_command_on_server(private_ip, task_user, stop_command)
                                                            execute_command_on_server(private_ip, task_user, remove_command)
                                    
                                                            # Rename Green to Blue
                                                            rename_command = f"docker rename {green_instance_name} {instance_name}"
                                                            execute_command_on_server(private_ip, task_user, rename_command)
                                                            click.echo(click.style(f"Blue-Green deployment completed for '{instance_name}'.", fg="green"))
                                                        else:
                                                            click.echo(click.style("Green container failed health check, rolling back.", fg="red"))
                                                            # Roll back by stopping and removing Green container
                                                            rollback_command = f"docker stop {green_instance_name} && docker rm {green_instance_name}"
                                                            execute_command_on_server(private_ip, task_user, rollback_command)
                                                            summary['failed'] += 1
                                                            continue
                                                    else:
                                                        click.echo(click.style(f"Failed to deploy Green container: {message}", fg="red"))
                                                        summary['failed'] += 1
                                                        continue
                                    
                                                # Standard Deployment (if Blue-Green is not enabled)
                                                else:
                                                    run_command = f"docker run -d -p {host_port + i}:{container_port} --name {instance_name} {full_image_name}"
                                                    click.echo(f"Deploying Docker container '{instance_name}' on port {host_port + i}...")
                                                    success, message = execute_command_on_server(private_ip, task_user, run_command)
                                                    if success:
                                                        click.echo(click.style(f"Docker container '{instance_name}' deployed successfully on port {host_port + i}.", fg="green"))
                                                        summary['completed'] += 1
                                                    else:
                                                        click.echo(click.style(f"Failed to deploy Docker container: {message}", fg="red"))
                                                        summary['failed'] += 1
                                    
                                            # Load Balancing (if enabled)
                                            if deployment_config.get("enable_load_balancing", False):
                                                lb_command = f"setup-load-balancer --container-name {container_name}"
                                                success, message = execute_command_on_server(private_ip, task_user, lb_command)
                                                if success:
                                                    click.echo(click.style(f"Load balancer configured for '{container_name}'.", fg="green"))
                                                else:
                                                    click.echo(click.style(f"Failed to configure load balancer: {message}", fg="red"))
                                                    summary['failed'] += 1 
                                    
    
    
                                    elif action == 'CHECK_SERVICE' and service:
                                        # Pre-check if the service exists before checking the status
                                        service_check_command = f"systemctl list-units --type=service --all | grep -Fq '{service}.service'"
                                        service_exists, _ = execute_command_on_server(private_ip, task_user, service_check_command)
    
                                        if not service_exists:
                                            click.echo(click.style(f"Service '{service}' not found on {identifier} ({private_ip}). Skipping status check.", fg="yellow"))
                                            summary['skipped'] += 1
                                        else:
                                            # Retry logic for checking the service status
                                            attempts = 0
                                            retries = task.get('retries', 2)
                                            while attempts <= retries:
                                                success, message = execute_command_on_server(private_ip, task_user, f"systemctl status {service}", timeout=timeout)
                                                if success:
                                                    click.echo(click.style(f"Service '{service}' status on {identifier} ({private_ip}):\n{message}", fg="green"))
                                                    summary['service_status_checked'] += 1
                                                    break
                                                else:
                                                    click.echo(click.style(f"Failed to check status of service '{service}' on {identifier} ({private_ip}) (Attempt {attempts + 1}/{retries + 1}). Error: {message}", fg="red"))
                                                    attempts += 1
    
                                                    if not success:
                                                       click.echo(click.style(f"Failed to check status of service '{service}' on {identifier} ({private_ip}) after {retries + 1} attempts.", fg="red"))
                                                       summary['skipped'] += 1
    
                                    elif action == 'DELETE' and path_final:
                                        success, message = execute_command_on_server(private_ip, task_user, f"rm -rf {path_final}", timeout=timeout)
                                        if success:
                                            summary['deleted'] += 1
                                    elif action == 'MOVE':
                                        src = task.get('src')
                                        dest = task.get('dest')
                                        if src and dest:
                                            success, message = execute_command_on_server(private_ip, task_user, f"mv {src} {dest}", timeout=timeout)
                                            if success:
                                                summary['moved'] += 1
                                    elif action == 'COPY':
                                        rc = task.get('src')
                                        dest = task.get('dest')
                                        if src and dest:
                                            handle_copy_task(src, dest)
                                            if success:
                                                summary['copied'] += 1
                                    elif action == 'DOWNLOAD':
                                        url = task.get('url')
                                        dest = task.get('dest')
                                        if url and dest:
                                            success, message = execute_command_on_server(private_ip, task_user, f"wget {url} -O {dest}", timeout=timeout)
                                            if success:
                                                summary['downloaded'] += 1
                                    elif action == 'REMOTE_TRANSFER':
                                          if source_url and dest_path:
                                              if os.path.isdir(dest_path):
                                                  dest_file_path = os.path.join(dest_path, os.path.basename(source_url))
                                              else:
                                                  dest_file_path = dest_path
                                              
                                              download_command = f"wget -O {dest_path} {source_url} || curl -o {dest_path} {source_url}"
                                              click.echo(click.style(f"Downloading from {source_url} to {task_user}@{private_ip}:{dest_path}", fg="green"))
                                              success, message = execute_command_on_server(private_ip, task_user, download_command, timeout=timeout)
                                              if success:
                                                  if "saved" in message.lower():
                                                      click.echo(click.style(f"File downloaded successfully to {identifier} ({private_ip})", fg="green"))
                                                      summary['transferred'] += 1
                                              else:
                                                  click.echo(click.style(f"File may have been downloaded, but encountered an error: {message}", fg="yellow"))
                                                  summary['skipped'] += 1
    
                                          else:
                                              click.echo(click.style("Source URL or destination path is missing for remote file transfer.", fg="red"))
                                              summary['skipped'] += 1
    
                                    elif action == 'TRANSFER':
                                          if source_file and dest_path:
                                              scp_command = f"scp {source_file} {task_user}@{private_ip}:{dest_path}"
                                              click.echo(click.style(f"Transferring {source_file} to {task_user}@{private_ip}:{dest_path}", fg="green"))
                                              result = subprocess.run(scp_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                                              if result.returncode == 0:
                                                  click.echo(click.style(f"File transferred successfully to {identifier} ({private_ip})", fg="green"))
                                                  summary['transferred'] += 1
                                                  success = True
                                              else:
                                                  click.echo(click.style(f"Error transferring file to {identifier} ({private_ip}): {result.stderr.decode('utf-8')}", fg="red"))
                                                  summary['skipped'] += 1
                                          else:
                                              click.echo(click.style("Source file or destination path is missing for file transfer.", fg="red"))
                                              summary['skipped'] += 1
                                    else:
                                        click.echo(f"Unknown action: {action}")
                                        summary['other'] += 1
                                        success = False
                                        message = ""
    
                                    # Print task result
                                    if success:
                                        click.echo(f"Task {task_name} on {identifier} ({private_ip}) was successful:\n{message}")
                                    else:
                                        click.echo(f"Failed to execute task {task_name} on {identifier} ({private_ip}): {message}")
                                        summary['failed'] += 1
                                        if notify_on_failure:
                                            click.echo(click.style(f"Notification: Task '{task_name}' failed on '{identifier}'.", fg="red"))
    
                                    if notify_on_failure and not success:
                                        click.echo(click.style(f"Task '{task_name}' failed. Sending failure notification...", fg="red"))
                                        notify_on_task_completion(task_name, 'failure', task.get('notification_recipients', {}), task.get('notification_channel', 'email'))
    
    
                                except ValueError as ve:
                                    click.echo(str(ve))
                                finally:
                                    attempts += 1
                                    if not success:
                                        summary['skipped'] += 1
                                        click.echo(f"Task '{task_name}' was skipped due to schedule or failure.")
                                    else:
                                         summary['completed'] += 1
                            # Notify on task completion
                            if task.get('notify_on_completion', False):
                                status = 'success' if success else 'failure'
                                notify_on_task_completion(task_name, status, task.get('notification_recipients', {}), task.get('notification_channel', 'email'))
        
    
        # Print summary after all tasks are executed
        click.echo("\nExecution Summary:")
        click.echo(f"  Packages Installed: {summary['installed']}")
        click.echo(f"  Packages Already Installed: {summary['already_installed']}")
        click.echo(f"  Directories Created: {summary['created']}")
        click.echo(f"  Directories/Files Deleted: {summary['deleted']}")
        click.echo(f"  Files Moved: {summary['moved']}")
        click.echo(f"  Files Copied: {summary['copied']}")
        click.echo(f"  Files Downloaded: {summary['downloaded']}")
        click.echo(f"  Services Started: {summary['started_service']}")
        click.echo(f"  Services Stopped: {summary['stopped_service']}")
        click.echo(f"  Service Status Checked: {summary['service_status_checked']}")
        click.echo(f"  Tasks Skipped: {summary['skipped']}")
        click.echo(f"  Tasks Completed: {summary['completed']}")
        click.echo(f"  Tasks Failed: {summary['failed']}")
        click.echo(f"  Other Actions: {summary['other']}")
    
    
        # Phase 5: Save State
        save_execution_state(data, execution_id, state_exicution_path)
        click.echo(f"Execution complete. State saved to: {state_exicution_path} (Execution ID: {execution_id})")
    
        click.echo(f"Execution completed. (Execution ID: {execution_id})\n")
    elif identifier and username and command:
        try:
            private_ip, _ = get_host_entry(identifier)
            success, message = execute_command_on_server(private_ip, username, command)
            if success:
                click.echo(f"{message}")
            else:
                click.echo(f"Failed to execute command on {identifier} ({private_ip}): {message}")
        except ValueError as ve:
            click.echo(str(ve))
        return
    else:
        click.echo("You must provide either a YAML screenplay file or the identifier, username, and command directly.")
        return

    click.echo(tabulate(table_data, headers=["#", "Resource Type", "Details"], tablefmt="fancy_grid"))


#############################################swa screenplay def section  ##############
# Helper function to upload the artifact to S3
def create_build_credentials_file():
    # Initialize the XML structure if it doesn't exist
    if not os.path.exists(CREDENTIALS_FILE):
        root = Element("credentials")
        tree = ElementTree(root)
        tree.write(CREDENTIALS_FILE)
        click.echo("Initialized build_credentials.xml file.")




def should_run_task(schedule):
    """
    Check if the current time matches the cron schedule.
    :param schedule: The cron schedule string (e.g., "0 2 * * *").
    :return: True if it's time to run the task, False otherwise.
    """
    base_time = datetime.now()
    cron = croniter(schedule, base_time)
    next_run = cron.get_next(datetime)

    return base_time >= next_run


def send_sms_notification(task_name, status):   
    config = load_notification_config()
    if not config or 'twilio' not in config:
        click.echo(click.style(f"Twilio SMS notification configuration is missing. Please update {CONFIGS_FILE}.", fg="red"))
        return

    twilio_config = config['twilio']
    account_sid = twilio_config.get('account_sid')
    auth_token = twilio_config.get('auth_token')
    from_number = twilio_config.get('from_number')
    recipients = twilio_config.get('default_recipients', [])

    if not (account_sid and auth_token and from_number):
        click.echo(click.style(f"Twilio SMS configuration is incomplete in {CONFIGS_FILE}.", fg="red"))
        return

    client = Client(account_sid, auth_token)
    message_body = f"Task {task_name} has completed with status: {status}."

    for recipient in recipients:
        try:
            message = client.messages.create(
                body=message_body,
                from_=from_number,
                to=recipient
            )
            click.echo(click.style(f"SMS sent successfully to {recipient}.", fg="green"))
        except Exception as e:
            click.echo(click.style(f"Failed to send SMS to {recipient}: {e}", fg="red"))

def send_sms_notification_aws(task_name, status):
    config = load_notification_config()
    if not config or 'aws_sns' not in config:
        click.echo(click.style(f"AWS SNS notification configuration is missing. Please update {CONFIGS_FILE}.", fg="red"))
        return

    recipients = config['aws_sns'].get('default_recipients', [])
    if not recipients:
        click.echo(click.style(f"No SMS recipients specified in {CONFIGS_FILE}.", fg="red"))
        return

    credentials = load_aws_credentials()  # Load credentials using your existing function

    # Initialize the SNS client using the credentials
    try:
        sns_client = boto3.client('sns', **credentials)
        message_body = f"Task {task_name} has completed with status: {status}."

        # Send SMS to each recipient
        for recipient in recipients:
            sns_client.publish(
                PhoneNumber=recipient,
                Message=message_body
            )
            click.echo(click.style(f"SMS sent successfully to {recipient}.", fg="green"))

    except (NoCredentialsError, PartialCredentialsError) as e:
        click.echo(click.style(f"Failed to send SMS: {e}", fg="red"))

def send_email_notification(task_name, status, recipients):
    config = load_notification_config()
    if not config or 'email' not in config:
        click.echo(click.style(f"Email notification configuration is missing. Please update {CONFIGS_FILE}.", fg="red"))
        return

    email_config = config['email']
    smtp_server = email_config.get('smtp_server')
    smtp_port = email_config.get('smtp_port')
    sender_email = email_config.get('sender_email')
    sender_password = email_config.get('sender_password')

    if not (smtp_server and smtp_port and sender_email and sender_password):
        click.echo(click.style(f"Incomplete email configuration in {CONFIGS_FILE}. Please provide SMTP details.", fg="red"))
        return

    subject = f"Task {task_name} - {status}"
    body = f"The task '{task_name}' has completed with status: {status}."

    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = ', '.join(recipients)
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        with smtplib.SMTP(smtp_server, smtp_port) as server:
            server.starttls()
            server.login(sender_email, sender_password)
            server.sendmail(sender_email, recipients, msg.as_string())
            click.echo(click.style("Email sent successfully.", fg="green"))
    except Exception as e:
        click.echo(click.style(f"Failed to send email: {e}", fg="red"))

def request_approval(task_name):
    # Prompt user for approval
    approval = click.prompt(f"Approval required for task '{task_name}'. Do you want to proceed? [y/N]", default='n')
    return approval.lower() == 'y'

def send_notification(task_name, status, recipients, channels):
    if not recipients:  # Ensure recipients are set
        recipients = {}
    
    if 'email' in channels:
        email_recipients = recipients.get('email', [])
        if email_recipients:
            send_email_notification(task_name, status, email_recipients)

    if 'slack' in channels:
        slack_recipients = recipients.get('slack', [])
        if slack_recipients:
            send_slack_notification(task_name, status, slack_recipients)

def send_slack_notification(task_name, status):
    config = load_notification_config()
    if not config or 'slack' not in config:
        click.echo(click.style(f"Slack notification configuration is missing. Please update {CONFIGS_FILE}.", fg="red"))
        return

    slack_config = config['slack']
    webhook_url = slack_config.get('webhook_url')

    if not webhook_url:
        click.echo(click.style(f"Slack webhook URL is missing in {CONFIGS_FILE}.", fg="red"))
        return

    slack_message = {
        "text": f"Task {task_name} - {status}"
    }

    try:
        response = requests.post(webhook_url, json=slack_message)
        if response.status_code == 200:
            click.echo(click.style("Slack notification sent successfully.", fg="green"))
        else:
            click.echo(click.style(f"Failed to send Slack notification: {response.text}", fg="red"))
    except Exception as e:
        click.echo(click.style(f"Failed to send Slack notification: {e}", fg="red"))


def notify_on_task_completion(task_name, status, recipients, channels):
    """
    Notify based on the specified notification channels (email, slack, sms).
    """
    if isinstance(channels, list):
        for channel in channels:
            if channel == 'email':
                send_email_notification(task_name, status, recipients.get('email', []))
            elif channel == 'slack':
                send_slack_notification(task_name, status)
            elif channel == 'sms':
                send_sms_notification_aws(task_name, status)
            else:
                click.echo(click.style(f"Unknown notification channel: {channel}.", fg="red"))
    else:
        click.echo(click.style(f"Invalid format for notification channels. Expected a list, got {type(channels)}", fg="red"))


def check_notification_setup():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration is missing at {CONFIGS_FILE}.", fg="red"))
        click.echo(click.style("Please create the file with necessary SMTP or Slack configurations.", fg="yellow"))
        return False
    return True

def load_notification_config():
    if not os.path.exists(CONFIGS_FILE):
        click.echo(click.style(f"Notification configuration file not found: {CONFIGS_FILE}. Please create it to enable notifications.", fg="red"))
        return None

    with open(CONFIGS_FILE, 'r') as file:
        config = yaml.safe_load(file)

    if not config:
        click.echo(click.style(f"Notification configuration file {CONFIGS_FILE} is empty or invalid. Please update it.", fg="red"))
        return None

    return config


def create_user_on_server(identifier, username, password=None, permissions=None, create_user_ssh_key=False, category=None):
    # Function implementation here, where generate_ssh_key controls SSH key generation
    pass


   # Helper functions to evaluate conditions
def evaluate_condition(condition, context):
    """Evaluate a condition against the context of the task."""
    try:
        return eval(condition, {}, context)
    except Exception as e:
        click.echo(click.style(f"Error evaluating condition '{condition}': {e}", fg="red"))
        return False
def validate_tags(tags):
    if not tags or not isinstance(tags, list):
        return []
    valid_tags = []
    for tag in tags:
        if 'Key' in tag and 'Value' in tag and tag['Key'] and tag['Value']:
            valid_tags.append(tag)
    return valid_tags


def file_exists(file_path):
    """Check if a file exists on the system."""
    return os.path.exists(file_path)

def package_installed(package_name):
    """Check if a package is installed (Linux-specific example using dpkg or rpm)."""
    try:
        if shutil.which('dpkg'):
            result = subprocess.run(['dpkg', '-l', package_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        elif shutil.which('rpm'):
            result = subprocess.run(['rpm', '-q', package_name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        else:
            raise EnvironmentError("Unsupported package manager.")
        return result.returncode == 0
    except Exception as e:
        click.echo(click.style(f"Error checking package '{package_name}': {e}", fg="red"))
        return False

def get_package_manager():
    """
    Detect the OS type and return the appropriate package manager command.
    :return: A tuple of (package_manager, update_command, install_command)
    """
    if shutil.which("apt-get"):
        return "apt-get", "apt-get update", "apt-get install -y"
    elif shutil.which("yum"):
        return "yum", "yum makecache", "yum install -y"
    elif shutil.which("dnf"):
        return "dnf", "dnf makecache", "dnf install -y"
    elif shutil.which("zypper"):
        return "zypper", "zypper refresh", "zypper install -y"
    elif shutil.which("brew"):
        return "brew", None, "brew install"  # Homebrew doesn't need an update command
    else:
        raise ValueError("Unsupported package manager. Unable to install packages on this system.")

def eval_condition(condition_str, variables):
    """
    Evaluate the condition against the given variables.
    :param condition_str: The condition string to evaluate (e.g., 'variables["env"] == "prod"')
    :param variables: A dictionary of variables to use in the condition evaluation.
    :return: Boolean result of the condition evaluation.
    """
    try:
        return eval(condition_str, {"variables": variables})
    except Exception as e:
        click.echo(f"Error evaluating condition: {e}")
        return False

def process_loops_and_conditions(resources, variables):
    """
    Process loops, for_each, and conditions for all resources without changing the provisioning code.
    :param resources: A list of resource dictionaries.
    :param variables: Dictionary containing global variables.
    :return: A list of processed resources that passed the conditions and loops.
    """
    processed_resources = []

    for resource in resources:
        # Ensure the resource is a dictionary
        if not isinstance(resource, dict):
            raise TypeError(f"Expected resource to be a dictionary, but got {type(resource).__name__}: {resource}")

        # Check if a condition is specified and evaluate it
        if 'condition' in resource:
            condition_result = eval_condition(resource['condition'], variables)
            if not condition_result:
                continue  # Skip resource if condition is not met
        # Handle for_each
        if 'for_each' in resource:
            for each_key, each_value in resource['for_each'].items():
                resource_copy = resource.copy()  # Copy the original resource
                resource_copy.update(each_value)  # Update the resource with the values from for_each

                resource_copy['name'] = f"{resource['name']}-{each_key}"  # Append key to name for uniqueness
                resource_copy['tags'] = interpolate_tags(resource_copy.get('tags', []), resource_copy)
                processed_resources.append(resource_copy)  # Add processed resource to the list



        # Handle loop_list
        elif 'loop_list' in resource:
            for item in resource['loop_list']:
                resource_copy = resource.copy()
                resource_copy.update(item)
                resource_copy['tags'] = interpolate_tags(resource_copy.get('tags', []), resource_copy)
                processed_resources.append(resource_copy)


        # Handle loop_range
        elif 'loop_range' in resource:
            start = resource['loop_range'].get('start', 0)
            end = resource['loop_range'].get('end', 1)
            for i in range(start, end):
                # Create a deep copy of the resource for this iteration
                resource_copy = resource.copy()
        
                # Interpolate all fields containing `{{i}}` with the current loop index
                resource_copy = interpolate_resource_fields(resource_copy, i)
        
                # Construct the unique name for this instance
                interpolated_name = f"{resource['name']}-{i}"
        
                # Process tags
                tags = resource_copy.get('tags', [])
                formatted_tags = []
        
                if isinstance(tags, list):
                    for tag in tags:
                        if isinstance(tag, dict) and 'Key' in tag and 'Value' in tag:
                            tag_copy = tag.copy()
                            if isinstance(tag_copy['Value'], str):
                                # Replace `{{i}}` in the tag value with the current loop index
                                tag_copy['Value'] = tag_copy['Value'].replace('{{i}}', str(i))
                            formatted_tags.append(tag_copy)
                        else:
                            # Debugging output to help identify the issue
                            print(f"DEBUG: Invalid tag structure: {tag}")
                            raise ValueError("Each tag must be a dictionary with 'Key' and 'Value'.")
                else:
                    print(f"DEBUG: Tags must be a list of dictionaries. Found: {tags}")
                    raise ValueError("Tags must be a list of dictionaries.")
        
                # Ensure the 'Name' tag is present and correctly formatted
                if not any(tag['Key'] == 'Name' for tag in formatted_tags):
                    formatted_tags.append({'Key': 'Name', 'Value': interpolated_name})
        
                # Assign the processed tags back to the resource
                resource_copy['tags'] = formatted_tags
        
                # Append the processed resource to the list of resources to be created
                processed_resources.append(resource_copy)
        

        elif 'loop_with_index' in resource:
            # Extract the index variable name and the list of items to loop over
            index_var = resource['loop_with_index'].get('index_var', 'index')
            for idx, item in enumerate(resource['loop_with_index']['items']):
                # Create a copy of the resource and update it with values from the current loop item
                resource_copy = resource.copy()
                resource_copy.update(item)
        
                # Replace `{{custom_index}}` or other index placeholders with the loop index
                for key, value in resource_copy.items():
                    if isinstance(value, str) and f"{{{{{index_var}}}}}" in value:
                        resource_copy[key] = value.replace(f"{{{{{index_var}}}}}", str(idx))
        
                # Process tags separately to handle interpolation for the custom index
                if 'tags' in resource_copy:
                    resource_copy['tags'] = [
                        {
                            'Key': tag['Key'],
                            'Value': tag['Value'].replace(f"{{{{{index_var}}}}}", str(idx))
                        } if isinstance(tag['Value'], str) else tag
                        for tag in resource_copy['tags']
                    ]
        
                # Update the instance name to include the loop index
                resource_copy['name'] = f"{resource['name']}-{idx}"
        
                # Append the processed resource to the list of resources to be created
                processed_resources.append(resource_copy)


        # Handle nested loop (outer_loop and inner_loop)
        elif 'outer_loop' in resource and 'inner_loop' in resource:
            outer_loop_items = resource['outer_loop']['regions']
            inner_loop_items = resource['inner_loop']['instance_types']
            for outer_item in outer_loop_items:
                for inner_item in inner_loop_items:
                    resource_copy = resource.copy()
                    resource_copy['region'] = outer_item
                    resource_copy['instance_type'] = inner_item
                    resource_copy['name'] = f"{resource['name']}-{outer_item}-{inner_item}"
                    resource_copy['tags'] = interpolate_tags(resource_copy.get('tags', []), resource_copy)
                    processed_resources.append(resource_copy)

         # Handle reverse loop
        elif 'loop_reverse' in resource:
            for item in reversed(resource['loop_reverse']['items']):
                resource_copy = resource.copy()
                resource_copy['instance_type'] = item
                resource_copy['tags'] = interpolate_tags(resource_copy.get('tags', []), resource_copy)
                processed_resources.append(resource_copy)

        elif 'loop' in resource:
            for loop_index, loop_item in enumerate(resource['loop']):
                looped_resource = resource.copy()
                looped_resource.update(loop_item)

                base_name = resource.get('name', 'Instance')
                looped_resource['name'] = f"{base_name}-{loop_item.get('name_suffix', loop_index)}"

                # Inject loop index and interpolate tags
                looped_resource['loop_index'] = loop_index
                looped_resource['tags'] = interpolate_tags(looped_resource.get('tags', []), looped_resource)

                processed_resources.append(looped_resource)

        elif 'while_condition' in resource:
            max_retries = resource.get('max_retries', 10)
            retry_delay = resource.get('retry_delay', 5)

            # Loop until condition is met or max retries are exhausted
            for attempt in range(max_retries):
                condition_result = eval_while_condition(resource['while_condition'], variables)
                if condition_result:
                    # If the condition is met, proceed to process the resource
                    processed_resources.append(resource)
                    break
                else:
                    # If condition is not met, wait and retry
                    click.echo(f"Condition not met: {resource['while_condition']}, retrying in {retry_delay} seconds... (Attempt {attempt + 1}/{max_retries})")
                    time.sleep(retry_delay)
            else:
                click.echo(f"Max retries reached for {resource['name']}. Condition was not met: {resource['while_condition']}")
                # Optionally, we could choose to fail the task or skip the resource

        else:
            # Ensure the resource has a name
            if 'name' not in resource:
                resource['name'] = 'Instance'

            # Ensure there is at least one tag and interpolate them
            resource['tags'] = interpolate_tags(resource.get('tags', []), resource)
            processed_resources.append(resource)

    return processed_resources

def execute_task_parallel(task, variables):
    """
    Function to execute a single task in parallel, passing variables for dynamic processing.
    """
    click.echo(f"Executing task in parallel: {task['name']}")
    # Simulate actual execution (could be EC2 creation or other tasks)
    time.sleep(2)  # Simulating execution delay
    return f"Task {task['name']} completed"

def process_parallel_loop(resources, variables):
    """
    Process resources in parallel.
    """
    with ThreadPoolExecutor() as executor:
        futures = {executor.submit(execute_task_parallel, resource, variables): resource for resource in resources}

        for future in as_completed(futures):
            resource = futures[future]
            try:
                result = future.result()
                click.echo(f"Parallel task result: {result}")
            except Exception as exc:
                click.echo(f"Task {resource['name']} generated an exception: {exc}")

def fetch_external_data(api_url):
    """
    Fetches data from an external API and returns the data.
    """
    try:
        response = requests.get(api_url)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        click.echo(f"Error fetching external data: {e}")
        return []

def process_external_data_loop(api_url, variables):
    """
    Process loop over external data from an API or file.
    """
    external_data = fetch_external_data(api_url)

    for item in external_data:
        resource = {
            'name': f"external-instance-{item['id']}",
            'instance_type': item['instance_type'],
            'region': item['region']
        }
        click.echo(f"Processing resource from external data: {resource['name']}")

def process_loop_with_branching(resources, variables):
    """
    Process resources with conditional branching.
    """
    for resource in resources:
        click.echo(f"Evaluating resource: {resource['name']}")
        if resource['instance_type'] == 't2.micro':
            click.echo(f"Processing t2.micro resource: {resource['name']}")
            # Process micro instance
        elif resource['instance_type'] == 't2.large':
            click.echo(f"Processing t2.large resource: {resource['name']}")
            # Process large instance
        else:
            click.echo(f"Skipping unsupported instance type for {resource['name']}")

def process_pipeline_loop(resources, variables):
    """
    Process a multi-stage pipeline loop.
    """
    intermediate_results = []
    
    # First Stage: Provision EC2 Instances
    for resource in resources:
        click.echo(f"Provisioning stage for: {resource['name']}")
        # Simulate instance provisioning and save the result
        instance_id = f"instance-{resource['name']}"
        intermediate_results.append(instance_id)

    # Second Stage: Perform actions on the provisioned instances
    for instance_id in intermediate_results:
        click.echo(f"Configuring instance: {instance_id}")
        # Simulate configuration of provisioned instance


def eval_while_condition(condition, variables):
    """
    Evaluates the condition by safely accessing variables.
    """
    try:
        condition_result = eval(condition, {}, variables)
        return condition_result
    except Exception as e:
        click.echo(f"Error evaluating condition: {condition}. Exception: {str(e)}")
        return False

def interpolate_resource_fields(resource, i):
    """
    Replace `{{i}}` placeholders with the current loop index `i` in the resource.
    """
    # Handle interpolation in tags
    if 'tags' in resource:
        resource['tags'] = [
            {tag['Key']: tag['Value'].replace('{{i}}', str(i))}
            if isinstance(tag['Value'], str) else tag
            for tag in resource['tags']
        ]

    # Handle interpolation in block device mappings
    if 'block_device_mappings' in resource:
        for mapping in resource['block_device_mappings']:
            if 'Ebs' in mapping and 'VolumeSize' in mapping['Ebs']:
                volume_size = mapping['Ebs']['VolumeSize']
                if isinstance(volume_size, str) and '{{i}}' in volume_size:
                    mapping['Ebs']['VolumeSize'] = volume_size.replace('{{i}}', str(i))

    # Handle interpolation in other fields
    for key, value in resource.items():
        if isinstance(value, str) and '{{i}}' in value:
            resource[key] = value.replace('{{i}}', str(i))

    return resource

def interpolate_tags(tags, resource):
    """
    Interpolates variables in tag values, such as region and instance_type.
    :param tags: List of tags
    :param resource: Resource with details like region, instance_type
    :return: List of tags with interpolated values
    """
    region = resource.get('region', '')
    instance_type = resource.get('instance_type', '')

    interpolated_tags = []
    for tag in tags:
        if isinstance(tag, dict) and 'Value' in tag:
            tag['Value'] = tag['Value'].replace('{{region}}', region).replace('{{instance_type}}', instance_type)
        interpolated_tags.append(tag)

    return interpolated_tags


def record_output_variable(execution_id, resource_type, resource_name, value):
    """
    Record the output variable in a separate state file for output variables using a standardized name.

    Args:
    - execution_id (str): Unique identifier for the execution.
    - resource_type (str): The type of the resource (e.g., 'vpc', 'subnet').
    - resource_name (str): The name of the resource to record.
    - value (str): The value of the output variable.

    Returns:
    - None
    """
    state_output_path = os.path.join(OUTPUT_STATE_DIR, f'{execution_id}_output.yaml')

    # Use the standardized output variable name
    variable_name = standardize_output_variable_name(resource_type, resource_name)

    # Load existing state if present
    if os.path.exists(state_output_path):
        with open(state_output_path, 'r') as file:
            state_data = yaml.safe_load(file)
    else:
        state_data = {'outputs': {}}

    # Update the state with the new variable and value
    state_data['outputs'][variable_name] = value

    # Save the updated state back to the file
    with open(state_output_path, 'w') as file:
        yaml.dump(state_data, file)

    click.echo(f"Output variable '{variable_name}' recorded with value: {value}")

def standardize_output_variable_name(resource_type, resource_name):
    """
    Standardize the output variable name based on the resource type and resource name.

    Args:
    - resource_type (str): The type of the resource (e.g., 'vpc', 'subnet').
    - resource_name (str): The name of the resource as defined in the YAML.

    Returns:
    - str: The standardized output variable name.
    """
    return f"{resource_type}_{resource_name}"


def save_output_variables(output_variables, file_name="outputs.yaml"):
    """
    Save output variables to a YAML file in the OUTPUT_STATE_DIR.

    Args:
        output_variables (dict): The dictionary of output variables to save.
        file_name (str): Name of the output file (default: "outputs.yaml").
    """
    # Ensure the output directory exists
    os.makedirs(OUTPUT_STATE_DIR, exist_ok=True)

    # Construct the full file path
    file_path = os.path.join(OUTPUT_STATE_DIR, file_name)

    # Save the output variables to the file
    with open(file_path, 'w') as f:
        yaml.dump(output_variables, f, default_flow_style=False)
    
    print(f"Output variables saved to {file_path}")

def get_output_variable(variable_name, output_variables):
    """
    Retrieve the output variable value based on its name.

    Args:
    - variable_name (str): The name of the variable to look up.
    - output_variables (dict): The dictionary of output variables.

    Returns:
    - The value of the output variable if found, else None.
    """
    return output_variables.get(variable_name)


def load_output_variables(file_path):
    """
    Load the output variables from the specified file path.

    Args:
    - file_path (str): The path to the YAML file containing output variables.

    Returns:
    - dict: The dictionary of output variables.
    """
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            output_variables = yaml.safe_load(f).get('outputs', {})
            print(f"Output variables loaded from {file_path}: {output_variables}")
            return output_variables
    else:
        print(f"No output variables file found at {file_path}.")
        return {}


def interpolate_output_variables(resource_config, output_variables):
    """
    Interpolate output variables in the resource configuration.

    Args:
    - resource_config (dict): The configuration of the resource where interpolation is needed.
    - output_variables (dict): The dictionary containing output variables.

    Returns:
    - dict: The interpolated resource configuration.
    """
    def replace_variable(value, output_vars):
        if isinstance(value, str) and "${" in value and "}" in value:
            # Extract the variable name between ${ and }
            start = value.find("${") + 2
            end = value.find("}")
            variable_name = value[start:end]
            # Replace if the variable exists in output variables
            if variable_name in output_vars:
                return value.replace(f"${{{variable_name}}}", str(output_vars[variable_name]))
        return value

    def recursive_interpolation(config, output_vars):
        if isinstance(config, dict):
            return {k: recursive_interpolation(replace_variable(v, output_vars), output_vars) for k, v in config.items()}
        elif isinstance(config, list):
            return [recursive_interpolation(replace_variable(item, output_vars), output_vars) for item in config]
        else:
            return replace_variable(config, output_vars)

    return recursive_interpolation(resource_config, output_variables)

def load_variables(variables_file=None):
    """
    Load variables from the specified YAML file. If no file is specified, the default VARIABLES_FILE will be used.
    """
    if variables_file is None:
        variables_file = VARIABLES_FILE  # Use the default if not provided

    if os.path.exists(variables_file):
        with open(variables_file, 'r') as file:
            try:
                variables = yaml.safe_load(file)
                if variables is None:
                    variables = {}
                print(f"DEBUG: Veriable loaded")
                return variables
            except yaml.YAMLError:
                print("Error: Invalid YAML format in variables file.")
                return {}
    else:
        return {}


def load_environment_variables(variables, environment):
    """
    Load and resolve environment-specific variables.

    Args:
    - variables (dict): The base variables loaded from the file.
    - environment (str): The current environment (e.g., "dev", "test", "prod").

    Returns:
    - dict: The updated variables with environment-specific values applied.
    """
    if 'environments' in variables and environment in variables['environments']:
        # Merge environment-specific variables with the base variables
        env_vars = variables['environments'][environment]
        variables.update(env_vars)
    return variables

def parse_command_line_overrides(set_values):
    """
    Parse command-line key-value pairs provided using --set option.
    
    Args:
    - set_values (tuple): Tuple of key-value pairs provided from the command line.
    
    Returns:
    - dict: Dictionary of parsed command-line overrides, structured correctly.
    """
    command_line_overrides = {}
    for item in set_values:
        if "=" in item:
            key, value = item.split("=", 1)  # Split only on the first occurrence of '='
            # Structure the command-line override properly
            command_line_overrides[key] = {
                'type': 'str',  # Assuming all command-line overrides are strings by default
                'value': value
            }
        else:
            print(f"Warning: Invalid --set format for '{item}'. Expected 'key=value'. Skipping this item.")
    return command_line_overrides


def override_variables(*variable_sources):
    """
    Merge variables from multiple sources, with the latter sources overriding the earlier ones.
    
    Args:
    - *variable_sources (list): List of dictionaries to be merged.
    
    Returns:
    - dict: The merged variables with precedence applied.
    """
    result = {}
    for variables in variable_sources:
        if isinstance(variables, dict):
            for key, value in variables.items():
                # Ensure that overrides follow the correct structure
                if isinstance(value, dict) and 'type' in value and 'value' in value:
                    result[key] = value  # Already structured, no changes needed
                else:
                    # If it's a raw value, wrap it in the expected structure
                    result[key] = {
                        'type': 'str' if isinstance(value, str) else 'list' if isinstance(value, list) else 'unknown',
                        'value': value
                    }
    return result


def interpolate_variables(variables):
    """
    Interpolate variables that reference other variables.

    Args:
    - variables (dict): The dictionary of variables.

    Returns:
    - dict: The variables with references replaced by actual values.
    """
    pattern = re.compile(r"\${ver\.([a-zA-Z0-9_]+)}")  # Pattern to match placeholders like ${ver.variable_name}

    def replace_placeholder(value):
        def _replace(match):
            var_name = match.group(1)
            if var_name in variables:
                return str(variables.get(var_name, ""))  # Replace with the variable value or an empty string if not found
            else:
                print(f"Warning: Referenced variable '{var_name}' not found. Using empty string.")
                return ""
        return pattern.sub(_replace, value)

    def interpolate(data):
        if isinstance(data, dict):
            return {k: interpolate(v) for k, v in data.items()}
        elif isinstance(data, list):
            return [interpolate(item) for item in data]
        elif isinstance(data, str):
            return replace_placeholder(data)
        else:
            return data

    return interpolate(variables)



def create_encryption_key():
    """
    Generate a new encryption key and save it to the key file.
    """
    key = Fernet.generate_key()
    with open(ENC_KEY_FILE, 'wb') as key_file:
        key_file.write(key)
    print(f"New encryption key created and saved to {ENC_KEY_FILE}")

def load_encryption_key():
    """
    Load the encryption key from the key file. If the file doesn't exist, create one.

    Returns:
    - Fernet object initialized with the loaded key.
    """
    ENC_KEY_FILE = os.path.join(BASE_DIR, "enc_key.key")  # Ensure the correct path for the key file is used

    if not os.path.exists(ENC_KEY_FILE):
        create_encryption_key()  # This function should create the key file if it doesn't exist

    with open(ENC_KEY_FILE, 'rb') as key_file:
        key = key_file.read()

    return Fernet(key)

cipher = load_encryption_key()

def encrypt_variable(value):
    """
    Encrypt a sensitive variable using the encryption key.

    Args:
    - value (str): The plain text value to encrypt.

    Returns:
    - str: The encrypted value.
    """
    if not isinstance(value, str):
        raise ValueError("Value to be encrypted must be a string.")
    encrypted_value = cipher.encrypt(value.encode()).decode()
    return encrypted_value

def decrypt_variable(encrypted_value):
    """
    Decrypt an encrypted variable using the encryption key.

    Args:
    - encrypted_value (str): The encrypted value to decrypt.

    Returns:
    - str: The decrypted plain text value.
    """
    if not isinstance(encrypted_value, str):
        raise ValueError("Encrypted value must be a string.")
    decrypted_value = cipher.decrypt(encrypted_value.encode()).decode()
    return decrypted_value

def load_remote_yaml(remote_url):
    """
    Load a YAML config file from a remote URL.
    """
    try:
        response = requests.get(remote_url)
        response.raise_for_status()

        # Validate the content type
        content_type = response.headers.get('Content-Type')
        if 'yaml' not in content_type and 'text' not in content_type:
            print(f"Unexpected content type: {content_type}. Make sure the URL points to a raw YAML file.")
            return {}

        # Parse and return the YAML data
        try:
            yaml_data = yaml.safe_load(response.text)
            return yaml_data
        except yaml.YAMLError as e:
            print(f"Failed to parse YAML content from remote file: {e}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch remote YAML file: {e}")
        return {}



def load_remote_variables(remote_url):
    """
    Load variables from a remote URL and handle potential issues with non-YAML content.
    """
    try:
        response = requests.get(remote_url)
        response.raise_for_status()  # Check for HTTP errors

        # Check if the content type is YAML or plain text to avoid HTML pages
        content_type = response.headers.get('Content-Type')
        if 'yaml' not in content_type and 'text' not in content_type:
            print(f"Unexpected content type: {content_type}. Make sure the URL points to a raw YAML file.")
            return {}

        # Attempt to parse the YAML content
        try:
            variables = yaml.safe_load(response.text)
            return variables
        except yaml.YAMLError as e:
            print(f"Failed to parse YAML content from remote file: {e}")
            return {}

    except requests.exceptions.RequestException as e:
        print(f"Failed to fetch remote variables file: {e}")
        return {}

def encrypt_variable_with_password(value, password):
    """
    Encrypt a sensitive variable using the password to derive the encryption key.

    Args:
    - value (str): The plain text value to encrypt.
    - password (str): The password used to generate the encryption key.

    Returns:
    - str: The encrypted value (includes salt and encrypted data).
    """
    salt = os.urandom(SALT_SIZE)  # Generate a new random salt
    key = generate_key_from_password(password, salt)  # Derive key from password and salt
    cipher = Fernet(key)

    encrypted_value = cipher.encrypt(value.encode())

    # Combine salt and encrypted value for storage
    return base64.urlsafe_b64encode(salt + encrypted_value).decode()

def generate_key_from_password(password, salt):
    """
    Generate a Fernet-compatible encryption key from the provided password and salt.

    Args:
    - password (str): The password provided by the user.
    - salt (bytes): The salt used for key derivation.

    Returns:
    - bytes: The derived encryption key.
    """
    kdf = PBKDF2HMAC(
        algorithm=hashes.SHA256(),
        length=32,
        salt=salt,
        iterations=ITERATIONS,
        backend=default_backend()
    )
    key = base64.urlsafe_b64encode(kdf.derive(password.encode()))
    return key

def decrypt_variable_with_password(encrypted_value, password):
    """
    Decrypt an encrypted value using the password to derive the decryption key.

    Args:
    - encrypted_value (str): The encrypted value to decrypt.
    - password (str): The password used to generate the decryption key.

    Returns:
    - str: The decrypted plain text value.
    """
    try:
        # Decode the base64 encoded value and extract salt and encrypted data
        encrypted_data = base64.urlsafe_b64decode(encrypted_value.encode())
        salt = encrypted_data[:SALT_SIZE]  # Extract the salt
        encrypted_value = encrypted_data[SALT_SIZE:]  # Extract the encrypted value

        # Derive the key using the provided password and the extracted salt
        key = generate_key_from_password(password, salt)
        cipher = Fernet(key)

        # Decrypt the value
        decrypted_value = cipher.decrypt(encrypted_value).decode()
        return decrypted_value
    except Exception as e:
        raise ValueError(f"Failed to decrypt the value: {e}")

# Function to decrypt a value using a password
def decrypt_sensitive_variables(variables, password=None, show_sensitive=False):
    """
    Decrypt sensitive variables using the provided password or encryption key.

    Args:
    - variables (dict): The dictionary of variables.
    - password (str): The password used to decrypt the sensitive values.
    - show_sensitive (bool): Whether to show decrypted sensitive values in the output.
    """
    for key, value in variables.items():
        if 'sensitive' in value and value['sensitive']:
            try:
                # Decrypt using password if provided, otherwise use predefined key
                if password:
                    value['value'] = decrypt_variable_with_password(value['value'], password)
                else:
                    value['value'] = decrypt_variable(value['value'])

                # If the `--show` option is set, display the decrypted value
                if show_sensitive:
                    print(f"Decrypted sensitive variable '{key}': {value['value']}")

            except Exception as e:
                print(f"Failed to decrypt sensitive variable '{key}': {str(e)}")
    return variables


def load_attempts():
    """
    Load the password attempts and lock status from the file.

    Returns:
    - dict: A dictionary containing the number of attempts and lock status.
    """
    if not os.path.exists(ATTEMPTS_FILE):
        return {"attempts": 0, "locked_until": None}

    with open(ATTEMPTS_FILE, 'r') as file:
        return json.load(file)

def save_attempts(attempts):
    """
    Save the password attempts and lock status to the file.

    Args:
    - attempts (dict): A dictionary containing the number of attempts and lock status.
    """
    with open(ATTEMPTS_FILE, 'w') as file:
        json.dump(attempts, file)

def reset_attempts():
    """
    Reset the number of failed attempts and remove the lock status.
    """
    save_attempts({"attempts": 0, "locked_until": None})

def update_failed_attempt():
    """
    Increment the number of failed attempts. If the attempts exceed 3, lock the decryption for 30 minutes.

    Returns:
    - bool: True if the decryption should be locked, False otherwise.
    """
    attempts = load_attempts()
    attempts["attempts"] += 1

    if attempts["attempts"] >= 3:
        # Lock for 30 minutes from now
        lock_until = datetime.now() + timedelta(minutes=30)
        attempts["locked_until"] = lock_until.strftime('%Y-%m-%d %H:%M:%S')
        save_attempts(attempts)
        return True

    save_attempts(attempts)
    return False

def check_lock_status():
    """
    Check if the decryption is currently locked due to failed attempts.

    Returns:
    - bool: True if the decryption is locked, False otherwise.
    - str: Message explaining the lock status.
    """
    attempts = load_attempts()
    locked_until_str = attempts.get("locked_until")

    if locked_until_str:
        locked_until = datetime.strptime(locked_until_str, '%Y-%m-%d %H:%M:%S')
        if datetime.now() < locked_until:
            remaining_time = locked_until - datetime.now()
            return True, f"Decryption is locked due to multiple failed attempts. Try again in {remaining_time.seconds // 60} minutes."
        else:
            # Lock has expired, reset attempts
            reset_attempts()
            return False, "Lock has expired. You can now try again."

    return False, ""

def resolve_variables(data, variables=None):
    # Ensure variables is always a dictionary
    if variables is None:
        variables = {}

    if not isinstance(variables, dict):
        raise ValueError("Variables must be a dictionary. Please check the variables file.")

    if isinstance(data, dict):
        # Recursively resolve dictionaries
        return {k: resolve_variables(v, variables) for k, v in data.items()}
    elif isinstance(data, list):
        # Recursively resolve lists
        return [resolve_variables(item, variables) for item in data]
    elif isinstance(data, str):
        # For strings, replace placeholders like "${ver.variable}"
        for key, value in variables.items():
            placeholder = "${ver." + key + "}"
            if placeholder in data:
                # Handle string variables
                if value['type'] == 'str':
                    data = data.replace(placeholder, value['value'])
                # Handle list variables (join them into a string)
                elif value['type'] == 'list':
                    data = data.replace(placeholder, ','.join(value['value']))
        return data
    else:
        # Return any other data types (e.g., int, float) unchanged
        return data



def validate_variables(variables, required_keys=None):
    """
    Validate that the variables are correctly formatted and contain the required keys.

    Args:
    - variables (dict): The dictionary of variables to validate.
    - required_keys (list): A list of keys that must be present in the variables, if provided.

    Returns:
    - bool: True if all validations pass, False otherwise.
    - list: List of validation error messages.
    """
    errors = []
    required_keys = required_keys or []

    # Check for required keys
    for key in required_keys:
        if key not in variables:
            errors.append(f"Missing required variable: {key}")

    # Validate variable types and structures
    for key, value in variables.items():
        if isinstance(value, dict):
            if "type" not in value or "value" not in value:
                errors.append(f"Variable '{key}' must have 'type' and 'value' fields.")
            elif value["type"] == "str" and not isinstance(value["value"], str):
                errors.append(f"Variable '{key}' should be of type 'str'.")
            elif value["type"] == "list" and not isinstance(value["value"], list):
                errors.append(f"Variable '{key}' should be of type 'list'.")
            elif value["type"] == "int" and not isinstance(value["value"], int):
                errors.append(f"Variable '{key}' should be of type 'int'.")
            elif value.get("sensitive", False) and not isinstance(value["value"], str):
                errors.append(f"Sensitive variable '{key}' should be an encrypted string.")

    return len(errors) == 0, errors


def lint_variables(variables):
    """
    Lint variables to identify common configuration issues.

    Args:
    - variables (dict): The dictionary of variables to lint.

    Returns:
    - bool: True if no linting errors are found, False otherwise.
    - list: List of linting error messages.
    """
    errors = []

    # Check for invalid references to other variables
    for key, value in variables.items():
        if isinstance(value, str) and "${ver." in value:
            referenced_var = value.split("${ver.")[1].split("}")[0]
            if referenced_var not in variables:
                errors.append(f"Variable '{key}' references unknown variable '{referenced_var}'.")

    # Check for environment-specific variables if 'environments' are defined
    if "environments" in variables:
        environments = variables["environments"]
        for env, env_vars in environments.items():
            for var in env_vars:
                if var not in variables:
                    errors.append(f"Environment '{env}' defines variable '{var}' not found in base variables.")

    return len(errors) == 0, errors

def validate_and_lint(variables, required_keys=None):
    """
    Validate and lint variables before executing any tasks.

    Args:
    - variables (dict): The dictionary of variables to validate and lint.
    - required_keys (list): A list of keys that must be present in the variables, if provided.

    Returns:
    - bool: True if all validations and linting checks pass, False otherwise.
    """
    print("Validating and linting variables...")

    # Validate variables
    is_valid, validation_errors = validate_variables(variables, required_keys)
    if not is_valid:
        print("Validation Errors:")
        for error in validation_errors:
            print(f"  - {error}")
        return False

    # Lint variables
    is_linted, linting_errors = lint_variables(variables)
    if not is_linted:
        print("Linting Errors:")
        for error in linting_errors:
            print(f"  - {error}")
        return False

    print("All validations and linting checks passed successfully!")
    return True




def wait_for_interval(seconds):
    """Wait for a specified number of seconds."""
    click.echo(f"Waiting for {seconds} seconds...")
    time.sleep(seconds)
    click.echo("Resuming execution...")

def wait_for_instance_to_be_active(instance_id, region, credentials):
    """Wait for an EC2 instance to become active."""
    click.echo(f"Waiting for EC2 instance {instance_id} to become active...")
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    waiter = ec2.get_waiter('instance_running')
    waiter.wait(InstanceIds=[instance_id])
    click.echo(f"Instance {instance_id} is now active.")

def save_execution_state(data, execution_id, state_exicution_path):
    """Save the state of the executed screenplay along with resource IDs for future reference."""
    # Create a copy of the data dictionary without the tasks section
    resources_data = data.copy()
    resources_data.pop('tasks', None)  # Remove the 'tasks' from the execution state if present

    # Ensure the 'resources' key is present in resources_data
    if 'resources' not in resources_data:
        click.echo(click.style(f"Warning: No resources found in the current screenplay.", fg="yellow"))
        resources_data['resources'] = {}

    # Attach the resource IDs to the original YAML structure
    state_data = {
        'execution_id': execution_id,
        'resources': resources_data['resources'],
    }

    # Order resources based on creation priority (reverse of destruction priority)
    ordered_resources = sorted(
        state_data['resources'].items(),
        key=lambda item: -RESOURCE_PRIORITY.get(item[0], 0)
    )

    state_data['resources'] = dict(ordered_resources)

    # If the file already exists (re-execution), load and update it instead of overwriting
    if os.path.exists(state_exicution_path):
        with open(state_exicution_path, 'r') as file:
            existing_data = yaml.safe_load(file)
        # Merge the new data with existing data
        existing_data.update(state_data)
        state_data = existing_data

    # Save the full YAML data (with resources) and the created resource IDs
    os.makedirs(STATE_DIR, exist_ok=True)  # Ensure the directory exists
    with open(state_exicution_path, 'w') as state_file:
        yaml.dump(state_data, state_file)

    click.echo(f"Execution state saved to: {state_exicution_path}")


@aws.command(name="destroy", help="Destroy resources based on execution ID.")
@click.argument('execution_id', type=str)
@click.option('--ignore-yml', '--iy', is_flag=True, help="Ignore the .yml file and only delete the .yaml file (short: --iy).")
def destroy(execution_id, ignore_yml):
    """Destroy resources based on the given execution ID and optionally remove state files."""

    state_file_path_yaml = os.path.join(STATE_DIR, f'{execution_id}.yaml')
    state_file_path_yml = os.path.join(STATE_DIR, f'{execution_id}.yml')

    if not os.path.exists(state_file_path_yaml):
        click.echo(f"No state file found for execution ID: {execution_id}. Unable to proceed with destruction.")
        return

    # Load the state file
    with open(state_file_path_yaml, 'r') as file:
        state_data = yaml.safe_load(file)

    # Initialize the EC2 client
    credentials = load_aws_credentials()
    ec2 = boto3.client('ec2', **credentials)

    # Go through the resources and destroy them
    destroy_resources(state_data, ec2, execution_id, credentials)
    click.echo(f"Destroy process completed for execution ID: {execution_id}")

    # Check if we should delete the state files after destruction
    try:
        # Delete the .yaml state file
        if os.path.exists(state_file_path_yaml):
            os.remove(state_file_path_yaml)
            click.echo(f"Deleted YAML state file: {state_file_path_yaml}")

        # Delete the .yml state file if --ignore-yml is not passed
        if not ignore_yml and os.path.exists(state_file_path_yml):
            os.remove(state_file_path_yml)
            click.echo(f"Deleted YML state file: {state_file_path_yml}")

    except Exception as e:
        click.echo(click.style(f"Error deleting state files: {e}", fg="red"))

# Priority mapping for resource destruction
RESOURCE_PRIORITY = {
    'ec2_instance': 10,
    'target_group': 20,
    'nat_gateway': 30,
    'elastic_ip': 40,
    'network_interface': 50,
    'subnet_creation': 70,  # Adjusting this priority to be after EC2
    'route_table': 80,
    'internet_gateway': 90,
    'security_group': 100,
    'vpc_creation': 110
}
def destroy_resources(state_data, ec2, execution_id, credentials):
    """Destroy resources recorded in the state file according to priority, with wait mechanisms for dependencies."""
    if 'tasks' in state_data:
        # Sort the tasks based on the predefined RESOURCE_PRIORITY mapping
        sorted_tasks = sorted(
            state_data['tasks'].items(),
            key=lambda item: RESOURCE_PRIORITY.get(re.sub(r'_\d+$', '', item[0]), 999)
        )

        for task_name, task_info in sorted_tasks:
            resource_id = task_info.get('resource_id')
            # Check if the resource is already marked as destroyed
            if task_info['status'] == 'destroyed':
                click.echo(f"Resource {resource_id} is already destroyed. Skipping...")
                continue

            if task_info['status'] == 'success' and resource_id:

                if 'target_registration' in task_name:
                    click.echo(f"Deregistering targets for Target Group: {resource_id}")
                    targets = task_info.get('targets', [])  # Ensure 'targets' list is retrieved from the task_info
                    deregister_targets(resource_id, targets, elb_client, execution_id)  # Corrected function call



                # Destroy NAT Gateway
                elif 'nat_gateway' in task_name:
                    click.echo(f"Destroying NAT Gateway: {resource_id}")
                    destroy_nat_gateway(resource_id,ec2,  execution_id)
                    wait_for_nat_gateway_deletion(resource_id, credentials)

                # Destroy Listeners (before Load Balancers)
                elif re.match(r'^listener_\d+$', task_name):
                    click.echo(f"Destroying Listener: {resource_id}")
                    elb_client = boto3.client('elbv2')  # Create the elb_client
                    destroy_listener(resource_id, elb_client, execution_id)

                # Destroy Target Groups
                elif 'target_group' in task_name:
                    click.echo(f"Destroying Target Group: {resource_id}")
                    destroy_target_group(resource_id, execution_id)


                # Destroy Load Balancer (before Target Groups)
                elif 'load_balancer' in task_name:
                    click.echo(f"Destroying Load Balancer: {resource_id}")
                    destroy_load_balancer(resource_id, execution_id)
                    wait_for_load_balancer_deletion(resource_id, credentials)




                # Destroy EKS Node Groups (before EKS Cluster)
                elif 'eks_nodegroup' in task_name:
                    click.echo(f"Destroying EKS Node Group: {state_data['tasks']['eks_nodegroup']['resource_id']}")
                    eks_client = boto3.client('eks', **credentials)  # Initialize the EKS client
                    cluster_name = state_data['tasks']['eks_cluster']['resource_id']  # Access the cluster name
                    nodegroup_name = state_data['tasks']['eks_nodegroup']['resource_id']  # Access the node group name
                    destroy_eks_nodegroup(nodegroup_name, cluster_name, eks_client, execution_id)
                    wait_for_nodegroup_deletion(cluster_name, nodegroup_name, credentials)  # Ensure node group deletion is complete
                    click.echo(f"Destroying EKS Cluster: {cluster_name}")
                    destroy_eks_cluster(cluster_name, execution_id, eks_client)
                    wait_for_eks_cluster_deletion(cluster_name, credentials)  # Wait for the cluster to be deleted


                # Ensure all node groups are deleted before deleting the cluster
                elif 'eks_cluster' in task_name:
                    click.echo(f"Destroying EKS Cluster: {state_data['tasks']['eks_cluster']['resource_id']}")
                    eks_client = boto3.client('eks', **credentials)  # Initialize the EKS client
                    cluster_name = state_data['tasks']['eks_cluster']['resource_id']  # Access the cluster name

                    # Check if any node groups remain
                    response = eks_client.list_nodegroups(clusterName=cluster_name)
                    if response['nodegroups']:
                        click.echo(f"Cluster {cluster_name} still has active node groups. Cannot delete cluster.")
                    else:
                        destroy_eks_cluster(cluster_name, execution_id, eks_client)
                        wait_for_eks_cluster_deletion(cluster_name, credentials)  # Wait for the cluster to be deleted

                # Destroy RDS Instances
                elif 'rds_instance' in task_name:
                    click.echo(f"Destroying RDS Instance: {resource_id}")
                    destroy_rds_instance(resource_id, execution_id)
                    wait_for_rds_instance_deletion(resource_id, credentials)

                # Destroy Elastic IP
                elif 'elastic_ip' in task_name:
                    click.echo(f"Releasing Elastic IP: {resource_id}")
                    release_elastic_ip(resource_id, ec2, execution_id)

                # Destroy Network Interfaces
                elif 'network_interface' in task_name:
                    click.echo(f"Deleting Network Interface: {resource_id}")
                    destroy_network_interface(resource_id, ec2, execution_id)


                # Destroy Subnet
                elif 'subnet_creation' in task_name:
                    click.echo(f"Destroying Subnet: {resource_id}")
                    destroy_subnet(resource_id, execution_id)
                    wait_for_subnet_deletion(resource_id, credentials)

                # Destroy Route Table (before Internet Gateway)
                elif 'route_table' in task_name:
                    click.echo(f"Destroying Route Table: {resource_id}")
                    destroy_route_table(resource_id,ec2, execution_id)

                # Destroy Internet Gateway (after EC2, NAT Gateway, etc.)
                elif 'internet_gateway' in task_name:
                    click.echo(f"Destroying Internet Gateway: {resource_id}")
                    vpc_id = task_info.get('vpc_id')
                    destroy_internet_gateway(resource_id, ec2, execution_id)


                # Destroy Security Group
                elif 'security_group' in task_name:
                    click.echo(f"Destroying Security Group: {resource_id}")
                    destroy_security_group(resource_id, ec2, execution_id)

                # Destroy S3 Bucket
                elif 's3_bucket' in task_name:
                    click.echo(f"Deleting S3 Bucket: {resource_id}")
                    destroy_s3_bucket(resource_id, execution_id)

                # Destroy VPC (after Subnets, Route Tables, Internet Gateways)
                elif 'vpc_creation' in task_name:
                    click.echo(f"Destroying VPC: {resource_id}")
                    destroy_vpc(resource_id, execution_id)
                    wait_for_vpc_deletion(resource_id, credentials)

                # Destroy EC2 Instance
                elif re.match(r'^ec2_instance_\d+$', task_name):
                    click.echo(f"Destroying EC2 instance: {resource_id}")
                    destroy_ec2_instance(resource_id, execution_id)
                    wait_for_ec2_termination(resource_id, credentials)

                # Destroy SSL Certificate
                elif 'ssl_certificate' in task_name:
                    click.echo(f"Deleting SSL Certificate: {resource_id}")
                    destroy_ssl_certificate(resource_id, execution_id)

                # Destroy CodeBuild project
                elif 'codebuild_project' in task_name:
                    click.echo(f"Destroying CodeBuild Project: {resource_id}")
                    destroy_codebuild_project(resource_id, cb_client, execution_id)
                    click.echo(f"CodeBuild Project {resource_id} destroyed successfully.")




    click.echo(f"Destroy process completed for execution ID: {execution_id}")

# Define wait functions for resources that require time to fully delete
def wait_for_ec2_termination(instance_id, credentials):
    """Wait for the EC2 instance to be terminated."""
    ec2 = boto3.client('ec2', **credentials)
    waiter = ec2.get_waiter('instance_terminated')

    try:
        click.echo(f"Waiting for EC2 instance {instance_id} to terminate...")
        waiter.wait(InstanceIds=[instance_id])
        click.echo(f"EC2 instance {instance_id} has been terminated.")
    except Exception as e:
        click.echo(f"Error waiting for EC2 instance termination: {str(e)}")


def wait_for_subnet_deletion(subnet_id, credentials):
    ec2 = boto3.client('ec2', **credentials)
    while True:
        try:
            response = ec2.describe_subnets(SubnetIds=[subnet_id])
            if not response['Subnets']:
                break
        except ec2.exceptions.ClientError as e:
            if 'InvalidSubnetID.NotFound' in str(e):
                break
        click.echo(f"Waiting for Subnet {subnet_id} to be deleted...")
        time.sleep(5)
    click.echo(f"Subnet {subnet_id} deleted successfully.")

def wait_for_vpc_deletion(vpc_id, credentials):
    ec2 = boto3.client('ec2', **credentials)
    while True:
        try:
            response = ec2.describe_vpcs(VpcIds=[vpc_id])
            if not response['Vpcs']:
                break
        except ec2.exceptions.ClientError as e:
            if 'InvalidVpcID.NotFound' in str(e):
                break
        click.echo(f"Waiting for VPC {vpc_id} to be deleted...")
        time.sleep(5)
    click.echo(f"VPC {vpc_id} deleted successfully.")

def wait_for_nat_gateway_deletion(nat_gateway_id, credentials):
    ec2 = boto3.client('ec2', **credentials)
    waiter = ec2.get_waiter('nat_gateway_deleted')
    click.echo(f"Waiting for NAT Gateway {nat_gateway_id} to be deleted...")
    waiter.wait(NatGatewayIds=[nat_gateway_id])
    click.echo(f"NAT Gateway {nat_gateway_id} deleted successfully.")

def wait_for_rds_instance_deletion(db_instance_identifier):
    """Wait for the RDS instance to be deleted."""
    rds = boto3.client('rds')

    try:
        # Waiter to wait until the RDS instance is fully deleted
        waiter = rds.get_waiter('db_instance_deleted')
        click.echo(f"Waiting for RDS instance {db_instance_identifier} to be deleted...")
        waiter.wait(DBInstanceIdentifier=db_instance_identifier)
        click.echo(f"RDS instance {db_instance_identifier} successfully deleted.")

    except ClientError as e:
        click.echo(f"Error waiting for RDS instance deletion: {e}")
        raise


def wait_for_load_balancer_deletion(lb_id, credentials):
    elb = boto3.client('elbv2', **credentials)
    waiter = elb.get_waiter('load_balancers_deleted')
    click.echo(f"Waiting for Load Balancer {lb_id} to be deleted...")
    waiter.wait(LoadBalancerArns=[lb_id])
    click.echo(f"Load Balancer {lb_id} deleted successfully.")

def wait_for_nodegroup_deletion(cluster_name, nodegroup_name, credentials ):
    eks = boto3.client('eks',  **credentials)
    click.echo(f"Waiting for EKS Node Group {nodegroup_name} to be deleted...")

    while True:
        try:
            response = eks.describe_nodegroup(clusterName=cluster_name, nodegroupName=nodegroup_name)
            nodegroup_status = response['nodegroup']['status']

            if nodegroup_status == 'DELETE_FAILED':
                click.echo(f"Node Group {nodegroup_name} deletion failed.")
                raise Exception(f"Failed to delete Node Group: {nodegroup_name}")
            elif nodegroup_status == 'DELETED':
                click.echo(f"EKS Node Group {nodegroup_name} deleted successfully.")
                break
            else:
                click.echo(f"Node Group {nodegroup_name} is in status: {nodegroup_status}. Waiting...")
                time.sleep(20)  # Wait for 20 seconds before checking again
        except eks.exceptions.ResourceNotFoundException:
            click.echo(f"Node Group {nodegroup_name} not found. Assuming deletion is complete.")
            break

def wait_for_eks_cluster_deletion(cluster_name, credentials):
    eks = boto3.client('eks', **credentials)
    waiter = eks.get_waiter('cluster_deleted')
    click.echo(f"Waiting for EKS Cluster {cluster_name} to be deleted...")
    waiter.wait(name=cluster_name)
    click.echo(f"EKS Cluster {cluster_name} deleted successfully.")

def wait_for_rds_instance_deletion(instance_id,  credentials):
    rds = boto3.client('rds', **credentials)
    waiter = rds.get_waiter('db_instance_deleted')
    click.echo(f"Waiting for RDS instance {instance_id} to be deleted...")
    waiter.wait(DBInstanceIdentifier=instance_id)
    click.echo(f"RDS instance {instance_id} deleted successfully.")

def destroy_load_balancer(lb_arn, execution_id):
    """Delete the load balancer."""
    elb_client = boto3.client('elbv2')  # Ensure you're using the correct ELB client for application/network load balancers
    try:
        elb_client.delete_load_balancer(LoadBalancerArn=lb_arn)
        click.echo(f"Deleted Load Balancer: {lb_arn}")
        # Update state file to mark the resource as destroyed (consistent naming)
        update_task_state(execution_id, 'load_balancer', 'destroyed', resource_id=lb_arn)
    except Exception as e:
        click.echo(f"Failed to delete Load Balancer {lb_arn}: {e}")

def destroy_internet_gateway(igw_id, ec2, execution_id):
    try:
        # Check if the Internet Gateway still exists before attempting to delete
        response = ec2.describe_internet_gateways(InternetGatewayIds=[igw_id])
        if not response['InternetGateways']:
            click.echo(f"Internet Gateway {igw_id} does not exist. Skipping deletion.")
            return

        # Retrieve the VPC ID associated with the Internet Gateway
        click.echo(f"Retrieving VPC ID associated with Internet Gateway {igw_id}...")
        vpc_id = response['InternetGateways'][0]['Attachments'][0]['VpcId']
        click.echo(f"Found VPC ID {vpc_id} for Internet Gateway {igw_id}.")

        # Detach the Internet Gateway from the VPC
        click.echo(f"Detaching Internet Gateway {igw_id} from VPC {vpc_id}...")
        ec2.detach_internet_gateway(InternetGatewayId=igw_id, VpcId=vpc_id)
        click.echo(f"Detached Internet Gateway {igw_id} from VPC {vpc_id}")

        # Delete the Internet Gateway
        click.echo(f"Deleting Internet Gateway {igw_id}...")
        ec2.delete_internet_gateway(InternetGatewayId=igw_id)
        click.echo(f"Deleted Internet Gateway {igw_id}")

        # Record the destruction in the state file
        update_task_state(execution_id, 'internet_gateway', 'destroyed', resource_id=igw_id)

    except ClientError as e:
        if 'InvalidInternetGatewayID.NotFound' in str(e):
            click.echo(f"Internet Gateway {igw_id} not found. It may have already been deleted.")
        else:
            click.echo(f"Failed to detach or delete Internet Gateway {igw_id}: {e}")
        raise

def destroy_codebuild_project(cb_project_name, cb_client, execution_id):
    try:
        # Delete the CodeBuild project
        click.echo(f"Deleting CodeBuild Project: {cb_project_name}")
        cb_client.delete_project(name=cb_project_name)

        # Update state file to mark CodeBuild project as destroyed
        update_task_state(execution_id, 'codebuild_project', 'destroyed', resource_id=cb_project_name)
        click.echo(f"CodeBuild Project {cb_project_name} deleted successfully.")

    except ClientError as e:
        click.echo(f"Failed to delete CodeBuild Project {cb_project_name}: {e}")
        raise

def destroy_ec2_instance(instance_id, execution_id):
    """Terminate EC2 instance and wait for it to be fully terminated."""
    credentials = load_aws_credentials()
    ec2 = boto3.client('ec2', **credentials)

    try:
        # Terminate the EC2 instance
        ec2.terminate_instances(InstanceIds=[instance_id])
        click.echo(f"Terminated EC2 instance: {instance_id}")

        # Wait for the instance to be fully terminated
        waiter = ec2.get_waiter('instance_terminated')
        click.echo(f"Waiting for EC2 instance {instance_id} to terminate...")
        waiter.wait(InstanceIds=[instance_id])

        click.echo(f"EC2 instance {instance_id} has been terminated.")
        
        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 'ec2_instance', 'destroyed', resource_id=instance_id)

    except ClientError as e:
        click.echo(f"Failed to terminate EC2 instance {instance_id}: {e}")


def destroy_subnet(subnet_id, execution_id):
    """Delete subnet after ensuring no dependencies exist (EC2 instances or ENIs)."""
    credentials = load_aws_credentials()
    ec2 = boto3.client('ec2', **credentials)

    try:
        # Check for active EC2 instances in the subnet
        response = ec2.describe_instances(Filters=[{'Name': 'subnet-id', 'Values': [subnet_id]}])
        if response['Reservations']:
            click.echo(f"Cannot delete Subnet {subnet_id} because there are EC2 instances still running in it.")
            return

        # Check for network interfaces in the subnet
        response = ec2.describe_network_interfaces(Filters=[{'Name': 'subnet-id', 'Values': [subnet_id]}])
        if response['NetworkInterfaces']:
            click.echo(f"Cannot delete Subnet {subnet_id} because there are network interfaces still attached.")
            return

        # Proceed with subnet deletion
        ec2.delete_subnet(SubnetId=subnet_id)
        click.echo(f"Deleted Subnet: {subnet_id}")

        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 'subnet_creation', 'destroyed', resource_id=subnet_id)

    except ClientError as e:
        click.echo(f"Failed to delete Subnet {subnet_id}: {e}")


def deregister_targets(target_group_arn, targets, elb_client, execution_id=None):
    """Deregister targets from the specified target group."""
    try:
        # Deregister the targets from the load balancer
        click.echo(f"Deregistering targets from Target Group: {target_group_arn}")
        elb_client.deregister_targets(
            TargetGroupArn=target_group_arn,
            Targets=[{'Id': target} for target in targets]
        )

        # Optionally update the state file
        if execution_id:
            update_task_state(execution_id, 'target_registration', 'deregistered', resource_id=target_group_arn)
        click.echo(f"Targets deregistered from {target_group_arn} successfully.")

    except ClientError as e:
        click.echo(f"Failed to deregister targets from {target_group_arn}: {e}")
        raise


def destroy_network_interface(interface_id, ec2, execution_id):
    """Delete a network interface."""
    try:
        # Delete the network interface
        ec2.delete_network_interface(NetworkInterfaceId=interface_id)
        click.echo(f"Deleted Network Interface: {interface_id}")

        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 'network_interface', 'destroyed', resource_id=interface_id)
    except ClientError as e:
        click.echo(f"Failed to delete Network Interface {interface_id}: {e}")


def destroy_nat_gateway(nat_gw_id, ec2, execution_id):
    try:
        # Delete the NAT Gateway
        click.echo(f"Deleting NAT Gateway: {nat_gw_id}")
        ec2.delete_nat_gateway(NatGatewayId=nat_gw_id)

        # Wait for NAT Gateway deletion to complete
        waiter = ec2.get_waiter('nat_gateway_deleted')
        click.echo(f"Waiting for NAT Gateway {nat_gw_id} to be deleted...")
        waiter.wait(NatGatewayIds=[nat_gw_id])

        # Update state file to mark NAT Gateway as destroyed
        update_task_state(execution_id, 'nat_gateway', 'destroyed', resource_id=nat_gw_id)
        click.echo(f"NAT Gateway {nat_gw_id} deleted successfully.")

    except ClientError as e:
        click.echo(f"Failed to delete NAT Gateway {nat_gw_id}: {e}")
        raise


def destroy_vpc(vpc_id, execution_id):
    """Delete VPC."""
    credentials = load_aws_credentials()
    ec2 = boto3.client('ec2', **credentials)

    try:
        ec2.delete_vpc(VpcId=vpc_id)
        click.echo(f"Deleted VPC: {vpc_id}")
        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 'vpc_creation', 'destroyed', resource_id=vpc_id)
    except ClientError as e:
        click.echo(f"Failed to delete VPC {vpc_id}: {e}")

def destroy_target_group(target_group_arn, execution_id):
    """Delete the target group."""
    elb_client = boto3.client('elbv2')  # Ensure you're using the correct client for Application Load Balancer (ALB)
    try:
        elb_client.delete_target_group(TargetGroupArn=target_group_arn)
        click.echo(f"Deleted Target Group: {target_group_arn}")
        # Update state file to mark the resource as destroyed (consistent naming)
        update_task_state(execution_id, 'target_group', 'destroyed', resource_id=target_group_arn)
    except Exception as e:
        click.echo(f"Failed to delete Target Group {target_group_arn}: {e}")


def destroy_listener(listener_arn, elb_client, execution_id):
    try:
        elb_client.delete_listener(ListenerArn=listener_arn)
        click.echo(f"Deleted Listener: {listener_arn}")

        # Update state file to mark the listener as destroyed
        update_task_state(execution_id, 'listener', 'destroyed', resource_id=listener_arn)
    except ClientError as e:
        click.echo(f"Failed to delete Listener {listener_arn}: {e}")


def destroy_eks_cluster(cluster_name, execution_id, eks_client):
    try:
        eks_client.delete_cluster(name=cluster_name)
        click.echo(f"Deleted EKS Cluster: {cluster_name}")

        # Update state file to mark the cluster as destroyed
        update_task_state(execution_id, 'eks_cluster', 'destroyed', resource_id=cluster_name)
    except ClientError as e:
        click.echo(f"Failed to delete EKS Cluster {cluster_name}: {e}")

def destroy_eks_nodegroup(nodegroup_name, cluster_name, eks_client, execution_id):
    try:
        eks_client.delete_nodegroup(clusterName=cluster_name, nodegroupName=nodegroup_name)
        click.echo(f"Deleted EKS Nodegroup: {nodegroup_name}")

        # Update state file to mark the nodegroup as destroyed
        update_task_state(execution_id, 'eks_nodegroup', 'destroyed', resource_id=nodegroup_name)
    except ClientError as e:
        click.echo(f"Failed to delete EKS Nodegroup {nodegroup_name}: {e}")

def destroy_route_table(route_table_id, ec2, execution_id):
    try:
        # Retrieve the current routes in the route table
        response = ec2.describe_route_tables(RouteTableIds=[route_table_id])
        routes = response['RouteTables'][0]['Routes']

        # Delete all non-local routes from the route table
        for route in routes:
            if route.get('DestinationCidrBlock') == '10.0.0.0/16' and route.get('Origin') == 'CreateRouteTable':
                click.echo(f"Skipping local route {route['DestinationCidrBlock']} in route table {route_table_id}.")
                continue

            if 'GatewayId' in route or 'InstanceId' in route or 'NetworkInterfaceId' in route:
                click.echo(f"Deleting route {route['DestinationCidrBlock']} from route table {route_table_id}.")
                ec2.delete_route(
                    RouteTableId=route_table_id,
                    DestinationCidrBlock=route['DestinationCidrBlock']
                )

        # Delete the route table itself
        click.echo(f"Deleting Route Table: {route_table_id}")
        ec2.delete_route_table(RouteTableId=route_table_id)
        click.echo(f"Deleted Route Table: {route_table_id}")

        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 'route_table', 'destroyed', resource_id=route_table_id)
    except ClientError as e:
        click.echo(f"Failed to delete Route Table {route_table_id}: {e}")
        raise


def destroy_rds_instance(db_instance_identifier, execution_id):
    """Delete an RDS instance."""
    credentials = load_aws_credentials()
    rds = boto3.client('rds', **credentials)

    try:
        click.echo(f"Starting deletion of RDS instance: {db_instance_identifier}")

        # Delete the RDS instance, skip final snapshot for simplicity
        rds.delete_db_instance(
            DBInstanceIdentifier=db_instance_identifier,
            SkipFinalSnapshot=True,  # Or set this to False if you need a final snapshot
            DeleteAutomatedBackups=True  # Optional: delete automated backups as well
        )

        # Log the deletion process started
        click.echo(f"RDS instance {db_instance_identifier} deletion initiated.")

        # Wait for the instance to be fully deleted
        waiter = rds.get_waiter('db_instance_deleted')
        click.echo(f"Waiting for RDS instance {db_instance_identifier} to be deleted...")
        waiter.wait(DBInstanceIdentifier=db_instance_identifier)

        click.echo(f"RDS instance {db_instance_identifier} deleted successfully.")

        # Update the state file to mark the RDS instance as destroyed
        update_task_state(execution_id, 'rds_instance', 'destroyed', resource_id=db_instance_identifier)

    except ClientError as e:
        click.echo(f"Failed to delete RDS instance {db_instance_identifier}: {e}")
        raise

def release_elastic_ip(allocation_id, ec2, execution_id):
    try:
        # Check if the Elastic IP is associated with any resource
        response = ec2.describe_addresses(AllocationIds=[allocation_id])
        if 'Addresses' in response and response['Addresses']:
            association_id = response['Addresses'][0].get('AssociationId')
            if association_id:
                click.echo(f"Disassociating Elastic IP with Association ID: {association_id}")
                ec2.disassociate_address(AssociationId=association_id)
                click.echo(f"Disassociated Elastic IP with Association ID: {association_id}")

        # Release the Elastic IP
        click.echo(f"Releasing Elastic IP with Allocation ID: {allocation_id}")
        ec2.release_address(AllocationId=allocation_id)

        # Update the state file to mark the Elastic IP as destroyed
        update_task_state(execution_id, 'elastic_ip', 'destroyed', resource_id=allocation_id)
        click.echo(f"Elastic IP with Allocation ID {allocation_id} released successfully.")

    except ClientError as e:
        click.echo(f"Failed to release Elastic IP {allocation_id}: {e}")
        raise


def destroy_network_interface(network_interface_id, ec2, execution_id):
    try:
        # Delete the Network Interface
        click.echo(f"Deleting Network Interface: {network_interface_id}")
        ec2.delete_network_interface(NetworkInterfaceId=network_interface_id)

        # Update state file to mark the network interface as destroyed
        update_task_state(execution_id, 'network_interface', 'destroyed', resource_id=network_interface_id)
        click.echo(f"Network Interface {network_interface_id} deleted successfully.")

    except ClientError as e:
        click.echo(f"Failed to delete Network Interface {network_interface_id}: {e}")
        raise

def destroy_security_group(sg_id, ec2, execution_id):
    try:
        # Delete the Security Group
        ec2.delete_security_group(GroupId=sg_id)
        click.echo(f"Deleted Security Group {sg_id}")

        # Update the state file to mark the Security Group as destroyed
        update_task_state(execution_id, 'security_group', 'destroyed', resource_id=sg_id)

    except ClientError as e:
        click.echo(f"Failed to delete Security Group {sg_id}: {e}")
        raise


def destroy_s3_bucket(bucket_name, execution_id):
    """Delete an S3 bucket and its contents."""
    # Load AWS credentials
    credentials = load_aws_credentials()
    s3 = boto3.client('s3', **credentials)

    try:
        click.echo(f"Deleting S3 Bucket: {bucket_name}")

        # Delete all objects in the bucket
        paginator = s3.get_paginator('list_objects_v2')
        for page in paginator.paginate(Bucket=bucket_name):
            if 'Contents' in page:
                for obj in page['Contents']:
                    s3.delete_object(Bucket=bucket_name, Key=obj['Key'])
                    click.echo(f"Deleted object {obj['Key']} from bucket {bucket_name}")

        # Check if versioning is enabled and delete all versions if present
        versioning = s3.get_bucket_versioning(Bucket=bucket_name)
        if versioning.get('Status') == 'Enabled':
            click.echo(f"Versioning is enabled for S3 Bucket '{bucket_name}'. Deleting all versions and delete markers...")
            paginator = s3.get_paginator('list_object_versions')
            for page in paginator.paginate(Bucket=bucket_name):
                for version in page.get('Versions', []):
                    s3.delete_object(Bucket=bucket_name, Key=version['Key'], VersionId=version['VersionId'])
                    click.echo(f"Deleted version {version['VersionId']} of object {version['Key']} from bucket {bucket_name}")
                for delete_marker in page.get('DeleteMarkers', []):
                    s3.delete_object(Bucket=bucket_name, Key=delete_marker['Key'], VersionId=delete_marker['VersionId'])
                    click.echo(f"Deleted delete marker {delete_marker['VersionId']} from bucket {bucket_name}")

        # Finally, delete the bucket itself
        s3.delete_bucket(Bucket=bucket_name)
        click.echo(f"Deleted S3 Bucket: {bucket_name}")

        # Update state file to mark the resource as destroyed
        update_task_state(execution_id, 's3_bucket', 'destroyed', resource_id=bucket_name)
    except ClientError as e:
        click.echo(f"Failed to delete S3 Bucket {bucket_name}: {e}")



SUPPORTED_KUBERNETES_VERSIONS = ['1.27', '1.26', '1.25', '1.24', '1.23']

def get_valid_kubernetes_version(requested_version=None):
    """Validate the Kubernetes version or fallback to the latest supported version."""
    if requested_version and requested_version in SUPPORTED_KUBERNETES_VERSIONS:
        return requested_version
    else:
        click.echo(f"Invalid or unsupported Kubernetes version: {requested_version}. Falling back to latest supported version.")
        return SUPPORTED_KUBERNETES_VERSIONS[0]  # Return latest supported version

os.makedirs(STATE_DIR, exist_ok=True) 

def update_task_state(execution_id, task_name, status, resource_id=None):
    """Update the task state in the state file."""
    state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')

    if os.path.exists(state_file_path):
        with open(state_file_path, 'r') as file:
            state_data = yaml.safe_load(file)
    else:
        state_data = {'tasks': {}}

    # Update the task status
    state_data['tasks'][task_name] = {
        'status': status,
        'resource_id': resource_id
    }

    # Save the updated state back to the file
    with open(state_file_path, 'w') as file:
        yaml.dump(state_data, file)

def record_task_state(execution_id, task_name, status, resource_id=None):
    """Update the state file for a given task."""
    state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')

    if os.path.exists(state_file_path):
        with open(state_file_path, 'r') as file:
            state_data = yaml.safe_load(file)
    else:
        state_data = {'tasks': {}}

    # Ensure task names are unique for each instance
    task_count = len([key for key in state_data['tasks'] if task_name in key])
    unique_task_name = f"{task_name}_{task_count}" if task_count > 0 else task_name

    # Update the task status
    state_data['tasks'][unique_task_name] = {
        'status': status,
        'resource_id': resource_id
    }

    # Save the updated state back to the file
    with open(state_file_path, 'w') as file:
        yaml.dump(state_data, file)



def save_instance_ips(instances):
    existing_names = set()

    # Read the existing names from the hosts file to avoid duplicates
    with open(HOSTS_FILE, 'r') as hosts_file:
        for line in hosts_file:
            parts = line.split()
            if len(parts) >= 2 and not line.startswith('#'):
                existing_names.add(parts[1])

    with open(HOSTS_FILE, 'a') as hosts_file:
        for idx, instance in enumerate(instances):
            ip = instance['private_ip']
            name = instance.get('name') or f"user{idx + 1}"

            if name in existing_names:
                print(f"Error: The hostname '{name}' already exists in {HOSTS_FILE}. Please change the name manually.")
            else:
                hosts_file.write(f"{ip}\t{name}\n")
                print(f"Added {name} with IP {ip} to {HOSTS_FILE}")


def check_dependencies(execution_id, dependencies):
    """
    Check if all dependencies are met before creating a resource.

    :param execution_id: The execution ID for checking the state.
    :param dependencies: List of dependencies (task names) that must be met.
    :return: Tuple (True/False, unmet_dependency) where:
             - True if all dependencies are met, False otherwise.
             - unmet_dependency returns the first unmet dependency or None.
    """
    state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')
    if not os.path.exists(state_file_path):
        click.echo(f"State file not found for Execution ID: {execution_id}")
        return False, "State file missing"

    with open(state_file_path, 'r') as file:
        state_data = yaml.safe_load(file)

    for dependency in dependencies:
        task_info = state_data.get('tasks', {}).get(dependency, {})
        if task_info.get('status') != 'success':
            return False, dependency  # Return the first unmet dependency

    return True, None


# Define the is_task_completed function
def is_task_completed(execution_id, task_name):
    """
    Check if the specified task has been completed successfully or failed.

    :param execution_id: The execution ID to check in the state file.
    :param task_name: The name of the task to check (e.g., 'vpc_creation').
    :return: Tuple (True/False, resource_id, status) where:
             - True if the task status is 'success', False otherwise.
             - resource_id if the task is completed successfully, None otherwise.
             - status to indicate 'success', 'failed', or 'not_found'.
    """
    state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')
    if not os.path.exists(state_file_path):
        return False, None, 'not_found'  # Ensure 3 values are returned

    with open(state_file_path, 'r') as file:
        state_data = yaml.safe_load(file)

    # Check if the task is marked as 'success' or 'failed' in the state file
    tasks = state_data.get('tasks', {})
    task_info = tasks.get(task_name, {})
    status = task_info.get('status', 'not_found')
    resource_id = task_info.get('resource_id', None)  # Extract the resource ID if available

    if status == 'success':
        return True, resource_id, 'success'
    elif status == 'failed':
        return False, resource_id, 'failed'
    else:
        return False, None, 'not_found'

# Function to create a boto3 client with the correct credentials and region

def handle_commands(commands):
    for cmd in commands:
        identifiers = [id.strip() for id in cmd['identifiers'].split(',')]
        user = cmd['username']
        cmd_to_run = cmd['command']

        for identifier in identifiers:
            try:
                private_ip, _ = get_host_entry(identifier)
                success, message = execute_command_on_server(private_ip, user, cmd_to_run)
                if success:
                    click.echo(f"Command execution on {identifier} ({private_ip}) was successful:\n{message}")
                else:
                    click.echo(f"Failed to execute command on {identifier} ({private_ip}): {message}")
            except ValueError as ve:
                click.echo(str(ve))

def execute_command_on_server(hostname, username, command, timeout=None, real_time_output=False):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username)

        # Use the timeout parameter for the exec_command
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)

        output, error = "", ""

        if real_time_output:
            # Read stdout line by line for real-time feedback
            for line in iter(stdout.readline, ""):
                print(line, end="", flush=True)  # Print each line immediately
                output += line

            # Read stderr line by line as well, for any immediate errors
            for line in iter(stderr.readline, ""):
                print(line, end="", flush=True)
                error += line
        else:
            # If not real-time, capture the full output and error at once
            output = stdout.read().decode()
            error = stderr.read().decode()

        exit_status = stdout.channel.recv_exit_status()
        client.close()

        # Interpret success based on exit status
        if exit_status == 0:
            return True, output + error  # Combine output and error for informational messages
        else:
            return False, output + error

    except Exception as e:
        # Return failure with the exception message
        return False, str(e)


# Function to execute a command and print the result
def execute_and_print(identifier, username, command, category=None):
    """Executes the command on the remote worker and returns success status and output"""
    try:
        private_ip, _ = get_host_entry(identifier, category)
        success, message = execute_command_on_server(private_ip, username, command)
        if success:
            return True, message  # Return success and the command output
        else:
            return False, message  # Return failure and the error message
    except ValueError as ve:
        return False, str(ve)

# Function to get host entry from the hosts file based on identifier and optional category
def get_host_entry(identifier, category=None):
    """
    Retrieves the IP and name of the host entry based on the identifier.
    Optionally looks within a specified category if provided.
    
    :param identifier: The identifier for the host (e.g., instance name).
    :param category: Optional category (e.g., dev, prod) to search within.
    :return: Tuple of (IP address, identifier).
    :raises: ValueError if the identifier is not found.
    """
    category_found = False
    with open(HOSTS_FILE, 'r') as hosts_file:
        for line in hosts_file:
            # Check if category matches, or if we're searching in the default section
            if category:
                if line.strip() == f"[{category}]":
                    category_found = True
                # If we're inside a category and hit a new category, stop
                elif line.startswith("[") and category_found:
                    break
            else:
                # Only look in the default section (no category)
                if line.startswith("["):
                    continue

            # Check if identifier matches within the current section (category or default)
            if identifier in line:
                return line.split()[0], line.split()[1]

    raise ValueError(f"No entry found for identifier '{identifier}' in category '{category or 'default'}'.")

# Function to get all environments (categories) from the hosts file
def get_all_environments():
    environments = set()
    with open(HOSTS_FILE, 'r') as f:
        for line in f:
            match = re.match(r'\[(.+)\]', line)
            if match:
                environments.add(match.group(1))
    return list(environments)

# Function to get all hosts in a specific environment (category)
def get_hosts_from_environment(environment):
    hosts = []
    in_environment = False
    with open(HOSTS_FILE, 'r') as f:
        for line in f:
            if re.match(r'\[' + re.escape(environment) + r'\]', line):
                in_environment = True
            elif re.match(r'\[.+\]', line):
                in_environment = False
            elif in_environment and line.strip():
                parts = line.split()
                if len(parts) >= 2:
                    ip, name = parts[:2]
                    hosts.append({'name': name, 'ip': ip})
    return hosts

# Main function to execute multiple commands
def execute_commands(commands):
    for cmd in commands:
        identifiers = [id.strip() for id in cmd['identifiers'].split(',')]
        environments = [env.strip() for env in cmd.get('Environment', 'ALL').split(',')]
        user = cmd['username']
        cmd_to_run = cmd['command']

        # Retrieve all environments if 'ALL' is specified
        if 'ALL' in environments:
            environments = get_all_environments()

        # Iterate through each environment and execute the command
        for env in environments:
            hosts = get_hosts_from_environment(env)
            for identifier in identifiers:
                if identifier == 'ALL':
                    # Execute command on all hosts in the current environment
                    for host in hosts:
                        success, message = execute_and_print(host['name'], user, cmd_to_run, env)
                        if success:
                            print(f"Success on {host['name']} ({env}): {message}")
                        else:
                            print(f"Error on {host['name']} ({env}): {message}")
                else:
                    # Execute command on the specific host if identifier matches
                    host = next((host for host in hosts if host['name'] == identifier), None)
                    if host:
                        success, message = execute_and_print(host['name'], user, cmd_to_run, env)
                        if success:
                            print(f"Success on {host['name']} ({env}): {message}")
                        else:
                            print(f"Error on {host['name']} ({env}): {message}")

output_variables = {}
@aws.command(name="outputs", help="Display or export captured output variables.")
@click.option('--export-file', '-e', type=click.Path(), help="File path to export the output variables (short: -e).")
@click.option('--import-file', '-i', type=click.Path(), help="File path to import existing output variables (short: -i).")
def manage_outputs(export_file, import_file):
    """
    Manage the captured output variables: display, export, or import.

    Args:
    - export_file (str): Optional path to export the output variables.
    - import_file (str): Optional path to import existing output variables.
    """
    global output_variables

    if import_file:
        load_output_variables(import_file)
    elif export_file:
        save_output_variables(export_file)
    else:
        click.echo("\nCaptured Output Variables:")
        click.echo(tabulate([(k, v) for k, v in output_variables.items()], headers=["Resource", "Details"], tablefmt="grid"))

############################################################################################################
from pathlib import Path

@cli.group(name="dobp", help="DevOps Bot Proxy configuration commands.")
def dobp():
    pass


PROXY_CREDENTIALS_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_credentials.json")
PROXY_KEY_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_key.key")

def generate_proxy_key():
    if not os.path.exists(PROXY_KEY_FILE):
        key = Fernet.generate_key()
        with open(PROXY_KEY_FILE, 'wb') as key_file:
            key_file.write(key)


def encrypt_proxy_data(data, key):
    cipher_suite = Fernet(key)
    encrypted_data = cipher_suite.encrypt(data.encode())
    return encrypted_data

def load_proxy_key():
    with open(PROXY_KEY_FILE, 'rb') as key_file:
        return key_file.read()

def decrypt_proxy_data(encrypted_data, key):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data

def load_proxy_credentials():
    """Load and decrypt proxy credentials."""
    try:
        with open(os.path.join(BASE_DIR, PROXY_CREDENTIALS_FILE), 'rb') as cred_file:
            encrypted_data = cred_file.read()
        
        key = load_proxy_key()  # Load encryption key
        decrypted_data = decrypt_proxy_data(encrypted_data, key)  # Decrypt data
        credentials = json.loads(decrypted_data)  # Convert JSON string to dictionary
        return credentials  # Return as dictionary
    except (FileNotFoundError, ValueError, KeyError) as e:
        click.echo(f"Failed to load proxy credentials: {e}")
        return None



# Function to communicate with the devops-bot-proxy
def send_proxy_request(endpoint, data=None, method="GET"):
    # Load proxy URL and API key
    proxy_url, api_key = load_proxy_credentials()
    if not proxy_url or not api_key:
        print("Proxy credentials not found. Please configure them using the `dobp configure` command.")
        return None

    # Prepare request details
    url = f"{proxy_url}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    # Make the HTTP request
    try:
        if method == "GET":
            response = requests.get(url, headers=headers)
        elif method == "POST":
            response = requests.post(url, json=data, headers=headers)
        else:
            raise ValueError("Unsupported HTTP method")

        response.raise_for_status()  # Raises an error for 4xx/5xx responses
        return response.json()  # Return the JSON response if successful

    except requests.exceptions.RequestException as e:
        print(f"Error connecting to devops-bot-proxy: {e}")
        return None


def proxy_load_balancer_request(url, endpoint, api_token, data=None, method="POST"):
    full_url = f"{url}{endpoint}"
    headers = {
        "Authorization": f"Bearer {api_token}",
        "Content-Type": "application/json"
    }

    try:
        if method == "GET":
            response = requests.get(full_url, headers=headers)
        elif method == "POST":
            response = requests.post(full_url, json=data, headers=headers)
        else:
            raise ValueError("Unsupported HTTP method")
        
        response.raise_for_status()
        return response.json()

    except requests.exceptions.RequestException as e:
        click.echo(click.style(f"Error connecting to the proxy: {e}", fg="red"))
        return None


##########################################################################################################################
@dobp.command(name="configure", help="Configure DevOps Bot Proxy and save credentials locally.")
@click.option('--url', required=True, help="DevOps Bot Proxy API URL.")
@click.option('--api-key', required=True, help="API Key for DevOps Bot Proxy.")
def configure_proxy(url, api_key):
    # Step 1: Ensure encryption key exists
    generate_proxy_key()
    key = load_proxy_key()

    # Step 2: Encrypt the credentials
    credentials = {
        'proxy_url': url,
        'api_key': api_key
    }
    encrypted_credentials = encrypt_proxy_data(json.dumps(credentials), key)

    # Step 3: Save encrypted credentials to file
    try:
        credentials_file_path = os.path.join(BASE_DIR, PROXY_CREDENTIALS_FILE)
        with open(credentials_file_path, 'wb') as cred_file:
            cred_file.write(encrypted_credentials)
        click.echo(f"DevOps Bot Proxy credentials saved successfully in {credentials_file_path}.")
    except Exception as e:
        click.echo(f"Error saving DevOps Bot Proxy credentials: {e}")


@dobp.command(name="test-proxy", help="Test communication with the DevOps Bot Proxy.")
def test_proxy():
    """Test connection to the proxy and display a welcome message."""
    try:
        # Load stored credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        # Set up the request with loaded credentials
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/welcome"

        # Send the request
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        # Display the response
        click.echo(response.json().get("message", "No message received from proxy"))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="deploy", help="Deploy a container via DevOps Bot Proxy.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=False, help="Name of the container.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--host-port', required=False, type=int, help="Host port to expose.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--count', default=1, type=int, help="Number of container instances to deploy.")
def deploy(config_file, container_name, image, host_port, container_port, count):
    """Deploy a container through the proxy with options or YAML config."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/deploy"

        # Load config from YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            image = config.get("image", image)
            host_port = config.get("host_port", host_port)
            container_port = config.get("container_port", container_port)
            count = config.get("count", count)

        # Validate required parameters
        if not all([container_name, image, host_port, container_port]):
            click.echo("Missing required deployment parameters.")
            return

        # Payload to send to the proxy's deploy function
        payload = {
            "container_name": container_name,
            "image": image,
            "host_port": host_port,
            "container_port": container_port,
            "count": count
        }

        # Send the deployment request to the proxy
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Deployment response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="setup-load-balancer", help="Setup load balancer for specified container.")
@click.option('--container-name', required=True, help="Name of the container to load balance.")
def setup_load_balancer(container_name):
    """Setup load balancer for a specified container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/load-balance/setup"  # Updated to the new setup endpoint

        payload = {
            "container_name": container_name
        }

        # Send the setup request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Load balancer setup response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")



@dobp.command(name="destroy", help="Destroy specified containers.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=True, help="Name of the container to destroy.")
@click.option('--count', required=False, type=int, default=1, help="Number of container instances to destroy.")
def destroy(config_file, container_name, count):
    """Destroy containers through the proxy with options or YAML config."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/destroy"

        # Load config from YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            count = config.get("count", count)

        # Validate required parameters
        if not container_name:
            click.echo("Container name required for destruction.")
            return

        payload = {
            "container_name": container_name,
            "count": count
        }

        # Send the destroy request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        removed_containers = response.json().get("removed_containers", [])
        click.echo(f"Removed containers: {', '.join(removed_containers)}")

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="blue-green", help="Perform a blue-green deployment via DevOps Bot Proxy.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=False, help="Name of the container.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--host-port', required=False, type=int, help="Host port to expose.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--count', required=False, type=int, help="Number of container instances to deploy.")
def blue_green(config_file, container_name, image, host_port, container_port, count):
    """Perform a blue-green deployment through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/blue-green"

        # Load config from YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            image = config.get("image", image)
            host_port = config.get("host_port", host_port)
            container_port = config.get("container_port", container_port)
            count = config.get("count", count)

        # Validate required parameters
        if not all([container_name, image, host_port, container_port]):
            click.echo("Missing required deployment parameters.")
            return

        payload = {
            "container_name": container_name,
            "image": image,
            "host_port": host_port,
            "container_port": container_port,
            "count": count
        }

        # Send the blue-green deployment request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Blue-Green deployment response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="rollback", help="Rollback to previous Blue deployment via DevOps Bot Proxy.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=False, help="Name of the container.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--host-port', required=False, type=int, help="Host port to expose.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--count', required=False, type=int, help="Number of container instances to rollback.")
def rollback(config_file, container_name, image, host_port, container_port, count):
    """Perform a rollback to Blue deployment through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/rollback"

        # Load config from YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            image = config.get("image", image)
            host_port = config.get("host_port", host_port)
            container_port = config.get("container_port", container_port)
            count = config.get("count", count)

        # Validate required parameters
        if not all([container_name, image, host_port, container_port]):
            click.echo("Missing required rollback parameters.")
            return

        payload = {
            "container_name": container_name,
            "image": image,
            "host_port": host_port,
            "container_port": container_port,
            "count": count
        }

        # Send the rollback request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Rollback response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="auto-scale", help="Auto-scale container instances via DevOps Bot Proxy.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=False, help="Name of the container.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--target-count', required=True, type=int, help="Desired number of container instances.")
def auto_scale(config_file, container_name, image, container_port, target_count):
    """Auto-scale container instances to the desired count through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/auto-scale"

        # Load config from YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            image = config.get("image", image)
            container_port = config.get("container_port", container_port)
            target_count = config.get("target_count", target_count)

        # Validate required parameters
        if not all([container_name, image, container_port, target_count]):
            click.echo("Missing required scaling parameters.")
            return

        payload = {
            "container_name": container_name,
            "image": image,
            "container_port": container_port,
            "target_count": target_count
        }

        # Send the scaling request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Auto-scaling response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="logs", help="Fetch logs for a specific container.")
@click.option('--container-id', required=True, help="ID of the container to fetch logs for.")
def fetch_logs(container_id):
    """Fetch logs for a specific container through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/logs"
        params = {"container_id": container_id}

        response = requests.get(url, headers=headers, params=params)
        response.raise_for_status()
        logs = response.json().get("logs", "No logs available")
        click.echo(logs)

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to fetch logs from DevOps Bot Proxy: {e}")

@dobp.command(name="list-containers", help="List all running containers managed by the proxy.")
def list_containers():
    """List all running containers with details through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/list-containers"

        response = requests.get(url, headers=headers)
        response.raise_for_status()
        containers = response.json().get("containers", [])

        if containers:
            click.echo("Container List:")
            for container in containers:
                click.echo(f"- ID: {container['id']}, IP: {container['ip']}, Port: {container['port']}, Status: {container['status']}")
        else:
            click.echo("No running containers found.")

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to retrieve container list from DevOps Bot Proxy: {e}")


@dobp.command(name="view-load-balancer", help="View the load balancer status for a specified container.")
@click.option('--container-name', required=True, help="Name of the container to view load balancer status.")
def view_load_balancer(container_name):
    """View load balancer status for a specified container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/load-balance/status"  # Updated to the correct status endpoint

        payload = {
            "container_name": container_name
        }

        # Send the view status request
        response = requests.get(url, json=payload, headers=headers)
        response.raise_for_status()
        status = response.json()
        click.echo(f"Load Balancer for container '{container_name}': {status}")

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="create-volume", help="Create a new Docker volume.")
@click.option('--volume-name', required=True, help="Name of the volume to create.")
@click.option('--driver', default="local", help="Volume driver to use.")
@click.option('--labels', default=None, help="Optional JSON data for volume labels.")
def create_volume(volume_name, driver, labels):
    """Send a request to the proxy to create a Docker volume."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        # Define payload for volume creation
        payload = {
            "volume_name": volume_name,
            "driver": driver,
            "labels": labels
        }

        # Make the request to the proxy endpoint
        url = f"{proxy_url}/create-volume"
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        
        # Output response content
        click.echo(response.json())
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="attach-volume", help="Attach a Docker volume to a container.")
@click.option('--container-name', required=True, help="Name of the container to attach volume to.")
@click.option('--volume-name', required=True, help="Name of the volume to attach.")
@click.option('--mount-path', required=True, help="Mount path inside the container.")
def attach_volume(container_name, volume_name, mount_path):
    """Send a request to the proxy to attach a volume to a container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        # Define payload for attaching volume
        payload = {
            "container_name": container_name,
            "volume_name": volume_name,
            "mount_path": mount_path
        }

        # Send the request to the proxy endpoint
        url = f"{proxy_url}/attach-volume"
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()

        click.echo(response.json())
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")
import json

@dobp.command(name="inspect-container", help="Inspect a container.")
@click.option('--container-name', required=True, help="Name of the container to inspect.")
def inspect_container(container_name):
    """Inspect a Docker container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        # Define the URL and params payload
        url = f"{proxy_url}/inspect-container"
        params = {"container_name": container_name}

        # Make the request to the proxy server
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()  # Raise error for HTTP issues

        # Parse the JSON response and pretty-print it
        container_info = response.json().get("container_info", "")
        formatted_info = json.loads(container_info)  # Convert the string to JSON format
        click.echo(json.dumps(formatted_info, indent=4))  # Pretty-print with indentation

    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")
    except json.JSONDecodeError:
        click.echo("Error formatting container information.")

@dobp.command(name="detach-volume", help="Detach a Docker volume from a container.")
@click.option('--container-name', required=True, help="Name of the container to detach volume from.")
@click.option('--volume-name', required=True, help="Name of the volume to detach.")
def detach_volume(container_name, volume_name):
    """Send a request to the proxy to detach a volume from a container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }

        payload = {
            "container_name": container_name,
            "volume_name": volume_name
        }

        url = f"{proxy_url}/detach-volume"
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()

        click.echo(response.json())
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="view-volume", help="View details of a Docker volume.")
@click.option('--volume-name', required=True, help="Name of the volume to inspect.")
def view_volume(volume_name):
    """Fetch and display information for a specific Docker volume."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        
        url = f"{proxy_url}/view-volume"
        params = {"volume_name": volume_name}

        # Make the request to the proxy
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()

        # Pretty-print the volume information
        volume_info = response.json().get("volume_info", {})
        click.echo(json.dumps(volume_info, indent=4))

    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")



@dobp.command(name="proxy-request", help="Send a request through the load balancer.")
@click.option('--container-name', required=True, help="Name of the container for load balancing.")
@click.option('--path', default="/", help="Path to forward the request to.")
@click.option('--method', default="GET", type=click.Choice(["GET", "POST"]), help="HTTP method for the request.")
@click.option('--data', default=None, help="Optional JSON data to include in POST requests.")
def proxy_request(container_name, path, method, data):
    """Send a proxied request to a load-balanced container."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']
        
        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/proxy-request"

        payload = {
            "container_name": container_name,
            "path": path
        }

        # Send the request through the proxy
        if method == "POST" and data:
            response = requests.post(url, json=payload, headers=headers, data=data)
        else:
            response = requests.get(url, json=payload, headers=headers)
        
        response.raise_for_status()
        click.echo(response.json())
        
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="register-service", help="Register a container under a service for internal routing.")
@click.option('--service-name', required=True, help="Name of the service to register.")
@click.option('--container-name', required=True, help="Name of the container to register.")
@click.option('--ip', required=True, help="IP address of the container.")
@click.option('--port', required=True, type=int, help="Port of the container.")
def register_service(service_name, container_name, ip, port):
    """Register a container under a service for service discovery."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/register-service"

        payload = {
            "service_name": service_name,
            "container_info": {
                "name": container_name,
                "ip": ip,
                "port": port
            }
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Service registration response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="resolve-service", help="Resolve a service name to a container endpoint.")
@click.option('--service-name', required=True, help="Name of the service to resolve.")
def resolve_service(service_name):
    """Resolve a service name to a container endpoint."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}"
        }
        url = f"{proxy_url}/resolve-service"

        params = {"service_name": service_name}
        response = requests.get(url, params=params, headers=headers)
        response.raise_for_status()

        container_info = response.json().get("container")
        click.echo(f"Resolved endpoint for service '{service_name}': {container_info}")

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="proxy-to-service", help="Proxy a request to a specified service.")
@click.option('--service-name', required=True, help="Name of the service to proxy to.")
@click.option('--path', default="/", help="Path to request on the target service.")
@click.option('--method', default="GET", help="HTTP method (GET or POST) to use.")
@click.option('--data', type=str, help="Optional data payload for POST requests.")
def proxy_to_service(service_name, path, method, data):
    """Proxy a request to a specific service."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/proxy-to-service"

        payload = {
            "service_name": service_name,
            "path": path,
            "method": method,
            "data": json.loads(data) if data else {}
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Service proxy request response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")
    except json.JSONDecodeError:
        click.echo("Invalid JSON format in data payload.")

@dobp.command(name="deploy-and-register", help="Deploy and register multiple containers for a service.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--service-name', required=False, help="Name of the service.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--count', required=False, type=int, help="Number of container instances to deploy.")
def deploy_and_register(config_file, service_name, image, container_port, count):
    """Deploy and register containers for a service."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/deploy-and-register"

        # Load config from YAML if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            service_name = config.get("service_name", service_name)
            image = config.get("image", image)
            container_port = config.get("container_port", container_port)
            count = config.get("count", count)

        if not all([service_name, image, container_port]):
            click.echo("Missing required deployment parameters.")
            return

        payload = {
            "service_name": service_name,
            "image": image,
            "container_port": container_port,
            "count": count
        }

        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Deploy and register response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="update-config", help="Update proxy configuration.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
def update_config(config_file):
    """Update the proxy configuration with a YAML file."""
    if not config_file:
        click.echo("Configuration file is required.")
        return

    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        with open(config_file, 'r') as file:
            config_data = yaml.safe_load(file)

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/config"

        response = requests.post(url, json=config_data, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Configuration updated."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="create-vpc", help="Create a new VPC.")
@click.option('--vpc-name', required=True, help="Name of the VPC.")
def create_vpc(vpc_name):
    """Create a new VPC through the proxy."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/create-vpc"

        payload = {"vpc_name": vpc_name}
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "VPC creation response received."))
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="create-subnet", help="Create a new subnet in a VPC.")
@click.option('--vpc-name', required=True, help="Name of the VPC.")
@click.option('--subnet-name', required=True, help="Name of the subnet.")
@click.option('--cidr-block', required=True, help="CIDR block for the subnet.")
@click.option('--subnet-type', required=True, type=click.Choice(['public', 'private']), help="Type of subnet (public or private).")
def create_subnet(vpc_name, subnet_name, cidr_block, subnet_type):
    """Create a new subnet in a specified VPC."""
    try:
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/create-subnet"

        payload = {
            "vpc_name": vpc_name,
            "subnet_name": subnet_name,
            "cidr_block": cidr_block,
            "subnet_type": subnet_type
        }
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Subnet creation response received."))
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="create-router", help="Create a router container for a specified VPC.")
@click.option('--vpc-name', required=True, help="Name of the VPC to associate the router with.")
@click.option('--router-name', help="Name of the router to be created.")
@click.option('--public-subnet', required=True, help="Name of the public subnet to connect the router to.")
@click.option('--private-subnet', required=True, help="Name of the private subnet to connect the router to.")
def create_router(vpc_name, router_name, public_subnet, private_subnet):
    """Create a router container through the proxy with the specified VPC and subnets."""
    try:
        # Load proxy credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/create-router"

        # Use default router name if not provided
        if not router_name:
            router_name = f"{vpc_name}_router"

        # Prepare the payload
        payload = {
            "vpc_name": vpc_name,
            "router_name": router_name,
            "public_subnet": public_subnet,
            "private_subnet": private_subnet
        }

        # Send the request to the proxy
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Router creation response received."))

    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="fetch-metrics", help="Fetch system metrics from DevOps Bot Proxy.")
def fetch_metrics():
    """Fetch system metrics through the proxy."""
    try:
        # Load proxy credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/metrics"

        # Make a GET request to the `/metrics` endpoint
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        # Display metrics
        metrics = response.json()
        for key, value in metrics.items():
            click.echo(f"{key}: {value}")

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="create-route-table", help="Create a route table for a specified VPC.")
@click.option('--vpc-name', required=True, help="Name of the VPC to associate the route table with.")
@click.option('--route-table-name', required=True, help="Name of the route table to be created.")
@click.option('--routes', required=False, help="JSON string defining the routes.")
def create_route_table(vpc_name, route_table_name, routes):
    """Create a route table for the specified VPC."""
    try:
        # Load proxy credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/create-route-table"

        # Prepare the payload
        payload = {
            "vpc_name": vpc_name,
            "route_table_name": route_table_name,
            "routes": json.loads(routes) if routes else []
        }

        # Send the request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Route Table creation response received."))

    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

@dobp.command(name="add-route", help="Add a route to a specified route table in a VPC.")
@click.option('--vpc-name', required=True, help="Name of the VPC containing the route table.")
@click.option('--route-table-name', required=True, help="Name of the route table to update.")
@click.option('--destination-cidr', required=True, help="CIDR block for the destination.")
@click.option('--target', required=True, help="Target for the route (e.g., a router name).")
def add_route(vpc_name, route_table_name, destination_cidr, target):
    """Add a route to a specified route table through the proxy."""
    try:
        # Load proxy credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/add-route"

        # Payload for the request
        payload = {
            "vpc_name": vpc_name,
            "route_table_name": route_table_name,
            "destination_cidr": destination_cidr,
            "target": target
        }

        # Send the request
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Route added successfully."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")


@dobp.command(name="deploy-private", help="Deploy a private container via DevOps Bot Proxy.")
@click.option('--config-file', type=click.Path(exists=True), help="Path to a YAML configuration file.")
@click.option('--container-name', required=False, help="Name of the container.")
@click.option('--image', required=False, help="Docker image to deploy.")
@click.option('--container-port', required=False, type=int, help="Container port.")
@click.option('--count', default=1, type=int, help="Number of container instances to deploy.")
def deploy_private(config_file, container_name, image, container_port, count):
    """Deploy a private container through the proxy with options or YAML config."""
    try:
        # Load proxy credentials
        credentials = load_proxy_credentials()
        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/deploy-private"

        # Load configuration from a YAML file if provided
        if config_file:
            with open(config_file, 'r') as file:
                config = yaml.safe_load(file)
            container_name = config.get("container_name", container_name)
            image = config.get("image", image)
            container_port = config.get("container_port", container_port)
            count = config.get("count", count)

        # Validate required parameters
        if not all([container_name, image, container_port]):
            click.echo("Missing required deployment parameters.")
            return

        # Prepare the payload to send to the proxy
        payload = {
            "container_name": container_name,
            "image": image,
            "container_port": container_port,
            "count": count
        }

        # Send the request to the proxy's `deploy-private` function
        response = requests.post(url, json=payload, headers=headers)
        response.raise_for_status()
        click.echo(response.json().get("message", "Private deployment response received."))

    except FileNotFoundError:
        click.echo("Proxy credentials not found. Please configure the proxy first.")
    except requests.exceptions.RequestException as e:
        click.echo(f"Failed to connect to DevOps Bot Proxy: {e}")

#########################################################################################################################

@cli.command(name="generate-token", help="Generate a token for a user.")
@click.option('--username', prompt=True, help="The username for which to generate a token.")
def generate_token(username):
    # Replace with real logic to generate a secure token
    token = secrets.token_hex(16)  # Generate a secure token
    save_token(username, token)    # Save the token for future use
    print(f"Generated token: {token}")


def save_token(username, token):
    """
    Save a token for a specific user to a file in the USER_DATA_DIR.

    Args:
        username (str): The username associated with the token.
        token (str): The token to save.
    """
    # Ensure the users_data directory exists
    os.makedirs(USER_DATA_DIR, exist_ok=True)

    # Construct the file path dynamically
    user_token_file = os.path.join(USER_DATA_DIR, f"{username}_token.txt")

    # Write the token to the file
    with open(user_token_file, 'w') as file:
        file.write(token)

    print(f"Token saved for user '{username}' at {user_token_file}")



@cli.command(name="encrypt", help="Encrypt a sensitive value with salt and output the encrypted result.")
@click.argument('plain_text', required=True, type=str)
@click.option('--password', '-p', required=True, help="Password to use for encrypting the value.")
@click.option('--output-file', '-o', type=click.Path(), help="Optional output file to save the encrypted value.")
def encrypt_command(plain_text, password, output_file):
    """
    Encrypt the provided plain text using the password and display or save the result.

    Args:
    - plain_text (str): The plain text value to encrypt.
    - password (str): The password used to derive the encryption key.
    - output_file (str): Optional file path to save the encrypted result.
    """
    encrypted_value = encrypt_variable_with_password(plain_text, password)

    if output_file:
        with open(output_file, 'w') as file:
            file.write(encrypted_value)
        print(f"Encrypted value saved to {output_file}")
    else:
        print(f"Encrypted Value: {encrypted_value}")


@cli.command(name="decrypt", help="Decrypt an encrypted value with salt and output the plain text result.")
@click.argument('encrypted_text', required=True, type=str)
@click.option('--password', '-p', required=True, help="Password to use for decrypting the value.")
@click.option('--output-file', '-o', type=click.Path(), help="Optional output file to save the decrypted value.")
def decrypt_command(encrypted_text, password, output_file):
    """
    Decrypt the provided encrypted text using the password and display or save the result.

    Args:
    - encrypted_text (str): The encrypted value to decrypt.
    - password (str): The password used to derive the decryption key.
    - output_file (str): Optional file path to save the decrypted result.
    """
    # Check if decryption is locked due to multiple failed attempts
    is_locked, lock_message = check_lock_status()
    if is_locked:
        print(lock_message)
        return

    # Attempt to decrypt the value
    try:
        decrypted_value = decrypt_variable_with_password(encrypted_text, password)
    except ValueError as e:
        print("Incorrect password. Please try again.")

        # Update failed attempt count and check if the lock should be applied
        if update_failed_attempt():
            print("You have exceeded the maximum number of attempts. Decryption is locked for 30 minutes.")

        return

    # Reset attempts if successful
    reset_attempts()

    if output_file:
        with open(output_file, 'w') as file:
            file.write(decrypted_value)
        print(f"Decrypted value saved to {output_file}")
    else:
        print(f"Decrypted Value: {decrypted_value}")


@cli.command(name='list-executions', help="List all stored execution IDs or details of a specific execution")
@click.argument('execution_id', required=False)
@click.option('--state', is_flag=True, help="Print the state details of the specified execution ID.")
def list_executions(execution_id=None, state=False):
    """
    List all saved executions or print details of a specific execution based on ID.
    """
    if not os.path.exists(STATE_DIR):
        click.echo("No executions found.")
        return

    state_files = [f for f in os.listdir(STATE_DIR) if f.endswith('.yaml') or f.endswith('.yml')]

    if not state_files:
        click.echo("No executions found.")
        return

    if execution_id:
        # Generate paths for YAML and state files
        state_file_path = os.path.join(STATE_DIR, f'{execution_id}.yaml')
        state_execution_path = os.path.join(STATE_DIR, f'{execution_id}.yml')

        if not os.path.exists(state_file_path) and not os.path.exists(state_execution_path):
            click.echo(f"Execution ID {execution_id} not found.")
            return

        # Print state details if --state is provided
        if state:
            if os.path.exists(state_file_path):
                with open(state_file_path, 'r') as f:
                    state_data = yaml.safe_load(f)
                click.echo(f"State details for Execution ID {execution_id}:")
                click.echo(yaml.dump(state_data, default_flow_style=False))
            else:
                click.echo(f"State file for Execution ID {execution_id} not found.")
            return

        # Print execution details if --state is not provided
        if os.path.exists(state_execution_path):
            with open(state_execution_path, 'r') as f:
                execution_data = yaml.safe_load(f)
            click.echo(f"Execution details for Execution ID {execution_id}:")
            click.echo(yaml.dump(execution_data, default_flow_style=False))
        else:
            click.echo(f"Execution file for Execution ID {execution_id} not found.")
    else:
        # List all execution IDs if no specific ID is provided
        click.echo("Execution IDs:")
        for state_file in state_files:
            execution_id = state_file.split('.')[0]
            click.echo(execution_id)


@cli.command(name='edit-execution', help="Edit an entire execution state")
@click.argument('execution_id', required=True)
def edit_execution(execution_id):
    """Load and edit a specific execution state."""
    state_exicution_path = os.path.join(STATE_DIR, f'{execution_id}.yml')

    if not os.path.exists(state_exicution_path):
        click.echo(click.style(f"State file not found for Execution ID: {execution_id}", fg="red"))
        return

    with open(state_exicution_path, 'r') as state_file:
        state_data = yaml.safe_load(state_file)

    # Display the state for editing
    click.echo(click.style(f"Loaded state for Execution ID: {execution_id}", fg="green"))
    click.echo("Here is the current state (you can edit it):")
    click.echo(yaml.dump(state_data, default_flow_style=False))

    # Prompt user for editing
    if click.confirm(click.style("Do you want to edit this state?", fg="yellow"), default=True):
        # We could allow editing directly in the terminal, or ask for a file to edit in an external editor
        updated_state = click.edit(yaml.dump(state_data))

        if updated_state:
            updated_data = yaml.safe_load(updated_state)

            # Save changes
            with open(state_exicution_path, 'w') as state_file:
                yaml.dump(updated_data, state_file)

            click.echo(click.style(f"State updated for Execution ID: {execution_id}", fg="green"))


@cli.command(name='re-execute', help="Re-execute a modified execution state")
@click.argument('execution_id', required=True)
@click.option('-y', '--yes', is_flag=True, help="Automatic yes to prompts")
def re_execute(execution_id, yes):
    """Re-execute a specific execution after editing."""
    state_execution_path = os.path.join(STATE_DIR, f'{execution_id}.yml')
    if not os.path.exists(state_execution_path):
        click.echo(click.style(f"State file not found for Execution ID: {execution_id}", fg="red"))
        return

    # Load the edited state data
    with open(state_execution_path, 'r') as state_file:
        data = yaml.safe_load(state_file)

    click.echo(click.style(f"Re-executing actions based on the edited state (Execution ID: {execution_id})", fg="blue"))

    # List of all known resource task names to check in state file
    resource_task_names = [
        'vpc_creation', 'subnet_creation', 'internet_gateway', 'nat_gateway',
        'route_table', 'security_group', 'elastic_ip', 'ec2_instance',
        'load_balancer', 'target_group', 'listener', 'target_registration',
        's3_bucket', 'network_interface', 'eks_cluster', 'eks_nodegroup', 'rds_instance'
    ]

    # Track whether re-execution occurred
    re_execution_needed = False

    # Iterate through each defined task name in the list and re-execute if necessary
    for task_name in resource_task_names:
        task_completed, resource_id, status = is_task_completed(execution_id, task_name)

        # Skip tasks that have already been completed successfully
        if status == 'success':
            click.echo(f"Task '{task_name}' is already completed successfully. Skipping...")
            continue

        # Re-execute tasks that have failed or were not found
        elif status in ['failed', 'not_found']:
            click.echo(f"Task '{task_name}' will be re-executed as its status is '{status}'.")

            # Use the existing context to invoke the screenplay function for the specific task
            ctx = click.get_current_context()
            ctx.invoke(screenplay, screenplay=state_execution_path, identifier=None, username=None, command=None, create_remote=False, add_remote=False, reuse_id=execution_id, yes=True)

            re_execution_needed = True
            break  # Exit loop and re-invoke screenplay to ensure proper execution flow

    if not re_execution_needed:
        click.echo(click.style(f"All tasks are already completed successfully for Execution ID: {execution_id}.", fg="green"))
    else:
        click.echo(click.style(f"Re-execution completed successfully for Execution ID: {execution_id}.", fg="green"))
#############################################################################################
@aws.command(name='transfer-file', help="Transfer a file from host to a remote instance")
@click.argument('source_file', required=True, type=click.Path(exists=True))
@click.argument('dest_path', required=True)
@click.option('--identifier', '-id', required=False, help="Instance identifier (short: -id)")
@click.option('--category', '-c', required=False, help="Category for remote instances (e.g., dev, prod)")
@click.option('--username', '-u', required=False, help="Username for SSH connection")
@click.option('--scp-options', '-o', default="", help="Extra SCP options if needed (e.g., -P 2222 for port)")
@click.pass_context
def transfer_file(ctx, source_file, dest_path, identifier, category, username, scp_options):
    """
    Transfer a file from the host instance to the remote instance.
    """
    try:
        # Check if identifier is provided
        if not identifier:
            click.echo(click.style("Error: Instance identifier is required.", fg="red"))
            return

        # Determine the target identifiers based on category and task
        if identifier.lower() == 'all':
            if category:
                target_identifiers = get_all_identifiers_in_category(category)
            else:
                target_identifiers = [server.get('identifiers') for server in ctx.obj.get('remote-server')]
        else:
            try:
                if category:
                    target_identifiers = [get_host_entry(identifier, category)[1]]
                else:
                    target_identifiers = [get_host_entry(identifier)[1]]
            except ValueError as e:
                click.echo(click.style(f"Error: {e}", fg="red"))
                return

        # Transfer file to each remote instance
        for remote_identifier in target_identifiers:
            task_user = username
            if not task_user:
                for server in ctx.obj.get('remote-server'):
                    if server.get('identifiers') == remote_identifier:
                        task_user = server.get('username')
                        break

            if not task_user:
                task_user = "root"  # Default to root if no username is provided

            # Build the SCP command
            scp_command = f"scp {scp_options} {source_file} {task_user}@{remote_identifier}:{dest_path}"

            # Execute the SCP command
            click.echo(click.style(f"Transferring {source_file} to {task_user}@{remote_identifier}:{dest_path}", fg="green"))
            result = subprocess.run(scp_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

            if result.returncode == 0:
                click.echo(click.style(f"File transferred successfully to {remote_identifier}", fg="green"))
            else:
                click.echo(click.style(f"Error transferring file to {remote_identifier}: {result.stderr.decode('utf-8')}", fg="red"))

    except Exception as e:
        click.echo(click.style(f"Error: {e}", fg="red"))

#####################################################################################
def generate_build_key():
    """Generate and save an encryption key."""
    try:
        if os.path.exists(KEY_FILE_PATH):
            logger.warning(f"Key file already exists at '{KEY_FILE_PATH}'. No new key generated.")
           # print(f"Key file already exists at '{KEY_FILE_PATH}'. No new key generated.")
            return

        # Generate the encryption key
        key = Fernet.generate_key()

        # Save the key to the specified file
        with open(KEY_FILE_PATH, "wb") as key_file:
            key_file.write(key)
        
        logger.info(f"Encryption key generated and saved to '{KEY_FILE_PATH}'.")
       # print(f"Encryption key generated and saved to '{KEY_FILE_PATH}'.")
    except PermissionError as e:
        logger.error(f"Permission denied: {e}")
       # print(f"Error: Permission denied when trying to write to '{KEY_FILE_PATH}'.")
    except Exception as e:
        logger.error(f"An unexpected error occurred: {e}")
       # print(f"Error: An unexpected error occurred: {e}")

# Run the function
generate_build_key()
# Command to save and encrypt credentials

@aws.command(name="save-build-credential", help="Save and encrypt credentials for various tools with build-specific settings")
@click.option('-n', '--credential_name', required=True, help="Unique name for the credential")
@click.option('--tool', required=True, type=click.Choice(['s3', 'github', 'docker'], case_sensitive=False), help="Tool type (e.g., s3, github, docker)")
@click.option('-u', '--username', default=None, help="Username for the service (e.g., GitHub username)")
@click.option('-p', '--password', default=None, help="Password for the service (e.g., GitHub password)")
@click.option('-t', '--token', default=None, help="Optional token for the service (e.g., GitHub token)")
@click.option('--aws-access-key', default=None, help="AWS access key for S3")
@click.option('--aws-secret-key', default=None, help="AWS secret key for S3")
def save_build_credential(credential_name, tool, username, password, token, aws_access_key, aws_secret_key):
    key = load_build_key()
    cipher = Fernet(key)

    # Encrypt credentials if provided
    encrypted_credentials = {}
    if username and password:
        encrypted_credentials['username'] = cipher.encrypt(username.encode()).decode()
        encrypted_credentials['password'] = cipher.encrypt(password.encode()).decode()
    if token:
        encrypted_credentials['token'] = cipher.encrypt(token.encode()).decode()
    if aws_access_key and aws_secret_key:
        encrypted_credentials['aws_access_key'] = cipher.encrypt(aws_access_key.encode()).decode()
        encrypted_credentials['aws_secret_key'] = cipher.encrypt(aws_secret_key.encode()).decode()

    # Initialize or parse the XML file
    if os.path.exists(BUILD_FILE):
        try:
            tree = ET.parse(BUILD_FILE)
            root = tree.getroot()
        except ET.ParseError:
            root = ET.Element("Credentials")
    else:
        root = ET.Element("Credentials")

    # Remove existing credential with the same name and tool to avoid duplicates
    for elem in root.findall(f"./Credential[@name='{credential_name}'][@tool='{tool}']"):
        root.remove(elem)

    # Create a new credential entry with the tool as an attribute
    cred_elem = ET.SubElement(root, "Credential", name=credential_name, tool=tool)
    for key, value in encrypted_credentials.items():
        ET.SubElement(cred_elem, key).text = value

    # Pretty print and save the XML file
    xml_str = minidom.parseString(ET.tostring(root)).toprettyxml(indent="  ")
    with open(BUILD_FILE, "w") as f:
        f.write(xml_str)

    click.echo(f"Build credential '{credential_name}' for tool '{tool}' saved and encrypted successfully.")

def load_build_key():
    with open("encryption.key", "rb") as key_file:
        return key_file.read()

# Load credentials based on tool-specific credential name and tool type
def load_build_credential(credential_name, tool):
    if not os.path.exists(BUILD_FILE):
        raise FileNotFoundError(f"Credential file '{BUILD_FILE}' not found.")
    
    tree = ET.parse(BUILD_FILE)
    root = tree.getroot()

    credential_data = {}
    for cred in root.findall(f"./Credential[@name='{credential_name}'][@tool='{tool}']"):
        for child in cred:
            credential_data[child.tag] = child.text
    return credential_data if credential_data else None


@aws.command(name="subnet", help="Create a subnet within an existing VPC.")
@click.option('-r', '--region', required=True, help="The AWS region where the subnet will be created.")
@click.option('-v', '--vpc-id', required=True, help="The ID of the VPC where the subnet will be created.")
@click.option('-c', '--cidr-block', required=True, help="The CIDR block for the subnet.")
@click.option('-a', '--availability-zone', required=True, help="The Availability Zone for the subnet.")
@click.option('-t', '--tags', multiple=True, help="Tags to assign to the subnet (format: Key=Name,Value=MySubnet).")
def create_subnet_command(region, vpc_id, cidr_block, availability_zone, tags):
    credentials = load_aws_credentials()  # Load AWS credentials
    
    # Initialize the boto3 client using the region and credentials
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    
    # Convert tags from format Key=Name,Value=MySubnet to [{'Key': 'Name', 'Value': 'MySubnet'}]
    formatted_tags = [{'Key': tag.split('=')[0], 'Value': tag.split('=')[1]} for tag in tags]
    
    subnet_id = create_subnet_direct(vpc_id, cidr_block, availability_zone, formatted_tags, ec2)
    click.echo(f"Subnet created with ID: {subnet_id}")

def create_subnet_direct(vpc_id, cidr_block, availability_zone, tags, ec2):
    response = ec2.create_subnet(
        VpcId=vpc_id,
        CidrBlock=cidr_block,
        AvailabilityZone=availability_zone
    )
    subnet_id = response['Subnet']['SubnetId']
    ec2.create_tags(Resources=[subnet_id], Tags=tags)
    return subnet_id


@aws.command(name="target-group", help="Create a Target Group")
@click.option('-r', '--region', required=True, help="AWS region")
@click.option('-n', '--name', required=True, help="Name of the Target Group")
@click.option('-v', '--vpc-id', required=True, help="VPC ID for the Target Group")
@click.option('-p', '--protocol', default='HTTP', help="Protocol for the Target Group")
@click.option('--port', default=80, type=int, help="Port for the Target Group")
@click.option('--target-type', default='instance', help="Type of targets (instance, ip, or lambda)")
@click.option('--health-check-protocol', default=None, help="Protocol for health check (default: same as protocol)")
@click.option('--health-check-port', default=None, help="Port for health check (default: same as port)")
@click.option('-t', '--tags', multiple=True, help="Tags for the Target Group in the format Key=Value")
def create_target_group_command(region, name, vpc_id, protocol, port, target_type, health_check_protocol, health_check_port, tags):
    credentials = load_aws_credentials()
    elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    create_target_group(elb_client, name, vpc_id, protocol, port, target_type, health_check_protocol, health_check_port, tags)

def create_target_group_comand(elb_client, name, vpc_id, protocol='HTTP', port=80, target_type='instance', health_check_protocol='HTTP', health_check_port=None, tags=[]):
    if health_check_port is None:
        health_check_port = port

    response = elb_client.create_target_group(
        Name=name,
        Protocol=protocol,
        Port=port,
        VpcId=vpc_id,
        TargetType=target_type,
        HealthCheckProtocol=health_check_protocol,
        HealthCheckPort=str(health_check_port),
        Tags=tags
    )

    target_group_arn = response['TargetGroups'][0]['TargetGroupArn']
    click.echo(f"Target Group created with ARN: {target_group_arn}")
    return target_group_arn

@aws.command(name="create-listener", help="Create a Listener for a Load Balancer")
@click.option('-r', '--region', required=True, help="AWS region")
@click.option('-l', '--load-balancer-arn', required=True, help="ARN of the Load Balancer")
@click.option('-p', '--protocol', required=True, help="Protocol for the Listener (HTTP, HTTPS, TCP, TLS, UDP, TCP_UDP)")
@click.option('--port', required=True, type=int, help="Port for the Listener")
@click.option('-t', '--target-group-arn', help="ARN of the Target Group (required for forward action)")
@click.option('--ssl-certificate-arn', help="ARN of the SSL certificate (required for HTTPS or TLS listeners)")
@click.option('-a', '--action-type', default='forward', help="Action type for the Listener (e.g., forward, redirect, authenticate-oidc, authenticate-cognito)")
def create_listener_command(region, load_balancer_arn, protocol, port, target_group_arn, ssl_certificate_arn, action_type):
    credentials = load_aws_credentials()
    elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    create_listener(elb_client, load_balancer_arn, protocol, port, target_group_arn, ssl_certificate_arn, action_type)

def create_listener_comand(elb_client, load_balancer_arn, protocol, port, target_group_arn=None, ssl_certificate_arn=None, action_type='forward'):
    try:
        actions = []
        if action_type == 'forward':
            if not target_group_arn:
                raise ValueError("Target Group ARN is required for 'forward' action type.")
            actions.append({
                'Type': 'forward',
                'TargetGroupArn': target_group_arn
            })
        elif action_type == 'redirect':
            actions.append({
                'Type': 'redirect',
                'RedirectConfig': {
                    # Fill with required redirect config parameters
                }
            })
        # Add more action types if needed

        listener_params = {
            'LoadBalancerArn': load_balancer_arn,
            'Protocol': protocol,
            'Port': int(port),
            'DefaultActions': actions
        }

        if protocol in ['HTTPS', 'TLS']:
            if not ssl_certificate_arn:
                raise ValueError("SSL Certificate ARN is required for HTTPS or TLS listeners.")
            listener_params['Certificates'] = [{'CertificateArn': ssl_certificate_arn}]

        listener_response = elb_client.create_listener(**listener_params)
        listener_arn = listener_response['Listeners'][0]['ListenerArn']
        click.echo(f"Listener created with ARN: {listener_arn}")
        return listener_arn
    except ClientError as e:
        click.echo(f"Failed to create listener: {e}")
        return None


@aws.command(name="register-targets", help="Register Targets to a Target Group")
@click.option('-r', '--region', required=True, help="AWS region")
@click.option('-t', '--target-group-arn', required=True, help="ARN of the Target Group")
@click.option('--targets', multiple=True, required=True, help="IDs of the targets (e.g., EC2 instance IDs)")
def register_targets_command(region, target_group_arn, targets):
    credentials = load_aws_credentials()
    ec2 = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})
    register_targets(ec2, target_group_arn, targets)

def register_targets_comand(ec2, target_group_arn, targets):
    try:
        response = ec2.register_targets(
            TargetGroupArn=target_group_arn,
            Targets=[{'Id': target} for target in targets]
        )
        click.echo(f"Targets registered to Target Group: {target_group_arn}")
        return response
    except ClientError as e:
        click.echo(f"Failed to register targets: {e}")
        return None

@aws.command(name="create-load-balancer", help="Create a Load Balancer.")
@click.option('-r', '--region', required=True, help="AWS region where the Load Balancer will be created.")
@click.option('-n', '--name', required=True, help="Name of the Load Balancer.")
@click.option('-s', '--subnets', multiple=True, required=True, help="Subnets for the Load Balancer.")
@click.option('-sg', '--security-groups', multiple=True, required=True, help="Security groups for the Load Balancer.")
@click.option('--scheme', default='internet-facing', type=click.Choice(['internet-facing', 'internal']), help="Scheme of the Load Balancer.")
@click.option('-t', '--tags', multiple=True, help="Tags for the Load Balancer in the format Key=Value.")
def create_load_balancer_command(region, name, subnets, security_groups, scheme, tags):
    credentials = load_aws_credentials()

    # Initialize the boto3 client for ELB using the region and credentials
    elb_client = boto3.client('elbv2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    # Create Load Balancer
    try:
        response = elb_client.create_load_balancer(
            Name=name,
            Subnets=subnets,
            SecurityGroups=security_groups,
            Scheme=scheme,
            Tags=[{'Key': k, 'Value': v} for tag in tags for k, v in [tag.split('=')]],
            Type='application'
        )

        load_balancer_arn = response['LoadBalancers'][0]['LoadBalancerArn']
        click.echo(f"Load Balancer created with ARN: {load_balancer_arn}")
    except ClientError as e:
        click.echo(f"Failed to create Load Balancer: {e}")


@aws.command(name="create-sg", help="Create a Security Group")
@click.option('-r', '--region', required=True, help="The AWS region where the Security Group will be created.")
@click.option('-v', '--vpc-id', required=True, help="VPC ID where the Security Group will be created.")
@click.option('-g', '--group-name', required=True, help="Name of the Security Group.")
@click.option('-d', '--description', required=True, help="Description of the Security Group.")
@click.option('--inbound-rules', multiple=True, help="Inbound rules in the format protocol:port_range:cidr_blocks (e.g., tcp:22-22:0.0.0.0/0).")
@click.option('-t', '--tags', type=str, multiple=True, help="Tags for the Security Group in the format Key=Value.")
@click.pass_context
def create_security_group_command(ctx, region, vpc_id, group_name, description, inbound_rules, tags):
    credentials = load_aws_credentials()  # Load AWS credentials

    # Initialize the boto3 client for EC2
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    # Create the Security Group
    try:
        click.echo(f"Creating Security Group '{group_name}' in VPC {vpc_id}...")
        response = ec2.create_security_group(
            VpcId=vpc_id,
            GroupName=group_name,
            Description=description
        )
        sg_id = response['GroupId']
        click.echo(f"Security Group created with ID: {sg_id}")
    except ClientError as e:
        click.echo(f"Failed to create Security Group: {e}", err=True)
        return

    # Add Inbound Rules
    if inbound_rules:
        ip_permissions = []
        for rule in inbound_rules:
            protocol, port_range, cidr_blocks = rule.split(':')
            from_port, to_port = map(int, port_range.split('-'))
            ip_permissions.append({
                'IpProtocol': protocol,
                'FromPort': from_port,
                'ToPort': to_port,
                'IpRanges': [{'CidrIp': cidr_blocks}]
            })

        try:
            ec2.authorize_security_group_ingress(
                GroupId=sg_id,
                IpPermissions=ip_permissions
            )
            click.echo(f"Inbound rules added to Security Group {sg_id}")
        except ClientError as e:
            click.echo(f"Failed to add inbound rules to Security Group: {e}", err=True)
            return

    # Add Tags to the Security Group
    if tags:
        tag_dict = {tag.split('=')[0]: tag.split('=')[1] for tag in tags}
        ec2.create_tags(Resources=[sg_id], Tags=[{'Key': k, 'Value': v} for k, v in tag_dict.items()])
        click.echo(f"Tags applied to Security Group: {tag_dict}")

    return sg_id

@aws.command(name="internet_gateway", help="Create an Internet Gateway and attach it to a VPC.")
@click.option('-r', '--region', required=True, help="AWS region")
@click.option('-v', '--vpc-id', required=True, help="VPC ID where the Internet Gateway will be attached")
@click.option('-t', '--tags', multiple=True, type=str, help="Tags to apply to the Internet Gateway (e.g., --tags Key=Name,Value=MyIGW)")
def create_internet_gateway_command(region, vpc_id, tags):
    # Load AWS credentials
    credentials = load_aws_credentials()

    # Initialize the boto3 client using the region and credentials
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    igw_id = create_internet_gateway_direct(vpc_id, tags, ec2)
    click.echo(f"Internet Gateway created with ID: {igw_id}")


def create_internet_gateway_direct(vpc_id, tags, ec2):
    # Create the Internet Gateway
    response = ec2.create_internet_gateway()
    igw_id = response['InternetGateway']['InternetGatewayId']

    # Attach the Internet Gateway to the VPC
    ec2.attach_internet_gateway(InternetGatewayId=igw_id, VpcId=vpc_id)

    # Process tags if any
    formatted_tags = []
    if tags:
        for tag in tags:
            key, value = tag.split(',')
            formatted_tags.append({'Key': key.split('=')[1], 'Value': value.split('=')[1]})
        ec2.create_tags(Resources=[igw_id], Tags=formatted_tags)

    return igw_id

@aws.command(name="create-elastic-ip", help="Create an Elastic IP and optionally associate it with an instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the Elastic IP will be created.")
@click.option('-d', '--domain', required=False, default='vpc', help="The domain type. For VPC, specify 'vpc'. Default is 'vpc'.")
@click.option('-i', '--instance-id', required=False, help="The instance ID to associate with the Elastic IP.")
@click.option('-t', '--tags', type=str, multiple=True, help="Tags for the Elastic IP in the format Key=Value.")
@click.pass_context
def create_elastic_ip_command(ctx, region, domain, instance_id, tags):
    credentials = load_aws_credentials()  # Load AWS credentials

    # Initialize the boto3 client for EC2
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    # Create the Elastic IP
    try:
        click.echo(f"Creating Elastic IP in region: {region}...")
        response = ec2.allocate_address(Domain=domain)
        allocation_id = response['AllocationId']
        public_ip = response['PublicIp']
        click.echo(f"Elastic IP created with Allocation ID: {allocation_id} and Public IP: {public_ip}")
    except ClientError as e:
        click.echo(f"Failed to create Elastic IP: {e}", err=True)
        return

    # Create tags for the Elastic IP if provided
    if tags:
        tag_dict = {tag.split('=')[0]: tag.split('=')[1] for tag in tags}
        ec2.create_tags(Resources=[allocation_id], Tags=[{'Key': k, 'Value': v} for k, v in tag_dict.items()])
        click.echo(f"Tags applied to Elastic IP: {tag_dict}")

    # Associate the Elastic IP with an instance if instance_id is provided
    if instance_id:
        try:
            click.echo(f"Associating Elastic IP {public_ip} with instance {instance_id}...")
            ec2.associate_address(InstanceId=instance_id, AllocationId=allocation_id)
            click.echo(f"Elastic IP {public_ip} associated with instance {instance_id}.")
        except ClientError as e:
            click.echo(f"Failed to associate Elastic IP with instance {instance_id}: {e}", err=True)

@aws.command(name="create-route-table", help="Create a Route Table and add routes to it.")
@click.option('-v', '--vpc-id', required=True, help="VPC ID where the Route Table will be created.")
@click.option('-r', '--region', required=True, help="The AWS region where the Route Table will be created.")
@click.option('-t', '--tags', type=str, multiple=True, help="Tags for the route table in the format Key=Value.")
@click.option('-R', '--routes', type=(str, str), multiple=True, help="Routes to add to the table in the format DESTINATION_CIDR_BLOCK GATEWAY_ID.")
@click.pass_context
def create_route_table_command(ctx, vpc_id, region, tags, routes):
    credentials = load_aws_credentials()  # Load AWS credentials

    # Initialize the boto3 client for EC2
    ec2 = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    # Create the route table
    try:
        click.echo(f"Creating Route Table in VPC: {vpc_id} in region: {region}...")
        response = ec2.create_route_table(VpcId=vpc_id)
        route_table_id = response['RouteTable']['RouteTableId']
        click.echo(f"Route Table created with ID: {route_table_id}")
    except ClientError as e:
        click.echo(f"Failed to create Route Table: {e}", err=True)
        return

    # Create tags for the route table if provided
    if tags:
        tag_dict = {tag.split('=')[0]: tag.split('=')[1] for tag in tags}
        ec2.create_tags(Resources=[route_table_id], Tags=[{'Key': k, 'Value': v} for k, v in tag_dict.items()])
        click.echo(f"Tags applied to Route Table: {tag_dict}")

    # Add routes to the route table if provided
    for destination_cidr_block, gateway_id in routes:
        try:
            ec2.create_route(
                RouteTableId=route_table_id,
                DestinationCidrBlock=destination_cidr_block,
                GatewayId=gateway_id
            )
            click.echo(f"Added route: {destination_cidr_block} -> {gateway_id}")
        except ClientError as e:
            click.echo(f"Failed to add route {destination_cidr_block} -> {gateway_id}: {e}", err=True)
            return

    click.echo(f"Route Table {route_table_id} setup completed successfully.")

@aws.command(name="create-eks-cluster", help="Create an EKS cluster")
@click.option('-n', '--cluster-name', required=True, help="The name of the EKS cluster")
@click.option('-r', '--region', required=True, help="The AWS region for the EKS cluster")
@click.option('-v', '--version', default="1.25", help="Kubernetes version for the EKS cluster")
@click.option('--role-arn', required=True, help="The IAM role ARN for the EKS cluster")
@click.option('-s', '--subnets', required=True, multiple=True, help="The subnet IDs for the EKS cluster")
@click.option('--security-group-ids', required=True, multiple=True, help="Security group IDs for the EKS cluster")
@click.option('-t', '--tags', type=str, multiple=True, help="Tags for the cluster in the format Key=Value")
@click.pass_context
def create_eks_cluster_command(ctx, cluster_name, region, version, role_arn, subnets, security_group_ids, tags):
    # Initialize EKS client
    eks_client = boto3.client('eks', region_name=region)

    # Create EKS Cluster
    try:
        click.echo(f"Creating EKS cluster: {cluster_name} in region {region} with Kubernetes version {version}...")
        response = eks_client.create_cluster(
            name=cluster_name,
            version=version,
            roleArn=role_arn,
            resourcesVpcConfig={
                'subnetIds': list(subnets),
                'securityGroupIds': list(security_group_ids),
                'endpointPublicAccess': True,
                'endpointPrivateAccess': False
            },
            tags={tag.split('=')[0]: tag.split('=')[1] for tag in tags} if tags else {}
        )
        click.echo(f"EKS Cluster '{cluster_name}' creation initiated. Status: {response['cluster']['status']}")
    except ClientError as e:
        click.echo(f"Failed to create EKS cluster: {e}", err=True)
        return

    # Wait for the cluster to be active
    click.echo("Waiting for the EKS cluster to become active...")
    waiter = eks_client.get_waiter('cluster_active')
    waiter.wait(name=cluster_name)
    click.echo(f"EKS Cluster '{cluster_name}' is now active.")

@aws.command(name="create-eks-nodegroup", help="Create an EKS node group")
@click.option('-c', '--cluster-name', required=True, help="The name of the EKS cluster")
@click.option('-r', '--region', required=True, help="The AWS region for the EKS node group")
@click.option('-n', '--nodegroup-name', required=True, help="The name of the EKS node group")
@click.option('--node-role-arn', required=True, help="The IAM role ARN for the EKS node group")
@click.option('-i', '--instance-types', default=["t3.medium"], multiple=True, help="Instance types for the node group")
@click.option('-s', '--subnets', required=True, multiple=True, help="The subnet IDs for the EKS node group")
@click.option('--min-size', default=1, help="Minimum size of the node group")
@click.option('--max-size', default=3, help="Maximum size of the node group")
@click.option('--desired-size', default=2, help="Desired size of the node group")
@click.option('-t', '--tags', type=str, multiple=True, help="Tags for the node group in the format Key=Value")
@click.pass_context
def create_eks_nodegroup_command(ctx, cluster_name, region, nodegroup_name, node_role_arn, instance_types, subnets, min_size, max_size, desired_size, tags):
    # Initialize EKS client
    eks_client = boto3.client('eks', region_name=region)

    # Create Node Group
    try:
        click.echo(f"Creating node group: {nodegroup_name} for EKS cluster: {cluster_name}...")
        response = eks_client.create_nodegroup(
            clusterName=cluster_name,
            nodegroupName=nodegroup_name,
            nodeRole=node_role_arn,
            subnets=list(subnets),
            scalingConfig={
                'minSize': min_size,
                'maxSize': max_size,
                'desiredSize': desired_size
            },
            instanceTypes=list(instance_types),
            tags={tag.split('=')[0]: tag.split('=')[1] for tag in tags} if tags else {}
        )
        click.echo(f"EKS Node Group '{nodegroup_name}' creation initiated. Status: {response['nodegroup']['status']}")
    except ClientError as e:
        click.echo(f"Failed to create EKS node group: {e}", err=True)
        return

    # Wait for the node group to be active
    click.echo("Waiting for the EKS node group to become active...")
    waiter = eks_client.get_waiter('nodegroup_active')
    waiter.wait(clusterName=cluster_name, nodegroupName=nodegroup_name)
    click.echo(f"EKS Node Group '{nodegroup_name}' is now active.")

@aws.command(name="create-s3-bucket", help="Create an S3 bucket with optional configurations")
@click.option('-b', '--bucket-name', required=True, help="The name of the S3 bucket to create.")
@click.option('-r', '--region', required=True, help="The AWS region for the S3 bucket.")
@click.option('--public-access-block', is_flag=True, default=True, help="Block public access to the bucket.")
@click.option('--versioning', is_flag=True, default=False, help="Enable versioning on the bucket.")
@click.option('--lifecycle-rules', type=str, multiple=True, help="Lifecycle rules in JSON format.")
@click.option('--logging', type=str, help="Logging configuration in JSON format.")
@click.option('--encryption', type=str, help="Encryption configuration in JSON format.")
def create_s3_bucket_command(bucket_name, region, public_access_block, versioning, lifecycle_rules, logging, encryption):
    # Load AWS credentials
    credentials = load_aws_credentials()

    # Remove 'region_name' from credentials if it exists
    credentials.pop('region_name', None)

    # Initialize the S3 client using the region and credentials
    s3_client = boto3.client('s3', region_name=region, **credentials)

    # Convert lifecycle rules, logging, and encryption from JSON string to dictionary if provided
    lifecycle_rules = [eval(rule) for rule in lifecycle_rules] if lifecycle_rules else None
    logging = eval(logging) if logging else None
    encryption = eval(encryption) if encryption else None

    try:
        # Create the S3 bucket with optional configurations
        click.echo(f"Creating S3 bucket '{bucket_name}' in region '{region}'...")
        create_s3_bucket_declarative(s3_client, bucket_name, region, public_access_block, versioning, lifecycle_rules, logging, encryption)
        click.echo(f"S3 Bucket '{bucket_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create S3 bucket: {e}", err=True)
    except NoCredentialsError as e:
        click.echo(f"AWS credentials error: {e}", err=True)
    except Exception as e:
        click.echo(f"An unexpected error occurred: {e}", err=True)

def create_s3_bucket_declarative(s3_client, bucket_name, region, public_access_block, versioning, lifecycle_rules, logging, encryption):
    create_bucket_params = {'Bucket': bucket_name}

    # Only add the region configuration if a region is specified and it is not us-east-1
    if region != 'us-east-1':
        create_bucket_params['CreateBucketConfiguration'] = {'LocationConstraint': region}

    s3_client.create_bucket(**create_bucket_params)

    # Additional settings and confirmations
    if public_access_block:
        s3_client.put_public_access_block(
            Bucket=bucket_name,
            PublicAccessBlockConfiguration={
                'BlockPublicAcls': True,
                'IgnorePublicAcls': True,
                'BlockPublicPolicy': True,
                'RestrictPublicBuckets': True
            }
        )

    if versioning:
        s3_client.put_bucket_versioning(
            Bucket=bucket_name,
            VersioningConfiguration={'Status': 'Enabled'}
        )

    if lifecycle_rules:
        s3_client.put_bucket_lifecycle_configuration(
            Bucket=bucket_name,
            LifecycleConfiguration={'Rules': lifecycle_rules}
        )

    if logging:
        s3_client.put_bucket_logging(
            Bucket=bucket_name,
            BucketLoggingStatus={'LoggingEnabled': logging}
        )

    if encryption:
        s3_client.put_bucket_encryption(
            Bucket=bucket_name,
            ServerSideEncryptionConfiguration={'Rules': [{'ApplyServerSideEncryptionByDefault': encryption}]}
        )

@aws.command(name="request-ssl-certificate", help="Request an SSL certificate")
@click.option('-d', '--domain-name', required=True, help="The domain name for the SSL certificate")
@click.option('-v', '--validation-method', required=True, help="The method to validate the SSL certificate (e.g., DNS, EMAIL)")
@click.option('-s', '--subject-alternative-names', multiple=True, help="Additional domain names to include in the certificate")
@click.option('-t', '--tags', multiple=True, help="Tags to assign to the certificate (format: Key=Value)")
def request_ssl_certificate_command(domain_name, validation_method, subject_alternative_names, tags):
    # Load AWS credentials
    credentials = load_aws_credentials()

    # Initialize the boto3 client using the region and credentials
    acm_client = boto3.client('acm', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Process tags correctly
        formatted_tags = []
        for tag in tags:
            key_value_pair = tag.split('=', 1)  # Split on the first '=' only
            if len(key_value_pair) == 2:
                key = key_value_pair[0].strip()
                value = key_value_pair[1].strip()

                # Validate AWS tag format
                if not key or not value:
                    raise ValueError(f"Invalid tag format: '{tag}'. Key and Value must not be empty.")

                formatted_tags.append({'Key': key, 'Value': value})
            else:
                raise ValueError(f"Invalid tag format: '{tag}'. Expected format is Key=Value.")

        # Request SSL Certificate
        response = acm_client.request_certificate(
            DomainName=domain_name,
            ValidationMethod=validation_method,
            SubjectAlternativeNames=list(subject_alternative_names),
            Tags=formatted_tags
        )
        certificate_arn = response['CertificateArn']
        click.echo(f"SSL Certificate requested with ARN: {certificate_arn}")
        return certificate_arn

    except ClientError as e:
        click.echo(f"Failed to request SSL certificate: {e}", err=True)
    except NoCredentialsError as e:
        click.echo(f"AWS credentials error: {e}", err=True)
    except Exception as e:
        click.echo(f"An unexpected error occurred: {e}", err=True)


@aws.command(name="create-ec2-instance", help="Create an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the instance will be created.")
@click.option('-i', '--instance-type', required=True, help="The type of EC2 instance (e.g., t2.micro, m5.large).")
@click.option('-a', '--ami-id', required=True, help="The AMI ID of the instance.")
@click.option('-k', '--key-name', required=True, help="The name of the key pair to use for the instance.")
@click.option('-s', '--security-group-ids', multiple=True, required=True, help="Security Group IDs to assign to the instance.")
@click.option('-t', '--tags', multiple=True, help="Tags to assign to the instance (format: Key=Value).")
@click.option('--subnet-id', required=False, help="The ID of the subnet in which to launch the instance.")
@click.option('--associate-public-ip', is_flag=True, default=False, help="Associate a public IP with the instance.")
def create_ec2_instance_command(region, instance_type, ami_id, key_name, security_group_ids, tags, subnet_id, associate_public_ip):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Build instance parameters
        instance_params = {
            'ImageId': ami_id,
            'InstanceType': instance_type,
            'KeyName': key_name,
            'SecurityGroupIds': list(security_group_ids),
            'MinCount': 1,
            'MaxCount': 1
        }

        if subnet_id:
            instance_params['SubnetId'] = subnet_id

        if associate_public_ip:
            instance_params['NetworkInterfaces'] = [{
                'SubnetId': subnet_id,
                'DeviceIndex': 0,
                'AssociatePublicIpAddress': True,
                'Groups': list(security_group_ids)
            }]
        
        # Add tags if provided
        if tags:
            formatted_tags = [{'Key': tag.split('=')[0], 'Value': tag.split('=')[1]} for tag in tags]
            instance_params['TagSpecifications'] = [{
                'ResourceType': 'instance',
                'Tags': formatted_tags
            }]

        # Launch the EC2 instance
        response = ec2_client.run_instances(**instance_params)
        instance_id = response['Instances'][0]['InstanceId']
        click.echo(f"EC2 instance created with Instance ID: {instance_id}")
        return instance_id

    except ClientError as e:
        click.echo(f"Failed to create EC2 instance: {e}", err=True)
    except NoCredentialsError as e:
        click.echo(f"AWS credentials error: {e}", err=True)
    except Exception as e:
        click.echo(f"An unexpected error occurred: {e}", err=True)

@aws.command(name="terminate-ec2-instance", help="Terminate an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the instance is located.")
@click.option('-i', '--instance-id', required=True, help="The ID of the EC2 instance to terminate.")
def terminate_ec2_instance_command(region, instance_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Terminate the instance
        ec2_client.terminate_instances(InstanceIds=[instance_id])
        click.echo(f"EC2 instance {instance_id} terminated.")
    except ClientError as e:
        click.echo(f"Failed to terminate EC2 instance: {e}", err=True)

@aws.command(name="describe-ec2-instances", help="Describe EC2 instances.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('-i', '--instance-ids', multiple=True, required=False, help="Optional list of instance IDs to describe.")
def describe_ec2_instances_command(region, instance_ids):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe the instances
        response = ec2_client.describe_instances(InstanceIds=list(instance_ids) if instance_ids else None)
        for reservation in response['Reservations']:
            for instance in reservation['Instances']:
                click.echo(f"Instance ID: {instance['InstanceId']}, State: {instance['State']['Name']}, Instance Type: {instance['InstanceType']}")
    except ClientError as e:
        click.echo(f"Failed to describe EC2 instances: {e}", err=True)

@aws.command(name="attach-elastic-ip", help="Associate an Elastic IP with an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('-i', '--instance-id', required=True, help="The instance ID to associate the Elastic IP with.")
@click.option('--allocation-id', required=True, help="The allocation ID of the Elastic IP.")
def attach_elastic_ip_command(region, instance_id, allocation_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Associate Elastic IP
        ec2_client.associate_address(InstanceId=instance_id, AllocationId=allocation_id)
        click.echo(f"Elastic IP with Allocation ID {allocation_id} associated with instance {instance_id}.")
    except ClientError as e:
        click.echo(f"Failed to associate Elastic IP: {e}", err=True)

@aws.command(name="allocate-elastic-ip", help="Allocate a new Elastic IP.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('--domain', default='vpc', help="The domain to allocate the Elastic IP (default: vpc).")
def allocate_elastic_ip_command(region, domain):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Allocate Elastic IP
        response = ec2_client.allocate_address(Domain=domain)
        click.echo(f"Elastic IP allocated with Public IP: {response['PublicIp']}, Allocation ID: {response['AllocationId']}")
    except ClientError as e:
        click.echo(f"Failed to allocate Elastic IP: {e}", err=True)

@aws.command(name="modify-ec2-attributes", help="Modify attributes of an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('-i', '--instance-id', required=True, help="The instance ID to modify.")
@click.option('--instance-type', required=False, help="The new instance type (optional).")
@click.option('--security-group-ids', multiple=True, required=False, help="New security group IDs to assign (optional).")
def modify_ec2_attributes_command(region, instance_id, instance_type, security_group_ids):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Modify instance attributes
        if instance_type:
            ec2_client.modify_instance_attribute(InstanceId=instance_id, InstanceType={'Value': instance_type})
            click.echo(f"EC2 instance {instance_id} updated to type {instance_type}.")

        if security_group_ids:
            ec2_client.modify_instance_attribute(InstanceId=instance_id, Groups=list(security_group_ids))
            click.echo(f"EC2 instance {instance_id} security groups updated.")
    except ClientError as e:
        click.echo(f"Failed to modify EC2 instance: {e}", err=True)

@aws.command(name="stop-ec2-instance", help="Stop an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the instance is located.")
@click.option('-i', '--instance-id', required=True, help="The ID of the EC2 instance to stop.")
def stop_ec2_instance_command(region, instance_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Stop the instance
        ec2_client.stop_instances(InstanceIds=[instance_id])
        click.echo(f"EC2 instance {instance_id} stopped.")
    except ClientError as e:
        click.echo(f"Failed to stop EC2 instance: {e}", err=True)

@aws.command(name="start-ec2-instance", help="Start an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the instance is located.")
@click.option('-i', '--instance-id', required=True, help="The ID of the EC2 instance to start.")
def start_ec2_instance_command(region, instance_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Start the instance
        ec2_client.start_instances(InstanceIds=[instance_id])
        click.echo(f"EC2 instance {instance_id} started.")
    except ClientError as e:
        click.echo(f"Failed to start EC2 instance: {e}", err=True)

@aws.command(name="create-key-pair", help="Create a new EC2 key pair.")
@click.option('-r', '--region', required=True, help="The AWS region where the key pair will be created.")
@click.option('--key-name', required=True, help="The name of the EC2 key pair.")
def create_key_pair_command(region, key_name):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create the key pair
        response = ec2_client.create_key_pair(KeyName=key_name)
        key_material = response['KeyMaterial']

        # Save the private key to a local file
        file_name = f"{key_name}.pem"
        with open(file_name, 'w') as file:
            file.write(key_material)
        click.echo(f"Key pair '{key_name}' created and saved as {file_name}.")
    except ClientError as e:
        click.echo(f"Failed to create key pair: {e}", err=True)

@aws.command(name="delete-key-pair", help="Delete an EC2 key pair.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('--key-name', required=True, help="The name of the key pair to delete.")
def delete_key_pair_command(region, key_name):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete the key pair
        ec2_client.delete_key_pair(KeyName=key_name)
        click.echo(f"Key pair '{key_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete key pair: {e}", err=True)

@aws.command(name="describe-key-pairs", help="List all EC2 key pairs.")
@click.option('-r', '--region', required=True, help="The AWS region.")
def describe_key_pairs_command(region):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe the key pairs
        response = ec2_client.describe_key_pairs()
        for key_pair in response['KeyPairs']:
            click.echo(f"Key Pair Name: {key_pair['KeyName']}, Key Fingerprint: {key_pair['KeyFingerprint']}")
    except ClientError as e:
        click.echo(f"Failed to describe key pairs: {e}", err=True)

@aws.command(name="authorize-sg-ingress", help="Add an inbound rule to a Security Group.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('--group-id', required=True, help="The Security Group ID.")
@click.option('--protocol', required=True, help="The protocol (e.g., tcp, udp).")
@click.option('--port-range', required=True, help="The port range (e.g., 22 for SSH, 80 for HTTP).")
@click.option('--cidr', required=True, help="The CIDR block (e.g., 0.0.0.0/0 for all IPs).")
def authorize_sg_ingress_command(region, group_id, protocol, port_range, cidr):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Add inbound rule
        ec2_client.authorize_security_group_ingress(
            GroupId=group_id,
            IpPermissions=[
                {
                    'IpProtocol': protocol,
                    'FromPort': int(port_range),
                    'ToPort': int(port_range),
                    'IpRanges': [{'CidrIp': cidr}]
                }
            ]
        )
        click.echo(f"Inbound rule added to Security Group {group_id}.")
    except ClientError as e:
        click.echo(f"Failed to add inbound rule: {e}", err=True)

@aws.command(name="authorize-sg-egress", help="Add an outbound rule to a Security Group.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('--group-id', required=True, help="The Security Group ID.")
@click.option('--protocol', required=True, help="The protocol (e.g., tcp, udp).")
@click.option('--port-range', required=True, help="The port range (e.g., 22 for SSH, 80 for HTTP).")
@click.option('--cidr', required=True, help="The CIDR block (e.g., 0.0.0.0/0 for all IPs).")
def authorize_sg_egress_command(region, group_id, protocol, port_range, cidr):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Add outbound rule
        ec2_client.authorize_security_group_egress(
            GroupId=group_id,
            IpPermissions=[
                {
                    'IpProtocol': protocol,
                    'FromPort': int(port_range),
                    'ToPort': int(port_range),
                    'IpRanges': [{'CidrIp': cidr}]
                }
            ]
        )
        click.echo(f"Outbound rule added to Security Group {group_id}.")
    except ClientError as e:
        click.echo(f"Failed to add outbound rule: {e}", err=True)

@aws.command(name="delete-security-group", help="Delete a Security Group.")
@click.option('-r', '--region', required=True, help="The AWS region.")
@click.option('--group-id', required=True, help="The Security Group ID.")
def delete_security_group_command(region, group_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete the security group
        ec2_client.delete_security_group(GroupId=group_id)
        click.echo(f"Security Group {group_id} deleted.")
    except ClientError as e:
        click.echo(f"Failed to delete Security Group: {e}", err=True)

@aws.command(name="reboot-ec2-instance", help="Reboot an EC2 instance.")
@click.option('-r', '--region', required=True, help="The AWS region where the instance is located.")
@click.option('-i', '--instance-id', required=True, help="The ID of the EC2 instance to reboot.")
def reboot_ec2_instance_command(region, instance_id):
    credentials = load_aws_credentials()

    # Initialize EC2 client
    ec2_client = boto3.client('ec2', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Reboot the instance
        ec2_client.reboot_instances(InstanceIds=[instance_id])
        click.echo(f"EC2 instance {instance_id} is being rebooted.")
    except ClientError as e:
        click.echo(f"Failed to reboot EC2 instance: {e}", err=True)

@aws.command(name="create-rds-instance", help="Create an RDS database instance.")
@click.option('--db-instance-identifier', required=True, help="The DB instance identifier.")
@click.option('--db-instance-class', required=True, help="The compute and memory capacity of the DB instance (e.g., db.t3.micro).")
@click.option('--engine', required=True, help="The name of the database engine (e.g., MySQL, PostgreSQL, MariaDB).")
@click.option('--allocated-storage', required=True, type=int, help="The allocated storage in gibibytes.")
@click.option('--master-username', required=True, help="The master username for the DB instance.")
@click.option('--master-user-password', required=True, help="The master user password.")
@click.option('--vpc-security-group-ids', required=True, multiple=True, help="One or more VPC security groups.")
@click.option('--db-subnet-group-name', required=True, help="A DB subnet group to associate with the DB instance.")
@click.option('--region', required=True, help="AWS region for the RDS instance.")
@click.option('--tags', multiple=True, help="Tags to assign to the RDS instance (format: Key=Value).")
def create_rds_instance_command(db_instance_identifier, db_instance_class, engine, allocated_storage, master_username, master_user_password, vpc_security_group_ids, db_subnet_group_name, region, tags):
    credentials = load_aws_credentials()

    # Initialize RDS client
    rds_client = boto3.client('rds', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create RDS instance
        click.echo(f"Creating RDS instance '{db_instance_identifier}' in region '{region}'...")
        response = rds_client.create_db_instance(
            DBInstanceIdentifier=db_instance_identifier,
            DBInstanceClass=db_instance_class,
            Engine=engine,
            AllocatedStorage=allocated_storage,
            MasterUsername=master_username,
            MasterUserPassword=master_user_password,
            VpcSecurityGroupIds=list(vpc_security_group_ids),
            DBSubnetGroupName=db_subnet_group_name,
            Tags=[{'Key': k.split('=')[0], 'Value': k.split('=')[1]} for k in tags]
        )
        click.echo(f"RDS instance '{db_instance_identifier}' is being created.")
    except ClientError as e:
        click.echo(f"Failed to create RDS instance: {e}", err=True)

@aws.command(name="delete-rds-instance", help="Delete an RDS instance.")
@click.option('--db-instance-identifier', required=True, help="The DB instance identifier.")
@click.option('--skip-final-snapshot', is_flag=True, help="Skip the creation of a final snapshot before deletion.")
@click.option('--region', required=True, help="AWS region where the RDS instance is located.")
def delete_rds_instance_command(db_instance_identifier, skip_final_snapshot, region):
    credentials = load_aws_credentials()

    # Initialize RDS client
    rds_client = boto3.client('rds', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete RDS instance
        click.echo(f"Deleting RDS instance '{db_instance_identifier}'...")
        rds_client.delete_db_instance(
            DBInstanceIdentifier=db_instance_identifier,
            SkipFinalSnapshot=skip_final_snapshot
        )
        click.echo(f"RDS instance '{db_instance_identifier}' is being deleted.")
    except ClientError as e:
        click.echo(f"Failed to delete RDS instance: {e}", err=True)

@aws.command(name="describe-rds-instances", help="List all RDS instances.")
@click.option('--region', required=True, help="AWS region where the RDS instances are located.")
def describe_rds_instances_command(region):
    credentials = load_aws_credentials()

    # Initialize RDS client
    rds_client = boto3.client('rds', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # List RDS instances
        response = rds_client.describe_db_instances()
        for instance in response['DBInstances']:
            click.echo(f"DB Instance Identifier: {instance['DBInstanceIdentifier']}, Status: {instance['DBInstanceStatus']}")
    except ClientError as e:
        click.echo(f"Failed to describe RDS instances: {e}", err=True)

@aws.command(name="create-dynamodb-table", help="Create a DynamoDB table.")
@click.option('--table-name', required=True, help="The name of the DynamoDB table.")
@click.option('--partition-key', required=True, help="The partition key for the table.")
@click.option('--sort-key', help="The sort key for the table (optional).")
@click.option('--read-capacity-units', required=True, type=int, help="The read capacity units for the table.")
@click.option('--write-capacity-units', required=True, type=int, help="The write capacity units for the table.")
@click.option('--region', required=True, help="The AWS region for the DynamoDB table.")
def create_dynamodb_table_command(table_name, partition_key, sort_key, read_capacity_units, write_capacity_units, region):
    credentials = load_aws_credentials()

    # Initialize DynamoDB client
    dynamodb_client = boto3.client('dynamodb', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create table schema
        key_schema = [{'AttributeName': partition_key, 'KeyType': 'HASH'}]
        attribute_definitions = [{'AttributeName': partition_key, 'AttributeType': 'S'}]

        if sort_key:
            key_schema.append({'AttributeName': sort_key, 'KeyType': 'RANGE'})
            attribute_definitions.append({'AttributeName': sort_key, 'AttributeType': 'S'})

        # Create DynamoDB table
        dynamodb_client.create_table(
            TableName=table_name,
            KeySchema=key_schema,
            AttributeDefinitions=attribute_definitions,
            ProvisionedThroughput={
                'ReadCapacityUnits': read_capacity_units,
                'WriteCapacityUnits': write_capacity_units
            }
        )
        click.echo(f"DynamoDB table '{table_name}' is being created.")
    except ClientError as e:
        click.echo(f"Failed to create DynamoDB table: {e}", err=True)

@aws.command(name="delete-dynamodb-table", help="Delete a DynamoDB table.")
@click.option('--table-name', required=True, help="The name of the DynamoDB table to delete.")
@click.option('--region', required=True, help="The AWS region for the DynamoDB table.")
def delete_dynamodb_table_command(table_name, region):
    credentials = load_aws_credentials()

    # Initialize DynamoDB client
    dynamodb_client = boto3.client('dynamodb', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete DynamoDB table
        dynamodb_client.delete_table(TableName=table_name)
        click.echo(f"DynamoDB table '{table_name}' has been deleted.")
    except ClientError as e:
        click.echo(f"Failed to delete DynamoDB table: {e}", err=True)

@aws.command(name="describe-dynamodb-table", help="Describe a DynamoDB table.")
@click.option('--table-name', required=True, help="The name of the DynamoDB table to describe.")
@click.option('--region', required=True, help="The AWS region for the DynamoDB table.")
def describe_dynamodb_table_command(table_name, region):
    credentials = load_aws_credentials()

    # Initialize DynamoDB client
    dynamodb_client = boto3.client('dynamodb', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe DynamoDB table
        response = dynamodb_client.describe_table(TableName=table_name)
        click.echo(f"Table Name: {response['Table']['TableName']}, Status: {response['Table']['TableStatus']}")
    except ClientError as e:
        click.echo(f"Failed to describe DynamoDB table: {e}", err=True)

@aws.command(name="create-ecr-repo", help="Create an ECR repository.")
@click.option('--repo-name', required=True, help="The name of the ECR repository.")
@click.option('--region', required=True, help="The AWS region for the ECR repository.")
@click.option('--scan-on-push', is_flag=True, default=False, help="Enable image scanning on push.")
@click.option('--encryption', default='AES256', help="Encryption configuration for the repository (default: AES256).")
@click.option('--tags', multiple=True, help="Tags to assign to the repository (format: Key=Value).")
def create_ecr_repo_command(repo_name, region, scan_on_push, encryption, tags):
    credentials = load_aws_credentials()

    # Initialize ECR client
    ecr_client = boto3.client('ecr', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create ECR repository
        click.echo(f"Creating ECR repository '{repo_name}' in region '{region}'...")
        response = ecr_client.create_repository(
            repositoryName=repo_name,
            imageScanningConfiguration={'scanOnPush': scan_on_push},
            encryptionConfiguration={'encryptionType': encryption},
            tags=[{'Key': k.split('=')[0], 'Value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"ECR repository '{repo_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create ECR repository: {e}", err=True)

@aws.command(name="delete-ecr-repo", help="Delete an ECR repository.")
@click.option('--repo-name', required=True, help="The name of the ECR repository to delete.")
@click.option('--region', required=True, help="The AWS region for the ECR repository.")
@click.option('--force', is_flag=True, default=False, help="Force delete the repository and all images inside.")
def delete_ecr_repo_command(repo_name, region, force):
    credentials = load_aws_credentials()

    # Initialize ECR client
    ecr_client = boto3.client('ecr', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete ECR repository
        click.echo(f"Deleting ECR repository '{repo_name}' in region '{region}'...")
        ecr_client.delete_repository(
            repositoryName=repo_name,
            force=force
        )
        click.echo(f"ECR repository '{repo_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete ECR repository: {e}", err=True)

@aws.command(name="describe-ecr-repos", help="Describe all ECR repositories.")
@click.option('--region', required=True, help="The AWS region for the ECR repositories.")
def describe_ecr_repos_command(region):
    credentials = load_aws_credentials()

    # Initialize ECR client
    ecr_client = boto3.client('ecr', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe ECR repositories
        response = ecr_client.describe_repositories()
        for repo in response['repositories']:
            click.echo(f"Repository Name: {repo['repositoryName']}, URI: {repo['repositoryUri']}")
    except ClientError as e:
        click.echo(f"Failed to describe ECR repositories: {e}", err=True)

@aws.command(name="list-ecr-images", help="List images in an ECR repository.")
@click.option('--repo-name', required=True, help="The name of the ECR repository.")
@click.option('--region', required=True, help="The AWS region for the ECR repository.")
def list_ecr_images_command(repo_name, region):
    credentials = load_aws_credentials()

    # Initialize ECR client
    ecr_client = boto3.client('ecr', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # List images in ECR repository
        response = ecr_client.list_images(
            repositoryName=repo_name
        )
        if response['imageIds']:
            for image in response['imageIds']:
                click.echo(f"Image Digest: {image['imageDigest']}, Tag: {image.get('imageTag', 'untagged')}")
        else:
            click.echo(f"No images found in repository '{repo_name}'.")
    except ClientError as e:
        click.echo(f"Failed to list images in ECR repository: {e}", err=True)

@aws.command(name="delete-ecr-image", help="Delete an image from an ECR repository.")
@click.option('--repo-name', required=True, help="The name of the ECR repository.")
@click.option('--image-tag', required=True, help="The tag of the image to delete.")
@click.option('--region', required=True, help="The AWS region for the ECR repository.")
def delete_ecr_image_command(repo_name, image_tag, region):
    credentials = load_aws_credentials()

    # Initialize ECR client
    ecr_client = boto3.client('ecr', region_name=region, **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete image in ECR repository
        click.echo(f"Deleting image with tag '{image_tag}' from ECR repository '{repo_name}'...")
        ecr_client.batch_delete_image(
            repositoryName=repo_name,
            imageIds=[{'imageTag': image_tag}]
        )
        click.echo(f"Image with tag '{image_tag}' deleted from ECR repository '{repo_name}'.")
    except ClientError as e:
        click.echo(f"Failed to delete image from ECR repository: {e}", err=True)

@aws.command(name="create-eb-app", help="Create an Elastic Beanstalk application.")
@click.option('--app-name', required=True, help="The name of the Elastic Beanstalk application.")
@click.option('--description', default='', help="Description of the application.")
@click.option('--tags', multiple=True, help="Tags to assign to the application (format: Key=Value).")
def create_eb_app_command(app_name, description, tags):
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create Elastic Beanstalk application
        click.echo(f"Creating Elastic Beanstalk application '{app_name}'...")
        response = eb_client.create_application(
            ApplicationName=app_name,
            Description=description,
            Tags=[{'Key': k.split('=')[0], 'Value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"Elastic Beanstalk application '{app_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create Elastic Beanstalk application: {e}", err=True)

@aws.command(name="delete-eb-app", help="Delete an Elastic Beanstalk application.")
@click.option('--app-name', required=True, help="The name of the Elastic Beanstalk application to delete.")
@click.option('--terminate-envs', is_flag=True, help="Whether to terminate environments before deleting the application.")
def delete_eb_app_command(app_name, terminate_envs):
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Optionally terminate environments
        if terminate_envs:
            click.echo(f"Terminating all environments for application '{app_name}' before deletion...")
            envs_response = eb_client.describe_environments(ApplicationName=app_name)
            for env in envs_response['Environments']:
                if env['Status'] != 'Terminated':
                    eb_client.terminate_environment(EnvironmentName=env['EnvironmentName'])

        # Delete Elastic Beanstalk application
        click.echo(f"Deleting Elastic Beanstalk application '{app_name}'...")
        eb_client.delete_application(ApplicationName=app_name)
        click.echo(f"Elastic Beanstalk application '{app_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete Elastic Beanstalk application: {e}", err=True)

@aws.command(name="create-eb-env", help="Create an Elastic Beanstalk environment.")
@click.option('--app-name', required=True, help="The name of the Elastic Beanstalk application.")
@click.option('--env-name', required=True, help="The name of the Elastic Beanstalk environment.")
@click.option('--solution-stack-name', required=True, help="The solution stack (platform) to use for the environment (e.g., '64bit Amazon Linux 2 v3.3.7 running Python 3.8').")
@click.option('--version-label', required=False, help="The version label for the application to deploy.")
@click.option('--tags', multiple=True, help="Tags to assign to the environment (format: Key=Value).")
@click.option('--option-settings', multiple=True, help="Configuration options in the format Namespace:OptionName=Value.")
def create_eb_env_command(app_name, env_name, solution_stack_name, version_label, tags, option_settings):
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Prepare option settings
        formatted_option_settings = []
        for setting in option_settings:
            namespace, rest = setting.split(':', 1)
            option_name, value = rest.split('=', 1)
            formatted_option_settings.append({'Namespace': namespace, 'OptionName': option_name, 'Value': value})

        # Create Elastic Beanstalk environment
        click.echo(f"Creating environment '{env_name}' for application '{app_name}' with solution stack '{solution_stack_name}'...")
        response = eb_client.create_environment(
            ApplicationName=app_name,
            EnvironmentName=env_name,
            SolutionStackName=solution_stack_name,
            VersionLabel=version_label,
            Tags=[{'Key': k.split('=')[0], 'Value': k.split('=')[1]} for k in tags] if tags else [],
            OptionSettings=formatted_option_settings
        )
        click.echo(f"Elastic Beanstalk environment '{env_name}' created successfully. Status: {response['Status']}")
    except ClientError as e:
        click.echo(f"Failed to create Elastic Beanstalk environment: {e}", err=True)


@aws.command(name="terminate-eb-env", help="Terminate an Elastic Beanstalk environment.")
@click.option('--env-name', required=True, help="The name of the Elastic Beanstalk environment to terminate.")
def terminate_eb_env_command(env_name):
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Terminate Elastic Beanstalk environment
        click.echo(f"Terminating Elastic Beanstalk environment '{env_name}'...")
        response = eb_client.terminate_environment(EnvironmentName=env_name)
        click.echo(f"Environment termination initiated. Status: {response['Status']}")
    except ClientError as e:
        click.echo(f"Failed to terminate Elastic Beanstalk environment: {e}", err=True)

@aws.command(name="describe-eb-apps", help="Describe all Elastic Beanstalk applications.")
def describe_eb_apps_command():
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe all Elastic Beanstalk applications
        response = eb_client.describe_applications()
        for app in response['Applications']:
            click.echo(f"Application Name: {app['ApplicationName']}, Description: {app.get('Description', 'N/A')}")
    except ClientError as e:
        click.echo(f"Failed to describe Elastic Beanstalk applications: {e}", err=True)

@aws.command(name="describe-eb-envs", help="Describe all environments for an Elastic Beanstalk application.")
@click.option('--app-name', required=True, help="The name of the Elastic Beanstalk application.")
def describe_eb_envs_command(app_name):
    credentials = load_aws_credentials()

    # Initialize Elastic Beanstalk client
    eb_client = boto3.client('elasticbeanstalk', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Describe all environments for a specific application
        response = eb_client.describe_environments(ApplicationName=app_name)
        for env in response['Environments']:
            click.echo(f"Environment Name: {env['EnvironmentName']}, Status: {env['Status']}, Health: {env['Health']}")
    except ClientError as e:
        click.echo(f"Failed to describe Elastic Beanstalk environments: {e}", err=True)


@aws.command(name="create-ecs-cluster", help="Create an ECS Cluster.")
@click.option('--cluster-name', required=True, help="The name of the ECS cluster.")
@click.option('--tags', multiple=True, help="Tags to assign to the ECS cluster (format: Key=Value).")
def create_ecs_cluster_command(cluster_name, tags):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create ECS Cluster
        click.echo(f"Creating ECS Cluster '{cluster_name}'...")
        response = ecs_client.create_cluster(
            clusterName=cluster_name,
            tags=[{'key': k.split('=')[0], 'value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"ECS Cluster '{cluster_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create ECS Cluster: {e}", err=True)

@aws.command(name="delete-ecs-cluster", help="Delete an ECS Cluster.")
@click.option('--cluster-name', required=True, help="The name of the ECS cluster to delete.")
def delete_ecs_cluster_command(cluster_name):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete ECS Cluster
        click.echo(f"Deleting ECS Cluster '{cluster_name}'...")
        ecs_client.delete_cluster(cluster=cluster_name)
        click.echo(f"ECS Cluster '{cluster_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete ECS Cluster: {e}", err=True)

@aws.command(name="register-ecs-task", help="Register an ECS Task Definition.")
@click.option('--family', required=True, help="The family name of the task definition.")
@click.option('--container-name', required=True, help="The name of the container in the task definition.")
@click.option('--image', required=True, help="The Docker image for the container.")
@click.option('--cpu', required=True, help="The number of CPU units to allocate for the container.")
@click.option('--memory', required=True, help="The amount of memory to allocate for the container.")
@click.option('--port-mappings', multiple=True, help="Port mappings for the container (format: containerPort:hostPort).")
@click.option('--tags', multiple=True, help="Tags to assign to the task definition (format: Key=Value).")
def register_ecs_task_command(family, container_name, image, cpu, memory, port_mappings, tags):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Parse port mappings
        port_mapping_list = [{'containerPort': int(pm.split(':')[0]), 'hostPort': int(pm.split(':')[1])} for pm in port_mappings]

        # Register ECS Task Definition
        click.echo(f"Registering ECS Task Definition for family '{family}'...")
        response = ecs_client.register_task_definition(
            family=family,
            containerDefinitions=[
                {
                    'name': container_name,
                    'image': image,
                    'cpu': int(cpu),
                    'memory': int(memory),
                    'portMappings': port_mapping_list
                }
            ],
            tags=[{'key': k.split('=')[0], 'value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"Task Definition registered successfully: {response['taskDefinition']['taskDefinitionArn']}")
    except ClientError as e:
        click.echo(f"Failed to register ECS Task Definition: {e}", err=True)

@aws.command(name="create-ecs-service", help="Create an ECS Service.")
@click.option('--cluster-name', required=True, help="The name of the ECS cluster.")
@click.option('--service-name', required=True, help="The name of the ECS service.")
@click.option('--task-definition', required=True, help="The task definition to run in the service.")
@click.option('--desired-count', required=True, type=int, help="The desired number of tasks to run.")
@click.option('--launch-type', default='EC2', type=click.Choice(['EC2', 'FARGATE']), help="The launch type for the service (default: EC2).")
@click.option('--subnets', multiple=True, help="The subnets to use for Fargate tasks (required for Fargate).")
@click.option('--security-groups', multiple=True, help="The security groups to use for Fargate tasks (required for Fargate).")
@click.option('--tags', multiple=True, help="Tags to assign to the service (format: Key=Value).")
def create_ecs_service_command(cluster_name, service_name, task_definition, desired_count, launch_type, subnets, security_groups, tags):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create ECS Service
        click.echo(f"Creating ECS Service '{service_name}' in cluster '{cluster_name}'...")
        service_definition = {
            'cluster': cluster_name,
            'serviceName': service_name,
            'taskDefinition': task_definition,
            'desiredCount': desired_count,
            'launchType': launch_type,
            'tags': [{'key': k.split('=')[0], 'value': k.split('=')[1]} for k in tags] if tags else []
        }

        if launch_type == 'FARGATE':
            service_definition['networkConfiguration'] = {
                'awsvpcConfiguration': {
                    'subnets': list(subnets),
                    'securityGroups': list(security_groups),
                    'assignPublicIp': 'ENABLED'
                }
            }

        response = ecs_client.create_service(**service_definition)
        click.echo(f"ECS Service '{service_name}' created successfully. Status: {response['service']['status']}")
    except ClientError as e:
        click.echo(f"Failed to create ECS Service: {e}", err=True)

@aws.command(name="update-ecs-service", help="Update an ECS Service.")
@click.option('--cluster-name', required=True, help="The name of the ECS cluster.")
@click.option('--service-name', required=True, help="The name of the ECS service to update.")
@click.option('--desired-count', type=int, help="The new desired number of tasks.")
@click.option('--task-definition', help="The new task definition for the service.")
def update_ecs_service_command(cluster_name, service_name, desired_count, task_definition):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Update ECS Service
        click.echo(f"Updating ECS Service '{service_name}' in cluster '{cluster_name}'...")
        update_definition = {'cluster': cluster_name, 'service': service_name}

        if desired_count is not None:
            update_definition['desiredCount'] = desired_count
        if task_definition:
            update_definition['taskDefinition'] = task_definition

        ecs_client.update_service(**update_definition)
        click.echo(f"ECS Service '{service_name}' updated successfully.")
    except ClientError as e:
        click.echo(f"Failed to update ECS Service: {e}", err=True)

@aws.command(name="delete-ecs-service", help="Delete an ECS Service.")
@click.option('--cluster-name', required=True, help="The name of the ECS cluster.")
@click.option('--service-name', required=True, help="The name of the ECS service to delete.")
@click.option('--force', is_flag=True, default=False, help="Forcefully delete the ECS service.")
def delete_ecs_service_command(cluster_name, service_name, force):
    credentials = load_aws_credentials()

    # Initialize ECS client
    ecs_client = boto3.client('ecs', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete ECS Service
        click.echo(f"Deleting ECS Service '{service_name}' from cluster '{cluster_name}'...")
        ecs_client.update_service(cluster=cluster_name, service=service_name, desiredCount=0)
        ecs_client.delete_service(cluster=cluster_name, service=service_name, force=force)
        click.echo(f"ECS Service '{service_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete ECS Service: {e}", err=True)

@aws.command(name="create-codebuild-project", help="Create a CodeBuild project.")
@click.option('--project-name', required=True, help="The name of the CodeBuild project.")
@click.option('--source-type', required=True, type=click.Choice(['CODECOMMIT', 'S3', 'GITHUB', 'BITBUCKET']), help="The source type for the project (e.g., CODECOMMIT, S3, GITHUB, BITBUCKET).")
@click.option('--source-location', required=True, help="The location of the source code (e.g., repository URL or S3 bucket path).")
@click.option('--build-spec', required=True, help="The path to the buildspec file.")
@click.option('--environment-image', required=True, help="The Docker image to use for the build environment.")
@click.option('--service-role', required=True, help="The IAM role ARN for the CodeBuild project.")
@click.option('--artifacts-type', required=True, type=click.Choice(['S3', 'NO_ARTIFACTS']), help="The artifact type (e.g., S3, NO_ARTIFACTS).")
@click.option('--artifacts-location', help="The location to store the build artifacts (e.g., S3 bucket path). Required if artifact type is S3.")
@click.option('--environment-type', default='LINUX_CONTAINER', help="The environment type for the build project (default: LINUX_CONTAINER).")
@click.option('--timeout', default=60, help="Build timeout in minutes (default: 60 minutes).")
@click.option('--tags', multiple=True, help="Tags for the project in the format Key=Value.")
def create_codebuild_project_command(project_name, source_type, source_location, build_spec, environment_image, service_role, artifacts_type, artifacts_location, environment_type, timeout, tags):
    credentials = load_aws_credentials()

    # Initialize CodeBuild client
    codebuild_client = boto3.client('codebuild', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Create CodeBuild Project
        click.echo(f"Creating CodeBuild project '{project_name}'...")

        artifacts_config = {'type': artifacts_type}
        if artifacts_type == 'S3' and artifacts_location:
            artifacts_config['location'] = artifacts_location

        response = codebuild_client.create_project(
            name=project_name,
            source={
                'type': source_type,
                'location': source_location,
                'buildspec': build_spec
            },
            environment={
                'type': environment_type,
                'image': environment_image,
                'computeType': 'BUILD_GENERAL1_SMALL',
                'privilegedMode': True
            },
            serviceRole=service_role,
            artifacts=artifacts_config,
            timeoutInMinutes=timeout,
            tags=[{'key': k.split('=')[0], 'value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"CodeBuild project '{project_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create CodeBuild project: {e}", err=True)

@aws.command(name="start-codebuild", help="Start a build for a CodeBuild project.")
@click.option('--project-name', required=True, help="The name of the CodeBuild project.")
@click.option('--source-version', required=False, help="Optional source version to build.")
@click.option('--environment-variables', multiple=True, help="Environment variables for the build in the format Key=Value.")
def start_codebuild_command(project_name, source_version, environment_variables):
    credentials = load_aws_credentials()

    # Initialize CodeBuild client
    codebuild_client = boto3.client('codebuild', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Prepare environment variables
        env_vars = [{'name': k.split('=')[0], 'value': k.split('=')[1]} for k in environment_variables] if environment_variables else []

        # Start build
        click.echo(f"Starting build for project '{project_name}'...")
        response = codebuild_client.start_build(
            projectName=project_name,
            sourceVersion=source_version if source_version else None,
            environmentVariablesOverride=env_vars
        )
        build_id = response['build']['id']
        click.echo(f"Build started successfully with ID: {build_id}")
    except ClientError as e:
        click.echo(f"Failed to start build: {e}", err=True)


@aws.command(name="get-codebuild-builds", help="Get information about CodeBuild builds.")
@click.option('--build-ids', required=True, multiple=True, help="The IDs of the builds to retrieve.")
def get_codebuild_builds_command(build_ids):
    credentials = load_aws_credentials()

    # Initialize CodeBuild client
    codebuild_client = boto3.client('codebuild', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Fetch build information
        click.echo(f"Fetching information for builds: {', '.join(build_ids)}")
        response = codebuild_client.batch_get_builds(ids=list(build_ids))
        for build in response['builds']:
            click.echo(f"Build ID: {build['id']}, Status: {build['buildStatus']}, Start Time: {build['startTime']}, End Time: {build.get('endTime', 'In Progress')}")
    except ClientError as e:
        click.echo(f"Failed to get build information: {e}", err=True)

@aws.command(name="delete-codebuild-project", help="Delete a CodeBuild project.")
@click.option('--project-name', required=True, help="The name of the CodeBuild project to delete.")
def delete_codebuild_project_command(project_name):
    credentials = load_aws_credentials()

    # Initialize CodeBuild client
    codebuild_client = boto3.client('codebuild', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete CodeBuild Project
        click.echo(f"Deleting CodeBuild project '{project_name}'...")
        codebuild_client.delete_project(name=project_name)
        click.echo(f"CodeBuild project '{project_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete CodeBuild project: {e}", err=True)

@aws.command(name="create-codepipeline", help="Create a CodePipeline.")
@click.option('--pipeline-name', required=True, help="The name of the CodePipeline.")
@click.option('--role-arn', required=True, help="The IAM role ARN for the CodePipeline.")
@click.option('--artifact-store-type', required=True, type=click.Choice(['S3']), help="The artifact store type (e.g., S3).")
@click.option('--artifact-store-location', required=True, help="The location of the artifact store (e.g., S3 bucket).")
@click.option('--stages', required=True, multiple=True, help="The stages configuration in JSON format.")
@click.option('--tags', multiple=True, help="Tags for the CodePipeline in the format Key=Value.")
def create_codepipeline_command(pipeline_name, role_arn, artifact_store_type, artifact_store_location, stages, tags):
    credentials = load_aws_credentials()

    # Initialize CodePipeline client
    codepipeline_client = boto3.client('codepipeline', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Convert stages from JSON string to dictionary
        stages_config = [eval(stage) for stage in stages]

        # Create CodePipeline
        click.echo(f"Creating CodePipeline '{pipeline_name}'...")

        response = codepipeline_client.create_pipeline(
            pipeline={
                'name': pipeline_name,
                'roleArn': role_arn,
                'artifactStore': {
                    'type': artifact_store_type,
                    'location': artifact_store_location
                },
                'stages': stages_config
            },
            tags=[{'key': k.split('=')[0], 'value': k.split('=')[1]} for k in tags] if tags else []
        )
        click.echo(f"CodePipeline '{pipeline_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create CodePipeline: {e}", err=True)

@aws.command(name="start-codepipeline", help="Start a CodePipeline execution.")
@click.option('--pipeline-name', required=True, help="The name of the CodePipeline to execute.")
def start_codepipeline_command(pipeline_name):
    credentials = load_aws_credentials()

    # Initialize CodePipeline client
    codepipeline_client = boto3.client('codepipeline', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Start pipeline execution
        click.echo(f"Starting execution of pipeline '{pipeline_name}'...")
        response = codepipeline_client.start_pipeline_execution(name=pipeline_name)
        execution_id = response['pipelineExecutionId']
        click.echo(f"Pipeline '{pipeline_name}' execution started with ID: {execution_id}")
    except ClientError as e:
        click.echo(f"Failed to start pipeline execution: {e}", err=True)

@aws.command(name="get-codepipeline-status", help="Get the status of a CodePipeline execution.")
@click.option('--pipeline-name', required=True, help="The name of the CodePipeline.")
@click.option('--execution-id', required=True, help="The ID of the pipeline execution to check.")
def get_codepipeline_status_command(pipeline_name, execution_id):
    credentials = load_aws_credentials()

    # Initialize CodePipeline client
    codepipeline_client = boto3.client('codepipeline', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Get pipeline execution status
        click.echo(f"Fetching status of pipeline execution '{execution_id}' for pipeline '{pipeline_name}'...")
        response = codepipeline_client.get_pipeline_execution(
            pipelineName=pipeline_name,
            pipelineExecutionId=execution_id
        )
        status = response['pipelineExecution']['status']
        click.echo(f"Pipeline execution '{execution_id}' status: {status}")
    except ClientError as e:
        click.echo(f"Failed to get pipeline execution status: {e}", err=True)

@aws.command(name="delete-codepipeline", help="Delete a CodePipeline.")
@click.option('--pipeline-name', required=True, help="The name of the CodePipeline to delete.")
def delete_codepipeline_command(pipeline_name):
    credentials = load_aws_credentials()

    # Initialize CodePipeline client
    codepipeline_client = boto3.client('codepipeline', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Delete CodePipeline
        click.echo(f"Deleting CodePipeline '{pipeline_name}'...")
        codepipeline_client.delete_pipeline(name=pipeline_name)
        click.echo(f"CodePipeline '{pipeline_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete CodePipeline: {e}", err=True)


@aws.command(name="delete-s3-bucket", help="Delete an S3 bucket and optionally delete its contents.")
@click.option('--bucket-name', required=True, help="The name of the S3 bucket to delete.")
@click.option('--force', is_flag=True, default=False, help="Delete the contents of the bucket before deletion.")
def delete_s3_bucket_command(bucket_name, force):
    credentials = load_aws_credentials()

    # Initialize S3 client
    s3_client = boto3.client('s3', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        if force:
            click.echo(f"Deleting contents of S3 bucket '{bucket_name}'...")
            delete_s3_bucket_contents(s3_client, bucket_name)

        # Delete the S3 bucket
        click.echo(f"Deleting S3 bucket '{bucket_name}'...")
        s3_client.delete_bucket(Bucket=bucket_name)
        click.echo(f"S3 bucket '{bucket_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete S3 bucket: {e}", err=True)

def delete_s3_bucket_contents(s3_client, bucket_name):
    # List all objects in the bucket
    objects = s3_client.list_objects_v2(Bucket=bucket_name).get('Contents', [])
    if objects:
        for obj in objects:
            s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
        click.echo(f"All contents deleted from bucket '{bucket_name}'.")
    else:
        click.echo(f"No contents found in bucket '{bucket_name}'.")


@aws.command(name="download-s3-object", help="Download an object from S3.")
@click.option('--bucket-name', required=True, help="The name of the S3 bucket.")
@click.option('--object-key', required=True, help="The key of the object to download.")
@click.option('--download-path', required=True, help="The local path where the object will be downloaded.")
def download_s3_object_command(bucket_name, object_key, download_path):
    credentials = load_aws_credentials()

    # Initialize S3 client
    s3_client = boto3.client('s3', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Download the object from S3
        click.echo(f"Downloading '{object_key}' from bucket '{bucket_name}' to '{download_path}'...")
        s3_client.download_file(Bucket=bucket_name, Key=object_key, Filename=download_path)
        click.echo(f"Object '{object_key}' downloaded successfully.")
    except ClientError as e:
        click.echo(f"Failed to download object: {e}", err=True)

@aws.command(name="list-s3-buckets", help="List all S3 buckets.")
def list_s3_buckets_command():
    credentials = load_aws_credentials()

    # Initialize S3 client
    s3_client = boto3.client('s3', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # List all buckets
        response = s3_client.list_buckets()
        buckets = response['Buckets']
        if buckets:
            click.echo("S3 Buckets:")
            for bucket in buckets:
                click.echo(f" - {bucket['Name']}")
        else:
            click.echo("No S3 buckets found.")
    except ClientError as e:
        click.echo(f"Failed to list S3 buckets: {e}", err=True)

@aws.command(name="upload-s3-file", help="Upload a file to an S3 bucket.")
@click.option('--bucket-name', required=True, help="The name of the S3 bucket.")
@click.option('--file-path', required=True, help="The local file path to upload.")
@click.option('--object-key', required=True, help="The key to assign to the uploaded object in S3.")
def upload_s3_file_command(bucket_name, file_path, object_key):
    credentials = load_aws_credentials()

    # Initialize S3 client
    s3_client = boto3.client('s3', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        # Upload the file to S3
        click.echo(f"Uploading '{file_path}' to bucket '{bucket_name}' as '{object_key}'...")
        s3_client.upload_file(Filename=file_path, Bucket=bucket_name, Key=object_key)
        click.echo(f"File '{file_path}' uploaded successfully to bucket '{bucket_name}'.")
    except ClientError as e:
        click.echo(f"Failed to upload file: {e}", err=True)

@aws.command(name="create-iam-user", help="Create a new IAM user.")
@click.option('--user-name', required=True, help="The name of the IAM user.")
@click.option('--tags', type=str, multiple=True, help="Tags to assign to the user in the format Key=Value.")
def create_iam_user_command(user_name, tags):
    credentials = load_aws_credentials()

    # Initialize IAM client
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        click.echo(f"Creating IAM user '{user_name}'...")

        # Create the IAM user
        response = iam_client.create_user(
            UserName=user_name,
            Tags=[{'Key': k, 'Value': v} for tag in tags for k, v in [tag.split('=')]] if tags else []
        )
        click.echo(f"IAM User '{user_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create IAM user: {e}", err=True)

@aws.command(name="create-iam-role", help="Create a new IAM role.")
@click.option('--role-name', required=True, help="The name of the IAM role.")
@click.option('--assume-role-policy-document', required=True, help="The policy document that grants an entity permission to assume the role.")
@click.option('--tags', type=str, multiple=True, help="Tags to assign to the role in the format Key=Value.")
def create_iam_role_command(role_name, assume_role_policy_document, tags):
    credentials = load_aws_credentials()

    # Initialize IAM client
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        click.echo(f"Creating IAM role '{role_name}'...")

        # Create the IAM role
        response = iam_client.create_role(
            RoleName=role_name,
            AssumeRolePolicyDocument=assume_role_policy_document,
            Tags=[{'Key': k, 'Value': v} for tag in tags for k, v in [tag.split('=')]] if tags else []
        )
        click.echo(f"IAM Role '{role_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create IAM role: {e}", err=True)

@aws.command(name="create-iam-group", help="Create a new IAM group.")
@click.option('--group-name', required=True, help="The name of the IAM group.")
@click.option('--tags', type=str, multiple=True, help="Tags to assign to the group in the format Key=Value.")
def create_iam_group_command(group_name, tags):
    credentials = load_aws_credentials()

    # Initialize IAM client
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        click.echo(f"Creating IAM group '{group_name}'...")

        # Create the IAM group
        response = iam_client.create_group(
            GroupName=group_name,
            Tags=[{'Key': k, 'Value': v} for tag in tags for k, v in [tag.split('=')]] if tags else []
        )
        click.echo(f"IAM Group '{group_name}' created successfully.")
    except ClientError as e:
        click.echo(f"Failed to create IAM group: {e}", err=True)

@aws.command(name="attach-role-policy", help="Attach a policy to an IAM role.")
@click.option('--role-name', required=True, help="The name of the IAM role.")
@click.option('--policy-arn', required=True, help="The ARN of the policy to attach.")
def attach_role_policy_command(role_name, policy_arn):
    credentials = load_aws_credentials()

    # Initialize IAM client
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        click.echo(f"Attaching policy '{policy_arn}' to role '{role_name}'...")
        iam_client.attach_role_policy(RoleName=role_name, PolicyArn=policy_arn)
        click.echo(f"Policy '{policy_arn}' attached to role '{role_name}' successfully.")
    except ClientError as e:
        click.echo(f"Failed to attach policy to IAM role: {e}", err=True)

@aws.command(name="add-user-to-group", help="Add a user to an IAM group.")
@click.option('--user-name', required=True, help="The name of the IAM user.")
@click.option('--group-name', required=True, help="The name of the IAM group.")
def add_user_to_group_command(user_name, group_name):
    credentials = load_aws_credentials()

    # Initialize IAM client
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})

    try:
        click.echo(f"Adding user '{user_name}' to group '{group_name}'...")
        iam_client.add_user_to_group(UserName=user_name, GroupName=group_name)
        click.echo(f"User '{user_name}' added to group '{group_name}' successfully.")
    except ClientError as e:
        click.echo(f"Failed to add user to IAM group: {e}", err=True)

@aws.command(name="delete-iam-user", help="Delete an IAM user.")
@click.option('--user-name', required=True, help="The name of the IAM user to delete.")
def delete_iam_user_command(user_name):
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        iam_client.delete_user(UserName=user_name)
        click.echo(f"IAM User '{user_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete IAM user: {e}", err=True)

@aws.command(name="delete-iam-role", help="Delete an IAM role.")
@click.option('--role-name', required=True, help="The name of the IAM role to delete.")
def delete_iam_role_command(role_name):
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        iam_client.delete_role(RoleName=role_name)
        click.echo(f"IAM Role '{role_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete IAM role: {e}", err=True)

@aws.command(name="delete-iam-group", help="Delete an IAM group.")
@click.option('--group-name', required=True, help="The name of the IAM group to delete.")
def delete_iam_group_command(group_name):
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        iam_client.delete_group(GroupName=group_name)
        click.echo(f"IAM Group '{group_name}' deleted successfully.")
    except ClientError as e:
        click.echo(f"Failed to delete IAM group: {e}", err=True)

@aws.command(name="list-iam-users", help="List all IAM users.")
def list_iam_users_command():
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        response = iam_client.list_users()
        users = response['Users']
        for user in users:
            click.echo(f"User: {user['UserName']} Created: {user['CreateDate']}")
    except ClientError as e:
        click.echo(f"Failed to list IAM users: {e}", err=True)

@aws.command(name="list-iam-roles", help="List all IAM roles.")
def list_iam_roles_command():
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        response = iam_client.list_roles()
        roles = response['Roles']
        for role in roles:
            click.echo(f"Role: {role['RoleName']} Created: {role['CreateDate']}")
    except ClientError as e:
        click.echo(f"Failed to list IAM roles: {e}", err=True)

@aws.command(name="list-iam-groups", help="List all IAM groups.")
def list_iam_groups_command():
    credentials = load_aws_credentials()
    iam_client = boto3.client('iam', **{k: v for k, v in credentials.items() if k != 'region_name'})
    try:
        response = iam_client.list_groups()
        groups = response['Groups']
        for group in groups:
            click.echo(f"Group: {group['GroupName']} Created: {group['CreateDate']}")
    except ClientError as e:
        click.echo(f"Failed to list IAM groups: {e}", err=True)

from time import sleep

@aws.command(name="create-custom-ami", help="Create a new AMI with specified instance configuration and setup commands.")
@click.option("--config", type=click.Path(exists=True), required=True, help="Path to the YAML configuration file for AMI creation.")
@click.option("--variables", "var_path", type=click.Path(exists=True), required=True, help="Path to the YAML file containing variable values.")
def create_custom_ami(config, var_path):
    # Load AWS credentials
    credentials = load_aws_credentials()

    # Load configuration and variables
    with open(config, 'r') as file:
        config_data = yaml.safe_load(file)
    with open(var_path, 'r') as var_file:
        variables = yaml.safe_load(var_file)

    # Substitute variables
    config_data = inject_variables(config_data, variables)

    ami_config = config_data.get('ami_creation')
    if not ami_config:
        click.echo("Error: 'ami_creation' section not found in configuration file.")
        return
    
    instance_details = ami_config.get('instance')
    if not instance_details:
        click.echo("Error: 'instance' section not found in 'ami_creation'.")
        return

    # Access necessary details
    base_ami_id = instance_details.get('ami_id')
    instance_type = instance_details.get('instance_type')
    security_group = instance_details.get('security_group')
    subnet_id = instance_details.get('subnet_id')
    instance_name = instance_details.get('name', 'ami-temp-instance')
    ami_name = config_data.get('ami_name')

    # Verify required fields
    if not all([base_ami_id, instance_type, security_group, subnet_id, ami_name]):
        click.echo("Error: One or more required fields are missing in the configuration file.")
        return

    # Step 2: Generate SSH Key if Necessary
    check_and_generate_ssh_key()

    # Step 3: Create the Instance
    instance_id, private_ip = launch_temp_instance(
        base_ami_id, instance_type, security_group, subnet_id, instance_name, credentials
    )

    # Wait a bit for SSH to be accessible
    sleep(30)  # Adjust based on average time needed

    # Step 4: Add Host Entry for the Temporary Instance
    add_temporary_host_entry(instance_name, private_ip)

    # Step 5: Run Setup Commands on the Instance
    execute_setup_commands(private_ip, ami_config['commands'])

    # Step 6: Create the AMI from the Configured Instance
    ami_id = create_image_from_instance(instance_id, ami_name, credentials)

    # Step 7: Clean Up - Remove Instance and Host Entry
    delete_temp_instance(instance_id, credentials)
    remove_temporary_host_entry(instance_name)

    click.echo(f"AMI created successfully: {ami_id}")
def inject_variables(config_data, variables):
    """Replace placeholders in config with values from the variables file."""
    def replace_placeholders(obj):
        if isinstance(obj, dict):
            return {k: replace_placeholders(v) for k, v in obj.items()}
        elif isinstance(obj, list):
            return [replace_placeholders(item) for item in obj]
        elif isinstance(obj, str) and obj.startswith("${") and obj.endswith("}"):
            var_name = obj[2:-1]
            return variables.get(var_name, obj)  # Replace with variable or keep original
        return obj

    return replace_placeholders(config_data)

def check_and_generate_ssh_key():
    """Ensure the SSH key is available."""
    if not os.path.exists(SSH_KEY_FILE):
        click.echo("SSH key not found. Generating SSH key...")
        os.system(f"ssh-keygen -t rsa -b 2048 -f {SSH_KEY_FILE[:-4]} -N ''")
        click.echo("SSH key generated.")

def launch_temp_instance(ami_id, instance_type, security_group, subnet_id, instance_name, credentials):
    """Create the temporary instance for AMI preparation without AWS key pair."""
    ec2 = boto3.resource('ec2', **credentials)

    # Prepare user data to inject SSH key
    user_data_script = prepare_ssh_key_injection_script(get_ssh_key_content())

    # Launch instance without specifying KeyName
    instance = ec2.create_instances(
        ImageId=ami_id,
        InstanceType=instance_type,
        SecurityGroupIds=[security_group],
        SubnetId=subnet_id,
        MinCount=1,
        MaxCount=1,
        TagSpecifications=[{
            'ResourceType': 'instance',
            'Tags': [{'Key': 'Name', 'Value': instance_name}]
        }],
        UserData=user_data_script
    )[0]

    # Wait until the instance is ready and retrieve its private IP
    instance.wait_until_running()
    instance.load()
    click.echo(f"Instance {instance.id} created with IP {instance.private_ip_address}")

    return instance.id, instance.private_ip_address


def prepare_ssh_key_injection_script(ssh_key_content):
    """Prepare the user data script to inject SSH key."""
    return f"""#!/bin/bash
    mkdir -p /root/.ssh
    echo "{ssh_key_content}" >> /root/.ssh/authorized_keys
    chmod 700 /root/.ssh
    chmod 600 /root/.ssh/authorized_keys
    """

def get_ssh_key_content():
    """Retrieve the SSH key content."""
    with open(SSH_KEY_FILE, 'r') as file:
        return file.read().strip()

def add_temporary_host_entry(instance_name, private_ip):
    """Add the instance IP and name to the hosts file."""
    entry = f"{private_ip} {instance_name}\n"
    with open(HOSTS_FILE, 'a') as file:
        file.write(entry)
    click.echo(f"Added {instance_name} with IP {private_ip} to {HOSTS_FILE}.")

def execute_setup_commands(private_ip, commands):
    """Execute setup commands on the instance via SSH."""
    for command in commands:
        success, output = execute_remote_command(private_ip, "root", command)
        if success:
            click.echo(f"Executed command: {command}\nOutput: {output}")
        else:
            click.echo(f"Failed to execute command: {command}\nError: {output}")

def execute_remote_command(hostname, username, command):
    """Execute command on the server via SSH."""
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username)
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode()
        error = stderr.read().decode()
        client.close()
        return (True, output) if not error else (False, error)
    except Exception as e:
        return False, str(e)
def create_image_from_instance(instance_id, ami_name, credentials):
    """Create an AMI from the instance."""
    ec2_client = boto3.client('ec2', **credentials)
    response = ec2_client.create_image(InstanceId=instance_id, Name=ami_name, NoReboot=True)
    ami_id = response['ImageId']
    click.echo(f"Creating AMI: {ami_id}. Waiting for completion...")

    # Define a customized waiter with increased attempts and delay
    waiter = ec2_client.get_waiter('image_available')
    try:
        waiter.wait(
            ImageIds=[ami_id],
            WaiterConfig={
                'Delay': 30,  # seconds between each check
                'MaxAttempts': 40  # number of attempts before timing out
            }
        )
    except botocore.exceptions.WaiterError as e:
        click.echo(f"Error: AMI creation timed out. Please verify the AMI status in the AWS Console.")
        raise e

    return ami_id


def delete_temp_instance(instance_id, credentials):
    """Terminate the temporary instance."""
    ec2_client = boto3.client('ec2', **credentials)
    ec2_client.terminate_instances(InstanceIds=[instance_id])
    click.echo(f"Instance {instance_id} terminated.")

def remove_temporary_host_entry(instance_name):
    """Remove the instance entry from the hosts file."""
    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    with open(HOSTS_FILE, 'w') as file:
        for line in lines:
            if instance_name not in line:
                file.write(line)

    click.echo(f"Removed {instance_name} entry from {HOSTS_FILE}.")



#####################################################################################
# A dictionary to temporarily store the identifier and username
context_file = os.path.join(BASE_DIR, "eagle.dob")

# Save active context to eagle.dob
def save_active_context(identifier, username):
    context = {'identifier': identifier, 'username': username}
    with open(context_file, 'w') as f:
        json.dump(context, f)

# Load active context from eagle.dob
def load_active_context():
    if os.path.exists(context_file):
        with open(context_file, 'r') as f:
            return json.load(f)
    return None

@cli.command(name='activation', help="Activate context for Kubernetes or Docker commands")
@click.option('--identifier', required=True, help="Instance identifier")
@click.option('--username', required=True, help="SSH username for the instance")
def set_active_context(identifier, username):
    save_active_context(identifier, username)
    click.echo(f"Active context set: {identifier} with user {username}")

@cli.command(name='doc', help="Execute docker command on a remote server", 
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('docker_command', nargs=-1, type=str)  # Accepts multiple arguments including flags
@click.pass_context
def run_docker(ctx, docker_command):
    # Load the active context from eagle.dob
    active_context = load_active_context()

    # Check if active context is set
    if not active_context:
        click.echo("No active context. Set context first using 'dob activation --identifier <identifier> --username <username>'")
        return

    identifier = active_context['identifier']
    username = active_context['username']

    # Build the docker command as a list
    full_command = ['docker'] + list(docker_command)

    # Translate to the full screenplay command, now with 'aws' added
    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    # Execute the command using subprocess
    try:
        result = subprocess.run(full_screenplay_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        click.echo(result.stdout.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        click.echo(f"Error occurred: {e.stderr.decode('utf-8')}")


@cli.command(name='kub', help="Execute kubectl command on a remote server", 
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('kubectl_command', nargs=-1, type=str)  # Accepts multiple arguments including flags
@click.pass_context
def run_kubectl(ctx, kubectl_command):
    # Load the active context from eagle.dob
    active_context = load_active_context()

    # Check if active context is set
    if not active_context:
        click.echo("No active context. Set context first using 'dob activation --identifier <identifier> --username <username>'")
        return

    identifier = active_context['identifier']
    username = active_context['username']

    # Build the kubectl command
    full_command = ['kubectl'] + list(kubectl_command)

    # Translate to the full screenplay command, now with 'aws' added
    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    # Execute the command using subprocess
    try:
        result = subprocess.run(full_screenplay_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        click.echo(result.stdout.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        click.echo(f"Error occurred: {e.stderr.decode('utf-8')}")

@cli.command(name='ans', help="Execute Ansible command on a remote server",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('ansible_command', nargs=-1, type=str)  # Accepts multiple arguments including flags
@click.pass_context
def run_ansible(ctx, ansible_command):
    # Load the active context from eagle.dob
    active_context = load_active_context()

    # Check if active context is set
    if not active_context:
        click.echo("No active context. Set context first using 'dob activation --identifier <identifier> --username <username>'")
        return

    identifier = active_context['identifier']
    username = active_context['username']

    # Build the Ansible command
    full_command = ['ansible'] + list(ansible_command)

    # Translate to the full screenplay command, now with 'aws' added
    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    # Execute the command using subprocess
    try:
        result = subprocess.run(full_screenplay_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        click.echo(result.stdout.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        click.echo(f"Error occurred: {e.stderr.decode('utf-8')}")

@cli.command(name='tf', help="Execute Terraform command on a remote server",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('terraform_command', nargs=-1, type=str)  # Accepts multiple arguments including flags
@click.pass_context
def run_terraform(ctx, terraform_command):
    # Load the active context from eagle.dob
    active_context = load_active_context()

    # Check if active context is set
    if not active_context:
        click.echo("No active context. Set context first using 'dob activation --identifier <identifier> --username <username>'")
        return

    identifier = active_context['identifier']
    username = active_context['username']

    # Build the Terraform command
    full_command = ['terraform'] + list(terraform_command)

    # Translate to the full screenplay command, now with 'aws' added
    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    # Execute the command using subprocess
    try:
        result = subprocess.run(full_screenplay_command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        click.echo(result.stdout.decode('utf-8'))
    except subprocess.CalledProcessError as e:
        click.echo(f"Error occurred: {e.stderr.decode('utf-8')}")

@cli.command(name='prometheus', help="Execute Prometheus commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('prometheus_command', nargs=-1, type=str)
@click.pass_context
def run_prometheus(ctx, prometheus_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['prometheus'] + list(prometheus_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)


@cli.command(name='packer', help="Execute Packer commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('packer_command', nargs=-1, type=str)
@click.pass_context
def run_packer(ctx, packer_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['packer'] + list(packer_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)


@cli.command(name='vault', help="Execute Vault commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('vault_command', nargs=-1, type=str)
@click.pass_context
def run_vault(ctx, vault_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['vault'] + list(vault_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)


@cli.command(name='consul', help="Execute Consul commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('consul_command', nargs=-1, type=str)
@click.pass_context
def run_consul(ctx, consul_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['consul'] + list(consul_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)


@cli.command(name='istio', help="Execute Istio commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('istio_command', nargs=-1, type=str)
@click.pass_context
def run_istio(ctx, istio_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['istioctl'] + list(istio_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='spinnaker', help="Execute Spinnaker commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('spinnaker_command', nargs=-1, type=str)
@click.pass_context
def run_spinnaker(ctx, spinnaker_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['spinnaker'] + list(spinnaker_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='gitlab', help="Execute GitLab commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('gitlab_command', nargs=-1, type=str)
@click.pass_context
def run_gitlab(ctx, gitlab_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['gitlab'] + list(gitlab_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='artifactory', help="Execute Artifactory commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('artifactory_command', nargs=-1, type=str)
@click.pass_context
def run_artifactory(ctx, artifactory_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['artifactory'] + list(artifactory_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='sonar', help="Execute SonarQube commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('sonar_command', nargs=-1, type=str)
@click.pass_context
def run_sonar(ctx, sonar_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['sonar'] + list(sonar_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='kustomize', help="Execute Kustomize commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('kustomize_command', nargs=-1, type=str)
@click.pass_context
def run_kustomize(ctx, kustomize_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = ['kustomize'] + list(kustomize_command)

    full_screenplay_command = [
        'dob', 'aws', 'screenplay',
        '--identifier', identifier,
        '--username', username,
        '--command', ' '.join(full_command)
    ]

    execute_command(full_screenplay_command)

@cli.command(name='chef', help="Execute Chef commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('chef_command', nargs=-1)
@click.pass_context
def run_chef(ctx, chef_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = "chef " + " ".join(chef_command)
    full_screenplay_command = f'dob aws screenplay --identifier {identifier} --username {username} --command "{full_command}"'
    execute_command(full_screenplay_command)

@cli.command(name='aws_cli', help="Execute AWS CLI commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('aws_command', nargs=-1)
@click.pass_context
def run_aws(ctx, aws_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = "aws " + " ".join(aws_command)
    full_screenplay_command = f'dob aws screenplay --identifier {identifier} --username {username} --command "{full_command}"'
    execute_command(full_screenplay_command)

@cli.command(name='docswarm', help="Execute Docker Swarm commands",
             context_settings={"ignore_unknown_options": True, "allow_extra_args": True})
@click.argument('swarm_command', nargs=-1)
@click.pass_context
def run_swarm(ctx, swarm_command):
    active_context = load_active_context()
    if not active_context:
        click.echo("No active context.")
        return

    identifier = active_context['identifier']
    username = active_context['username']
    full_command = "swarm " + " ".join(swarm_command)
    full_screenplay_command = f'dob aws screenplay --identifier {identifier} --username {username} --command "{full_command}"'
    execute_command(full_screenplay_command)


#########################################create veriable aws screenplay ###################################################################
def create_user_on_server(identifier, username, password=None, permissions=None, create_user_ssh_key=False, category=None):
    try:
        # Get the IP address of the host based on the identifier
        private_ip, _ = get_host_entry(identifier, category)

        # Establish SSH connection to the server
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(private_ip, username='root')

        # Generate a password if not provided
        if not password:
            password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))

        # Encrypt the password
        encrypted_password = crypt.crypt(password, crypt.mksalt(crypt.METHOD_SHA512))

        # Create the user
        create_user_command = f"sudo useradd -m -p '{encrypted_password}' {username}"
        stdin, stdout, stderr = client.exec_command(create_user_command)
        stdout.channel.recv_exit_status()
        output = stdout.read().decode()
        error = stderr.read().decode()
        if error:
            raise Exception(f"Error creating user: {error}")
        click.echo(f"User '{username}' created on server '{identifier}'")

        # Assign permissions if specified
        if permissions:
            permissions_command = f"sudo usermod -aG {permissions} {username}"
            stdin, stdout, stderr = client.exec_command(permissions_command)
            stdout.channel.recv_exit_status()
            error = stderr.read().decode()
            if error:
                raise Exception(f"Error assigning permissions: {error}")
            click.echo(f"Permissions '{permissions}' assigned to user '{username}'")

        # Generate SSH key for the user if required
        if create_user_ssh_key:
            ssh_dir = f"/home/{username}/.ssh"
            client.exec_command(f"sudo mkdir -p {ssh_dir} && sudo chown {username}:{username} {ssh_dir} && chmod 700 {ssh_dir}")
            keygen_command = f"ssh-keygen -t rsa -b 2048 -f {ssh_dir}/id_rsa -q -N ''"
            stdin, stdout, stderr = client.exec_command(f"sudo -u {username} {keygen_command}")
            stdout.channel.recv_exit_status()
            error = stderr.read().decode()
            if error:
                raise Exception(f"Error generating SSH key: {error}")
            click.echo(f"SSH key generated for user '{username}' on server '{identifier}'")

        client.close()
        return True, f"User '{username}' created successfully with{'out' if not password else ''} password."

    except Exception as e:
        return False, str(e)

def create_dynamodb_table(table_data, dynamodb):
    try:
        dynamodb.create_table(
            TableName=table_data['table_name'],
            KeySchema=table_data['key_schema'],
            AttributeDefinitions=table_data['attribute_definitions'],
            ProvisionedThroughput=table_data['provisioned_throughput']
        )
        return table_data['table_name']
    except Exception as e:
        click.echo(f"Failed to create DynamoDB Table: {e}")
        return None



def create_codebuild_project(cb_project_data, cb_client, execution_id):
    try:
        # Create the CodeBuild project using the provided parameters
        response = cb_client.create_project(
            name=cb_project_data['name'],
            source=cb_project_data['source'],
            environment=cb_project_data['environment'],
            serviceRole=cb_project_data['service_role'],
            artifacts=cb_project_data['artifacts'],
            tags=cb_project_data.get('tags', [])
        )

        # Debug: Print the entire response to inspect its structure
        click.echo(f"CreateProject Response: {response}")

        # Extract the project ID from the response (check if 'project' key exists)
        if 'project' in response:
            cb_project_id = response['project']['name']
            click.echo(f"CodeBuild Project created successfully with ID: {cb_project_id}")
            record_task_state(execution_id, 'codebuild_project', 'success', resource_id=cb_project_id)
            return cb_project_id
        else:
            raise ValueError(f"Unexpected response structure: {response}")

    except ClientError as e:
        click.echo(f"Failed to create CodeBuild Project: {e}")
        record_task_state(execution_id, 'codebuild_project', 'failed', resource_id=cb_project_data['name'])
        raise


def start_build(cb_client, project_name, environment_variables=None, source_version=None, execution_id=None):
    """
    Start a build for the specified CodeBuild project.

    Args:
        cb_client: The CodeBuild client object.
        project_name: Name of the CodeBuild project to start a build.
        environment_variables: A list of environment variables to pass to the build (optional).
        source_version: The source version (branch, tag, or commit) to build (optional).
        execution_id: The unique ID of the current execution for logging and state tracking.

    Returns:
        build_id: The ID of the initiated build.
        build_status: The status of the build upon initiation.
    """
    try:
        # Prepare build parameters
        build_params = {
            'projectName': project_name
        }
        if environment_variables:
            build_params['environmentVariablesOverride'] = environment_variables
        if source_version:
            build_params['sourceVersion'] = source_version

        # Start the build
        response = cb_client.start_build(**build_params)

        # Extract build details
        build_id = response['build']['id']
        build_status = response['build']['buildStatus']
        click.echo(f"Build started for project '{project_name}' with Build ID: {build_id}")

        # Record the build details in the state file
        record_task_state(execution_id, 'codebuild_build', 'success', resource_id=build_id)
        return build_id, build_status

    except ClientError as e:
        click.echo(f"Failed to start build for project '{project_name}': {e}")
        record_task_state(execution_id, 'codebuild_build', 'failed', resource_id=project_name)
        raise



def create_nat_gateway(nat_gw_data, ec2, execution_id):
    try:
        response = ec2.create_nat_gateway(
            SubnetId=nat_gw_data['subnet_id'],
            AllocationId=nat_gw_data['allocation_id']
        )
        nat_gw_id = response['NatGateway']['NatGatewayId']

        # Add tags if any
        if 'tags' in nat_gw_data:
            ec2.create_tags(Resources=[nat_gw_id], Tags=nat_gw_data['tags'])

        # Record the NAT Gateway creation in the state file
        record_task_state(execution_id, 'nat_gateway', 'success', resource_id=nat_gw_id)
        return nat_gw_id

    except ClientError as e:
        click.echo(f"Failed to create NAT Gateway: {e}")
        record_task_state(execution_id, 'nat_gateway', 'failed', resource_id=nat_gw_data.get('allocation_id'))
        raise


def register_targets(elb_client, target_group_arn, targets, execution_id=None):
    try:
        response = elb_client.register_targets(
            TargetGroupArn=target_group_arn,
            Targets=[{'Id': target} for target in targets]
        )

        if execution_id:
            record_task_state(execution_id, 'target_registration', 'success', resource_id=target_group_arn)

        return response

    except ClientError as e:
        click.echo(f"Failed to register targets: {e}")
        if execution_id:
            record_task_state(execution_id, 'target_registration', 'failed', resource_id=target_group_arn)
        raise



def create_internet_gateway(vpc_id, igw_data, ec2, execution_id, resource_outputs):
    try:
        # Create the Internet Gateway
        response = ec2.create_internet_gateway()
        igw_id = response['InternetGateway']['InternetGatewayId']
        click.echo(f"Created Internet Gateway with ID: {igw_id}")

        # Attach the Internet Gateway to the VPC
        ec2.attach_internet_gateway(InternetGatewayId=igw_id, VpcId=vpc_id)
        click.echo(f"Attached Internet Gateway {igw_id} to VPC {vpc_id}")

        # Add tags if any
        if 'tags' in igw_data:
            ec2.create_tags(Resources=[igw_id], Tags=igw_data['tags'])
            click.echo(f"Tags added to Internet Gateway {igw_id}")

        resource_outputs['internet_gateway_id'] = igw_id

        # Record the Internet Gateway creation in the state file
        record_task_state(execution_id, 'internet_gateway', 'success', resource_id=igw_id)


        return igw_id

    except ClientError as e:
        click.echo(f"Failed to create or attach Internet Gateway: {e}")
        # Record the failure in the state file
        record_task_state(execution_id, 'internet_gateway', 'failed', resource_id=None)
        raise

def create_vpc(vpc_data, ec2, execution_id):
    try:
        response = ec2.create_vpc(
            CidrBlock=vpc_data['cidr_block'],
            AmazonProvidedIpv6CidrBlock=False,
            InstanceTenancy='default'
        )

        vpc_id = response['Vpc']['VpcId']
        ec2.create_tags(Resources=[vpc_id], Tags=vpc_data.get('tags', []))

        # Record the VPC creation in the snapshot (state file)
        record_task_state(execution_id, 'vpc_creation', 'success', resource_id=vpc_id)

        return vpc_id
    except ClientError as e:
        click.echo(click.style(f"Failed to create vpc: {e}", fg="red"))
        return None


def create_target_group(elb_client, name, vpc_id, protocol, port, target_type, health_check_protocol, health_check_port, tags, execution_id):
    """Create a target group and record its state."""
    try:
        # Create the target group
        response = elb_client.create_target_group(
            Name=name,
            Protocol=protocol,
            Port=port,
            VpcId=vpc_id,
            TargetType=target_type,
            HealthCheckProtocol=health_check_protocol,
            HealthCheckPort=str(health_check_port)
        )
        target_group_arn = response['TargetGroups'][0]['TargetGroupArn']

        # Add tags if any
        if tags:
            elb_client.add_tags(ResourceArns=[target_group_arn], Tags=tags)

        click.echo(f"Target Group created with ARN: {target_group_arn}")

        # Record the creation in the state file (consistent naming)
        record_task_state(execution_id, 'target_group', 'success', resource_id=target_group_arn)

        return target_group_arn
    except Exception as e:
        click.echo(click.style(f"Failed to create target group: {e}", fg="red"))
        record_task_state(execution_id, 'target_group', 'failed')
        return None


def create_load_balancer(lb_data, elb_client, execution_id):
    """Create a load balancer and record its state."""
    # Initialize an empty dictionary to store unique tags
    unique_tags = {}

    # Collect tags from the lb_data
    for tag in lb_data.get('tags', []):
        key = tag['Key']
        value = tag['Value']
        # Ensure each tag key is unique
        unique_tags[key] = value

    # Convert the dictionary back to a list of dictionaries as required by AWS
    formatted_tags = [{'Key': k, 'Value': v} for k, v in unique_tags.items()]

    try:
        # Create the load balancer
        response = elb_client.create_load_balancer(
            Name=lb_data['name'],
            Subnets=lb_data['subnets'],
            SecurityGroups=lb_data['security_groups'],
            Scheme=lb_data.get('scheme', 'internet-facing'),
            Type=lb_data.get('type', 'application'),
            IpAddressType='ipv4',
            Tags=formatted_tags  # Use the correctly formatted tags
        )

        lb_arn = response['LoadBalancers'][0]['LoadBalancerArn']
        click.echo(f"Load Balancer created with ARN: {lb_arn}")

        # Record the creation in the state file
        record_task_state(execution_id, 'load_balancer', 'success', resource_id=lb_arn)

        return lb_arn
    except Exception as e:
        click.echo(click.style(f"Failed to create load balancer: {e}", fg="red"))
        record_task_state(execution_id, 'load_balancer', 'failed')
        return None

def create_listener(elb_client, load_balancer_arn, protocol, port, target_group_arn=None, ssl_certificate_arn=None, action_type='forward', execution_id=None):
    try:
        actions = []
        if action_type == 'forward':
            if not target_group_arn:
                raise ValueError("Target Group ARN is required for 'forward' action type.")
            actions.append({
                'Type': 'forward',
                'TargetGroupArn': target_group_arn
            })
        elif action_type == 'redirect':
            actions.append({
                'Type': 'redirect',
                'RedirectConfig': {
                    # Fill with required redirect config parameters if needed
                }
            })
        # Add more action types if needed

        listener_params = {
            'LoadBalancerArn': load_balancer_arn,
            'Protocol': protocol,
            'Port': int(port),
            'DefaultActions': actions
        }

        if protocol in ['HTTPS', 'TLS']:
            if not ssl_certificate_arn:
                raise ValueError("SSL Certificate ARN is required for HTTPS or TLS listeners.")
            listener_params['Certificates'] = [{'CertificateArn': ssl_certificate_arn}]

        listener_response = elb_client.create_listener(**listener_params)
        listener_arn = listener_response['Listeners'][0]['ListenerArn']

        # Record the creation in the state file
        record_task_state(execution_id, 'listener', 'success', resource_id=listener_arn)


        return listener_arn
    except ClientError as e:
        click.echo(f"Failed to create listener: {e}")
        return None

def create_rds_subnet_group(subnet_group_data, rds_client, execution_id):
    """
    Create an RDS Subnet Group using the given configuration.

    Args:
        subnet_group_data (dict): Configuration data for the RDS Subnet Group.
        rds_client (boto3.client): Boto3 client for RDS.
        execution_id (str): The execution ID for this run.

    Returns:
        str: The DBSubnetGroupName created.
    """
    # Create the RDS Subnet Group
    try:
        response = rds_client.create_db_subnet_group(
            DBSubnetGroupName=subnet_group_data['name'],
            SubnetIds=subnet_group_data['subnets'],
            DBSubnetGroupDescription=subnet_group_data['description'],
            Tags=subnet_group_data.get('tags', [])
        )
        db_subnet_group_name = response['DBSubnetGroup']['DBSubnetGroupName']
        click.echo(f"RDS Subnet Group created with Name: {db_subnet_group_name}")

        # Record the creation in the state file
        record_task_state(execution_id, 'rds_subnet_group', 'success', resource_id=db_subnet_group_name)
        return db_subnet_group_name
    except ClientError as e:
        click.echo(click.style(f"Failed to create RDS Subnet Group: {e}", fg="red"))
        record_task_state(execution_id, f'rds_subnet_group_{subnet_group_data["name"]}', 'failed')
        return None


def create_subnet(vpc_id, cidr_block, availability_zone, tags, ec2, execution_id, depends_on=None):
    """
    Create a subnet in a specified VPC with optional dependency checks.

    :param vpc_id: ID of the VPC to create the subnet in.
    :param cidr_block: CIDR block of the subnet.
    :param availability_zone: Availability Zone to create the subnet in.
    :param tags: Tags to add to the subnet.
    :param ec2: EC2 client object.
    :param execution_id: The execution ID for tracking the state.
    :param depends_on: List of dependencies to check before creating the subnet.
    :return: The created Subnet ID or None if creation failed.
    """
    # Check if dependencies are met
    if depends_on:
        dependencies_met, unmet_dependency = check_dependencies(execution_id, depends_on)
        if not dependencies_met:
            click.echo(click.style(f"Cannot create Subnet. Dependency '{unmet_dependency}' not met.", fg="red"))
            return None

    try:
        # Create the subnet in the specified VPC
        response = ec2.create_subnet(
            VpcId=vpc_id,
            CidrBlock=cidr_block,
            AvailabilityZone=availability_zone
        )
        subnet_id = response['Subnet']['SubnetId']

        # Add tags to the subnet
        if tags:
            ec2.create_tags(Resources=[subnet_id], Tags=tags)

        # Record the subnet creation in the state file
        record_task_state(execution_id, 'subnet_creation', 'success', resource_id=subnet_id)
        click.echo(f"Subnet created with ID: {subnet_id} in VPC: {vpc_id}")

        return subnet_id
    except ClientError as e:
        click.echo(click.style(f"Failed to create subnet: {e}", fg="red"))
        # Record the failure in the state file
        record_task_state(execution_id, 'subnet_creation', 'failed', resource_id=None)
        return None


def create_eks_nodegroup(nodegroup_data, eks_client, execution_id):
    try:
        # Convert the list of tags to a dictionary as required by the boto3 API
        tags_dict = {tag['Key']: tag['Value'] for tag in nodegroup_data.get('tags', [])}

        # Create the node group
        response = eks_client.create_nodegroup(
            clusterName=nodegroup_data['clusterName'],
            nodegroupName=nodegroup_data['name'],
            nodeRole=nodegroup_data['nodeRole'],
            subnets=nodegroup_data['subnets'],
            scalingConfig={
                'minSize': nodegroup_data['scalingConfig']['minSize'],
                'maxSize': nodegroup_data['scalingConfig']['maxSize'],
                'desiredSize': nodegroup_data['scalingConfig']['desiredSize']
            },
            instanceTypes=nodegroup_data['instanceTypes'],
            tags=tags_dict  # Pass the converted tags dictionary
        )

        # Record the creation in the state file
        record_task_state(execution_id, 'eks_nodegroup', 'success', resource_id=response['nodegroup']['nodegroupName'])

        return response['nodegroup']['nodegroupName']
    except ClientError as e:
        click.echo(f"Failed to create EKS Node Group: {e}")
        record_task_state(execution_id, 'eks_nodegroup_creation', 'failed')
        return None


def create_eks_cluster(eks_cluster_data, eks_client, execution_id, version):
    try:
        response = eks_client.create_cluster(
            name=eks_cluster_data['name'],
            version=version,
            roleArn=eks_cluster_data['role_arn'],
            resourcesVpcConfig={
                'subnetIds': eks_cluster_data['resources_vpc_config']['subnetIds'],
                'securityGroupIds': eks_cluster_data['resources_vpc_config'].get('securityGroupIds', []),
                'endpointPublicAccess': eks_cluster_data['resources_vpc_config'].get('endpointPublicAccess', True),
                'endpointPrivateAccess': eks_cluster_data['resources_vpc_config'].get('endpointPrivateAccess', False)
            }
        )
        cluster_name = response['cluster']['name']

        # Record the cluster creation in the state file
        record_task_state(execution_id, 'eks_cluster', 'success', resource_id=cluster_name)

        return cluster_name
    except ClientError as e:
        click.echo(f"Failed to create EKS Cluster: {e}")
        record_task_state(execution_id, 'eks_cluster_creation', 'failed')
        return None

def wait_for_cluster_active(eks_client, cluster_name):
    while True:
        response = eks_client.describe_cluster(name=cluster_name)
        status = response['cluster']['status']
        if status == 'ACTIVE':
            click.echo(f"EKS Cluster {cluster_name} is active and ready.")
            break
        elif status in ['CREATING', 'UPDATING']:
            click.echo(f"EKS Cluster {cluster_name} is in status {status}. Waiting for it to become active...")
            time.sleep(30)  # Wait for 30 seconds before checking again
        else:
            raise RuntimeError(f"EKS Cluster {cluster_name} is in an invalid state: {status}")



def create_elastic_ip(eip_data, ec2, execution_id):
    try:
        # Allocate the Elastic IP
        response = ec2.allocate_address(Domain=eip_data.get('domain', 'vpc'))
        allocation_id = response['AllocationId']
        public_ip = response['PublicIp']

        # Associate the Elastic IP with the specified instance if provided
        if 'instance_id' in eip_data:
            ec2.associate_address(
                InstanceId=eip_data['instance_id'],
                AllocationId=allocation_id
            )

        # Add tags if specified
        if 'tags' in eip_data:
            ec2.create_tags(Resources=[allocation_id], Tags=eip_data['tags'])

        # Log the Elastic IP creation in the state file
        record_task_state(execution_id, 'elastic_ip', 'success', resource_id=allocation_id)

        click.echo(f"Elastic IP {public_ip} created with Allocation ID {allocation_id}.")
        return allocation_id, public_ip

    except ClientError as e:
        click.echo(f"Failed to create Elastic IP: {e}")
        record_task_state(execution_id, 'elastic_ip', 'failed', resource_id=None)
        raise


def create_ec2_instances(
        instance_type,
        ami_id,
        key_name,
        security_group,
        loop_item,
        count,
        tags,
        user_data=None,
        execution_id=None):

    credentials = load_aws_credentials()
    if not credentials:
        click.echo("No AWS credentials found. Please configure them first.")
        return None

    ec2 = boto3.client('ec2', **credentials)
    try:
        instances = ec2.run_instances(
            InstanceType=instance_type,
            ImageId=ami_id,
            KeyName=key_name,
            SecurityGroupIds=[security_group],
            MinCount=count,
            MaxCount=count,
            TagSpecifications=[{
                'ResourceType': 'instance',
                'Tags': [{'Key': key, 'Value': value} for key, value in tags.items()]
            }],
            UserData=user_data
        )

        instance_ids = [instance['InstanceId'] for instance in instances['Instances']]

        # Record the instance creation in the state file
        for instance_id in instance_ids:
            record_task_state(execution_id, 'ec2_instance', 'success', resource_id=instance_id)

        return instance_ids
    except ClientError as e:
        click.echo(click.style(f"Failed to create instances: {e}", fg="red"))
        return None



def create_security_group(vpc_id, sg_data, ec2, execution_id):
    try:
        # Create the Security Group
        response = ec2.create_security_group(
            VpcId=vpc_id,
            GroupName=sg_data['name'],
            Description=sg_data['description']
        )

        sg_id = response['GroupId']
        click.echo(f"Security Group {sg_id} created in VPC {vpc_id}")

        # Create the security group ingress rules
        ip_permissions = []
        for rule in sg_data['inbound_rules']:
            if isinstance(rule['port_range'], str):
                from_port = int(rule['port_range'].split('-')[0])
                to_port = int(rule['port_range'].split('-')[1])
            elif isinstance(rule['port_range'], int):
                from_port = to_port = rule['port_range']
            else:
                raise ValueError(f"Invalid port_range format: {rule['port_range']}")

            ip_permissions.append({
                'IpProtocol': rule['protocol'],
                'FromPort': from_port,
                'ToPort': to_port,
                'IpRanges': [{'CidrIp': rule['cidr_blocks']}]
            })

        # Authorize security group ingress with the constructed rules
        ec2.authorize_security_group_ingress(GroupId=sg_id, IpPermissions=ip_permissions)
        click.echo(f"Ingress rules applied to Security Group {sg_id}")

        # Add tags to the security group
        ec2.create_tags(Resources=[sg_id], Tags=sg_data.get('tags', []))

        # Record the Security Group creation in the state file
        record_task_state(execution_id, 'security_group', 'success', resource_id=sg_id)

        return sg_id

    except ClientError as e:
        click.echo(f"Failed to create Security Group: {e}")
        record_task_state(execution_id, 'security_group', 'failed', resource_id=None)
        raise

def create_route_table(vpc_id, route_data, ec2, execution_id, resource_outputs):
    try:
        # Create the route table
        response = ec2.create_route_table(VpcId=vpc_id)
        route_table_id = response['RouteTable']['RouteTableId']
        click.echo(f"Created Route Table with ID: {route_table_id}")

        # Create tags for the route table if specified
        if 'tags' in route_data:
            ec2.create_tags(Resources=[route_table_id], Tags=route_data['tags'])
            click.echo(f"Tags added to Route Table {route_table_id}")

        # Add routes to the route table
        for route in route_data.get('routes', []):

            # Retrieve the gateway ID from resource_outputs or the route configuration
            gateway_id = resource_outputs.get('internet_gateway_id') or route.get('gateway_id')
            if not gateway_id:
                raise ValueError("Internet Gateway ID is required for creating a route but was not found in the configuration or resource outputs.")

            # Add the route to the route table
            ec2.create_route(
                RouteTableId=route_table_id,
                DestinationCidrBlock=route['destination_cidr_block'],
                GatewayId=gateway_id  # Use the resolved gateway_id
            )
            click.echo(f"Route {route['destination_cidr_block']} added to Route Table {route_table_id}")
            record_task_state(execution_id, f'route_{route_table_id}_{route["destination_cidr_block"]}', 'success', resource_id=route_table_id)



        # Record the Route Table creation in the state file
        record_task_state(execution_id, 'route_table', 'success', resource_id=route_table_id)

        return route_table_id

    except ClientError as e:
        click.echo(f"Failed to create Route Table: {e}")
        # Record the failure in the state file
        record_task_state(execution_id, 'route_table', 'failed', resource_id=None)
        raise


def create_rds_instance(rds_instance_data, rds, execution_id):
    rds_params = {
        'DBInstanceIdentifier': rds_instance_data['db_instance_identifier'],
        'DBInstanceClass': rds_instance_data['db_instance_class'],
        'Engine': rds_instance_data['engine'],
        'MasterUsername': rds_instance_data['master_username'],
        'MasterUserPassword': rds_instance_data['master_user_password'],
        'AllocatedStorage': rds_instance_data['allocated_storage'],
        'VpcSecurityGroupIds': rds_instance_data['vpc_security_group_ids']
    }

    # Add EngineVersion only if provided, otherwise let AWS choose the default
    if 'engine_version' in rds_instance_data:
        rds_params['EngineVersion'] = rds_instance_data['engine_version']

    # Add tags during creation
    if 'tags' in rds_instance_data:
        rds_params['Tags'] = rds_instance_data['tags']

    try:
        response = rds.create_db_instance(**rds_params)

        db_instance_id = response['DBInstance']['DBInstanceIdentifier']
        db_instance_arn = response['DBInstance']['DBInstanceArn']

        # Log the creation in the state file
        click.echo(f"RDS instance {db_instance_id} creation started.")
        record_task_state(execution_id, 'rds_instance', 'success', resource_id=db_instance_id)

        # Wait for the RDS instance to be available
        waiter = rds.get_waiter('db_instance_available')
        click.echo(f"Waiting for RDS instance {db_instance_id} to become available...")
        waiter.wait(DBInstanceIdentifier=db_instance_id)

        click.echo(f"RDS instance {db_instance_id} is now available.")
        return db_instance_id

    except ClientError as e:
        click.echo(f"Error creating RDS instance: {e}")
        record_task_state(execution_id, 'rds_instance', 'failed', resource_id=rds_instance_data['db_instance_identifier'])
        raise

def create_s3_bucket(bucket_name, region=None, public_access_block=True, versioning=False, lifecycle_rules=None, logging=None, encryption=None, execution_id=None):
    try:
        credentials = load_aws_credentials()
        s3 = boto3.client('s3', region_name=region, aws_access_key_id=credentials['aws_access_key_id'], aws_secret_access_key=credentials['aws_secret_access_key'])

        click.echo(f"Creating S3 bucket '{bucket_name}' in region '{region or 'us-east-1'}'")
        create_bucket_params = {'Bucket': bucket_name}

        # Only add the region configuration if a region is specified and it is not us-east-1
        if region and region != 'us-east-1':
            create_bucket_params['CreateBucketConfiguration'] = {'LocationConstraint': region}

        # Create the bucket
        s3.create_bucket(**create_bucket_params)
        click.echo(f"S3 Bucket '{bucket_name}' created successfully.")

        # Apply public access block settings if specified
        if public_access_block:
            s3.put_public_access_block(
                Bucket=bucket_name,
                PublicAccessBlockConfiguration={
                    'BlockPublicAcls': True,
                    'IgnorePublicAcls': True,
                    'BlockPublicPolicy': True,
                    'RestrictPublicBuckets': True
                }
            )
            click.echo(f"Public access blocked for S3 Bucket '{bucket_name}'")

        # Enable versioning if specified
        if versioning:
            s3.put_bucket_versioning(
                Bucket=bucket_name,
                VersioningConfiguration={'Status': 'Enabled'}
            )
            click.echo(f"Versioning enabled for S3 Bucket '{bucket_name}'")

        # Apply lifecycle rules if specified
        if lifecycle_rules and isinstance(lifecycle_rules, list):
            s3.put_bucket_lifecycle_configuration(
                Bucket=bucket_name,
                LifecycleConfiguration={'Rules': lifecycle_rules}
            )
            click.echo(f"Lifecycle rules applied to S3 Bucket '{bucket_name}'")

        # Enable logging if specified
        if logging and isinstance(logging, dict):
            s3.put_bucket_logging(
                Bucket=bucket_name,
                BucketLoggingStatus={'LoggingEnabled': logging}
            )
            click.echo(f"Logging enabled for S3 Bucket '{bucket_name}'")

        # Apply encryption settings if specified
        if encryption and isinstance(encryption, dict):
            s3.put_bucket_encryption(
                Bucket=bucket_name,
                ServerSideEncryptionConfiguration={'Rules': [{'ApplyServerSideEncryptionByDefault': encryption}]}
            )
            click.echo(f"Encryption applied to S3 Bucket '{bucket_name}'")

        # Record the S3 bucket creation in the state file
        if execution_id:
            record_task_state(execution_id, 's3_bucket', 'success', resource_id=bucket_name)

    except ClientError as e:
        click.echo(f"Failed to create S3 Bucket '{bucket_name}': {e}")
        if execution_id:
            record_task_state(execution_id, 's3_bucket', 'failed', resource_id=bucket_name)
        raise

def create_network_interface(network_interface_data, ec2, execution_id):
    try:
        # Create the network interface
        response = ec2.create_network_interface(
            SubnetId=network_interface_data['subnet_id'],
            Description=network_interface_data.get('description', ''),
            Groups=network_interface_data.get('groups', [])
        )
        network_interface_id = response['NetworkInterface']['NetworkInterfaceId']

        # Add tags to the network interface
        if 'tags' in network_interface_data:
            ec2.create_tags(Resources=[network_interface_id], Tags=network_interface_data['tags'])

        # Record the Network Interface creation in the state file
        record_task_state(execution_id, 'network_interface', 'success', resource_id=network_interface_id)


        return network_interface_id

    except ClientError as e:
        click.echo(f"Failed to create Network Interface: {e}")
        record_task_state(execution_id, 'network_interface', 'failed', resource_id=network_interface_data.get('subnet_id'))
        raise


def ssl_certificate_request(acm_client, domain_name, validation_method, subject_alternative_names, tags):
    try:
        # Correct the tag processing
        formatted_tags = []
        for tag in tags:
            key_value_pair = tag.split('=', 1)  # Split on the first '=' only
            if len(key_value_pair) == 2:
                key = key_value_pair[0].strip()
                value = key_value_pair[1].strip()
                if not key or not value:
                    raise ValueError(f"Invalid tag format: '{tag}'. Key and Value must not be empty.")
                formatted_tags.append({'Key': key, 'Value': value})
            else:
                raise ValueError(f"Invalid tag format: '{tag}'. Expected format is Key=Value.")

        response = acm_client.request_certificate(
            DomainName=domain_name,
            ValidationMethod=validation_method,
            SubjectAlternativeNames=list(subject_alternative_names),
            Tags=formatted_tags
        )
        certificate_arn = response['CertificateArn']

        return certificate_arn

    except ClientError as e:
        click.echo(f"Failed to request SSL certificate: {e}", err=True)
    except NoCredentialsError as e:
        click.echo(f"AWS credentials error: {e}", err=True)
    except Exception as e:
        click.echo(f"An unexpected error occurred: {e}", err=True)

##########################################################################################
# JENKINS Command Group
@cli.group(help="Commands to manage Jenkins server.")
def jenkins():
    pass



@jenkins.command(name="create-credential", help="Create a Jenkins credential.")
@click.option('--credential_id', required=True, help="Unique ID for the credential")
@click.option('--credential_type', required=True, type=click.Choice(['ssh', 'username_password', 'secret_text', 'secret_file']), help="Type of credential to create")
@click.option('--username', required=False, help="Username for username-password or SSH credentials")
@click.option('--private_key', required=False, help="Private SSH Key (required if creating SSH credential)")
@click.option('--password', required=False, help="Password for username-password credential (required if creating username-password credential)")
@click.option('--secret_text', required=False, help="Secret text for Secret Text credential (required if creating secret text credential)")
@click.option('--secret_file_path', required=False, help="Path to secret file for Secret File credential (required if creating secret file credential)")
@click.option('--description', default="", help="Description for the credential")
def create_jenkins_credential(credential_id, credential_type, username, private_key, password, secret_text, secret_file_path, description):
    """
    Create a Jenkins credential using the Jenkins REST API.
    Supports creating SSH credentials, username-password credentials, secret text credentials, and secret file credentials.
    """
    try:
        # Step 1: Load Jenkins credentials
        jenkins_credentials = load_jenkins_credentials()
        if not jenkins_credentials:
            click.echo("Failed to load Jenkins credentials. Please configure Jenkins credentials first.")
            return

        jenkins_url = jenkins_credentials['jenkins_url']
        jenkins_username = jenkins_credentials['username']
        api_token = jenkins_credentials['api_token']

        # Step 2: Construct URL for creating the credential
        credential_url = f"{jenkins_url}/credentials/store/system/domain/_/createCredentials"

        # Step 3: Get Jenkins Crumb for CSRF protection
        crumb_value = get_jenkins_crumb(jenkins_url, jenkins_username, api_token)

        # Step 4: Set headers with Jenkins Crumb
        headers = {
            'Jenkins-Crumb': crumb_value,
            'Content-Type': 'application/xml'
        }

        # Step 5: Define XML payloads based on the credential type
        if credential_type == 'ssh':
            if not username or not private_key:
                click.echo("For SSH credentials, --username and --private_key are required.")
                return

            # SSH Credential XML Payload
            credential_xml = f"""
            <com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey>
                <scope>GLOBAL</scope>
                <id>{credential_id}</id>
                <description>{description}</description>
                <username>{username}</username>
                <privateKeySource class="com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey$DirectEntryPrivateKeySource">
                    <privateKey>{private_key}</privateKey>
                </privateKeySource>
                <passphrase></passphrase>
            </com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey>
            """

        elif credential_type == 'username_password':
            if not username or not password:
                click.echo("For username-password credentials, --username and --password are required.")
                return

            # Username-Password Credential XML Payload
            credential_xml = f"""
            <com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl>
                <scope>GLOBAL</scope>
                <id>{credential_id}</id>
                <description>{description}</description>
                <username>{username}</username>
                <password>{password}</password>
            </com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl>
            """

        elif credential_type == 'secret_text':
            if not secret_text:
                click.echo("For secret text credentials, --secret_text is required.")
                return

            # Secret Text Credential XML Payload
            credential_xml = f"""
            <org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl>
                <scope>GLOBAL</scope>
                <id>{credential_id}</id>
                <description>{description}</description>
                <secret>{secret_text}</secret>
            </org.jenkinsci.plugins.plaincredentials.impl.StringCredentialsImpl>
            """

        elif credential_type == 'secret_file':
            if not secret_file_path or not os.path.exists(secret_file_path):
                click.echo("For secret file credentials, --secret_file_path must be a valid file path.")
                return

            # Read the file content and base64 encode it
            with open(secret_file_path, 'rb') as f:
                secret_file_content = base64.b64encode(f.read()).decode('utf-8')

            # Secret File Credential XML Payload
            credential_xml = f"""
            <org.jenkinsci.plugins.plaincredentials.impl.FileCredentialsImpl>
                <scope>GLOBAL</scope>
                <id>{credential_id}</id>
                <description>{description}</description>
                <fileName>{os.path.basename(secret_file_path)}</fileName>
                <secretBytes>{secret_file_content}</secretBytes>
            </org.jenkinsci.plugins.plaincredentials.impl.FileCredentialsImpl>
            """

        # Step 6: POST request to create the credential
        response = requests.post(credential_url, auth=HTTPBasicAuth(jenkins_username, api_token), headers=headers, data=credential_xml)

        # Step 7: Handle response
        if response.status_code in [200, 201, 204]:
            click.echo(f"Credential '{credential_id}' created successfully.")
        else:
            click.echo(f"Failed to create credential '{credential_id}'. Status code: {response.status_code}")
            click.echo(f"Response: {response.text}")

    except Exception as e:
        click.echo(f"An error occurred: {str(e)}")

@jenkins.command(name="create-user", help="Create a new Jenkins user using stored credentials.")
@click.option('--new_user', required=True, help="New username to register in Jenkins")
@click.option('--new_password', required=True, help="Password for the new user")
@click.option('--full_name', required=True, help="Full name of the new user")
@click.option('--email', required=True, help="Email of the new user")
def create_jenkins_user(new_user, new_password, full_name, email):
    """
    Register a new Jenkins user using stored credentials and configuration.
    """
    # Load the saved Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        click.echo("Failed to load Jenkins credentials. Please configure Jenkins first using `configure-jenkins`.")
        return

    jenkins_url = credentials['jenkins_url']
    admin_username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins endpoint for creating a new user
    create_user_url = f"{jenkins_url}/securityRealm/createAccountByAdmin"

    # Form data for creating the user
    form_data = {
        'username': new_user,
        'password1': new_password,
        'password2': new_password,
        'fullname': full_name,
        'email': email
    }

    try:
        # CSRF protection crumb
        headers = {
            'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, admin_username, api_token)
        }

        # POST request to create the user
        response = requests.post(create_user_url, auth=HTTPBasicAuth(admin_username, api_token), data=form_data, headers=headers)

        if response.status_code == 200:
            click.echo(f"User '{new_user}' created successfully.")
        elif response.status_code == 400:
            click.echo(f"Failed to create user '{new_user}'. Response: {response.text}")
        else:
            click.echo(f"Unexpected error. Status code: {response.status_code}")
            click.echo(f"Response: {response.text}")

    except Exception as e:
        click.echo(f"An error occurred while creating the user: {str(e)}")

@jenkins.command(name="token", help="Retrieve Jenkins API token using existing credentials.")
@click.option('--token-name', required=True, help="Name for the new API token.")
def get_jenkins_token(token_name):
    """
    Retrieve Jenkins API token using the saved Jenkins credentials and save it locally.
    """
    # Load Jenkins credentials from the configuration file
    credentials = load_jenkins_credentials()

    if not credentials:
        print("Jenkins credentials not found. Please configure Jenkins using 'dob configure-jenkins' first.")
        return

    # Extract saved Jenkins URL and username
    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    password = credentials.get('password', None)  # Optional, based on how it was saved

    # URLs for crumb and token generation
    crumb_url = f"{jenkins_url}{JENKINS_CRUMB_URL}"
    token_url = f"{jenkins_url}{JENKINS_TOKEN_URL}?newTokenName={token_name}"

    # Step 1: Retrieve CSRF Crumb
    try:
        print("Retrieving crumb...")
        crumb_response = requests.get(crumb_url, auth=(username, password), cookies={}, timeout=10)
        crumb_response.raise_for_status()

        crumb_data = crumb_response.json()
        crumb_value = crumb_data['crumb']
        crumb_request_field = crumb_data['crumbRequestField']
        print(f"Crumb retrieved successfully: {crumb_value}")

    except requests.exceptions.RequestException as e:
        print(f"Error retrieving crumb: {e}")
        return

    # Step 2: Use crumb to get API token
    try:
        print("Requesting new API token...")
        headers = {crumb_request_field: crumb_value}
        cookies = crumb_response.cookies
        token_response = requests.post(token_url, auth=(username, password), cookies=cookies, headers=headers, timeout=10)
        token_response.raise_for_status()

        token_data = token_response.json()
        new_token = token_data['data']['tokenValue']
        print(f"New token generated successfully: {new_token}")

        # Update the local credentials file with the new token
        credentials['api_token'] = new_token
        save_jenkins_credentials(credentials)
        print(f"Jenkins credentials updated with new token.")

    except requests.exceptions.RequestException as e:
        print(f"Error generating token: {e}")


@jenkins.command(name="configure", help="Configure Jenkins and save credentials locally.")
@click.option('--ip', required=True, help="Jenkins server IP.")
@click.option('-u', '--user', required=True, help="Jenkins user in format username:password.")
@click.option('--token-name', required=True, help="Name for the new API token.")
@click.option('--job-name', required=True, help="Jenkins Job Name.")
def configure_jenkins(ip, user, token_name, job_name):
    jenkins_url = f"http://{ip}:8080"
    crumb_url = f"{jenkins_url}{JENKINS_CRUMB_URL}"
    token_url = f"{jenkins_url}{JENKINS_TOKEN_URL}?newTokenName={token_name}"

    # Step 1: Retrieve CSRF Crumb
    try:
        print("Retrieving crumb...")
        crumb_response = requests.get(crumb_url, auth=(user.split(":")[0], user.split(":")[1]), cookies={}, timeout=10)
        crumb_response.raise_for_status()

        crumb_data = crumb_response.json()
        crumb_value = crumb_data['crumb']
        crumb_request_field = crumb_data['crumbRequestField']
        print(f"Crumb retrieved successfully: {crumb_value}")

    except requests.exceptions.RequestException as e:
        print(f"Error retrieving crumb: {e}")
        return

    # Step 2: Use crumb to get API token
    try:
        print("Requesting new API token...")
        headers = {crumb_request_field: crumb_value}
        cookies = crumb_response.cookies
        token_response = requests.post(token_url, auth=(user.split(":")[0], user.split(":")[1]), cookies=cookies, headers=headers, timeout=10)
        token_response.raise_for_status()

        token_data = token_response.json()
        api_token = token_data['data']['tokenValue']
        print(f"New token generated successfully: {api_token}")

    except requests.exceptions.RequestException as e:
        print(f"Error generating token: {e}")
        return

    # Step 3: Save Jenkins credentials locally
    try:
        ensure_folder(BASE_DIR)
        print(f"Ensuring base directory exists: {BASE_DIR}")

        if not os.path.exists(JENKINS_KEY_FILE):
            generate_jenkins_key()
            print(f"Generated new Jenkins key at: {JENKINS_KEY_FILE}")

        key = load_jenkins_key()
        print(f"Loaded Jenkins key: {key}")

        credentials = {
            'jenkins_url': jenkins_url,
            'job_name': job_name,
            'username': user.split(":")[0],
            'api_token': api_token
        }

        encrypted_credentials = encrypt_jenkins_data(json.dumps(credentials), key)
        print(f"Encrypted Jenkins credentials: {encrypted_credentials}")

        # Save encrypted credentials to file
        credentials_file_path = os.path.join(BASE_DIR, JENKINS_CREDENTIALS_FILE)
        print(f"Saving credentials to {credentials_file_path}...")

        with open(credentials_file_path, 'wb') as cred_file:
            cred_file.write(encrypted_credentials)

        print(f"Jenkins credentials saved successfully in {credentials_file_path}.")

    except Exception as e:
        print(f"Error saving Jenkins credentials: {e}")


@jenkins.command(name="create-job", help="Create a Jenkins job with a specified Jenkinsfile.")
@click.argument('job_name')
@click.argument('jenkinsfile_path', type=click.Path(exists=True))
def create_jenkins_job_command(job_name, jenkinsfile_path):
    result = create_jenkins_job(job_name, jenkinsfile_path)
    click.echo(result)


def create_jenkins_job(job_name, jenkinsfile_path):
    """Create a Jenkins job."""
    jenkins_credentials = load_jenkins_credentials()
    if not jenkins_credentials:
        click.echo("Failed to load Jenkins credentials.")
        return

    jenkins_url = jenkins_credentials['jenkins_url']
    username = jenkins_credentials['username']
    api_token = jenkins_credentials['api_token']

    with open(jenkinsfile_path, 'r') as file:
        jenkinsfile_content = file.read()

    job_config_xml = f"""<?xml version='1.1' encoding='UTF-8'?>
<flow-definition plugin="workflow-job@2.40">
  <description></description>
  <keepDependencies>false</keepDependencies>
  <properties/>
  <definition class="org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition" plugin="workflow-cps@2.92">
    <script>{jenkinsfile_content}</script>
    <sandbox>true</sandbox>
  </definition>
  <triggers/>
  <disabled>false</disabled>
</flow-definition>"""

    job_url = f"{jenkins_url}/createItem?name={job_name}"
    headers = {'Content-Type': 'application/xml'}
    response = requests.post(
        job_url,
        data=job_config_xml,
        headers=headers,
        auth=(username, api_token))

    if response.status_code == 200:
        return f"Job '{job_name}' created successfully."
    elif response.status_code == 400:
        return f"Job '{job_name}' already exists. Updating the job."
    else:
        return f"Failed to create job '{job_name}'. Status code: {response.status_code}\n{response.text}"


@jenkins.command(name="trigger-job", help="Trigger a Jenkins job.")
@click.argument('job_name')
def trigger_jenkins_job_command(job_name):
    result = trigger_jenkins_job(job_name)
    click.echo(result)


def trigger_jenkins_job(job_name):
    """Trigger a Jenkins job."""
    credentials = load_jenkins_credentials()

    if not credentials:
        click.echo("Failed to load Jenkins credentials.")
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    job_url = f"{jenkins_url}/job/{job_name}/build"
    response = requests.post(job_url, auth=(username, api_token))

    if response.status_code == 201:
        return f"Job '{job_name}' triggered successfully."
    else:
        return f"Failed to trigger job '{job_name}'. Status code: {response.status_code}\n{response.text}"

def generate_jenkins_key():
    """Generate and save Jenkins encryption key."""
    key = Fernet.generate_key()
    with open(JENKINS_KEY_FILE, 'wb') as key_file:
        key_file.write(key)
    click.echo("Jenkins encryption key generated and saved.")


def load_jenkins_key():
    """Load Jenkins encryption key."""
    return open(JENKINS_KEY_FILE, 'rb').read()


def encrypt_jenkins_data(data, key):
    """Encrypt Jenkins data."""
    fernet = Fernet(key)
    encrypted = fernet.encrypt(data.encode())
    return encrypted


def decrypt_jenkins_data(encrypted_data, key):
    """Decrypt Jenkins data."""
    fernet = Fernet(key)
    decrypted = fernet.decrypt(encrypted_data).decode()
    return decrypted




def install_java_on_worker(identifier, username):
    """Installs Java 17 on the worker depending on the package manager"""
    command = """
    if ! java -version &> /dev/null; then
        echo "Java is not installed. Installing Java 17..."
        if [ -x "$(command -v yum)" ]; then
            sudo yum update -y
            sudo yum install -y java-17-openjdk
        elif [ -x "$(command -v dnf)" ]; then
            sudo dnf install -y java-17-openjdk
        elif [ -x "$(command -v apt-get)" ]; then
            sudo apt-get update -y
            sudo apt-get install -y openjdk-17-jdk
        else
            echo "No known package manager found. Java installation failed."
        fi

        if java -version &> /dev/null; then
            echo "Java 17 installed successfully."
        else
            echo "Failed to install Java 17."
        fi
    else
        echo "Java is already installed."
    fi
    """
    execute_and_print(identifier, username, command)


def check_node_exists(jenkins_url, node_name, username, api_token):
    """Checks if the node exists in Jenkins."""
    get_node_config_url = f"{jenkins_url}/computer/{node_name}/config.xml"
    response = requests.get(get_node_config_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        return True
    else:
        return False



def get_jenkins_crumb(jenkins_url, username, api_token):
    """Helper function to retrieve Jenkins Crumb for CSRF protection."""
    crumb_url = f"{jenkins_url}/crumbIssuer/api/json"
    response = requests.get(crumb_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code == 200:
        crumb_data = response.json()
        return crumb_data['crumb']
    else:
        raise Exception(f"Failed to get Jenkins crumb. Status code: {response.status_code}")


@jenkins.command(name="get-system-info", help="Retrieve Jenkins system information.")
def get_jenkins_system_info():
    """
    Retrieve and display Jenkins system information using saved credentials.
    """
    # Load saved Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    # Extract Jenkins URL, Username, and API Token from saved credentials
    jenkins_url = credentials.get("jenkins_url")
    username = credentials.get("username")
    api_token = credentials.get("api_token")

    # Correct API URL to get Jenkins system information
    system_info_url = f"{jenkins_url}/computer/api/json?depth=1"

    response = requests.get(system_info_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        system_info = response.json()
        click.echo("Jenkins System Information:")
        click.echo(json.dumps(system_info, indent=4))
    else:
        click.echo(f"Failed to retrieve Jenkins system information. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")


@jenkins.command(name="create-folder", help="Create a new folder in Jenkins to organize jobs.")
@click.option('--folder_name', required=True, help="Name of the folder to create in Jenkins.")
def create_jenkins_folder(folder_name):
    """
    Create a new folder in Jenkins using saved credentials.
    """
    # Load saved Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    # Extract Jenkins URL, Username, and API Token from saved credentials
    jenkins_url = credentials.get("jenkins_url")
    username = credentials.get("username")
    api_token = credentials.get("api_token")

    folder_url = f"{jenkins_url}/createItem?name={folder_name}"
    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/xml'
    }

    folder_config_xml = """
    <com.cloudbees.hudson.plugins.folder.Folder plugin="cloudbees-folder">
      <actions/>
      <description>Folder for organizing jobs</description>
      <properties/>
      <views>
        <hudson.model.AllView>
          <owner class="com.cloudbees.hudson.plugins.folder.Folder" reference="../../../.."/>
          <name>All</name>
          <filterExecutors>false</filterExecutors>
          <filterQueue>false</filterQueue>
          <properties class="hudson.model.View$PropertyList"/>
        </hudson.model.AllView>
      </views>
      <healthMetrics/>
      <icon class="com.cloudbees.hudson.plugins.folder.icons.StockFolderIcon"/>
    </com.cloudbees.hudson.plugins.folder.Folder>
    """

    response = requests.post(folder_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=folder_config_xml)

    if response.status_code == 200:
        click.echo(f"Folder '{folder_name}' created successfully.")
    else:
        click.echo(f"Failed to create folder '{folder_name}'. Status code: {response.status_code}\nResponse: {response.text}")




@jenkins.command(name="disable-security", help="Disable Jenkins security settings.")
@click.option('--jenkins_url', required=True, help="Jenkins URL (e.g., http://jenkins.example.com)")
@click.option('--username', required=True, help="Admin Username for Jenkins.")
@click.option('--api_token', required=True, hide_input=True, help="Admin API Token.")
def disable_jenkins_security(jenkins_url, username, api_token):
    """
    Disable Jenkins security settings by modifying the Jenkins configuration.
    """
    try:
        # Jenkins configuration URL for security settings
        security_config_url = f"{jenkins_url}/configureSecurity/configure"
        headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)}

        # Data payload to disable security
        security_data = {
            'json': {
                '': '0',
                'core:apply': '',
                'Submit': 'Save',
                'jenkins-model-Jenkins': {
                    'authorizationStrategy': 'hudson.security.AuthorizationStrategy$Unsecured',
                    'securityRealm': 'hudson.security.SecurityRealm$None'
                }
            }
        }

        # Send POST request to disable security
        response = requests.post(security_config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, json=security_data)

        if response.status_code in [200, 201]:
            click.echo("Jenkins security settings disabled successfully.")
        else:
            click.echo(f"Failed to disable Jenkins security settings. Status code: {response.status_code}\nResponse: {response.text}")
    except Exception as e:
        click.echo(f"An error occurred: {str(e)}")

@jenkins.command(name="set-quiet-mode", help="Set Jenkins to quiet mode, preventing new builds from starting.")
@click.option('--enable', is_flag=True, help="Enable quiet mode. If not specified, disables quiet mode.")
def set_jenkins_quiet_mode(enable):
    """
    Enable or disable Jenkins quiet mode.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    quiet_mode_url = f"{jenkins_url}/quietDown" if enable else f"{jenkins_url}/cancelQuietDown"
    headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)}

    # Send POST request to enable/disable quiet mode
    response = requests.post(quiet_mode_url, auth=HTTPBasicAuth(username, api_token), headers=headers)

    if response.status_code == 200:
        click.echo(f"Jenkins quiet mode {'enabled' if enable else 'disabled'} successfully.")
    else:
        click.echo(f"Failed to {'enable' if enable else 'disable'} quiet mode. Status code: {response.status_code}")

@jenkins.command(name="clear-queue", help="Clear all items in the Jenkins build queue.")
def clear_jenkins_queue():
    """
    Clear all items in the Jenkins build queue.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins queue URL
    queue_url = f"{jenkins_url}/queue/cancelItem"
    headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)}

    # Get the current queue
    queue_info_url = f"{jenkins_url}/queue/api/json"
    response = requests.get(queue_info_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code == 200:
        queue_items = response.json().get('items', [])
        for item in queue_items:
            item_id = item['id']
            cancel_response = requests.post(f"{queue_url}?id={item_id}", auth=HTTPBasicAuth(username, api_token), headers=headers)
            if cancel_response.status_code == 200:
                click.echo(f"Queue item with ID {item_id} cancelled successfully.")
            else:
                click.echo(f"Failed to cancel queue item with ID {item_id}. Status code: {cancel_response.status_code}")
    else:
        click.echo(f"Failed to retrieve queue status. Status code: {response.status_code}")

@jenkins.command(name="restore-system", help="Restore Jenkins system configuration and optionally job configurations from a backup zip file.")
@click.option('--backup_file', required=True, type=click.Path(exists=True), help="Path to the backup zip file.")
def restore_jenkins_system(backup_file):
    """
    Restore Jenkins system and job configurations from a backup zip file.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    temp_restore_dir = os.path.join(os.path.dirname(backup_file), 'jenkins_restore_temp')
    os.makedirs(temp_restore_dir, exist_ok=True)

    # Extract the backup zip file
    with zipfile.ZipFile(backup_file, 'r') as backup_zip:
        backup_zip.extractall(temp_restore_dir)

    # Restore system configuration
    config_file_path = os.path.join(temp_restore_dir, 'config.xml')
    if os.path.exists(config_file_path):
        with open(config_file_path, 'r') as config_file:
            config_xml = config_file.read()

        config_url = f"{jenkins_url}/config.xml"
        headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token), 'Content-Type': 'application/xml'}
        response = requests.post(config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=config_xml)

        if response.status_code == 200:
            click.echo("Jenkins system configuration restored successfully.")
        else:
            click.echo(f"Failed to restore system configuration. Status code: {response.status_code}")
            shutil.rmtree(temp_restore_dir)
            return
    else:
        click.echo("System configuration file 'config.xml' not found in backup.")
        shutil.rmtree(temp_restore_dir)
        return

    # Restore job configurations if present
    job_files = [file for file in os.listdir(temp_restore_dir) if file.endswith('.xml') and file != 'config.xml']
    for job_file in job_files:
        job_name = job_file.replace('.xml', '')
        with open(os.path.join(temp_restore_dir, job_file), 'r') as file:
            job_config = file.read()

        job_url = f"{jenkins_url}/job/{job_name}/config.xml"
        headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token), 'Content-Type': 'application/xml'}
        job_response = requests.post(job_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=job_config)

        if job_response.status_code == 200:
            click.echo(f"Job '{job_name}' configuration restored successfully.")
        else:
            click.echo(f"Failed to restore job '{job_name}' configuration. Status code: {job_response.status_code}")

    # Cleanup temporary directory
    shutil.rmtree(temp_restore_dir)
    click.echo("Restore completed successfully.")

@jenkins.command(name="create-node", help="Create a Jenkins worker node and prepare the worker server.")
@click.option('--node_name', required=True, help="The name of the Jenkins worker node")
@click.option('--remote_fs', required=True, help="The remote file system directory for the agent")
@click.option('--labels', required=False, default="", help="Labels to associate with the worker node")
@click.option('--num_executors', required=False, default=1, help="Number of executors for the worker node")
@click.option('--host', required=True, help="Host where the worker node will connect from")
@click.option('--ssh_port', required=False, default=22, help="SSH port for the worker node")
@click.option('--credentials_id', required=True, help="Jenkins SSH credentials ID for the worker node")
@click.option('--identifier', required=True, help="Identifier for the worker to generate SSH keys")
@click.option('--username_ssh', required=True, help="Username to use on the worker")
def create_jenkins_worker(node_name, remote_fs, labels, num_executors, host, ssh_port, credentials_id, identifier, username_ssh):
    """
    Create a Jenkins worker node and set up the worker environment.
    """

    # Step 1: Load Jenkins credentials from configuration
    jenkins_credentials = load_jenkins_credentials()
    if not jenkins_credentials:
        click.echo("Failed to load Jenkins credentials. Please configure them first.")
        return

    jenkins_url = jenkins_credentials['jenkins_url']
    username = jenkins_credentials['username']
    api_token = jenkins_credentials['api_token']

    # Step 2: Check if the node exists
    if check_node_exists(jenkins_url, node_name, username, api_token):
        click.echo(f"Node '{node_name}' already exists. No changes were made.")
        return

    # Step 3: Generate SSH key on the worker
    click.echo(f"Generating SSH key on the worker node '{identifier}'...")
    private_key = generate_ssh_key_on_worker(identifier, username_ssh)
    if not private_key:
        click.echo("Failed to generate SSH key.")
        return

    click.echo(f"Private SSH key retrieved. Saving to host...")

    # Step 4: Install Java on the worker if not present
    click.echo(f"Installing Java on the worker '{identifier}' if not installed...")
    install_java_on_worker(identifier, username_ssh)

    # Step 5: Create Jenkins SSH credential using the generated SSH key
    click.echo(f"Creating Jenkins SSH credential for the worker node '{node_name}'...")
    create_jenkins_credential(credentials_id, private_key, "", f"SSH Credential for {node_name}", username_ssh)

    # Step 6: Create the worker node using the correct form submission method
    click.echo(f"Adding worker node '{node_name}' to Jenkins...")

    # Jenkins XML configuration for the node (as a string to be passed in form data)
    node_config_xml = f"""
    <slave>
      <name>{node_name}</name>
      <description>Automatically created worker node</description>
      <remoteFS>{remote_fs}</remoteFS>
      <numExecutors>{num_executors}</numExecutors>
      <mode>NORMAL</mode>
      <retentionStrategy class="hudson.slaves.RetentionStrategy$Always"/>
      <launcher class="hudson.plugins.sshslaves.SSHLauncher">
        <host>{host}</host>
        <port>{ssh_port}</port>
        <credentialsId>{credentials_id}</credentialsId>
        <launchTimeoutSeconds>60</launchTimeoutSeconds>
        <maxNumRetries>5</maxNumRetries>
        <retryWaitTime>15</retryWaitTime>
        <sshHostKeyVerificationStrategy class="hudson.plugins.sshslaves.verifiers.NonVerifyingKeyVerificationStrategy"/>
      </launcher>
      <label>{labels}</label>
      <nodeProperties/>
    </slave>
    """

    # Correct URL for creating the node
    config_node_url = f"{jenkins_url}/computer/doCreateItem"

    # Form data to submit, including node XML and the type of the item
    form_data = {
        'name': node_name,
        'type': 'hudson.slaves.DumbSlave$DescriptorImpl',
        'json': json.dumps({
            'name': node_name,
            'nodeDescription': 'Automatically created worker node',
            'remoteFS': remote_fs,
            'numExecutors': num_executors,
            'mode': 'NORMAL',
            '': '5',  # Form validation for numExecutors, Jenkins expects this empty value
            'retentionStrategy': {'stapler-class': 'hudson.slaves.RetentionStrategy$Always', 'value': 'RetentionStrategy$Always'},
            'launcher': {
                'stapler-class': 'hudson.plugins.sshslaves.SSHLauncher',
                'host': host,
                'port': ssh_port,
                'credentialsId': credentials_id,
                'launchTimeoutSeconds': '60',
                'maxNumRetries': '5',
                'retryWaitTime': '15',
                'sshHostKeyVerificationStrategy': {'stapler-class': 'hudson.plugins.sshslaves.verifiers.NonVerifyingKeyVerificationStrategy'}
            },
            'labelString': labels,
            'nodeProperties': []
        })
    }

    # Headers and CSRF Crumb
    headers = {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)
    }

    # POST the form data to create the node
    response = requests.post(config_node_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=form_data)

    if response.status_code == 200:
        click.echo(f"Worker node '{node_name}' created and configured successfully.")
    else:
        click.echo(f"Failed to configure worker node '{node_name}'. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")



@jenkins.command(name="delete-node", help="Delete a Jenkins worker node.")
@click.option('--node_name', required=True, help="The name of the Jenkins worker node to delete")
def delete_jenkins_node(node_name):
    """Delete a Jenkins worker node."""
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the URL for deleting the node
    delete_node_url = f"{jenkins_url}/computer/{node_name}/doDelete"

    # Delete request to remove the node
    response = requests.post(delete_node_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        click.echo(f"Worker node '{node_name}' deleted successfully.")
    else:
        click.echo(f"Failed to delete worker node '{node_name}'. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")

@jenkins.command(name="deactivate-token", help="Deactivate a Jenkins API token for a user.")
@click.option('--token_name', required=True, help="Name of the token to deactivate")
def deactivate_jenkins_token(token_name):
    """Deactivate a Jenkins API token for a user."""
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the URL for revoking the API token
    token_url = f"{jenkins_url}/me/descriptorByName/jenkins.security.ApiTokenProperty/revoke"

    # Construct the JSON payload to identify the token
    token_payload = {
        "tokenName": token_name
    }

    # Headers for the request
    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/json'
    }

    # POST request to deactivate the token
    response = requests.post(token_url, json=token_payload, headers=headers, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        click.echo(f"API Token '{token_name}' deactivated successfully.")
    else:
        click.echo(f"Failed to deactivate API token '{token_name}'. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")


@jenkins.command(name="delete-user", help="Delete a Jenkins user.")
@click.option('--user_id', required=True, help="ID of the Jenkins user to delete")
def delete_jenkins_user(user_id):
    """Delete a Jenkins user."""
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the URL for deleting the user
    delete_user_url = f"{jenkins_url}/securityRealm/user/{user_id}/doDelete"

    # Post request to delete the user
    response = requests.post(delete_user_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        click.echo(f"User '{user_id}' deleted successfully.")
    else:
        click.echo(f"Failed to delete user '{user_id}'. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")

@jenkins.command(name="delete-credential", help="Delete a specific Jenkins credential.")
@click.option('--credential_id', required=True, help="ID of the credential to delete.")
def delete_jenkins_credential(credential_id):
    """
    Delete a specific Jenkins credential.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    delete_url = f"{jenkins_url}/credentials/store/system/domain/_/credential/{credential_id}/doDelete"
    response = requests.post(delete_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        click.echo(f"Credential '{credential_id}' deleted successfully.")
    else:
        click.echo(f"Failed to delete credential '{credential_id}'. Status code: {response.status_code}")


@jenkins.command(name="update-credential", help="Update an existing Jenkins credential.")
@click.option('--credential_id', required=True, help="ID of the credential to update.")
@click.option('--new_username', required=False, help="New username (if updating username/password credential).")
@click.option('--new_password', required=False, hide_input=True, help="New password (if updating username/password credential).")
@click.option('--description', required=False, help="New description for the credential.")
def update_jenkins_credential(credential_id, new_username, new_password, description):
    """
    Update an existing Jenkins credential.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    update_url = f"{jenkins_url}/credentials/store/system/domain/_/credential/{credential_id}/configSubmit"
    data = {
        'json': {
            '': '0',
            'credentials': {
                'scope': 'GLOBAL',
                'id': credential_id,
                'username': new_username,
                'password': new_password,
                'description': description,
                '$class': 'com.cloudbees.plugins.credentials.impl.UsernamePasswordCredentialsImpl'
            }
        }
    }
    response = requests.post(update_url, auth=HTTPBasicAuth(username, api_token), data=data)

    if response.status_code == 200:
        click.echo(f"Credential '{credential_id}' updated successfully.")
    else:
        click.echo(f"Failed to update credential '{credential_id}'. Status code: {response.status_code}")


@jenkins.command(name="check-plugin-status", help="Check the health and status of installed Jenkins plugins.")
def check_plugin_status():
    """
    Check the health status of all installed plugins in Jenkins.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    plugin_status_url = f"{jenkins_url}/pluginManager/api/json?depth=1"
    response = requests.get(plugin_status_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        plugins = response.json().get('plugins', [])
        click.echo("Installed Plugin Status:")
        for plugin in plugins:
            click.echo(f"{plugin['shortName']} - Version: {plugin['version']} - Enabled: {plugin['enabled']} - Active: {plugin['active']}")
    else:
        click.echo(f"Failed to retrieve plugin status. Status code: {response.status_code}")


@jenkins.command(name="list-installed-plugins", help="Get a list of all installed plugins.")
def list_installed_plugins():
    """
    List all installed plugins in Jenkins.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    plugins_url = f"{jenkins_url}/pluginManager/api/json?depth=1"
    response = requests.get(plugins_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        plugins_info = response.json()
        plugins = plugins_info.get('plugins', [])
        click.echo(f"Installed Plugins ({len(plugins)}):")
        for plugin in plugins:
            click.echo(f"  {plugin['shortName']} - Version: {plugin['version']} - Active: {plugin['active']}")
    else:
        click.echo(f"Failed to retrieve plugin list. Status code: {response.status_code}")



@jenkins.command(name="uninstall-plugin", help="Uninstall or remove a specific Jenkins plugin.")
@click.option('--plugin_name', required=True, help="Name of the plugin to uninstall.")
def uninstall_jenkins_plugin(plugin_name):
    """
    Uninstall a Jenkins plugin.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    uninstall_url = f"{jenkins_url}/pluginManager/plugin/{plugin_name}/doUninstall"
    response = requests.post(uninstall_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        click.echo(f"Plugin '{plugin_name}' uninstalled successfully.")
    else:
        click.echo(f"Failed to uninstall plugin '{plugin_name}'. Status code: {response.status_code}")

@jenkins.command(name="replay-pipeline", help="Replay a previous pipeline build.")
@click.option('--job_name', required=True, help="Name of the Jenkins job.")
@click.option('--build_number', required=True, type=int, help="Build number to replay.")
@click.option('--modified_pipeline_script', type=click.Path(exists=True), help="Path to modified pipeline script (optional).")
def replay_pipeline(job_name, build_number, modified_pipeline_script):
    """
    Replay a previous Jenkins pipeline build.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    replay_url = f"{jenkins_url}/job/{job_name}/{build_number}/replay/run"

    # Check if a modified pipeline script is provided
    data = {}
    if modified_pipeline_script:
        with open(modified_pipeline_script, 'r') as file:
            data['script'] = file.read()

    response = requests.post(replay_url, auth=HTTPBasicAuth(username, api_token), data=data)

    if response.status_code == 201:
        click.echo(f"Pipeline '{job_name}' build #{build_number} replayed successfully.")
    else:
        click.echo(f"Failed to replay pipeline '{job_name}' build #{build_number}. Status code: {response.status_code}")

@jenkins.command(name="check-health", help="Check Jenkins and plugin health status.")
def check_jenkins_health():
    """
    Check the health status of Jenkins and its plugins.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Health check URL for Jenkins and plugins
    health_url = f"{jenkins_url}/overallLoad/api/json"

    response = requests.get(health_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        health_data = response.json()

        # Display health details
        click.echo("Jenkins Health Check:")
        for health_check, result in health_data.items():
            click.echo(f"{health_check}: {result}")
    else:
        click.echo(f"Failed to retrieve Jenkins health status. Status code: {response.status_code}\nResponse: {response.text}")


@jenkins.command(name="view-build-metrics", help="View build metrics for a Jenkins job.")
@click.option('--job_name', required=True, help="Name of the Jenkins job to retrieve metrics for.")
def view_build_metrics(job_name):
    """
    Retrieve and display build metrics for a Jenkins job.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins job metrics URL
    job_metrics_url = f"{jenkins_url}/job/{job_name}/api/json?tree=builds[number,status,duration,result]"

    response = requests.get(job_metrics_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        builds = response.json().get('builds', [])

        total_builds = len(builds)
        total_duration = sum(build['duration'] for build in builds)
        total_success = sum(1 for build in builds if build['result'] == 'SUCCESS')
        total_failures = sum(1 for build in builds if build['result'] == 'FAILURE')
        total_unstable = sum(1 for build in builds if build['result'] == 'UNSTABLE')

        # Calculate average duration
        average_duration = total_duration / total_builds if total_builds > 0 else 0

        click.echo(f"Job: {job_name} - Build Metrics")
        click.echo(f"Total Builds: {total_builds}")
        click.echo(f"Total Successful Builds: {total_success}")
        click.echo(f"Total Failed Builds: {total_failures}")
        click.echo(f"Total Unstable Builds: {total_unstable}")
        click.echo(f"Average Build Duration: {average_duration} ms")
    else:
        click.echo(f"Failed to retrieve build metrics. Status code: {response.status_code}\nResponse: {response.text}")


@jenkins.command(name="get-logs", help="Retrieve logs from Jenkins master or a specific node.")
@click.option('--node_name', default='', help="Name of the Jenkins node. Leave empty to get master logs.")
@click.option('--tail', default=100, help="Number of log lines to retrieve (default: 100).")
def get_jenkins_logs(node_name, tail):
    """
    Retrieve Jenkins logs from master or a specific node.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the URL for master or node logs
    if node_name:
        log_url = f"{jenkins_url}/computer/{node_name}/logText/progressiveText?start=0"
    else:
        log_url = f"{jenkins_url}/log/all?start=0"

    # Retrieve logs using GET request
    response = requests.get(log_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        log_data = response.text.splitlines()
        # Display the last 'tail' number of log lines
        for line in log_data[-tail:]:
            click.echo(line)
    else:
        click.echo(f"Failed to retrieve logs. Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="add-job-to-folder", help="Add an existing Jenkins job to a folder.")
@click.option('--job_name', required=True, help="Name of the existing job to add to the folder.")
@click.option('--folder_name', required=True, help="Name of the folder to add the job to.")
def add_job_to_folder(job_name, folder_name):
    """
    Add an existing Jenkins job to a folder.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Define the move URL
    move_url = f"{jenkins_url}/job/{job_name}/doMove"

    # Data payload to move the job to the specified folder
    data = {
        'destination': f"/job/{folder_name}",
        'json': '{"destination": "/job/' + folder_name + '"}'
    }

    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    # Send POST request to move the job to the folder
    response = requests.post(move_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=data)

    if response.status_code == 302:
        click.echo(f"Job '{job_name}' added to folder '{folder_name}' successfully.")
    else:
        click.echo(f"Failed to add job '{job_name}' to folder '{folder_name}'. Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="create-multibranch-pipeline", help="Create a new multi-branch pipeline job in Jenkins.")
@click.option('--job_name', required=True, help="Name of the multi-branch pipeline job to create.")
@click.option('--repo_url', required=True, help="Git repository URL for the multi-branch pipeline job.")
@click.option('--branch_pattern', default='*', help="Branch pattern for the pipeline (default: all branches '*').")
@click.option('--credentials_id', required=False, help="Credentials ID for the repository access, if needed.")
@click.option('--folder_name', required=False, help="Folder name to create the multi-branch pipeline in (optional).")
def create_multibranch_pipeline(job_name, repo_url, branch_pattern, credentials_id, folder_name):
    """
    Create a new multi-branch pipeline job in Jenkins.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Define the base URL based on the folder name (if provided)
    base_url = f"{jenkins_url}/job/{folder_name}/createItem" if folder_name else f"{jenkins_url}/createItem"
    job_url = f"{base_url}?name={job_name}&mode=com.cloudbees.hudson.plugins.folder.Folder&Jenkins-Crumb={get_jenkins_crumb(jenkins_url, username, api_token)}"

    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/xml'
    }

    # Define the multi-branch pipeline configuration XML
    multibranch_pipeline_config_xml = f"""
    <org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject>
      <description>Multi-branch pipeline for {job_name}</description>
      <properties/>
      <sources class="jenkins.branch.MultiBranchProject$BranchSourceList" plugin="branch-api@2.5.3">
        <data>
          <jenkins.branch.BranchSource>
            <source class="org.jenkinsci.plugins.github_branch_source.GitHubSCMSource" plugin="github-branch-source@2.4.2">
              <id>{job_name}-source</id>
              <credentialsId>{credentials_id}</credentialsId>
              <repoOwner>GITHUB_REPO_OWNER</repoOwner>
              <repository>{repo_url}</repository>
              <includes>{branch_pattern}</includes>
              <excludes></excludes>
            </source>
            <strategy class="jenkins.branch.NamedExceptionsBranchPropertyStrategy">
              <defaultProperties/>
              <namedExceptions/>
            </strategy>
          </jenkins.branch.BranchSource>
        </data>
      </sources>
      <factory class="org.jenkinsci.plugins.workflow.multibranch.WorkflowBranchProjectFactory">
        <scriptPath>Jenkinsfile</scriptPath>
      </factory>
      <orphanedItemStrategy class="com.cloudbees.hudson.plugins.folder.computed.DefaultOrphanedItemStrategy">
        <pruneDeadBranches>true</pruneDeadBranches>
        <daysToKeep>1</daysToKeep>
        <numToKeep>1</numToKeep>
      </orphanedItemStrategy>
      <triggers/>
      <disabled>false</disabled>
    </org.jenkinsci.plugins.workflow.multibranch.WorkflowMultiBranchProject>
    """

    response = requests.post(job_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=multibranch_pipeline_config_xml)

    if response.status_code == 200:
        click.echo(f"Multi-branch pipeline job '{job_name}' created successfully.")
    else:
        click.echo(f"Failed to create multi-branch pipeline job '{job_name}'. Status code: {response.status_code}\nResponse: {response.text}")


@jenkins.command(name="list-webhooks", help="List all Jenkins webhooks configured for a job.")
@click.option('--job_name', required=True, help="Name of the Jenkins job to list webhooks.")
def list_jenkins_webhooks(job_name):
    """
    List all webhooks configured for a Jenkins job.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins job configuration URL
    job_config_url = f"{jenkins_url}/job/{job_name}/config.xml"

    # Get the current job configuration XML
    response = requests.get(job_config_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code == 200:
        config_xml = response.text
        # Extract webhook URLs
        webhooks = [line for line in config_xml.split('\n') if '<url>' in line]
        if webhooks:
            click.echo(f"Webhooks configured for job '{job_name}':")
            for webhook in webhooks:
                click.echo(f"- {webhook.strip()}")
        else:
            click.echo(f"No webhooks configured for job '{job_name}'.")
    else:
        click.echo(f"Failed to get job configuration for '{job_name}'. Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="delete-webhook", help="Delete a Jenkins webhook from a job trigger.")
@click.option('--job_name', required=True, help="Name of the Jenkins job to remove the webhook.")
@click.option('--webhook_url', required=True, help="URL of the webhook to be removed.")
def delete_jenkins_webhook(job_name, webhook_url):
    """
    Delete a webhook for a Jenkins job.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins job configuration URL
    job_config_url = f"{jenkins_url}/job/{job_name}/config.xml"

    # Get the current job configuration XML
    response = requests.get(job_config_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code != 200:
        click.echo(f"Failed to get job configuration for '{job_name}'. Status code: {response.status_code}\nResponse: {response.text}")
        return

    # Parse the current XML and remove the webhook node if it matches the webhook URL
    config_xml = response.text
    if webhook_url in config_xml:
        config_xml = config_xml.replace(f"<url>{webhook_url}</url>", "")
    else:
        click.echo(f"No matching webhook URL found in job '{job_name}' configuration.")
        return

    # Update the job configuration
    headers = {
        'Content-Type': 'application/xml',
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)
    }
    update_response = requests.post(job_config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=config_xml)
    if update_response.status_code == 200:
        click.echo(f"Webhook for job '{job_name}' deleted successfully.")
    else:
        click.echo(f"Failed to delete webhook for job '{job_name}'. Status code: {update_response.status_code}\nResponse: {update_response.text}")

@jenkins.command(name="create-webhook", help="Create or update a Jenkins webhook for a job trigger.")
@click.option('--job_name', required=True, help="Name of the Jenkins job to add the webhook.")
@click.option('--webhook_url', required=True, help="URL of the webhook to be triggered by the Jenkins job.")
@click.option('--webhook_events', required=True, multiple=True, help="Webhook events to trigger (e.g., 'job_completed', 'job_failed').")
@click.option('--description', required=False, help="Description of the webhook.")
def create_jenkins_webhook(job_name, webhook_url, webhook_events, description):
    """
    Create or update a webhook for a Jenkins job.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins job configuration URL
    job_config_url = f"{jenkins_url}/job/{job_name}/config.xml"

    # Define webhook trigger XML
    webhook_triggers_xml = "\n".join(
        [f"<hudson.triggers.TimerTrigger><spec>{event}</spec></hudson.triggers.TimerTrigger>" for event in webhook_events]
    )

    # Define webhook configuration XML
    webhook_config_xml = f"""
    <project>
        <description>{description}</description>
        <triggers>
            {webhook_triggers_xml}
        </triggers>
        <publishers>
            <jenkins.plugins.webhook.WebhookPublisher plugin="webhook">
                <url>{webhook_url}</url>
                <timeout>300</timeout>
                <format>json</format>
            </jenkins.plugins.webhook.WebhookPublisher>
        </publishers>
        <disabled>false</disabled>
    </project>
    """

    headers = {
        'Content-Type': 'application/xml',
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)
    }

    # Update the Jenkins job configuration with the webhook
    response = requests.post(job_config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=webhook_config_xml)

    # Check if the webhook creation/update was successful
    if response.status_code == 200:
        click.echo(f"Webhook for job '{job_name}' created/updated successfully.")
    else:
        click.echo(f"Failed to create/update webhook for job '{job_name}'. Status code: {response.status_code}\nResponse: {response.text}")


@jenkins.command(name="update-pipeline", help="Update a Jenkins pipeline script for an existing job.")
@click.option('--job_name', required=True, help="Name of the Jenkins job to update.")
@click.option('--pipeline_script', type=click.Path(exists=True), required=True, help="Path to the pipeline script file to update.")
def update_jenkins_pipeline(job_name, pipeline_script):
    """
    Update a Jenkins pipeline script for an existing job.
    Reads the pipeline script from a local file and updates the Jenkins job's pipeline.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the Jenkins job config URL
    job_config_url = f"{jenkins_url}/job/{job_name}/config.xml"

    # Read the pipeline script content
    with open(pipeline_script, 'r') as script_file:
        pipeline_content = script_file.read()

    # Prepare the Jenkins pipeline job configuration XML
    config_xml = f"""
    <flow-definition plugin="workflow-job">
        <description>Updated pipeline script for {job_name}</description>
        <keepDependencies>false</keepDependencies>
        <properties/>
        <definition class="org.jenkinsci.plugins.workflow.cps.CpsFlowDefinition" plugin="workflow-cps">
            <script>{pipeline_content}</script>
            <sandbox>true</sandbox>
        </definition>
        <triggers/>
        <disabled>false</disabled>
    </flow-definition>
    """

    headers = {
        'Content-Type': 'application/xml',
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)  # CSRF Protection
    }

    # Update the pipeline script via the Jenkins API
    response = requests.post(job_config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=config_xml)

    # Check for success or failure
    if response.status_code == 200:
        click.echo(f"Pipeline script for job '{job_name}' updated successfully.")
    else:
        click.echo(f"Failed to update pipeline script for job '{job_name}'. Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="visualize-pipeline", help="Retrieve and visualize pipeline stages and steps.")
@click.option('--job_name', required=True, help="Name of the Jenkins job.")
@click.option('--build_number', required=True, type=int, help="Build number to visualize the pipeline stages.")
def visualize_pipeline(job_name, build_number):
    """
    Retrieve and display pipeline stages and steps.
    """
    # Load stored Jenkins credentials
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Construct the pipeline URL
    pipeline_url = f"{jenkins_url}/job/{job_name}/{build_number}/wfapi/describe"
    response = requests.get(pipeline_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        pipeline_info = response.json()
        click.echo(f"Pipeline: {job_name} - Build #{build_number}")

        for stage in pipeline_info['stages']:
            stage_name = stage.get('name', 'Unknown Stage')
            stage_status = stage.get('status', 'Unknown Status')
            click.echo(f"Stage: {stage_name} - Status: {stage_status}")

            # Check if 'stageFlowNodes' is present and iterate over steps
            if 'stageFlowNodes' in stage:
                for step in stage['stageFlowNodes']:
                    step_name = step.get('name', 'Unknown Step')
                    step_status = step.get('status', 'Unknown Status')
                    click.echo(f"  Step: {step_name} - Status: {step_status}")
            else:
                click.echo(f"  No detailed steps available for stage: {stage_name}")

    else:
        click.echo(f"Failed to retrieve pipeline information for job '{job_name}', build #{build_number}.")
        click.echo(f"Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="update-system-config", help="Update Jenkins system configuration settings.")
@click.option('--config_file', required=True, type=click.Path(exists=True), help="Path to the local Jenkins config.xml file.")
def update_jenkins_system_config(config_file):
    """
    Update Jenkins system configuration settings by uploading a new config.xml file.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins config.xml endpoint
    config_url = f"{jenkins_url}/config.xml"

    # Read the new configuration file
    with open(config_file, 'r') as file:
        config_xml_content = file.read()

    # Set headers with Jenkins Crumb
    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/xml'
    }

    # Send POST request to update the configuration
    response = requests.post(config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=config_xml_content)

    if response.status_code == 200:
        click.echo("Jenkins system configuration updated successfully.")
    else:
        click.echo(f"Failed to update Jenkins system configuration. Status code: {response.status_code}\nResponse: {response.text}")



@jenkins.command(name="set-env-variables", help="Set global environment variables in Jenkins.")
@click.option('--env_key', required=True, help="Environment variable key to set.")
@click.option('--env_value', required=True, help="Environment variable value to set.")
def set_jenkins_env_variables(env_key, env_value):
    """
    Set global environment variables in Jenkins by updating the config.xml file.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Get current config.xml
    config_url = f"{jenkins_url}/config.xml"
    response = requests.get(config_url, auth=HTTPBasicAuth(username, api_token))

    if response.status_code == 200:
        config_xml = response.text

        # Modify the XML to add the environment variable
        new_env_variable = f"""
            <envVars>
                <key>{env_key}</key>
                <value>{env_value}</value>
            </envVars>
        """
        if "<globalNodeProperties>" in config_xml:
            # Add the environment variable before the closing </globalNodeProperties> tag
            config_xml = config_xml.replace("</globalNodeProperties>", f"{new_env_variable}\n</globalNodeProperties>")
        else:
            # If no globalNodeProperties tag, add it
            config_xml = f"<hudson>\n<globalNodeProperties>{new_env_variable}\n</globalNodeProperties>\n</hudson>"

        # Post the updated config.xml back to Jenkins
        headers = {'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token), 'Content-Type': 'application/xml'}
        update_response = requests.post(config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=config_xml)

        if update_response.status_code == 200:
            click.echo(f"Environment variable '{env_key}' set successfully.")
        else:
            click.echo(f"Failed to set environment variable. Status code: {update_response.status_code}\nResponse: {update_response.text}")
    else:
        click.echo(f"Failed to retrieve Jenkins configuration. Status code: {response.status_code}\nResponse: {response.text}")



@jenkins.command(name="restart", help="Restart the Jenkins server.")
def restart_jenkins():
    """
    Restart the Jenkins server.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Jenkins restart URL
    restart_url = f"{jenkins_url}/safeRestart"

    headers = {
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token),
        'Content-Type': 'application/x-www-form-urlencoded'
    }

    # Send POST request to restart Jenkins
    response = requests.post(restart_url, auth=HTTPBasicAuth(username, api_token), headers=headers)

    if response.status_code == 200:
        click.echo("Jenkins server is restarting...")
    else:
        click.echo(f"Failed to restart Jenkins. Status code: {response.status_code}\nResponse: {response.text}")

@jenkins.command(name="backup-system", help="Backup the entire Jenkins system configuration and optionally all job configurations.")
@click.option('--backup_path', required=True, type=click.Path(exists=True), help="Path to store the backup zip file.")
@click.option('--include_jobs', is_flag=True, help="Include job configurations in the backup.")
def backup_jenkins_system(backup_path, include_jobs):
    """
    Backup Jenkins system and optionally all job configurations.
    """
    credentials = load_jenkins_credentials()
    if not credentials:
        return

    jenkins_url = credentials['jenkins_url']
    username = credentials['username']
    api_token = credentials['api_token']

    # Define backup file paths
    config_backup_path = os.path.join(backup_path, 'jenkins_system_backup.zip')
    temp_backup_dir = os.path.join(backup_path, 'jenkins_backup_temp')
    os.makedirs(temp_backup_dir, exist_ok=True)

    # Backup system config.xml
    config_url = f"{jenkins_url}/config.xml"
    response = requests.get(config_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code == 200:
        with open(os.path.join(temp_backup_dir, 'config.xml'), 'w') as config_file:
            config_file.write(response.text)
        click.echo("System configuration backed up successfully.")
    else:
        click.echo(f"Failed to backup system configuration. Status code: {response.status_code}")
        shutil.rmtree(temp_backup_dir)
        return

    # Backup job configurations if specified
    if include_jobs:
        jobs_url = f"{jenkins_url}/api/json?tree=jobs[name,url]"
        response = requests.get(jobs_url, auth=HTTPBasicAuth(username, api_token))
        if response.status_code == 200:
            jobs = response.json().get('jobs', [])
            click.echo(f"Backing up {len(jobs)} job configurations...")

            for job in jobs:
                job_name = job['name']
                job_config_url = f"{jenkins_url}/job/{job_name}/config.xml"
                job_response = requests.get(job_config_url, auth=HTTPBasicAuth(username, api_token))
                if job_response.status_code == 200:
                    with open(os.path.join(temp_backup_dir, f'{job_name}.xml'), 'w') as job_file:
                        job_file.write(job_response.text)
                else:
                    click.echo(f"Failed to backup job '{job_name}'. Status code: {job_response.status_code}")

    # Create zip file for backup
    with zipfile.ZipFile(config_backup_path, 'w') as backup_zip:
        for root, dirs, files in os.walk(temp_backup_dir):
            for file in files:
                file_path = os.path.join(root, file)
                backup_zip.write(file_path, os.path.relpath(file_path, temp_backup_dir))

    # Cleanup temporary directory
    shutil.rmtree(temp_backup_dir)
    click.echo(f"Backup completed successfully and saved to {config_backup_path}.")

############################################################################

def generate_ssh_key_on_worker(identifier, username):
    """
    Generates SSH key on the worker, converts it to PEM format, copies the public key to the authorized_keys file,
    sets correct permissions, and returns the private key.
    """
    try:
        # Commands to generate SSH key, convert it to RSA PEM format, and update authorized_keys
        command = """
        # Check if .ssh directory exists and create if it does not
        mkdir -p /root/.ssh
        chmod 700 /root/.ssh

        # Generate SSH key in OpenSSH format (default) if it does not exist
        if [ ! -f /root/.ssh/id_rsa ]; then
            ssh-keygen -t rsa -b 4096 -f /root/.ssh/id_rsa -q -N "";
        fi

        # Convert OpenSSH private key to PEM format
        ssh-keygen -p -m PEM -f /root/.ssh/id_rsa -N "" > /dev/null 2>&1

        # Copy public key to authorized_keys
        cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
        chmod 600 /root/.ssh/authorized_keys

        # Output the private key in PEM format
        cat /root/.ssh/id_rsa
        """

        click.echo(f"Running SSH key generation on worker {identifier} and setting up authorized keys...")

        # Execute the command on the worker and capture output
        success, private_key = execute_and_print(identifier, username, command)

        # Check if private_key was successfully retrieved
        if success and private_key:
            click.echo("Private SSH key (PEM format) retrieved. Saving to host.")
            REMOTE_SSH_TRANSIT = os.path.join(BASE_DIR, "ostrich.dob")
            with open(REMOTE_SSH_TRANSIT, 'w') as f:
                f.write(private_key)
            return private_key
        else:
            click.echo(f"Failed to retrieve private key. Response: {private_key}")
            return None

    except Exception as e:
        click.echo(f"Error during SSH key generation: {str(e)}")
        return None

def create_jenkins_credential(credential_id, private_key, passphrase, description, username_ssh):
    """
    Create a Jenkins credential using the Jenkins REST API.
    Supports creating SSH credentials.
    """
    # Load Jenkins credentials from the local file
    jenkins_credentials = load_jenkins_credentials()
    if not jenkins_credentials:
        click.echo("Failed to load Jenkins credentials. Please configure them first.")
        return

    # Extract Jenkins URL, username, and API token from saved credentials
    jenkins_url = jenkins_credentials['jenkins_url']
    username = jenkins_credentials['username']
    api_token = jenkins_credentials['api_token']

    headers = {
        'Content-Type': 'application/xml',
        'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)
    }

    # Define the XML payload for the SSH credential
    credential_xml = f"""
    <com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey>
        <scope>GLOBAL</scope>
        <id>{credential_id}</id>
        <description>{description}</description>
        <username>{username_ssh}</username>
        <privateKeySource class="com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey$DirectEntryPrivateKeySource">
            <privateKey>{private_key}</privateKey>
        </privateKeySource>
        <passphrase>{passphrase}</passphrase>
    </com.cloudbees.jenkins.plugins.sshcredentials.impl.BasicSSHUserPrivateKey>
    """

    credential_url = f"{jenkins_url}/credentials/store/system/domain/_/createCredentials"

    response = requests.post(credential_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=credential_xml)

    if response.status_code in [200, 201, 204]:
        click.echo(f"Credential '{credential_id}' created successfully.")
    else:
        click.echo(f"Failed to create credential '{credential_id}'. Status code: {response.status_code}")
        click.echo(f"Response: {response.text}")


def load_jenkins_credentials():
    """Load Jenkins credentials from the local encrypted file."""
    if not os.path.exists(JENKINS_CREDENTIALS_FILE) or not os.path.exists(JENKINS_KEY_FILE):
        click.echo("Jenkins credentials not configured. Please run 'configure-jenkins' command first.")
        return None

    # Decrypt and load the Jenkins credentials
    with open(JENKINS_KEY_FILE, 'rb') as key_file, open(JENKINS_CREDENTIALS_FILE, 'rb') as cred_file:
        key = key_file.read()
        encrypted_credentials = cred_file.read()

        # Replace `decrypt_jenkins_data` with your own decryption function
        decrypted_credentials = decrypt_jenkins_data(encrypted_credentials, key)
        return json.loads(decrypted_credentials)


def save_jenkins_credentials(jenkins_url, username, api_token, job_name):
    if not os.path.exists(BASE_DIR):
        os.makedirs(BASE_DIR)

    # Generate encryption key if not exists
    if not os.path.exists(JENKINS_KEY_FILE):
        key = Fernet.generate_key()
        with open(JENKINS_KEY_FILE, 'wb') as key_file:
            key_file.write(key)
    else:
        with open(JENKINS_KEY_FILE, 'rb') as key_file:
            key = key_file.read()

    credentials = {
        'jenkins_url': jenkins_url,
        'job_name': job_name,
        'username': username,
        'api_token': api_token
    }

    fernet = Fernet(key)
    encrypted_credentials = fernet.encrypt(json.dumps(credentials).encode('utf-8'))

    with open(JENKINS_CREDENTIALS_FILE, 'wb') as cred_file:
        cred_file.write(encrypted_credentials)

    echo(f"Jenkins credentials saved successfully in {JENKINS_CREDENTIALS_FILE}.")
#######################################################
# K8s Command Group
@cli.group(help="Commands to manage k8s server.")
def kubectl():
    pass

@kubectl.command(name="connect", help="Fetch Kubernetes config and save credentials locally.")
@click.option('--identifier', required=True, help="Identifier for the Kubernetes server to retrieve the configuration.")
@click.option('--category', required=False, help="Category for remote instances (e.g., dev, prod).")
@click.option('--context', required=False, help="Kubernetes context to set as default.")
@click.option('--namespace', required=False, help="Default namespace for operations.")
@click.pass_context
def configure_k8s(ctx, identifier, category, context, namespace):
    """
    Fetch kubeconfig from the Kubernetes server and save it securely.
    """
    # Retrieve kubeconfig from the remote server
    kubeconfig_path = retrieve_kubeconfig_from_server(ctx, identifier, category)

    if kubeconfig_path:
        # Save the kubeconfig, context, and namespace
        save_k8s_credentials(kubeconfig_path, context, namespace)
        click.echo("Kubernetes credentials configured and saved.")
    else:
        click.echo("Failed to retrieve the kubeconfig. Please check your configuration.")




@kubectl.command(name="list-namespaces", help="List all namespaces in the Kubernetes cluster.")
def list_namespaces():
    """
    List all namespaces in the Kubernetes cluster.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    v1 = client.CoreV1Api()
    try:
        namespaces = v1.list_namespace().items
        click.echo(f"Namespaces in the cluster:")
        for ns in namespaces:
            click.echo(f"- {ns.metadata.name}")
    except ApiException as e:
        click.echo(f"Failed to list namespaces: {e}")


@kubectl.command(name="create-namespace", help="Create a new namespace in the Kubernetes cluster.")
@click.option('--namespace', required=True, help="Name of the namespace to create.")
def create_namespace(namespace):
    """
    Create a new namespace in the Kubernetes cluster.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    v1 = client.CoreV1Api()
    ns = client.V1Namespace(metadata=client.V1ObjectMeta(name=namespace))
    try:
        v1.create_namespace(ns)
        click.echo(f"Namespace '{namespace}' created successfully.")
    except ApiException as e:
        click.echo(f"Failed to create namespace '{namespace}': {e}")


@kubectl.command(name="get-pods", help="List all pods in a Kubernetes namespace.")
@click.option('--namespace', required=False, default='default', help="Namespace to list pods from. Defaults to 'default'.")
def get_pods(namespace):
    """
    Retrieve all pods in a specified namespace.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    v1 = client.CoreV1Api()
    try:
        pods = v1.list_namespaced_pod(namespace=namespace).items
        click.echo(f"Pods in namespace '{namespace}':")
        for pod in pods:
            click.echo(f"- {pod.metadata.name}")
    except ApiException as e:
        click.echo(f"Failed to retrieve pods in namespace '{namespace}': {e}")


@kubectl.command(name="create-deployment", help="Create a new Kubernetes deployment.")
@click.option('--name', required=True, help="Name of the deployment.")
@click.option('--image', required=True, help="Container image for the deployment.")
@click.option('--replicas', required=False, default=1, type=int, help="Number of replicas.")
@click.option('--namespace', required=False, default='default', help="Namespace to create the deployment in.")
def create_deployment(name, image, replicas, namespace):
    """
    Create a new Kubernetes deployment with the specified container image and replicas.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    # Define deployment specification
    deployment_spec = client.V1Deployment(
        metadata=client.V1ObjectMeta(name=name),
        spec=client.V1DeploymentSpec(
            replicas=replicas,
            selector={'matchLabels': {'app': name}},
            template=client.V1PodTemplateSpec(
                metadata=client.V1ObjectMeta(labels={'app': name}),
                spec=client.V1PodSpec(containers=[client.V1Container(name=name, image=image)])
            )
        )
    )

    # Create the deployment in the specified namespace
    apps_v1 = client.AppsV1Api()
    try:
        apps_v1.create_namespaced_deployment(namespace=namespace, body=deployment_spec)
        click.echo(f"Deployment '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create deployment '{name}': {e}")


@kubectl.command(name="delete-deployment", help="Delete a Kubernetes deployment.")
@click.option('--name', required=True, help="Name of the deployment to delete.")
@click.option('--namespace', required=False, default='default', help="Namespace of the deployment.")
def delete_deployment(name, namespace):
    """
    Delete a Kubernetes deployment in a specified namespace.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    apps_v1 = client.AppsV1Api()
    try:
        apps_v1.delete_namespaced_deployment(name=name, namespace=namespace)
        click.echo(f"Deployment '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete deployment '{name}': {e}")


@kubectl.command(name="scale-deployment", help="Scale a Kubernetes deployment to a specified number of replicas.")
@click.option('--name', required=True, help="Name of the deployment to scale.")
@click.option('--replicas', required=True, type=int, help="Number of replicas to scale to.")
@click.option('--namespace', required=False, default='default', help="Namespace of the deployment.")
def scale_deployment(name, replicas, namespace):
    """
    Scale a Kubernetes deployment to a specified number of replicas.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    apps_v1 = client.AppsV1Api()
    try:
        deployment = apps_v1.read_namespaced_deployment(name=name, namespace=namespace)
        deployment.spec.replicas = replicas
        apps_v1.replace_namespaced_deployment(name=name, namespace=namespace, body=deployment)
        click.echo(f"Deployment '{name}' scaled to {replicas} replicas successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to scale deployment '{name}': {e}")


@kubectl.command(name="list-pods", help="List all pods in a specified namespace.")
@click.option('--namespace', required=False, default='default', help="Namespace to list pods from. Defaults to 'default'.")
def list_pods(namespace):
    """
    List all pods in a specified namespace.
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    v1 = client.CoreV1Api()
    try:
        pods = v1.list_namespaced_pod(namespace=namespace).items
        click.echo(f"Pods in namespace '{namespace}':")
        for pod in pods:
            click.echo(f"- {pod.metadata.name} (Status: {pod.status.phase})")
    except ApiException as e:
        click.echo(f"Failed to retrieve pods in namespace '{namespace}': {e}")


@kubectl.command(name="get-pod-logs", help="Retrieve logs for a specified pod.")
@click.option('--namespace', required=False, default='default', help="Namespace of the pod. Defaults to 'default'.")
@click.option('--pod_name', required=True, help="Name of the pod to retrieve logs from.")
@click.option('--container', required=False, help="Container name (if the pod has multiple containers).")
def get_pod_logs(namespace, pod_name, container):
    """
    Retrieve logs from a specific pod and container (if applicable).
    """
    # Load saved Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    v1 = client.CoreV1Api()
    try:
        log = v1.read_namespaced_pod_log(name=pod_name, namespace=namespace, container=container)
        click.echo(f"Logs for pod '{pod_name}' in namespace '{namespace}':\n{log}")
    except ApiException as e:
        click.echo(f"Failed to retrieve logs for pod '{pod_name}': {e}")


@kubectl.command(name="list-nodes", help="List all nodes in the Kubernetes cluster.")
def list_nodes():
    """
    List all nodes in the Kubernetes cluster.
    """
    try:
        # Load the decrypted Kubernetes credentials
        kubeconfig_path, context = load_k8s_credentials()
        config.load_kube_config(config_file=kubeconfig_path, context=context)

        # Initialize the Kubernetes client
        v1 = client.CoreV1Api()
        nodes = v1.list_node().items

        # Print the list of nodes
        click.echo("Nodes in the cluster:")
        for node in nodes:
            click.echo(f"- {node.metadata.name} (Status: {node.status.conditions[-1].type})")
    except Exception as e:
        click.echo(f"Failed to retrieve nodes in the cluster: {e}")


@kubectl.command(name="create-service", help="Create a new Kubernetes service.")
@click.option('--name', required=True, help="Name of the service.")
@click.option('--type', required=True, type=click.Choice(['ClusterIP', 'NodePort', 'LoadBalancer']), help="Type of the service.")
@click.option('--port', required=True, type=int, help="Service port.")
@click.option('--target_port', required=True, type=int, help="Target port for the service.")
@click.option('--namespace', required=False, default='default', help="Namespace to create the service in.")
@click.option('--selector', required=True, help="Selector labels for the service (e.g., app=nginx).")
def create_service(name, type, port, target_port, namespace, selector):
    """
    Create a new Kubernetes service in a specified namespace.
    """
    # Load Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    # Parse selector into a dictionary
    selector_dict = dict(item.split("=") for item in selector.split(","))

    # Define service specification
    service_spec = client.V1Service(
        metadata=client.V1ObjectMeta(name=name),
        spec=client.V1ServiceSpec(
            type=type,
            ports=[client.V1ServicePort(port=port, target_port=target_port)],
            selector=selector_dict
        )
    )

    # Create the service
    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_service(namespace=namespace, body=service_spec)
        click.echo(f"Service '{name}' of type '{type}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create service '{name}': {e}")


@kubectl.command(name="delete-service", help="Delete a Kubernetes service.")
@click.option('--name', required=True, help="Name of the service to delete.")
@click.option('--namespace', required=False, default='default', help="Namespace of the service.")
def delete_service(name, namespace):
    """
    Delete a Kubernetes service in a specified namespace.
    """
    # Load Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_service(name=name, namespace=namespace)
        click.echo(f"Service '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete service '{name}': {e}")

@kubectl.command(name="create-configmap", help="Create a new ConfigMap in Kubernetes.")
@click.option('--name', required=True, help="Name of the ConfigMap.")
@click.option('--data', required=True, help="Key-value pairs for the ConfigMap data (e.g., key1=value1,key2=value2).")
@click.option('--namespace', required=False, default='default', help="Namespace to create the ConfigMap in.")
def create_configmap(name, data, namespace):
    """
    Create a new ConfigMap with specified data in a specified namespace.
    """
    # Load Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    # Parse data into a dictionary
    data_dict = dict(item.split("=") for item in data.split(","))

    # Define ConfigMap specification
    configmap_spec = client.V1ConfigMap(
        metadata=client.V1ObjectMeta(name=name),
        data=data_dict
    )

    # Create the ConfigMap
    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_config_map(namespace=namespace, body=configmap_spec)
        click.echo(f"ConfigMap '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create ConfigMap '{name}': {e}")


@kubectl.command(name="delete-configmap", help="Delete a Kubernetes ConfigMap.")
@click.option('--name', required=True, help="Name of the ConfigMap to delete.")
@click.option('--namespace', required=False, default='default', help="Namespace of the ConfigMap.")
def delete_configmap(name, namespace):
    """
    Delete a ConfigMap in a specified namespace.
    """
    # Load Kubernetes credentials
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_config_map(name=name, namespace=namespace)
        click.echo(f"ConfigMap '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete ConfigMap '{name}': {e}")

@kubectl.command(name="create-pvc", help="Create a new Persistent Volume Claim (PVC) in Kubernetes.")
@click.option('--name', required=True, help="Name of the PVC.")
@click.option('--storage_size', required=True, help="Requested storage size (e.g., 1Gi, 500Mi).")
@click.option('--storage_class', required=False, help="Storage class to use for the PVC.")
@click.option('--access_modes', required=False, default="ReadWriteOnce", help="Access modes (e.g., ReadWriteOnce, ReadOnlyMany).")
@click.option('--namespace', required=False, default='default', help="Namespace to create the PVC in.")
def create_pvc(name, storage_size, storage_class, access_modes, namespace):
    """
    Create a new PVC in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    pvc_spec = client.V1PersistentVolumeClaim(
        metadata=client.V1ObjectMeta(name=name),
        spec=client.V1PersistentVolumeClaimSpec(
            access_modes=[access_modes],
            resources=client.V1ResourceRequirements(requests={"storage": storage_size}),
            storage_class_name=storage_class
        )
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_persistent_volume_claim(namespace=namespace, body=pvc_spec)
        click.echo(f"Persistent Volume Claim '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create PVC '{name}': {e}")


@kubectl.command(name="delete-pvc", help="Delete a Kubernetes Persistent Volume Claim (PVC).")
@click.option('--name', required=True, help="Name of the PVC to delete.")
@click.option('--namespace', required=False, default='default', help="Namespace of the PVC.")
def delete_pvc(name, namespace):
    """
    Delete a PVC in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_persistent_volume_claim(name=name, namespace=namespace)
        click.echo(f"Persistent Volume Claim '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete PVC '{name}': {e}")

@kubectl.command(name="create-storage-class", help="Create a new Storage Class in Kubernetes.")
@click.option('--name', required=True, help="Name of the Storage Class.")
@click.option('--provisioner', required=True, help="Provisioner for the Storage Class (e.g., kubernetes.io/aws-ebs).")
@click.option('--parameters', required=False, help="Provisioner parameters (e.g., type=gp2).")
@click.option('--reclaim_policy', required=False, default='Delete', help="Reclaim policy (e.g., Delete, Retain).")
@click.option('--allow_volume_expansion', required=False, type=bool, default=False, help="Allow volume expansion.")
@click.option('--namespace', required=False, default='default', help="Namespace to create the Storage Class in.")
def create_storage_class(name, provisioner, parameters, reclaim_policy, allow_volume_expansion, namespace):
    """
    Create a new Storage Class with specified parameters.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    parameters_dict = dict(item.split("=") for item in parameters.split(",")) if parameters else {}

    storage_class_spec = client.V1StorageClass(
        metadata=client.V1ObjectMeta(name=name),
        provisioner=provisioner,
        parameters=parameters_dict,
        reclaim_policy=reclaim_policy,
        allow_volume_expansion=allow_volume_expansion
    )

    storage_v1 = client.StorageV1Api()
    try:
        storage_v1.create_storage_class(body=storage_class_spec)
        click.echo(f"Storage Class '{name}' created successfully.")
    except ApiException as e:
        click.echo(f"Failed to create Storage Class '{name}': {e}")


@kubectl.command(name="delete-storage-class", help="Delete a Kubernetes Storage Class.")
@click.option('--name', required=True, help="Name of the Storage Class to delete.")
def delete_storage_class(name):
    """
    Delete a Storage Class.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    storage_v1 = client.StorageV1Api()
    try:
        storage_v1.delete_storage_class(name=name)
        click.echo(f"Storage Class '{name}' deleted successfully.")
    except ApiException as e:
        click.echo(f"Failed to delete Storage Class '{name}': {e}")

@kubectl.command(name="create-namespace", help="Create a new namespace in Kubernetes.")
@click.option('--name', required=True, help="Name of the namespace to create.")
def create_namespace(name):
    """
    Create a new namespace in the Kubernetes cluster.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    namespace_spec = client.V1Namespace(
        metadata=client.V1ObjectMeta(name=name)
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespace(body=namespace_spec)
        click.echo(f"Namespace '{name}' created successfully.")
    except ApiException as e:
        click.echo(f"Failed to create namespace '{name}': {e}")


@kubectl.command(name="delete-namespace", help="Delete a namespace in Kubernetes.")
@click.option('--name', required=True, help="Name of the namespace to delete.")
def delete_namespace(name):
    """
    Delete a namespace in the Kubernetes cluster.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespace(name=name)
        click.echo(f"Namespace '{name}' deleted successfully.")
    except ApiException as e:
        click.echo(f"Failed to delete namespace '{name}': {e}")


@kubectl.command(name="list-namespaces", help="List all namespaces in the Kubernetes cluster.")
def list_namespaces():
    """
    List all namespaces in the Kubernetes cluster.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        namespaces = core_v1.list_namespace().items
        click.echo("Namespaces in the cluster:")
        for ns in namespaces:
            click.echo(f"- {ns.metadata.name}")
    except ApiException as e:
        click.echo(f"Failed to list namespaces: {e}")

@kubectl.command(name="create-resource-quota", help="Create a new resource quota in a namespace.")
@click.option('--name', required=True, help="Name of the resource quota.")
@click.option('--namespace', required=True, help="Namespace to create the resource quota in.")
@click.option('--cpu_limits', required=False, help="CPU limits (e.g., 2).")
@click.option('--memory_limits', required=False, help="Memory limits (e.g., 1Gi).")
@click.option('--pods', required=False, type=int, help="Maximum number of pods.")
@click.option('--services', required=False, type=int, help="Maximum number of services.")
def create_resource_quota(name, namespace, cpu_limits, memory_limits, pods, services):
    """
    Create a new resource quota in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    limits = {
        'limits.cpu': cpu_limits,
        'limits.memory': memory_limits,
        'pods': pods,
        'services': services
    }

    # Remove None values
    limits = {k: v for k, v in limits.items() if v is not None}

    resource_quota_spec = client.V1ResourceQuota(
        metadata=client.V1ObjectMeta(name=name),
        spec=client.V1ResourceQuotaSpec(hard=limits)
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_resource_quota(namespace=namespace, body=resource_quota_spec)
        click.echo(f"Resource quota '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create resource quota '{name}': {e}")
@kubectl.command(name="create-ingress", help="Create a new Ingress resource in Kubernetes.")
@click.option('--name', required=True, help="Name of the Ingress resource.")
@click.option('--namespace', required=True, default='default', help="Namespace to create the Ingress in.")
@click.option('--host', required=True, help="Host name for the Ingress (e.g., example.com).")
@click.option('--service_name', required=True, help="Name of the backend service to route traffic to.")
@click.option('--service_port', required=True, type=int, help="Port of the backend service.")
@click.option('--path', required=False, default='/', help="Path for the Ingress (default: '/').")
@click.option('--tls_secret', required=False, help="TLS secret for HTTPS (optional).")
def create_ingress(name, namespace, host, service_name, service_port, path, tls_secret):
    """
    Create a new Ingress resource in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    ingress_spec = client.V1Ingress(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        spec=client.V1IngressSpec(
            rules=[
                client.V1IngressRule(
                    host=host,
                    http=client.V1HTTPIngressRuleValue(
                        paths=[
                            client.V1HTTPIngressPath(
                                path=path,
                                path_type="Prefix",
                                backend=client.V1IngressBackend(
                                    service=client.V1IngressServiceBackend(
                                        name=service_name,
                                        port=client.V1ServiceBackendPort(number=service_port)
                                    )
                                )
                            )
                        ]
                    )
                )
            ],
            tls=[client.V1IngressTLS(hosts=[host], secret_name=tls_secret)] if tls_secret else None
        )
    )

    networking_v1 = client.NetworkingV1Api()
    try:
        networking_v1.create_namespaced_ingress(namespace=namespace, body=ingress_spec)
        click.echo(f"Ingress '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create Ingress '{name}': {e}")


@kubectl.command(name="delete-ingress", help="Delete an Ingress resource in Kubernetes.")
@click.option('--name', required=True, help="Name of the Ingress resource to delete.")
@click.option('--namespace', required=True, default='default', help="Namespace of the Ingress.")
def delete_ingress(name, namespace):
    """
    Delete an Ingress resource in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    networking_v1 = client.NetworkingV1Api()
    try:
        networking_v1.delete_namespaced_ingress(name=name, namespace=namespace)
        click.echo(f"Ingress '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete Ingress '{name}': {e}")

@kubectl.command(name="create-network-policy", help="Create a new Network Policy in Kubernetes.")
@click.option('--name', required=True, help="Name of the Network Policy.")
@click.option('--namespace', required=True, default='default', help="Namespace to create the Network Policy in.")
@click.option('--pod_selector', required=True, help="Pod selector for applying the Network Policy (e.g., 'app=web').")
@click.option('--ingress_ports', required=False, help="Comma-separated list of allowed ingress ports (e.g., '80,443').")
@click.option('--egress_ports', required=False, help="Comma-separated list of allowed egress ports (e.g., '53').")
def create_network_policy(name, namespace, pod_selector, ingress_ports, egress_ports):
    """
    Create a new Network Policy with specified ingress and egress rules.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    # Create the Pod Selector
    pod_selector_labels = dict(item.split("=") for item in pod_selector.split(","))

    # Create the Ingress and Egress Ports Lists
    ingress_ports_list = [
        client.V1NetworkPolicyPort(port=int(port)) for port in ingress_ports.split(",")
    ] if ingress_ports else []

    egress_ports_list = [
        client.V1NetworkPolicyPort(port=int(port)) for port in egress_ports.split(",")
    ] if egress_ports else []

    network_policy_spec = client.V1NetworkPolicy(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        spec=client.V1NetworkPolicySpec(
            pod_selector=client.V1LabelSelector(match_labels=pod_selector_labels),
            ingress=[client.V1NetworkPolicyIngressRule(ports=ingress_ports_list)],
            egress=[client.V1NetworkPolicyEgressRule(ports=egress_ports_list)]
        )
    )

    networking_v1 = client.NetworkingV1Api()
    try:
        networking_v1.create_namespaced_network_policy(namespace=namespace, body=network_policy_spec)
        click.echo(f"Network Policy '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create Network Policy '{name}': {e}")


@kubectl.command(name="delete-network-policy", help="Delete a Network Policy in Kubernetes.")
@click.option('--name', required=True, help="Name of the Network Policy to delete.")
@click.option('--namespace', required=True, default='default', help="Namespace of the Network Policy.")
def delete_network_policy(name, namespace):
    """
    Delete a Network Policy in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    networking_v1 = client.NetworkingV1Api()
    try:
        networking_v1.delete_namespaced_network_policy(name=name, namespace=namespace)
        click.echo(f"Network Policy '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete Network Policy '{name}': {e}")

@kubectl.command(name="create-service", help="Create a new Service in Kubernetes.")
@click.option('--name', required=True, help="Name of the Service.")
@click.option('--namespace', required=True, default='default', help="Namespace to create the Service in.")
@click.option('--service_type', required=True, type=click.Choice(['ClusterIP', 'NodePort', 'LoadBalancer']), help="Type of the Service (e.g., ClusterIP, NodePort, LoadBalancer).")
@click.option('--port', required=True, type=int, help="Service port.")
@click.option('--target_port', required=True, type=int, help="Target port for the pods.")
@click.option('--selector', required=True, help="Pod selector for the Service (e.g., 'app=web').")
def create_service(name, namespace, service_type, port, target_port, selector):
    """
    Create a new Service with specified properties.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    selector_labels = dict(item.split("=") for item in selector.split(","))

    service_spec = client.V1Service(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        spec=client.V1ServiceSpec(
            type=service_type,
            selector=selector_labels,
            ports=[client.V1ServicePort(port=port, target_port=target_port)]
        )
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_service(namespace=namespace, body=service_spec)
        click.echo(f"Service '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create Service '{name}': {e}")


@kubectl.command(name="delete-service", help="Delete a Service in Kubernetes.")
@click.option('--name', required=True, help="Name of the Service to delete.")
@click.option('--namespace', required=True, default='default', help="Namespace of the Service.")
def delete_service(name, namespace):
    """
    Delete a Service in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_service(name=name, namespace=namespace)
        click.echo(f"Service '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete Service '{name}': {e}")

@kubectl.command(name="create-role", help="Create a new Role in Kubernetes for a specific namespace.")
@click.option('--name', required=True, help="Name of the Role.")
@click.option('--namespace', required=True, help="Namespace to create the Role in.")
@click.option('--api_groups', required=True, help="API Groups to which the Role grants access (e.g., 'apps,core').")
@click.option('--resources', required=True, help="Comma-separated list of resources (e.g., 'pods,deployments').")
@click.option('--verbs', required=True, help="Comma-separated list of verbs (e.g., 'get,list,create,update').")
def create_role(name, namespace, api_groups, resources, verbs):
    """
    Create a new Role with specified permissions in a namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    api_groups_list = api_groups.split(",")
    resources_list = resources.split(",")
    verbs_list = verbs.split(",")

    role_spec = client.V1Role(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        rules=[
            client.V1PolicyRule(
                api_groups=api_groups_list,
                resources=resources_list,
                verbs=verbs_list
            )
        ]
    )

    rbac_v1 = client.RbacAuthorizationV1Api()
    try:
        rbac_v1.create_namespaced_role(namespace=namespace, body=role_spec)
        click.echo(f"Role '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create Role '{name}': {e}")


@kubectl.command(name="create-role-binding", help="Create a new RoleBinding in Kubernetes for a specific namespace.")
@click.option('--name', required=True, help="Name of the RoleBinding.")
@click.option('--namespace', required=True, help="Namespace to create the RoleBinding in.")
@click.option('--role_name', required=True, help="Name of the Role to bind to.")
@click.option('--user_name', required=True, help="Name of the user to bind the Role to.")
@click.option('--service_account_name', required=False, help="Service account name to bind to instead of a user (optional).")
def create_role_binding(name, namespace, role_name, user_name, service_account_name):
    """
    Create a new RoleBinding to grant permissions to a user or service account in a namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    subject = client.V1Subject(
        kind="ServiceAccount" if service_account_name else "User",
        name=service_account_name if service_account_name else user_name,
        namespace=namespace
    )

    role_binding_spec = client.V1RoleBinding(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        role_ref=client.V1RoleRef(
            api_group="rbac.authorization.k8s.io",
            kind="Role",
            name=role_name
        ),
        subjects=[subject]
    )

    rbac_v1 = client.RbacAuthorizationV1Api()
    try:
        rbac_v1.create_namespaced_role_binding(namespace=namespace, body=role_binding_spec)
        click.echo(f"RoleBinding '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create RoleBinding '{name}': {e}")


@kubectl.command(name="create-cluster-role", help="Create a new ClusterRole in Kubernetes for cluster-wide permissions.")
@click.option('--name', required=True, help="Name of the ClusterRole.")
@click.option('--api_groups', required=True, help="API Groups to which the ClusterRole grants access (e.g., 'apps,core').")
@click.option('--resources', required=True, help="Comma-separated list of resources (e.g., 'pods,deployments').")
@click.option('--verbs', required=True, help="Comma-separated list of verbs (e.g., 'get,list,create,update').")
def create_cluster_role(name, api_groups, resources, verbs):
    """
    Create a new ClusterRole with specified permissions.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    api_groups_list = api_groups.split(",")
    resources_list = resources.split(",")
    verbs_list = verbs.split(",")

    cluster_role_spec = client.V1ClusterRole(
        metadata=client.V1ObjectMeta(name=name),
        rules=[
            client.V1PolicyRule(
                api_groups=api_groups_list,
                resources=resources_list,
                verbs=verbs_list
            )
        ]
    )

    rbac_v1 = client.RbacAuthorizationV1Api()
    try:
        rbac_v1.create_cluster_role(body=cluster_role_spec)
        click.echo(f"ClusterRole '{name}' created successfully.")
    except ApiException as e:
        click.echo(f"Failed to create ClusterRole '{name}': {e}")

@kubectl.command(name="create-secret", help="Create a new secret in Kubernetes.")
@click.option('--name', required=True, help="Name of the secret.")
@click.option('--namespace', required=False, default='default', help="Namespace to create the secret in.")
@click.option('--type', required=True, type=click.Choice(['Opaque', 'docker-registry', 'tls']), help="Type of the secret (e.g., Opaque, docker-registry, tls).")
@click.option('--data', required=True, help="Secret data as comma-separated key=value pairs (e.g., 'username=admin,password=secret').")
def create_secret(name, namespace, type, data):
    """
    Create a new secret with specified data.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    data_dict = {k: base64.b64encode(v.encode()).decode() for k, v in (item.split("=") for item in data.split(","))}

    secret_spec = client.V1Secret(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace),
        type=type,
        data=data_dict
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_secret(namespace=namespace, body=secret_spec)
        click.echo(f"Secret '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create secret '{name}': {e}")


@kubectl.command(name="delete-secret", help="Delete a Kubernetes secret.")
@click.option('--name', required=True, help="Name of the secret to delete.")
@click.option('--namespace', required=True, default='default', help="Namespace of the secret.")
def delete_secret(name, namespace):
    """
    Delete a secret in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_secret(name=name, namespace=namespace)
        click.echo(f"Secret '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete secret '{name}': {e}")

@kubectl.command(name="create-service-account", help="Create a new service account in Kubernetes.")
@click.option('--name', required=True, help="Name of the service account.")
@click.option('--namespace', required=True, default='default', help="Namespace to create the service account in.")
def create_service_account(name, namespace):
    """
    Create a new service account in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    service_account_spec = client.V1ServiceAccount(
        metadata=client.V1ObjectMeta(name=name, namespace=namespace)
    )

    core_v1 = client.CoreV1Api()
    try:
        core_v1.create_namespaced_service_account(namespace=namespace, body=service_account_spec)
        click.echo(f"Service account '{name}' created successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to create service account '{name}': {e}")


@kubectl.command(name="delete-service-account", help="Delete a Kubernetes service account.")
@click.option('--name', required=True, help="Name of the service account to delete.")
@click.option('--namespace', required=True, default='default', help="Namespace of the service account.")
def delete_service_account(name, namespace):
    """
    Delete a service account in a specified namespace.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    try:
        core_v1.delete_namespaced_service_account(name=name, namespace=namespace)
        click.echo(f"Service account '{name}' deleted successfully in namespace '{namespace}'.")
    except ApiException as e:
        click.echo(f"Failed to delete service account '{name}': {e}")

@kubectl.command(name="create-ui-access", help="Create a service account for accessing the Kubernetes UI with a bearer token.")
@click.option('--service_account_name', required=True, help="Name of the service account.")
@click.option('--namespace', required=True, default='kube-system', help="Namespace to create the service account in (default: 'kube-system').")
@click.option('--role_name', required=True, default='cluster-admin', help="Role to bind the service account to (e.g., 'cluster-admin').")
def create_k8s_ui_access(service_account_name, namespace, role_name):
    """
    Create a service account and bind it to a role with UI access permissions.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()
    rbac_v1 = client.RbacAuthorizationV1Api()

    try:
        # Step 1: Create Service Account
        click.echo(f"Creating service account '{service_account_name}' in namespace '{namespace}'...")
        service_account = client.V1ServiceAccount(metadata=client.V1ObjectMeta(name=service_account_name, namespace=namespace))
        core_v1.create_namespaced_service_account(namespace=namespace, body=service_account)

        # Step 2: Create Role Binding
        click.echo(f"Creating RoleBinding for service account '{service_account_name}' with role '{role_name}'...")
        role_binding = client.V1RoleBinding(
            metadata=client.V1ObjectMeta(name=f"{service_account_name}-binding", namespace=namespace),
            role_ref=client.V1RoleRef(api_group="rbac.authorization.k8s.io", kind="ClusterRole", name=role_name),
            subjects=[client.V1Subject(kind="ServiceAccount", name=service_account_name, namespace=namespace)]
        )
        rbac_v1.create_namespaced_role_binding(namespace=namespace, body=role_binding)

        click.echo(f"Service account '{service_account_name}' and role binding created successfully.")

        # Step 3: Get Secret associated with Service Account to retrieve the token
        secrets_list = core_v1.list_namespaced_secret(namespace=namespace)
        secret_name = None
        for secret in secrets_list.items:
            if secret.metadata.annotations and secret.metadata.annotations.get('kubernetes.io/service-account.name') == service_account_name:
                secret_name = secret.metadata.name
                break

        if not secret_name:
            click.echo(f"Failed to retrieve the secret for service account '{service_account_name}'.")
            return

        secret = core_v1.read_namespaced_secret(name=secret_name, namespace=namespace)
        token = base64.b64decode(secret.data['token']).decode('utf-8')

        click.echo(f"Token for service account '{service_account_name}':\n{token}")

    except ApiException as e:
        click.echo(f"Failed to create service account or role binding: {e}")

@kubectl.command(name="generate-ui-token", help="Generate a token for an existing Kubernetes service account.")
@click.option('--service_account_name', required=True, help="Name of the service account.")
@click.option('--namespace', required=True, default='kube-system', help="Namespace where the service account is located (default: 'kube-system').")
def generate_k8s_ui_token(service_account_name, namespace):
    """
    Generate a token for an existing service account.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()

    try:
        # Retrieve the secret associated with the service account
        secrets_list = core_v1.list_namespaced_secret(namespace=namespace)
        secret_name = None
        for secret in secrets_list.items:
            if secret.metadata.annotations and secret.metadata.annotations.get('kubernetes.io/service-account.name') == service_account_name:
                secret_name = secret.metadata.name
                break

        if not secret_name:
            click.echo(f"Failed to retrieve the secret for service account '{service_account_name}'.")
            return

        secret = core_v1.read_namespaced_secret(name=secret_name, namespace=namespace)
        token = base64.b64decode(secret.data['token']).decode('utf-8')

        click.echo(f"Token for service account '{service_account_name}':\n{token}")

    except ApiException as e:
        click.echo(f"Failed to retrieve token for service account '{service_account_name}': {e}")

@kubectl.command(name="delete-ui-token", help="Delete a token associated with a Kubernetes service account.")
@click.option('--service_account_name', required=True, help="Name of the service account.")
@click.option('--namespace', required=True, default='kube-system', help="Namespace where the service account is located (default: 'kube-system').")
def delete_k8s_ui_token(service_account_name, namespace):
    """
    Delete the token associated with a service account.
    """
    credentials = load_k8s_credentials()
    config.load_kube_config(config_file=credentials['kubeconfig'], context=credentials['context'])

    core_v1 = client.CoreV1Api()

    try:
        # Retrieve the secret associated with the service account
        secrets_list = core_v1.list_namespaced_secret(namespace=namespace)
        secret_name = None
        for secret in secrets_list.items:
            if secret.metadata.annotations and secret.metadata.annotations.get('kubernetes.io/service-account.name') == service_account_name:
                secret_name = secret.metadata.name
                break

        if not secret_name:
            click.echo(f"Failed to retrieve the secret for service account '{service_account_name}'.")
            return

        # Delete the secret to remove the token
        core_v1.delete_namespaced_secret(name=secret_name, namespace=namespace)
        click.echo(f"Token for service account '{service_account_name}' deleted successfully.")

    except ApiException as e:
        click.echo(f"Failed to delete token for service account '{service_account_name}': {e}")




##################################################################

def generate_k8s_key():
    """Generate and save a secure key for encrypting Kubernetes credentials."""
    key = Fernet.generate_key()
    # Ensure the directory for the key file exists
    os.makedirs(os.path.dirname(K8S_KEY_FILE), exist_ok=True)
    with open(K8S_KEY_FILE, 'wb') as key_file:
        key_file.write(key)


def load_k8s_key():
    """Load the encryption key for Kubernetes credentials."""
    with open(K8S_KEY_FILE, 'rb') as key_file:
        return key_file.read()


def save_k8s_credentials(kubeconfig, context=None, namespace=None):
    # Check if the encryption key file exists; if not, generate it
    if not os.path.exists(K8S_KEY_FILE):
        generate_k8s_key()  # This ensures the key file is created

    # Load and use the key
    key = load_k8s_key()
    fernet = Fernet(key)

    # Create the credentials dictionary
    credentials = {
        "kubeconfig": kubeconfig,
        "context": context or "default",
        "namespace": namespace or "default"
    }

    # Encrypt and save the credentials
    encrypted_credentials = fernet.encrypt(yaml.dump(credentials).encode('utf-8'))

    # Ensure the directory for the config file exists
    os.makedirs(os.path.dirname(K8S_CONFIG_FILE), exist_ok=True)
    with open(K8S_CONFIG_FILE, 'wb') as config_file:
        config_file.write(encrypted_credentials)

    click.echo("Kubernetes configuration saved successfully.")

def load_k8s_credentials():
    """Load and decrypt Kubernetes credentials from the configuration file."""
    if not os.path.exists(K8S_CONFIG_FILE) or not os.path.exists(K8S_KEY_FILE):
        raise Exception("Kubernetes credentials not configured. Run the 'configure-k8s' command first.")

    # Load the encryption key
    key = load_k8s_key()
    fernet = Fernet(key)

    # Read and decrypt the kubeconfig
    with open(K8S_CONFIG_FILE, 'rb') as config_file:
        encrypted_credentials = config_file.read()
        decrypted_credentials = fernet.decrypt(encrypted_credentials)

    # Load the decrypted content as YAML
    credentials = yaml.safe_load(decrypted_credentials)
    if not isinstance(credentials, dict) or 'kubeconfig' not in credentials:
        raise Exception("Invalid kubeconfig structure. Please verify your configuration.")

    # Write the decrypted kubeconfig to a temporary file
    temp_kubeconfig_path = "/tmp/temp_kubeconfig.yaml"
    with open(temp_kubeconfig_path, 'w') as temp_file:
        temp_file.write(credentials['kubeconfig'])

    return temp_kubeconfig_path, credentials['context']

def retrieve_kubeconfig_from_server(ctx, identifier, category=None):
    """
    Retrieve the kubeconfig file from a Kubernetes server using the existing SSH setup.
    """
    # Define remote and local kubeconfig paths
    remote_kubeconfig_path = "/etc/kubernetes/admin.conf"
    local_kubeconfig_path = K8S_CONFIG_FILE  # Use K8S_CONFIG_FILE to save the kubeconfig

    # Access the remote-server data from ctx
    data = ctx.obj

    if identifier.lower() == 'all':
        if category:
            target_identifiers = get_all_identifiers_in_category(category, data)
        else:
            target_identifiers = [server.get('identifiers') for server in data.get('remote-server', [])]
    else:
        try:
            if category:
                target_identifiers = [get_host_entry(identifier, category)[1]]
            else:
                target_identifiers = [get_host_entry(identifier)[1]]
        except ValueError as e:
            click.echo(click.style(f"Error: {e}", fg="red"))
            return None

    # Loop through each identifier to retrieve the kubeconfig
    for remote_identifier in target_identifiers:
        task_user = None
        for server in data.get('remote-server', []):
            if server.get('identifiers') == remote_identifier:
                task_user = server.get('username')
                break

        # Default to "root" if no username is specified
        if not task_user:
            task_user = "root"

        # Build the SCP command
        scp_command = f"scp {task_user}@{remote_identifier}:{remote_kubeconfig_path} {local_kubeconfig_path}"

        # Execute the SCP command
        click.echo(click.style(f"Retrieving kubeconfig from {task_user}@{remote_identifier}", fg="green"))
        result = subprocess.run(scp_command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)

        if result.returncode == 0:
            click.echo(click.style(f"Kubeconfig retrieved successfully from {remote_identifier}", fg="green"))
            return local_kubeconfig_path
        else:
            click.echo(click.style(f"Error retrieving kubeconfig from {remote_identifier}: {result.stderr.decode('utf-8')}", fg="red"))

    return None

########################################################
def save_argocd_credentials(credentials):
    """Save Argo CD credentials to a local file."""
    os.makedirs(os.path.dirname(ARGOCD_CREDENTIALS_FILE), exist_ok=True)
    with open(ARGOCD_CREDENTIALS_FILE, 'w') as f:
        json.dump(credentials, f)
    click.echo("Argo CD credentials saved successfully.")

def load_argocd_credentials():
    """Load saved Argo CD credentials from a local file."""
    if os.path.exists(ARGOCD_CREDENTIALS_FILE):
        with open(ARGOCD_CREDENTIALS_FILE, 'r') as f:
            return json.load(f)
    return None

#####################################################
# sonarqube Command Group
@cli.group(help="Commands to manage sonarqube  resources.")
def sonar():
    pass


@sonar.command(name="assign-quality-gate-to-project", help="Assign a quality gate to a SonarQube project.")
@click.option('--sonarqube_url', required=True, help="SonarQube server URL (e.g., http://sonarqube.example.com)")
@click.option('--project_key', required=True, help="Key of the SonarQube project to assign the quality gate to.")
@click.option('--quality_gate_id', required=True, help="ID of the quality gate to assign to the project.")
def assign_quality_gate_to_project(sonarqube_url, project_key, quality_gate_id):
    """
    Assign a specific quality gate to a SonarQube project using the project key and quality gate ID.
    """
    # Load SonarQube credentials from the stored configuration
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please configure SonarQube credentials first.")
        return

    sonarqube_token = credentials['sonarqube_token']

    # Construct API URL and payload
    assign_url = f"{sonarqube_url}/api/qualitygates/select"
    data = {'projectKey': project_key, 'gateId': quality_gate_id}

    # Send POST request to assign the quality gate to the project
    response = requests.post(assign_url, auth=HTTPBasicAuth(sonarqube_token, ''), data=data)

    if response.status_code == 204:
        click.echo(f"Quality gate '{quality_gate_id}' assigned successfully to project '{project_key}'.")
    else:
        click.echo(f"Failed to assign quality gate to project '{project_key}'. Status code: {response.status_code}\nResponse: {response.text}")



@sonar.command(name="create-quality-gate", help="Create a new quality gate in SonarQube.")
@click.option('--sonarqube_url', required=True, help="SonarQube server URL (e.g., http://sonarqube.example.com)")
@click.option('--quality_gate_name', required=True, help="Name of the quality gate to create.")
def create_sonarqube_quality_gate(sonarqube_url, quality_gate_name):
    """
    Create a new quality gate in SonarQube with the specified name.
    """
    # Load SonarQube credentials from the stored configuration
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please configure SonarQube credentials first.")
        return

    sonarqube_token = credentials['sonarqube_token']

    # Construct API URL and payload
    create_quality_gate_url = f"{sonarqube_url}/api/qualitygates/create"
    data = {'name': quality_gate_name}

    # Send POST request to create the quality gate
    response = requests.post(create_quality_gate_url, auth=HTTPBasicAuth(sonarqube_token, ''), data=data)

    if response.status_code == 200:
        click.echo(f"Quality gate '{quality_gate_name}' created successfully in SonarQube.")
    else:
        click.echo(f"Failed to create quality gate '{quality_gate_name}'. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="get-scan-results", help="Get SonarQube scan results for a Jenkins job.")
@click.option('--sonarqube_url', required=True, help="SonarQube server URL.")
@click.option('--project_key', required=True, help="SonarQube project key to get results for.")
@click.option('--metric_keys', required=False, help="Comma-separated list of metric keys to retrieve (e.g., 'bugs,code_smells').")
def get_sonarqube_scan_results(sonarqube_url, project_key, metric_keys):
    """
    Retrieve SonarQube scan results for a specific project.
    """
    # Load SonarQube credentials from the stored configuration
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please configure SonarQube credentials first.")
        return

    sonarqube_token = credentials['sonarqube_token']

    # Construct the SonarQube API URL for retrieving scan results
    results_url = f"{sonarqube_url}/api/measures/component?component={project_key}&metricKeys={metric_keys or 'bugs,code_smells,coverage'}"
    response = requests.get(results_url, auth=HTTPBasicAuth(sonarqube_token, ''))

    if response.status_code == 200:
        measures = response.json().get('component', {}).get('measures', [])
        click.echo(f"SonarQube Scan Results for Project '{project_key}':")
        for measure in measures:
            click.echo(f"  {measure['metric']}: {measure['value']}")
    else:
        click.echo(f"Failed to retrieve SonarQube scan results. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="trigger-scan", help="Trigger a SonarQube scan from a Jenkins job.")
@click.option('--jenkins_url', required=True, help="Jenkins URL (e.g., http://jenkins.example.com)")
@click.option('--job_name', required=True, help="Name of the Jenkins job to trigger the SonarQube scan.")
@click.option('--branch_name', default='master', help="Branch to scan (default: master).")
@click.option('--build_parameters', default='', help="Additional build parameters for the scan (optional).")
def trigger_sonarqube_scan(jenkins_url, job_name, branch_name, build_parameters):
    """
    Trigger a SonarQube scan for a specified Jenkins job and branch.
    """
    # Load Jenkins credentials from the stored configuration
    jenkins_credentials = load_jenkins_credentials()
    if not jenkins_credentials:
        click.echo("Jenkins credentials not configured. Please configure Jenkins credentials first.")
        return

    username = jenkins_credentials['username']
    api_token = jenkins_credentials['api_token']

    # Construct the URL for triggering the Jenkins job build
    trigger_build_url = f"{jenkins_url}/job/{job_name}/buildWithParameters"
    params = {'SONARQUBE_PROJECT_KEY': job_name, 'branch': branch_name, **json.loads(build_parameters)}

    # Trigger the build
    response = requests.post(trigger_build_url, auth=HTTPBasicAuth(username, api_token), params=params)

    if response.status_code == 201:
        click.echo(f"SonarQube scan triggered successfully for Jenkins job '{job_name}' on branch '{branch_name}'.")
    else:
        click.echo(f"Failed to trigger SonarQube scan. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="configure-jenkins-with-sonarqube", help="Configure a Jenkins job to use SonarQube for analysis.")
@click.option('--jenkins_url', required=True, help="Jenkins URL (e.g., http://jenkins.example.com)")
@click.option('--job_name', required=True, help="Name of the Jenkins job to configure.")
@click.option('--sonarqube_server_url', required=True, help="SonarQube server URL.")
@click.option('--sonarqube_project_key', required=True, help="SonarQube project key for the analysis.")
@click.option('--sonarqube_credentials_id', required=True, help="Credentials ID for accessing SonarQube in Jenkins.")
def configure_jenkins_with_sonarqube(jenkins_url, job_name, sonarqube_server_url, sonarqube_project_key, sonarqube_credentials_id):
    """
    Configure a Jenkins job to use SonarQube for analysis by updating the job configuration.
    """
    # Load Jenkins credentials from the stored configuration
    jenkins_credentials = load_jenkins_credentials()
    if not jenkins_credentials:
        click.echo("Jenkins credentials not configured. Please configure Jenkins credentials first.")
        return

    username = jenkins_credentials['username']
    api_token = jenkins_credentials['api_token']

    # Retrieve the existing job configuration
    config_url = f"{jenkins_url}/job/{job_name}/config.xml"
    response = requests.get(config_url, auth=HTTPBasicAuth(username, api_token))
    if response.status_code != 200:
        click.echo(f"Failed to retrieve Jenkins job configuration. Status code: {response.status_code}")
        return

    # Parse and update the job configuration with SonarQube settings
    job_config_xml = response.text
    sonar_configuration_xml = f"""
    <org.sonarsource.scanner.jenkins.pipeline.SonarQubeInstallationNodeProperty plugin="sonar">
      <installations>
        <org.sonarsource.scanner.jenkins.pipeline.SonarQubeInstallation>
          <name>{sonarqube_project_key}</name>
          <serverUrl>{sonarqube_server_url}</serverUrl>
          <credentialsId>{sonarqube_credentials_id}</credentialsId>
        </org.sonarsource.scanner.jenkins.pipeline.SonarQubeInstallation>
      </installations>
    </org.sonarsource.scanner.jenkins.pipeline.SonarQubeInstallationNodeProperty>
    """

    # Append or update the SonarQube configuration in the job configuration XML
    if '<properties>' in job_config_xml:
        job_config_xml = job_config_xml.replace('<properties>', f'<properties>{sonar_configuration_xml}')
    else:
        job_config_xml = job_config_xml.replace('</project>', f'<properties>{sonar_configuration_xml}</properties></project>')

    # Save the updated configuration back to Jenkins
    headers = {'Content-Type': 'application/xml', 'Jenkins-Crumb': get_jenkins_crumb(jenkins_url, username, api_token)}
    update_response = requests.post(config_url, auth=HTTPBasicAuth(username, api_token), headers=headers, data=job_config_xml)

    if update_response.status_code == 200:
        click.echo(f"Jenkins job '{job_name}' configured successfully with SonarQube.")
    else:
        click.echo(f"Failed to configure Jenkins job '{job_name}' with SonarQube. Status code: {update_response.status_code}")


@sonar.command(name="generate-api-token", help="Generate a new API token for a SonarQube user.")
@click.option('--token_name', required=True, help="Name of the new token.")
@click.option('--username', required=True, help="Username for which to generate the token.")
def generate_sonarqube_api_token(token_name, username):
    """
    Generate a new API token for a SonarQube user.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for generating a new token
    generate_token_url = f"{sonarqube_url}/api/user_tokens/generate"
    data = {
        'name': token_name,
        'login': username
    }

    # Make POST request to generate a new token
    response = requests.post(generate_token_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 200:
        new_token = response.json().get('token')
        click.echo(f"New API token '{token_name}' generated successfully for user '{username}':\n{new_token}")
    else:
        click.echo(f"Failed to generate API token. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="list-api-tokens", help="List all API tokens for a SonarQube user.")
@click.option('--username', required=True, help="Username to list the tokens for.")
def list_sonarqube_api_tokens(username):
    """
    List all API tokens for a SonarQube user.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for listing tokens
    list_tokens_url = f"{sonarqube_url}/api/user_tokens/search?login={username}"

    # Make GET request to list tokens
    response = requests.get(list_tokens_url, auth=HTTPBasicAuth(token, ''))

    if response.status_code == 200:
        tokens = response.json().get('userTokens', [])
        click.echo(f"API Tokens for user '{username}':")
        for t in tokens:
            click.echo(f"  - {t['name']}")
    else:
        click.echo(f"Failed to list API tokens. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="revoke-api-token", help="Revoke an existing API token for a SonarQube user.")
@click.option('--token_name', required=True, help="Name of the token to revoke.")
@click.option('--username', required=True, help="Username for which to revoke the token.")
def revoke_sonarqube_api_token(token_name, username):
    """
    Revoke an existing API token for a SonarQube user.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for revoking a token
    revoke_token_url = f"{sonarqube_url}/api/user_tokens/revoke"
    data = {
        'name': token_name,
        'login': username
    }

    # Make POST request to revoke the token
    response = requests.post(revoke_token_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 204:
        click.echo(f"API token '{token_name}' revoked successfully for user '{username}'.")
    else:
        click.echo(f"Failed to revoke API token. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="assign-permission", help="Assign permissions to a SonarQube user or group.")
@click.option('--permission', required=True, help="Permission to assign (e.g., 'admin', 'scan', 'codeviewer').")
@click.option('--username', required=False, help="Username to assign the permission.")
@click.option('--group_name', required=False, help="Group name to assign the permission.")
@click.option('--project_key', required=False, help="Project key to assign the permission to a specific project.")
def assign_sonarqube_permission(permission, username, group_name, project_key):
    """
    Assign permissions to a SonarQube user or group.
    If a project key is not provided, the permission is assigned globally.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Check if either username or group_name is provided
    if not username and not group_name:
        click.echo("Please provide either a username or group name to assign the permission.")
        return

    # Construct the API URL for assigning permissions
    assign_permission_url = f"{sonarqube_url}/api/permissions/add_user" if username else f"{sonarqube_url}/api/permissions/add_group"
    params = {
        'permission': permission,
        'login' if username else 'groupName': username or group_name
    }

    if project_key:
        params['projectKey'] = project_key

    # Make POST request to assign the permission
    response = requests.post(assign_permission_url, auth=HTTPBasicAuth(token, ''), params=params)

    if response.status_code == 204:
        target = f"user '{username}'" if username else f"group '{group_name}'"
        scope = f"for project '{project_key}'" if project_key else "globally"
        click.echo(f"Permission '{permission}' assigned to {target} {scope}.")
    else:
        click.echo(f"Failed to assign permission. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="revoke-permission", help="Revoke permissions from a SonarQube user or group.")
@click.option('--permission', required=True, help="Permission to revoke (e.g., 'admin', 'scan', 'codeviewer').")
@click.option('--username', required=False, help="Username to revoke the permission from.")
@click.option('--group_name', required=False, help="Group name to revoke the permission from.")
@click.option('--project_key', required=False, help="Project key to revoke the permission from a specific project.")
def revoke_sonarqube_permission(permission, username, group_name, project_key):
    """
    Revoke permissions from a SonarQube user or group.
    If a project key is not provided, the permission is revoked globally.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Check if either username or group_name is provided
    if not username and not group_name:
        click.echo("Please provide either a username or group name to revoke the permission.")
        return

    # Construct the API URL for revoking permissions
    revoke_permission_url = f"{sonarqube_url}/api/permissions/remove_user" if username else f"{sonarqube_url}/api/permissions/remove_group"
    params = {
        'permission': permission,
        'login' if username else 'groupName': username or group_name
    }

    if project_key:
        params['projectKey'] = project_key

    # Make POST request to revoke the permission
    response = requests.post(revoke_permission_url, auth=HTTPBasicAuth(token, ''), params=params)

    if response.status_code == 204:
        target = f"user '{username}'" if username else f"group '{group_name}'"
        scope = f"for project '{project_key}'" if project_key else "globally"
        click.echo(f"Permission '{permission}' revoked from {target} {scope}.")
    else:
        click.echo(f"Failed to revoke permission. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="create-user", help="Create a new SonarQube user.")
@click.option('--username', required=True, help="Username for the new user.")
@click.option('--name', required=True, help="Name of the user.")
@click.option('--email', required=True, help="Email of the user.")
@click.option('--password', required=True, hide_input=True, help="Password for the user.")
def create_sonarqube_user(username, name, email, password):
    """
    Create a new SonarQube user.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for creating a user
    create_user_url = f"{sonarqube_url}/api/users/create"
    data = {
        'login': username,
        'name': name,
        'email': email,
        'password': password
    }

    # Make POST request to create the user
    response = requests.post(create_user_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 200:
        click.echo(f"User '{username}' created successfully.")
    else:
        click.echo(f"Failed to create user '{username}'. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="delete-user", help="Delete an existing SonarQube user.")
@click.option('--username', required=True, help="Username of the user to delete.")
def delete_sonarqube_user(username):
    """
    Delete an existing SonarQube user.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for deleting a user
    delete_user_url = f"{sonarqube_url}/api/users/deactivate"
    data = {'login': username}

    # Make POST request to deactivate the user
    response = requests.post(delete_user_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 204:
        click.echo(f"User '{username}' deleted successfully.")
    else:
        click.echo(f"Failed to delete user '{username}'. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="list-users", help="List all SonarQube users.")
def list_sonarqube_users():
    """
    List all SonarQube users.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for listing users
    list_users_url = f"{sonarqube_url}/api/users/search"

    # Make GET request to list users
    response = requests.get(list_users_url, auth=HTTPBasicAuth(token, ''))

    if response.status_code == 200:
        users = response.json().get('users', [])
        click.echo("SonarQube Users:")
        for user in users:
            click.echo(f"  - {user['login']} : {user['name']}")
    else:
        click.echo(f"Failed to list SonarQube users. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="configure", help="Configure SonarQube URL and credentials.")
@click.option('--sonarqube_url', required=True, help="SonarQube URL (e.g., http://sonarqube.example.com)")
@click.option('--username', required=False, help="Username for SonarQube. If provided, a token will be generated automatically.")
@click.option('--password', required=False, hide_input=True, help="Password for SonarQube.")
@click.option('--token', required=False, hide_input=True, help="API Token for SonarQube. Provide if available, otherwise username and password are required.")
def configure_sonarqube(sonarqube_url, username, password, token):
    """
    Configure SonarQube URL and credentials. Automatically saves the credentials for future use.
    If no API token is provided, the tool will generate one using the username and password.
    """
    if not token and (not username or not password):
        click.echo("Username and password are required to generate an API token.")
        return

    # If no token is provided, generate it using the username and password
    if not token:
        click.echo("Generating SonarQube API token using provided username and password...")
        token = generate_sonarqube_api_token(sonarqube_url, username, password)
        if not token:
            click.echo("Failed to generate API token. Please check your credentials.")
            return

    # Save the SonarQube credentials
    save_sonarqube_credentials(sonarqube_url, token)
    click.echo(f"SonarQube credentials saved successfully for {sonarqube_url}.")


@sonar.command(name="create-project", help="Create a new SonarQube project.")
@click.option('--project_key', required=True, help="Unique key for the SonarQube project.")
@click.option('--project_name', required=True, help="Name of the SonarQube project.")
def create_sonarqube_project(project_key, project_name):
    """
    Create a new SonarQube project.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for creating a project
    create_project_url = f"{sonarqube_url}/api/projects/create"
    data = {
        'project': project_key,
        'name': project_name
    }

    # Make POST request to create the project
    response = requests.post(create_project_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 200:
        click.echo(f"Project '{project_name}' with key '{project_key}' created successfully.")
    else:
        click.echo(f"Failed to create project '{project_name}'. Status code: {response.status_code}\nResponse: {response.text}")


@sonar.command(name="delete-project", help="Delete an existing SonarQube project.")
@click.option('--project_key', required=True, help="Unique key of the SonarQube project to delete.")
def delete_sonarqube_project(project_key):
    """
    Delete an existing SonarQube project.
    """
    credentials = load_sonarqube_credentials()
    if not credentials:
        click.echo("SonarQube credentials not configured. Please run 'configure-sonarqube' first.")
        return

    sonarqube_url = credentials.get('sonarqube_url')
    token = credentials.get('sonarqube_token')

    # Construct the API URL for deleting a project
    delete_project_url = f"{sonarqube_url}/api/projects/delete"
    data = {'project': project_key}

    # Make POST request to delete the project
    response = requests.post(delete_project_url, auth=HTTPBasicAuth(token, ''), data=data)

    if response.status_code == 204:
        click.echo(f"Project with key '{project_key}' deleted successfully.")
    else:
        click.echo(f"Failed to delete project with key '{project_key}'. Status code: {response.status_code}\nResponse: {response.text}")

############################################################################################################



@cli.group()
def ansible():
    """Commands related to Ansible configuration and setup."""

@ansible.command(name="config", help="Provision the Ansible controller and workers from the YAML configuration file.")
@click.option('--file-path', required=True, help="Path to the YAML configuration file.")
def setup_controller(file_path):
    with open(file_path, 'r') as file:
        config_data = yaml.safe_load(file)

    # Controller configuration
    ami_id = config_data['ami_id']
    instance_type = config_data['instance_type']
    key_name = config_data['key_name']
    security_group = config_data['security_group']
    controller_name = config_data['controller_name']
    inventory_path = config_data['inventory_path']
    username = config_data.get('username', 'root')

    # Generate and inject SSH key
    generate_ssh_key()
    ssh_key_content = get_ssh_key()
    user_data = prepare_user_data_script(ssh_key_content)

    # Provision the controller instance
    instance_ids, private_ips = create_ec2_instances_direct(
        instance_type=instance_type,
        ami_id=ami_id,
        key_name=key_name,
        security_group=security_group,
        count=1,
        tags={"Name": controller_name},
        user_data=user_data
    )

    if not instance_ids or not private_ips:
        click.echo("Failed to set up the Ansible controller.")
        return

    instance_ip = private_ips[0]
    add_ansible_host_entry(controller_name, instance_ip)

    # Wait for the controller instance to be ready
    click.echo(f"Waiting for the instance '{controller_name}' to be ready...")
    wait_for_instance(instance_ip, username)

    # Configure the controller
    controller_ssh_key = generate_ssh_key_on_controller(instance_ip, username)
    if controller_ssh_key:
        save_to_transit(controller_ssh_key)
    else:
        click.echo(click.style("Failed to save SSH key to transit as it was not retrieved.", fg="red"))
    create_inventory_on_controller(controller_name, inventory_path, username)
    install_ansible_on_controller(instance_ip, username)

        # Configure ansible.cfg on the controller
    ansible_cfg_path = config_data.get('ansible_cfg_path', '/etc/ansible/ansible.cfg')
    ansible_config = config_data.get('ansible_config', None)  # Allow overriding defaults
    configure_ansible_cfg(instance_ip, ansible_cfg_path, ansible_config, username)

    # Worker configuration
    workers = config_data.get('workers', [])
    if workers:
        provision_workers(workers, user_data, username)
        distribute_ssh_key_to_workers(workers, username)
        configure_workers(workers, username)
        add_workers_to_inventory(workers, controller_name, inventory_path, username)
        test_ansible_ping(controller_name, inventory_path, username)

    click.echo(f"Ansible controller '{controller_name}' setup complete.")

def save_to_transit(ssh_key):
    """
    Save the SSH public key to the transit file.
    """
    if ssh_key is None:
        click.echo(click.style("No SSH key provided to save in transit file.", fg="red"))
        return

    os.makedirs(os.path.dirname(REMOTE_SSH_TRANSIT), exist_ok=True)
    with open(REMOTE_SSH_TRANSIT, 'w') as file:
        file.write(ssh_key)
    click.echo(f"SSH key saved to transit file '{REMOTE_SSH_TRANSIT}'.")

def configure_ansible_cfg(instance_ip, ansible_cfg_path, ansible_config=None, username="root"):
    """
    Configure the ansible.cfg file on the controller, prioritizing user-provided configurations.
    """
    # If no additional configurations are provided, create an empty configuration file
    if not ansible_config:
        click.echo("No custom Ansible configurations provided. Using defaults in the script.")
        ansible_config = {}

    # Generate the ansible.cfg content
    cfg_lines = []
    for section, options in ansible_config.items():
        cfg_lines.append(f"[{section}]")
        for key, value in options.items():
            cfg_lines.append(f"{key} = {value}")
        cfg_lines.append("")  # Blank line between sections

    cfg_content = "\n".join(cfg_lines)

    # Ensure the ansible directory exists on the controller
    create_dir_command = f"mkdir -p $(dirname {ansible_cfg_path})"
    success, message = execute_command_on_controller(instance_ip, username, create_dir_command)

    if not success:
        click.echo(click.style(f"Failed to create directory for ansible.cfg: {message}", fg="red"))
        return

    # Upload the ansible.cfg to the controller
    command = f"echo '{cfg_content}' > {ansible_cfg_path}"
    success, message = execute_command_on_controller(instance_ip, username, command)

    if success:
        click.echo(f"ansible.cfg configured at '{ansible_cfg_path}' on the controller.")
    else:
        click.echo(click.style(f"Failed to configure ansible.cfg: {message}", fg="red"))

def distribute_ssh_key_to_workers(workers, username):
    """Distribute the SSH key from the transit file to the workers."""
    if not os.path.exists(REMOTE_SSH_TRANSIT):
        click.echo(click.style("Transit file does not exist. Cannot distribute SSH key.", fg="red"))
        return

    with open(REMOTE_SSH_TRANSIT, 'r') as file:
        ssh_key = file.read()

    for worker in workers:
        worker_ip = get_worker_host_entry(worker['name'])[0]
        command = f"echo '{ssh_key}' >> ~/.ssh/authorized_keys"
        success, message = execute_command_on_controller(worker_ip, username, command)
        if success:
            click.echo(f"SSH key added to worker '{worker['name']}' at IP '{worker_ip}'.")
        else:
            click.echo(f"Failed to add SSH key to worker '{worker['name']}': {message}")


def generate_ssh_key_on_controller(host_ip, username="root"):
    """
    Check if an SSH key exists on the Ansible controller. If not, generate one, and return the public key.
    """
    check_command = "ls ~/.ssh/id_rsa.pub"
    generate_command = "ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ''"
    cat_command = "cat ~/.ssh/id_rsa.pub"

    # Check if the SSH key exists
    success, _ = execute_command_on_controller(host_ip, username, check_command)
    if not success:
        # Generate the SSH key if it doesn't exist
        success, message = execute_command_on_controller(host_ip, username, generate_command)
        if not success:
            click.echo(click.style(f"Failed to generate SSH key on controller: {message}", fg="red"))
            return None

    # Retrieve the public key
    success, public_key = execute_command_on_controller(host_ip, username, cat_command)
    if success and public_key.strip():
        click.echo("SSH public key retrieved from controller.")
        return public_key.strip()
    else:
        click.echo(click.style(f"Failed to retrieve SSH public key: {public_key or 'Empty response'}", fg="red"))
        return None

def install_ansible_on_controller(host_ip, username="root"):
    """
    Detect the operating system, install Ansible on the controller,
    and set up the necessary configuration.
    """
    # Detect OS
    os_check_command = "cat /etc/os-release | grep '^ID=' | cut -d= -f2"
    success, os_id = execute_command_on_controller(host_ip, username, os_check_command)

    if not success:
        click.echo(click.style(f"Failed to detect operating system: {os_id}", fg="red"))
        return

    os_id = os_id.strip().lower()
    click.echo(f"Detected OS: {os_id}")

    # Install Ansible based on OS
    if os_id in ["ubuntu", "debian"]:
        install_command = (
            "apt-get update -y && "
            "apt-get install -y software-properties-common && "
            "add-apt-repository --yes --update ppa:ansible/ansible && "
            "apt-get install -y ansible"
        )
    elif os_id in ["centos", "rhel", "almalinux", "rocky"]:
        install_command = (
            "yum update -y && "
            "yum install -y epel-release && "
            "yum install -y ansible"
        )
    else:
        click.echo(click.style(f"Unsupported operating system: {os_id}", fg="red"))
        return

    success, message = execute_command_on_controller(host_ip, username, install_command)
    if success:
        click.echo("Ansible successfully installed on the controller.")
    else:
        click.echo(click.style(f"Failed to install Ansible: {message}", fg="red"))
        return

    # Create /etc/ansible directory
    create_ansible_dir_command = "mkdir -p /etc/ansible"
    success, message = execute_command_on_controller(host_ip, username, create_ansible_dir_command)
    if success:
        click.echo("/etc/ansible directory created.")
    else:
        click.echo(click.style(f"Failed to create /etc/ansible directory: {message}", fg="red"))
        return

    # Download default ansible.cfg
    download_ansible_cfg_command = (
        "curl -o /etc/ansible/ansible.cfg "
        "https://raw.githubusercontent.com/ansible/ansible/devel/examples/ansible.cfg"
    )
    success, message = execute_command_on_controller(host_ip, username, download_ansible_cfg_command)
    if success:
        click.echo("Default ansible.cfg downloaded to /etc/ansible.")
    else:
        click.echo(click.style(f"Failed to download ansible.cfg: {message}", fg="red"))
        return

    click.echo(click.style("Ansible installation and configuration complete.", fg="green"))



def setup_workers(worker_config):
    """
    Provision the Ansible worker instances.
    """
    # Generate and inject SSH key for workers
    generate_ssh_key()
    ssh_key_content = get_ssh_key()
    user_data = prepare_user_data_script(ssh_key_content)

    for worker in worker_config:
        worker_name = worker['name']
        worker_ami_id = worker['ami_id']
        worker_instance_type = worker['instance_type']
        worker_key_name = worker['key_name']
        worker_security_group = worker['security_group']

        # Provision the worker
        worker_instance_ids, worker_private_ips = create_ec2_instances_direct(
            instance_type=worker_instance_type,
            ami_id=worker_ami_id,
            key_name=worker_key_name,
            security_group=worker_security_group,
            count=1,
            tags={"Name": worker_name},
            user_data=user_data  # Inject SSH key during provisioning
        )

        if worker_instance_ids and worker_private_ips:
            add_ansible_worker_entry(worker_name, worker_private_ips[0])
            click.echo(f"Worker '{worker_name}' setup complete.")
        else:
            click.echo(f"Failed to set up worker '{worker_name}'.")

def add_ansible_worker_entry(instance_name, private_ip):
    """
    Add the instance IP and name to the hosts file under the 'ansible-workers' category.
    """
    ansible_workers_category = "[ansible-workers]"
    entry = f"{private_ip} {instance_name}\n"
    found_category = False

    # Read the existing hosts file
    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    updated_lines = []
    for line in lines:
        # Check if 'ansible-workers' category already exists
        if line.strip() == ansible_workers_category:
            found_category = True
            updated_lines.append(line)
            updated_lines.append(entry)  # Add the new entry under the category
        else:
            updated_lines.append(line)

    # Add the category and entry if it wasn't found
    if not found_category:
        updated_lines.append(f"\n{ansible_workers_category}\n")
        updated_lines.append(entry)

    # Write back the updated hosts file
    with open(HOSTS_FILE, 'w') as file:
        file.writelines(updated_lines)

    click.echo(f"Added '{instance_name}' with IP '{private_ip}' under '{ansible_workers_category}' in {HOSTS_FILE}.")

def get_worker_host_entry(identifier):
    """
    Retrieves the IP and name of the worker host entry based on the identifier.
    Looks specifically within the 'ansible-workers' category.
    """
    category_found = False
    with open(HOSTS_FILE, 'r') as hosts_file:
        for line in hosts_file:
            # Check if 'ansible-workers' category starts
            if line.strip() == "[ansible-workers]":
                category_found = True
            # Stop searching if a new category starts
            elif line.startswith("[") and category_found:
                break

            # Match identifier in the 'ansible-workers' category
            if category_found and identifier in line:
                return line.split()[0], line.split()[1]

    raise ValueError(f"No entry found for worker '{identifier}' in 'ansible-workers' category.")


def add_ansible_host_entry(instance_name, private_ip):
    """
    Add the instance IP and name to the hosts file under the 'ansible-config' category.
    """
    ansible_config_category = "[ansible-config]"
    entry = f"{private_ip} {instance_name}\n"
    found_category = False

    # Read the existing hosts file
    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    updated_lines = []
    for line in lines:
        # Check if 'ansible-config' category already exists
        if line.strip() == ansible_config_category:
            found_category = True
            updated_lines.append(line)
            updated_lines.append(entry)  # Add the new entry under the category
        else:
            updated_lines.append(line)

    # Add the category and entry if it wasn't found
    if not found_category:
        updated_lines.append(f"\n{ansible_config_category}\n")
        updated_lines.append(entry)

    # Write back the updated hosts file
    with open(HOSTS_FILE, 'w') as file:
        file.writelines(updated_lines)

    click.echo(f"Added '{instance_name}' with IP '{private_ip}' under '{ansible_config_category}' in {HOSTS_FILE}.")


def create_ec2_instances_direct(instance_type, ami_id, key_name, security_group, count, tags, user_data=None):
    """
    Create EC2 instances with the given parameters.
    """
    credentials = load_aws_credentials()
    if not credentials:
        click.echo("No AWS credentials found. Please configure them first.")
        return None, None

    ec2 = boto3.client('ec2', **credentials)
    try:
        instances = ec2.run_instances(
            InstanceType=instance_type,
            ImageId=ami_id,
            KeyName=key_name,
            SecurityGroupIds=[security_group],
            MinCount=count,
            MaxCount=count,
            TagSpecifications=[{
                'ResourceType': 'instance',
                'Tags': [{'Key': key, 'Value': value} for key, value in tags.items()]
            }],
            UserData=user_data
        )

        instance_ids = [instance['InstanceId'] for instance in instances['Instances']]
        private_ips = [instance['PrivateIpAddress'] for instance in instances['Instances']]

        # Log instance creation
        for instance_id in instance_ids:
            click.echo(f"Instance created with ID: {instance_id}")

        return instance_ids, private_ips
    except ClientError as e:
        click.echo(click.style(f"Failed to create instances: {e}", fg="red"))
        return None, None


# Function to execute commands on the Ansible controller
def execute_command_on_controller(host_ip, username, command, timeout=None, real_time_output=False):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(host_ip, username=username, key_filename=SSH_KEY_FILE)

        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)

        output, error = "", ""
        if real_time_output:
            for line in iter(stdout.readline, ""):
                print(line, end="", flush=True)
                output += line
            for line in iter(stderr.readline, ""):
                print(line, end="", flush=True)
                error += line
        else:
            output = stdout.read().decode()
            error = stderr.read().decode()

        exit_status = stdout.channel.recv_exit_status()
        client.close()

        if exit_status == 0:
            return True, output + error
        else:
            return False, output + error

    except Exception as e:
        return False, str(e)

def provision_workers(workers, user_data, username="root"):
    """Provision worker instances and configure them for Ansible."""
    for worker in workers:
        worker_name = worker['name']
        worker_ami_id = worker['ami_id']
        worker_instance_type = worker['instance_type']
        worker_key_name = worker['key_name']
        worker_security_group = worker['security_group']

        # Provision the worker instance
        instance_ids, private_ips = create_ec2_instances_direct(
            instance_type=worker_instance_type,
            ami_id=worker_ami_id,
            key_name=worker_key_name,
            security_group=worker_security_group,
            count=1,
            tags={"Name": worker_name},
            user_data=user_data
        )

        if instance_ids and private_ips:
            worker_ip = private_ips[0]  # Use the first private IP for the worker
            add_ansible_worker_entry(worker_name, worker_ip)
            click.echo(f"Worker '{worker_name}' setup complete.")

            # Wait for the worker to be ready
            if not wait_for_instance(worker_ip, username):
                click.echo(click.style(f"Worker '{worker_name}' is not ready. Skipping.", fg="red"))
                continue

            # Configure SSH on the worker
            if configure_worker_ssh(worker_ip, username):
                click.echo(f"Worker '{worker_name}' configured successfully.")
            else:
                click.echo(click.style(f"Failed to configure SSH on worker '{worker_name}'.", fg="red"))
        else:
            click.echo(click.style(f"Failed to provision worker '{worker_name}'.", fg="red"))




def test_ansible_ping(controller_name, inventory_path, username="root"):
    """
    Use Ansible ping module to test connectivity to all workers.
    """
    # Retrieve the IP of the Ansible controller from the hosts file
    private_ip, _ = get_ansible_host_entry(controller_name, category="ansible-config")

    # Construct the ping command
    ping_command = f"ansible all -i {inventory_path} -m ping"

    # Execute the ping command on the controller
    success, message = execute_command_on_controller(private_ip, username, ping_command)

    if success:
        click.echo("Ansible ping successful. Controller can connect to all workers.")
    else:
        click.echo(click.style(f"Ansible ping failed: {message}", fg="red"))


def get_worker_host_entry(identifier):
    """
    Retrieves the IP and name of the worker host entry based on the identifier.
    Looks specifically within the 'ansible-workers' category.
    """
    category_found = False
    with open(HOSTS_FILE, 'r') as hosts_file:
        for line in hosts_file:
            if line.strip() == "[ansible-workers]":
                category_found = True
            elif line.startswith("[") and category_found:
                break

            if category_found and identifier in line:
                parts = line.split()
                if len(parts) >= 2:
                    return parts[0], parts[1]

    raise ValueError(f"No entry found for worker '{identifier}' in 'ansible-workers' category.")

def configure_worker_for_ansible(worker_ip, controller_ssh_key, username="root"):
    """
    Configure the worker to accept connections from the controller.
    """
    add_key_command = f"echo '{controller_ssh_key.strip()}' >> /root/.ssh/authorized_keys && chmod 600 /root/.ssh/authorized_keys"
    restart_ssh_command = "service ssh restart || systemctl restart sshd"

    # Add controller's SSH key to worker's authorized_keys
    success, message = execute_command_on_worker(worker_ip, username, add_key_command)
    if not success:
        click.echo(click.style(f"Failed to add SSH key to worker '{worker_ip}': {message}", fg="red"))
        return False

    # Restart SSH service
    success, message = execute_command_on_worker(worker_ip, username, restart_ssh_command)
    if not success:
        click.echo(click.style(f"Failed to restart SSH service on worker '{worker_ip}': {message}", fg="red"))
        return False

    click.echo(f"Worker '{worker_ip}' configured to accept SSH connections from the controller.")
    return True


def wait_for_instance(host_ip, username, max_retries=10, retry_delay=15):
    """Wait for an instance to become reachable."""
    for attempt in range(max_retries):
        success, _ = execute_command_on_controller(host_ip, username, "echo Instance is up", timeout=10)
        if success:
            click.echo("Instance is ready.")
            return
        click.echo(f"Attempt {attempt + 1} failed. Retrying in {retry_delay} seconds...")
        time.sleep(retry_delay)
    click.echo(click.style("Failed to connect to the instance within the retry limit.", fg="red"))
    raise RuntimeError("Instance not reachable.")

def get_hosts_from_ansible_config():
    """
    Retrieves all hosts under the 'ansible-config' category from the hosts file.
    """
    hosts = []
    in_ansible_config = False
    with open(HOSTS_FILE, 'r') as file:
        for line in file:
            if line.strip() == "[ansible-config]":
                in_ansible_config = True
            elif line.startswith("[") and in_ansible_config:
                break  # Stop if another category starts
            elif in_ansible_config and line.strip():
                parts = line.split()
                if len(parts) >= 2:
                    ip, name = parts[:2]
                    hosts.append({'name': name, 'ip': ip})
    return hosts

def configure_workers(workers, username="root"):
    """Configure SSH on all workers and ensure they are ready for Ansible."""
    for worker in workers:
        # Retrieve IP from the worker entry in Ansible inventory or provisioning step
        worker_ip = worker.get('ip')
        worker_name = worker['name']
        if not worker_ip:
            click.echo(click.style(f"IP for worker '{worker_name}' not found. Skipping.", fg="red"))
            continue

        click.echo(f"Configuring SSH on worker '{worker_name}' with IP '{worker_ip}'...")
        if not configure_worker_ssh(worker_ip, username):
            click.echo(click.style(f"Failed to configure worker '{worker_name}'. Skipping.", fg="red"))
            continue

    click.echo("All workers configured for SSH.")

def configure_worker_ssh(worker_ip, username="root"):
    """
    Configures SSH on the worker to allow connections from the Ansible controller.
    """
    ssh_config_commands = [
        "sed -i 's/^#\\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config",
        "sed -i 's/^#\\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config",
        "systemctl restart sshd"
    ]

    for command in ssh_config_commands:
        success, message = execute_command_on_controller(worker_ip, username, command)
        if not success:
            click.echo(click.style(f"Failed to configure SSH on worker '{worker_ip}': {message}", fg="red"))
            return False

    click.echo(f"SSH configured successfully on worker '{worker_ip}'.")
    return True


def generate_inventory_content():
    """
    Generates inventory content dynamically based on the 'ansible-config' category in the hosts file.
    """
    hosts = get_hosts_from_ansible_config()
    inventory_lines = []
    for host in hosts:
        inventory_lines.append(f"{host['ip']} ansible_user=root")
    return "\n".join(inventory_lines)


def generate_ssh_key_on_controller(host_ip, username="root"):
    """
    Generate an SSH key on the controller if it doesn't exist and return the public key.
    """
    check_command = "ls ~/.ssh/id_rsa.pub"
    generate_command = "ssh-keygen -t rsa -b 2048 -f ~/.ssh/id_rsa -N ''"
    cat_command = "cat ~/.ssh/id_rsa.pub"

    # Check if the SSH key exists
    success, _ = execute_command_on_controller(host_ip, username, check_command)
    if not success:
        # Generate the SSH key if it doesn't exist
        success, message = execute_command_on_controller(host_ip, username, generate_command)
        if not success:
            click.echo(click.style(f"Failed to generate SSH key on the controller: {message}", fg="red"))
            return None

    # Retrieve the public key
    success, ssh_key = execute_command_on_controller(host_ip, username, cat_command)
    if success:
        click.echo("SSH key successfully generated on the controller.")
        return ssh_key.strip()
    else:
        click.echo(click.style(f"Failed to retrieve SSH public key from the controller: {ssh_key}", fg="red"))
        return None


def create_inventory_on_controller(identifier, inventory_path, username="root"):
    """
    Create an inventory file on the Ansible controller and ensure an SSH key is available.
    """
    private_ip, _ = get_ansible_host_entry(identifier, category="ansible-config")

    # Ensure SSH key is available on the controller
    generate_ssh_key_on_controller(private_ip, username)

    # Generate inventory content dynamically
    inventory_content = generate_inventory_content()

    # Command to write the inventory file content to the specified path
    command = f"echo '{inventory_content}' > {inventory_path}"
    success, message = execute_command_on_controller(private_ip, username, command)

    if success:
        click.echo(f"Ansible inventory file created at '{inventory_path}' on controller '{identifier}'.")
    else:
        click.echo(click.style(f"Failed to create inventory file on controller '{identifier}': {message}", fg="red"))

def get_hosts_from_ansible_config():
    hosts = []
    in_ansible_config = False
    with open(HOSTS_FILE, 'r') as file:
        for line in file:
            if line.strip() == "[ansible-config]":
                in_ansible_config = True
            elif line.startswith("[") and in_ansible_config:
                break
            elif in_ansible_config and line.strip():
                parts = line.split()
                if len(parts) >= 2:
                    ip, name = parts[:2]
                    hosts.append({'name': name, 'ip': ip})
    return hosts

def get_ansible_host_entry(identifier, category=None):
    """
    Retrieves the IP and name of the host entry based on the identifier.
    Optionally looks within a specified category if provided.
    """
    category_found = False
    with open(HOSTS_FILE, 'r') as hosts_file:
        for line in hosts_file:
            if category:
                if line.strip() == f"[{category}]":
                    category_found = True
                elif line.startswith("[") and category_found:
                    break
            else:
                if line.startswith("["):
                    continue

            if identifier in line:
                return line.split()[0], line.split()[1]

    raise ValueError(f"No entry found for identifier '{identifier}' in category '{category or 'default'}'.")


def add_workers_to_inventory(workers, controller_name, inventory_path, username):
    """
    Add workers to the controller's inventory file using names and IPs from the host file.
    """
    private_ip, _ = get_ansible_host_entry(controller_name, category="ansible-config")

    for worker in workers:
        worker_name = worker['name']
        try:
            worker_ip, saved_name = get_worker_host_entry(worker_name)
            inventory_entry = f"{saved_name} ansible_host={worker_ip} ansible_user=root\n"

            # Add entry to the controller's inventory
            command = f"echo '{inventory_entry}' >> {inventory_path}"
            success, message = execute_command_on_controller(private_ip, username, command)

            if success:
                click.echo(f"Added worker '{saved_name}' with IP '{worker_ip}' to inventory.")
            else:
                click.echo(click.style(f"Failed to add worker '{saved_name}' to inventory: {message}", fg="red"))
        except ValueError as e:
            click.echo(click.style(f"Worker '{worker_name}' not found in the host file: {e}", fg="red"))




@ansible.command(name="attach-worker", help="Attach new workers to the existing Ansible controller.")
@click.option('--file-path', required=True, help="Path to the YAML configuration file for the workers.")
def attach_worker(file_path):
    """
    Attach new workers to the Ansible controller.
    """
    with open(file_path, 'r') as file:
        config_data = yaml.safe_load(file)

    # Retrieve configuration for the controller
    controller_name = config_data['controller_name']
    inventory_path = config_data['inventory_path']
    username = config_data.get('username', 'root')

    ssh_key_content = get_ssh_key()
    user_data = prepare_user_data_script(ssh_key_content)


    # Worker configuration
    workers = config_data.get('workers', [])
    if workers:
        provision_workers(workers, user_data, username)
        distribute_ssh_key_to_workers(workers, username)
        configure_workers(workers, username)
        add_workers_to_inventory(workers, controller_name, inventory_path, username)
        test_ansible_ping(controller_name, inventory_path, username)

    click.echo(f"Ansible controller '{controller_name}' setup complete.")

##########################################################################################################
@cli.group()
def run():
    """
    Run commands through the dob tool.
    """


@run.command(name="ansible", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True))
@click.argument('ansible_command', nargs=-1, required=True)
@click.option('--controller-name', default="ansible-controller", help="Name of the Ansible controller.")
def run_ansible(ansible_command, controller_name):
    """
    Run an Ansible command on the controller.
    """
    # Join the command arguments to form the full Ansible command
    command_to_run = f"ansible {' '.join(ansible_command)}"

    # Retrieve the controller's IP from the hosts file
    try:
        controller_ip, _ = get_ansible_host_entry(controller_name, category="ansible-config")
    except ValueError as e:
        click.echo(click.style(f"Error retrieving controller details: {e}", fg="red"))
        return

    # Execute the command on the controller
   # click.echo(f"Running command on Ansible controller '{controller_name}': {command_to_run}")
    success, output = execute_command_on_controller(controller_ip, "root", command_to_run)

    if success:
       # click.echo(click.style("Command executed successfully.", fg="green"))
        click.echo(output)
    else:
        click.echo(click.style(f"Command execution failed: {output}", fg="red"))

@run.command(name="kubectl", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True))
@click.argument('kubectl_command', nargs=-1, required=True)
@click.option('--master-name', default="k8s-master", help="Name of the Kubernetes master node.")
def run_kubectl(kubectl_command, master_name):
    """
    Run a kubectl command on the master node.
    """
    # Join the command arguments to form the full kubectl command
    command_to_run = f"kubectl {' '.join(kubectl_command)}"

    # Retrieve the master's IP from the formatted hosts file
    try:
        master_ip = get_master_ip_from_hosts(master_name, category="dks-master")
    except ValueError as e:
        click.echo(click.style(f"Error retrieving master node details: {e}", fg="red"))
        return

    # Execute the command on the master node
   # click.echo(f"Running command on Kubernetes master '{master_name}' at IP '{master_ip}': {command_to_run}")
    success, output = execute_command_on_server(master_ip, "root", command_to_run)

    if success:
       # click.echo(click.style("Command executed successfully.", fg="green"))
        click.echo(output)
    else:
        click.echo(click.style(f"Command execution failed: {output}", fg="red"))


def get_master_ip_from_hosts(master_name, category="dks-master"):
    """
    Retrieve the master node's IP from the formatted hosts file.

    Args:
        master_name (str): Name of the master node.
        category (str): Category header in the hosts file (e.g., [dks-master]).

    Returns:
        str: IP address of the master node.

    Raises:
        ValueError: If the master node or category is not found.
    """
    hosts_file_path = "/etc/hosts"

    try:
        with open(hosts_file_path, "r") as file:
            lines = file.readlines()
    except FileNotFoundError:
        raise ValueError(f"Hosts file '{hosts_file_path}' not found.")

    inside_category = False
    for line in lines:
        line = line.strip()
        if line == f"[{category}]":
            inside_category = True
            continue

        if inside_category:
            if line == "" or line.startswith("["):
                break  # End of the current category
            parts = line.split()
            if len(parts) >= 2 and parts[1] == master_name:
                return parts[0]  # Return the IP address

    raise ValueError(f"Host '{master_name}' with category '{category}' not found in {hosts_file_path}.")

@run.command(name="docker", context_settings=dict(ignore_unknown_options=True, allow_extra_args=True))
@click.argument('docker_command', nargs=-1, required=True)
@click.option('--manager-name', default="swarm-manager", help="Name of the Docker Swarm manager node.")
def run_docker(docker_command, manager_name):
    """
    Run a Docker command on the Swarm manager node.
    """
    # Join the command arguments to form the full Docker command
    command_to_run = f"docker {' '.join(docker_command)}"

    # Retrieve the manager's IP from the formatted hosts file
    try:
        manager_ip = get_manager_ip_from_hosts(manager_name, category="swarm-manager")
    except ValueError as e:
        click.echo(click.style(f"Error retrieving manager node details: {e}", fg="red"))
        return

    # Execute the command on the manager node
    success, output = execute_command_on_server(manager_ip, "root", command_to_run)

    if success:
        click.echo(output)
    else:
        click.echo(click.style(f"Command execution failed: {output}", fg="red"))


def get_manager_ip_from_hosts(manager_name, category="swarm-manager"):
    """
    Retrieve the manager node's IP from the formatted hosts file.

    Args:
        manager_name (str): Name of the manager node.
        category (str): Category header in the hosts file (e.g., [swarm-manager]).

    Returns:
        str: IP address of the manager node.

    Raises:
        ValueError: If the manager node or category is not found.
    """
    hosts_file_path = "/etc/hosts"

    try:
        with open(hosts_file_path, "r") as file:
            lines = file.readlines()
    except FileNotFoundError:
        raise ValueError(f"Hosts file '{hosts_file_path}' not found.")

    inside_category = False
    for line in lines:
        line = line.strip()
        if line == f"[{category}]":
            inside_category = True
            continue

        if inside_category:
            if line == "" or line.startswith("["):
                break  # End of the current category
            parts = line.split()
            if len(parts) >= 2 and parts[1] == manager_name:
                return parts[0]  # Return the IP address

    raise ValueError(f"Host '{manager_name}' with category '{category}' not found in {hosts_file_path}.")


#################################################################################################################
@cli.group()
def dks():
    """Commands related to DevOps Kubernetes Services (DKS)."""

@dks.command(name="config", help="Provision and configure DKS (Kubernetes services).")
@click.option('--file-path', required=True, help="Path to the YAML configuration file.")
def setup_dks(file_path):
    """
    Read the configuration file and set up Kubernetes services using DKS.
    """
    try:
        # Load configuration from the YAML file
        with open(file_path, 'r') as file:
            config = yaml.safe_load(file)

        # Validate the configuration
        if "master" not in config or "workers" not in config:
            click.echo(click.style("Invalid configuration: Missing 'master' or 'workers' section.", fg="red"))
            return

        click.echo(click.style("Starting DKS (DevOps Kubernetes Services) setup...", fg="blue"))

        # Generate and inject SSH key for instances
        generate_ssh_key()
        ssh_key_content = get_ssh_key()
        user_data = prepare_user_data_script(ssh_key_content)

        # Provision and set up the Kubernetes master node
        master_ip = setup_dks_master(config, user_data)
        if not master_ip:
            click.echo(click.style("Failed to set up Kubernetes master node.", fg="red"))
            return

        click.echo(f"Kubernetes master node set up successfully at {master_ip}.")

        # Provision and configure worker nodes
        setup_dks_workers(config, user_data)
        click.echo(click.style("Kubernetes worker nodes configured successfully.", fg="green"))

        click.echo(click.style("DKS setup complete!", fg="green"))

    except FileNotFoundError:
        click.echo(click.style(f"Configuration file '{file_path}' not found.", fg="red"))
    except Exception as e:
        click.echo(click.style(f"Error during setup: {e}", fg="red"))



def get_and_execute_token_on_workers(worker_ips):
    """
    Fetch the Kubernetes join token and execute the join command on the worker nodes.

    Args:
        worker_ips (list): List of worker node IPs.
    """
    try:
        # Retrieve the token from the dynamically defined path
        with open(DKS_TOKEN, "r") as token_file:
            token_command = token_file.read().strip()
    except FileNotFoundError:
        click.echo(click.style(f"Error: Kubernetes join token file '{DKS_TOKEN}' not found.", fg="red"))
        return False

    # Execute the join command on each worker node
    for worker_ip in worker_ips:
        click.echo(f"Joining worker node at {worker_ip} to the Kubernetes cluster...")
        success, message = execute_command_on_server(worker_ip, "root", token_command)
        if success:
            click.echo(click.style(f"Worker node '{worker_ip}' successfully joined the cluster.", fg="green"))
        else:
            click.echo(click.style(f"Failed to join worker node '{worker_ip}': {message}", fg="red"))
            return False

    return True

def setup_dks_master(config, user_data):
    """Set up the Kubernetes master node."""
    master_config = config["master"]
    ami_id = "ami-06b21ccaeff8cd686"  # Default AMI for Kubernetes master

    instance_ids, private_ips = create_ec2_instances_direct(
        instance_type=master_config["instance_type"],
        ami_id=ami_id,
        key_name=master_config["key_name"],
        security_group=master_config["security_group"],
        count=1,
        tags={"Name": master_config["name"]},
        user_data=user_data
    )

    if not instance_ids or not private_ips:
        click.echo(click.style("Failed to provision Kubernetes master node.", fg="red"))
        return None

    master_ip = private_ips[0]
    add_k8s_host_entry(master_config["name"], master_ip, "dks-master")

    wait_for_instance(master_ip, "root")


    # Execute tasks for the master node
    tasks = get_default_master_tasks()
    if not execute_tasks(tasks, master_ip=master_ip):
        click.echo(click.style("Master setup failed during task execution.", fg="red"))
        return None

    save_k8s_join_token(master_ip)

    return master_ip


def setup_dks_workers(config, user_data):
    worker_config = config["workers"]
    worker_ips = []

    for i in range(worker_config["count"]):
        instance_name = f"{worker_config['name']}-{i + 1}"
        instance_ids, private_ips = create_ec2_instances_direct(
            instance_type=worker_config["instance_type"],
            ami_id="ami-06b21ccaeff8cd686",  # Default AMI for Kubernetes worker
            key_name=worker_config["key_name"],
            security_group=worker_config["security_group"],
            count=1,
            tags={"Name": instance_name},
            user_data=user_data
        )

        if instance_ids and private_ips:
            worker_ip = private_ips[0]
            worker_ips.append(worker_ip)
            add_k8s_host_entry(instance_name, worker_ip, "dks-worker")
            click.echo(f"Worker node '{instance_name}' provisioned at {worker_ip}.")
        else:
            click.echo(click.style(f"Failed to provision Kubernetes worker node '{instance_name}'.", fg="red"))

    if worker_ips:
        # Execute tasks on all worker nodes
        worker_tasks = get_default_worker_tasks()
        if not execute_tasks(worker_tasks, worker_ips=worker_ips):
            click.echo(click.style("Worker setup failed during task execution.", fg="red"))
            return False

        # Fetch and execute the join token on workers
        if not get_and_execute_token_on_workers(worker_ips):
            click.echo(click.style("Failed to join worker nodes to the Kubernetes cluster.", fg="red"))
            return False

    return True



def add_k8s_host_entry(instance_name, private_ip, category):
    """
    Add the instance IP and name to the hosts file under the given category.

    Args:
        instance_name (str): The name of the instance.
        private_ip (str): The IP address of the instance.
        category (str): The category for the host ('dks-master' or 'dks-worker').
    """
    category_header = f"[{category}]"
    entry = f"{private_ip} {instance_name}\n"
    found_category = False

    # Read the existing hosts file
    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    updated_lines = []
    for line in lines:
        # Check if the category already exists
        if line.strip() == category_header:
            found_category = True
            updated_lines.append(line)
            updated_lines.append(entry)  # Add the new entry under the category
        else:
            updated_lines.append(line)

    # Add the category and entry if it wasn't found
    if not found_category:
        updated_lines.append(f"\n{category_header}\n")
        updated_lines.append(entry)

    # Write back the updated hosts file
    with open(HOSTS_FILE, 'w') as file:
        file.writelines(updated_lines)

    click.echo(f"Added '{instance_name}' with IP '{private_ip}' under '{category}' in {HOSTS_FILE}.")



def save_k8s_join_token(master_ip):
    """Save the join token for Kubernetes workers."""
    token_command = "kubeadm token create --print-join-command"
    success, output = execute_command_on_server(master_ip, "root", token_command)
    if success:
        with open(DKS_TOKEN, "w") as file:
            file.write(output.strip())
        click.echo(click.style("Kubernetes join token saved successfully.", fg="green"))

def execute_tasks(tasks, master_ip=None, secondary_master_ips=None, worker_ips=None, retries=3, retry_delay=15):
    """
    Execute a list of tasks on the specified host(s), with retry logic for transient failures.

    Args:
        tasks (list): List of task dictionaries to execute.
        master_ip (str): IP of the master node (optional).
        secondary_master_ips (list): List of secondary control plane node IPs (optional).
        worker_ips (list): List of worker node IPs (optional).
        retries (int): Number of retry attempts for each task.
        retry_delay (int): Delay in seconds between retries.
    """
    for task in tasks:
        task_name = task.get('name', 'Unnamed Task')
        action = task.get('action', 'RUN').upper()  # Default action is 'RUN'
        task_command = task.get('command', None)
        category = task.get('category', None)  # Auto-assigned as 'dks-master', 'dks-worker', or 'dks-secondary-master'
        timeout = task.get('timeout', 600)

        click.echo(click.style(f"Processing task: {task_name}", fg="yellow"))

        # Determine the target IPs based on the category
        if category == "dks-master" and master_ip:
            target_ips = [master_ip]
        elif category == "dks-worker" and worker_ips:
            target_ips = worker_ips
        else:
            click.echo(click.style(f"Task '{task_name}' has an invalid category or no matching targets. Skipping.", fg="red"))
            continue

        # Execute the task on all target IPs
        for target_ip in target_ips:
            for attempt in range(1, retries + 1):
                click.echo(f"Executing task '{task_name}' on '{category}' ({target_ip}), Attempt {attempt}/{retries}...")
                if action == 'RUN' and task_command:
                    success, message = execute_command_on_server(
                        target_ip,
                        "root",
                        task_command,
                        timeout=timeout,
                        real_time_output=True  # Stream logs in real time
                    )
                    if success:
                        click.echo(click.style(f"Task '{task_name}' executed successfully on '{target_ip}'.", fg="green"))
                        break  # Task succeeded; exit retry loop
                    else:
                        click.echo(click.style(f"Task '{task_name}' failed on '{target_ip}': {message}", fg="red"))
                        if attempt < retries:
                            click.echo(click.style(f"Retrying in {retry_delay} seconds...", fg="yellow"))
                            time.sleep(retry_delay)  # Wait before retrying
                        else:
                            click.echo(click.style(f"Task '{task_name}' failed after {retries} attempts. Halting further task execution.", fg="red"))
                            return False  # Halt on repeated failure
                else:
                    click.echo(click.style(f"Task '{task_name}' has no valid action or command. Skipping.", fg="red"))
                    break

    return True  # Return success if all tasks pass



def retry_command(command, retries=3, delay=15):
    for attempt in range(1, retries + 1):
        click.echo(f"Attempt {attempt} for command: {command}")
        success, message = execute_command_on_server("root", command)
        if success:
            return True, message
        else:
            click.echo(f"Attempt {attempt} failed: {message}")
            if attempt < retries:
                time.sleep(delay)  # Wait before retrying
    return False, "All retry attempts failed."


def get_default_master_tasks():
    """
    Define default tasks for Kubernetes master setup.

    Returns:
        list: A list of task dictionaries for the master node.
    """
    return [
        {
            "name": "Set SELinux to Permissive and Enable IP Forwarding",
            "command": """
                sudo setenforce 0 || echo "SELinux not enforced" && \
                sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config || true && \
                echo "net.ipv4.ip_forward = 1" | sudo tee -a /etc/sysctl.conf && sudo sysctl -p
            """,
            "category": "dks-master"
        },
        {
            "name": "Fix Docker Repository for Amazon Linux 2023",
            "command": """
                sudo dnf install -y docker && \
                sudo systemctl start docker && \
                sudo systemctl enable docker
            """,
            "category": "dks-master"
        },
        {
            "name": "Install Kubernetes Components",
            "command": """
                echo -e "[kubernetes]\nname=Kubernetes\nbaseurl=https://pkgs.k8s.io/core:/stable:/v1.30/rpm/\nenabled=1\ngpgcheck=1\ngpgkey=https://pkgs.k8s.io/core:/stable:/v1.30/rpm/repodata/repomd.xml.key" | sudo tee /etc/yum.repos.d/kubernetes.repo
                sudo dnf clean all
                sudo dnf makecache
                sudo dnf install -y kubelet kubeadm kubectl && \
                sudo systemctl enable --now kubelet && \
                kubeadm version && kubectl version --client && kubelet --version
            """,
            "category": "dks-master"
        },
        {
            "name": "Install and Configure Containerd",
            "command": """
                sudo dnf install -y containerd && \
                sudo systemctl enable --now containerd && \
                sudo mkdir -p /etc/containerd && \
                containerd config default | sudo tee /etc/containerd/config.toml && \
                sudo sed -i '/SystemdCgroup = false/c\\SystemdCgroup = true' /etc/containerd/config.toml && \
                sudo systemctl restart containerd
            """,
            "category": "dks-master"
        },
        {
            "name": "Initialize Kubernetes Master",
            "command": """
                sudo kubeadm init --pod-network-cidr=192.168.0.0/16 --apiserver-advertise-address=$(hostname -i) && \
                mkdir -p $HOME/.kube && \
                sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config && \
                sudo chown $(id -u):$(id -g) $HOME/.kube/config
            """,
            "category": "dks-master"
        },
        {
            "name": "Deploy Calico Network",
            "command": """
                kubectl apply -f https://docs.projectcalico.org/manifests/calico.yaml --validate=false
            """,
            "category": "dks-master"
        }
    ]


def get_default_worker_tasks():
    """
    Define default tasks for Kubernetes worker setup.

    Returns:
        list: A list of task dictionaries for the worker nodes.
    """
    return [
        {
            "name": "Set SELinux to Permissive and Enable IP Forwarding",
            "command": """
                sudo setenforce 0 || echo "SELinux not enforced" && \
                sudo sed -i 's/^SELINUX=enforcing$/SELINUX=permissive/' /etc/selinux/config || true && \
                echo "net.ipv4.ip_forward = 1" | sudo tee -a /etc/sysctl.conf && sudo sysctl -p
            """,
            "category": "dks-worker"
        },
        {
            "name": "Fix Docker Repository for Amazon Linux 2023",
            "command": """
                sudo dnf install -y docker && \
                sudo systemctl start docker && \
                sudo systemctl enable docker
            """,
            "category": "dks-worker"
        },
        {
            "name": "Install Kubernetes Components",
            "command": """
                echo -e "[kubernetes]\nname=Kubernetes\nbaseurl=https://pkgs.k8s.io/core:/stable:/v1.30/rpm/\nenabled=1\ngpgcheck=1\ngpgkey=https://pkgs.k8s.io/core:/stable:/v1.30/rpm/repodata/repomd.xml.key" | sudo tee /etc/yum.repos.d/kubernetes.repo
                sudo dnf clean all
                sudo dnf makecache
                sudo dnf install -y kubelet kubeadm kubectl && \
                sudo systemctl enable --now kubelet && \
                kubeadm version && kubectl version --client && kubelet --version
            """,
            "category": "dks-worker"
        },
        {
            "name": "Install and Configure Containerd",
            "command": """
                sudo dnf install -y containerd && \
                sudo systemctl enable --now containerd && \
                sudo mkdir -p /etc/containerd && \
                containerd config default | sudo tee /etc/containerd/config.toml && \
                sudo sed -i '/SystemdCgroup = false/c\\SystemdCgroup = true' /etc/containerd/config.toml && \
                sudo systemctl restart containerd
            """,
            "category": "dks-worker"
        }

    ]


@dks.command(name="attach-node", help="Attach new nodes to the existing dks master.")
@click.option('--file-path', required=True, help="Path to the YAML configuration file.")
def setup_dks(file_path):
    """
    Read the configuration file and set up Kubernetes services using DKS.
    """
    try:
        # Load configuration from the YAML file
        with open(file_path, 'r') as file:
            config = yaml.safe_load(file)

        # Validate the configuration
        if "workers" not in config:
            click.echo(click.style("Invalid configuration: Missing 'master' or 'workers' section.", fg="red"))
            return

        click.echo(click.style("Starting DKS (DevOps Kubernetes Services) setup...", fg="blue"))

        # Generate and inject SSH key for instances
        ssh_key_content = get_ssh_key()
        user_data = prepare_user_data_script(ssh_key_content)

       
        setup_dks_workers(config, user_data)
        click.echo(click.style("Kubernetes worker nodes configured successfully.", fg="green"))

        click.echo(click.style("DKS setup complete!", fg="green"))

    except FileNotFoundError:
        click.echo(click.style(f"Configuration file '{file_path}' not found.", fg="red"))
    except Exception as e:
        click.echo(click.style(f"Error during setup: {e}", fg="red"))




#####################################################################################################

@cli.group()
def swarm():
    """Commands related to Docker Swarm Services."""

@swarm.command(name="config", help="Provision and configure Docker Swarm.")
@click.option('--file-path', required=True, help="Path to the YAML configuration file.")
def setup_swarm(file_path):
    """
    Read the configuration file and set up Docker Swarm.
    """
    try:
        # Load configuration from the YAML file
        with open(file_path, 'r') as file:
            config = yaml.safe_load(file)

        # Validate the configuration
        if "manager" not in config or "workers" not in config:
            click.echo(click.style("Invalid configuration: Missing 'manager' or 'workers' section.", fg="red"))
            return

        click.echo(click.style("Starting Docker Swarm setup...", fg="blue"))

        # Generate and inject SSH key for instances
        generate_ssh_key()
        ssh_key_content = get_ssh_key()
        user_data = prepare_user_data_script(ssh_key_content)

        # Provision and set up the Docker Swarm manager node
        manager_ip = setup_swarm_manager(config, user_data)
        if not manager_ip:
            click.echo(click.style("Failed to set up Docker Swarm manager node.", fg="red"))
            return

        click.echo(f"Docker Swarm manager node set up successfully at {manager_ip}.")

        # Provision and configure worker nodes
        setup_swarm_workers(config, user_data, manager_ip)
        click.echo(click.style("Docker Swarm worker nodes configured successfully.", fg="green"))

        click.echo(click.style("Docker Swarm setup complete!", fg="green"))

    except FileNotFoundError:
        click.echo(click.style(f"Configuration file '{file_path}' not found.", fg="red"))
    except Exception as e:
        click.echo(click.style(f"Error during setup: {e}", fg="red"))


def setup_swarm_manager(config, user_data):
    """Set up the Docker Swarm manager node."""
    manager_config = config["manager"]
    ami_id = manager_config.get("ami_id", "ami-06b21ccaeff8cd686")  # Default AMI for manager

    instance_ids, private_ips = create_ec2_instances_direct(
        instance_type=manager_config["instance_type"],
        ami_id=ami_id,
        key_name=manager_config["key_name"],
        security_group=manager_config["security_group"],
        count=1,
        tags={"Name": manager_config["name"]},
        user_data=user_data
    )

    if not instance_ids or not private_ips:
        click.echo(click.style("Failed to provision Docker Swarm manager node.", fg="red"))
        return None

    manager_ip = private_ips[0]
    add_swarm_host_entry(manager_config["name"], manager_ip, "swarm-manager")

    wait_for_instance(manager_ip, "root")

    # Execute tasks for the manager node
    manager_tasks = get_swarm_manager_tasks(manager_ip)
    if not execute_swarm_tasks(manager_tasks, master_ip=manager_ip):
        click.echo(click.style("Manager setup failed during task execution.", fg="red"))
        return None

    # Save the Swarm token
    save_swarm_join_token(manager_ip)

    return manager_ip


def setup_swarm_workers(config, user_data, manager_ip):
    """Provision and configure Docker Swarm worker nodes."""
    worker_config = config["workers"]
    worker_ips = []

    for i in range(worker_config["count"]):
        instance_name = f"{worker_config['name']}-{i + 1}"
        instance_ids, private_ips = create_ec2_instances_direct(
            instance_type=worker_config["instance_type"],
            ami_id=worker_config.get("ami_id", "ami-06b21ccaeff8cd686"),  # Default AMI for workers
            key_name=worker_config["key_name"],
            security_group=worker_config["security_group"],
            count=1,
            tags={"Name": instance_name},
            user_data=user_data
        )

        if instance_ids and private_ips:
            worker_ip = private_ips[0]
            worker_ips.append(worker_ip)
            add_swarm_host_entry(instance_name, worker_ip, "swarm-worker")
            click.echo(f"Worker node '{instance_name}' provisioned at {worker_ip}.")
        else:
            click.echo(click.style(f"Failed to provision Docker Swarm worker node '{instance_name}'.", fg="red"))

    if worker_ips:
        # Execute tasks on all worker nodes
        worker_tasks = get_swarm_worker_tasks(manager_ip)
        if not execute_swarm_tasks(worker_tasks, worker_ips=worker_ips):
            click.echo(click.style("Worker setup failed during task execution.", fg="red"))
            return False

        # Fetch and execute the join token on workers
        if not get_and_execute_swarm_token_on_workers(worker_ips, manager_ip):
            click.echo(click.style("Failed to join worker nodes to the Docker Swarm cluster.", fg="red"))
            return False

    return True


def save_swarm_join_token(manager_ip):
    """
    Save the Docker Swarm join token for workers.

    Args:
        manager_ip (str): IP address of the Swarm manager node.
    """
    token_command = "docker swarm join-token worker -q"
    success, output = execute_command_on_server(manager_ip, "root", token_command)
    if success:
        with open(SWARM_TOKEN, "w") as file:
            file.write(output.strip())
        click.echo(click.style("Docker Swarm worker join token saved successfully.", fg="green"))
    else:
        click.echo(click.style("Failed to retrieve Docker Swarm worker join token.", fg="red"))


def get_and_execute_swarm_token_on_workers(worker_ips, manager_ip):
    """
    Fetch the Docker Swarm join token and execute the join command on the worker nodes.

    Args:
        worker_ips (list): List of worker node IPs.
        manager_ip (str): IP of the Swarm manager node.
    """
    try:
        # Retrieve the token from the saved file
        with open(SWARM_TOKEN, "r") as token_file:
            token = token_file.read().strip()
    except FileNotFoundError:
        click.echo(click.style(f"Error: Docker Swarm worker join token file '{SWARM_TOKEN}' not found.", fg="red"))
        return False

    # Join each worker to the Swarm using the manager's IP
    for worker_ip in worker_ips:
        join_command = f"docker swarm join --token {token} {manager_ip}:2377"
        click.echo(f"Joining worker node at {worker_ip} to the Docker Swarm cluster using manager IP {manager_ip}...")
        success, message = execute_command_on_server(worker_ip, "root", join_command)
        if success:
            click.echo(click.style(f"Worker node '{worker_ip}' successfully joined the Swarm cluster.", fg="green"))
        else:
            click.echo(click.style(f"Failed to join worker node '{worker_ip}': {message}", fg="red"))
            return False

    return True


def execute_swarm_tasks(tasks, master_ip=None, worker_ips=None, retries=3, retry_delay=15):
    """
    Execute a list of tasks on the specified host(s), with retry logic for transient failures.

    Args:
        tasks (list): List of task dictionaries to execute.
        master_ip (str): IP of the master node (optional).
        worker_ips (list): List of worker node IPs (optional).
        retries (int): Number of retry attempts for each task.
        retry_delay (int): Delay in seconds between retries.
    """
    for task in tasks:
        task_name = task.get('name', 'Unnamed Task')
        task_command = task.get('command', None)
        category = task.get('category', None)  # 'swarm-manager' or 'swarm-worker'

        click.echo(click.style(f"Processing task: {task_name}", fg="yellow"))

        target_ips = []
        if category == "swarm-manager" and master_ip:
            target_ips = [master_ip]
        elif category == "swarm-worker" and worker_ips:
            target_ips = worker_ips

        if not target_ips:
            click.echo(click.style(f"Task '{task_name}' has no matching targets. Skipping.", fg="red"))
            continue

        for target_ip in target_ips:
            for attempt in range(1, retries + 1):
                click.echo(f"Executing task '{task_name}' on {category} ({target_ip}), Attempt {attempt}/{retries}...")
                success, message = execute_command_on_server(target_ip, "root", task_command)
                if success:
                    click.echo(click.style(f"Task '{task_name}' executed successfully on '{target_ip}'.", fg="green"))
                    break
                else:
                    click.echo(click.style(f"Task '{task_name}' failed: {message}", fg="red"))
                    if attempt < retries:
                        click.echo(click.style(f"Retrying in {retry_delay} seconds...", fg="yellow"))
                        time.sleep(retry_delay)
                    else:
                        click.echo(click.style(f"Task '{task_name}' failed after {retries} attempts.", fg="red"))
                        return False

    return True


def get_swarm_manager_tasks(manager_ip):
    """
    Define default tasks for Docker Swarm manager setup.
    """
    return [
        {
            "name": "Install Docker",
            "command": """
                sudo yum update -y && \
                sudo yum install -y docker && \
                sudo systemctl start docker && \
                sudo systemctl enable docker
            """,
            "category": "swarm-manager"
        },
        {
            "name": "Initialize Swarm Manager",
            "command": f"""
                docker swarm init --advertise-addr {manager_ip}
            """,
            "category": "swarm-manager"
        }
    ]


def get_swarm_worker_tasks(manager_ip):
    """
    Define default tasks for Docker Swarm worker setup.
    """
    return [
        {
            "name": "Install Docker",
            "command": """
                sudo yum update -y && \
                sudo yum install -y docker && \
                sudo systemctl start docker && \
                sudo systemctl enable docker
            """,
            "category": "swarm-worker"
        }
    ]


def add_swarm_host_entry(instance_name, private_ip, category):
    """
    Add the instance IP and name to the hosts file under the given category.

    Args:
        instance_name (str): The name of the instance.
        private_ip (str): The IP address of the instance.
        category (str): The category for the host ('swarm-manager' or 'swarm-worker').
    """
    category_header = f"[{category}]"
    entry = f"{private_ip} {instance_name}\n"
    found_category = False

    with open(HOSTS_FILE, 'r') as file:
        lines = file.readlines()

    updated_lines = []
    for line in lines:
        if line.strip() == category_header:
            found_category = True
            updated_lines.append(line)
            updated_lines.append(entry)
        else:
            updated_lines.append(line)

    if not found_category:
        updated_lines.append(f"\n{category_header}\n")
        updated_lines.append(entry)

    with open(HOSTS_FILE, 'w') as file:
        file.writelines(updated_lines)

    click.echo(f"Added '{instance_name}' with IP '{private_ip}' under '{category}' in {HOSTS_FILE}.")

@swarm.command(name="attach-worker", help="Attach new nodes to the existing swarm manager.")
@click.option('--file-path', required=True, help="Path to the YAML configuration file.")
def setup_swarm(file_path):
    """
    Read the configuration file and attach new workers to the existing Docker Swarm.
    """
    try:
        # Load configuration from the YAML file
        with open(file_path, 'r') as file:
            config = yaml.safe_load(file)
        ssh_key_content = get_ssh_key()
        user_data = prepare_user_data_script(ssh_key_content)

        # Validate the configuration
        if "workers" not in config:
            click.echo(click.style("Invalid configuration: Missing 'workers' section.", fg="red"))
            return

        click.echo(click.style("Starting Docker Swarm setup...", fg="blue"))

        # Get the manager IP
        try:
            manager_ip = get_manager_ip_from_hosts()
        except ValueError as e:
            click.echo(click.style(f"Error: {e}", fg="red"))
            return

        # Provision and configure worker nodes
        setup_swarm_workers(config, user_data, manager_ip)
        click.echo(click.style("Docker Swarm worker nodes configured successfully.", fg="green"))

        click.echo(click.style("Docker Swarm setup complete!", fg="green"))

    except FileNotFoundError:
        click.echo(click.style(f"Configuration file '{file_path}' not found.", fg="red"))
    except Exception as e:
        click.echo(click.style(f"Error during setup: {e}", fg="red"))

def get_manager_ip_from_hosts(manager_name="swarm-manager", category="swarm-manager"):
    """
    Retrieve the manager node's IP from the formatted hosts file.

    Args:
        manager_name (str): Name of the manager node (default: swarm-manager).
        category (str): Category header in the hosts file (default: swarm-manager).

    Returns:
        str: IP address of the manager node.

    Raises:
        ValueError: If the manager node or category is not found.
    """
    hosts_file_path = "/etc/hosts"

    try:
        with open(hosts_file_path, "r") as file:
            lines = file.readlines()
    except FileNotFoundError:
        raise ValueError(f"Hosts file '{hosts_file_path}' not found.")

    inside_category = False
    for line in lines:
        line = line.strip()
        if line == f"[{category}]":
            inside_category = True
            continue

        if inside_category:
            if line == "" or line.startswith("["):
                break  # End of the current category
            parts = line.split()
            if len(parts) >= 2 and parts[1] == manager_name:
                return parts[0]  # Return the IP address

    raise ValueError(f"Host '{manager_name}' with category '{category}' not found in {hosts_file_path}.")

def get_remote_instances():
    """
    Reads the remote instances from the `REMOTE_METRICS_FILE`.
    Each line in the file should follow the format: <IP> <Identifier>
    """
    remote_instances = []
    if not os.path.exists(REMOTE_METRICS_FILE):
        click.echo(click.style(f"Error: Remote metrics file not found at {REMOTE_METRICS_FILE}", fg="red"))
        return remote_instances

    with open(REMOTE_METRICS_FILE, 'r') as file:
        for line in file:
            parts = line.strip().split()
            if len(parts) == 2:
                ip, identifier = parts
                remote_instances.append({'ip': ip, 'identifier': identifier})
    return remote_instances


@cli.command(name="remote-metric")
@click.argument('identifier', required=True)
def remote_metric(identifier):
    """
    Fetch metrics from a remote instance using SSH.

    Example Usage:
    remote-metric devops
    """
    try:
        # Get the list of remote instances
        remote_instances = get_remote_instances()
        instance = next((inst for inst in remote_instances if inst['identifier'] == identifier), None)

        if not instance:
            click.echo(click.style(f"Error: No instance found with identifier '{identifier}'", fg="red"))
            return

        # Define the metrics command to execute remotely
        metrics_command = """
        python3 -c '
import psutil, datetime, json
boot_time = datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")
metrics_data = {
    "cpu_percent": psutil.cpu_percent(interval=1),
    "cpu_user_time": psutil.cpu_times().user,
    "cpu_system_time": psutil.cpu_times().system,
    "cpu_idle_time": psutil.cpu_times().idle,
    "cpu_count": psutil.cpu_count(),
    "memory_percent": psutil.virtual_memory().percent,
    "memory_total": round(psutil.virtual_memory().total / (1024 * 1024 * 1024), 2),
    "memory_used": round(psutil.virtual_memory().used / (1024 * 1024 * 1024), 2),
    "memory_available": round(psutil.virtual_memory().available / (1024 * 1024 * 1024), 2),
    "disk_percent": psutil.disk_usage("/").percent,
    "disk_total": round(psutil.disk_usage("/").total / (1024 * 1024 * 1024), 2),
    "disk_used": round(psutil.disk_usage("/").used / (1024 * 1024 * 1024), 2),
    "disk_free": round(psutil.disk_usage("/").free / (1024 * 1024 * 1024), 2),
    "network_sent": round(psutil.net_io_counters().bytes_sent / (1024 * 1024), 2),
    "network_received": round(psutil.net_io_counters().bytes_recv / (1024 * 1024), 2),
    "network_packets_sent": psutil.net_io_counters().packets_sent,
    "network_packets_received": psutil.net_io_counters().packets_recv,
    "boot_time": boot_time
}
print(json.dumps(metrics_data))'
        """
        # Execute the command on the remote server
        success, result = execute_command_on_server(instance['ip'], "root", metrics_command)

        if success:
            # Parse and pretty-print the metrics
            metrics = json.loads(result)
            click.echo(click.style(json.dumps(metrics, indent=4), fg="green"))
        else:
            click.echo(click.style(f"Failed to fetch metrics: {result}", fg="red"))

    except Exception as e:
        click.echo(click.style(f"An error occurred: {str(e)}", fg="red"))

if __name__ == "__main__":
    cli()
