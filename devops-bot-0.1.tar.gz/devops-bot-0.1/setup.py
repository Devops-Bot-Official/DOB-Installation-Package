import os
from setuptools import setup, find_packages
from setuptools.command.install import install
import subprocess


def load_requirements(filename):
    with open(filename, 'r') as f:
        return f.read().splitlines()


def find_package_files(directory, package_name):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.relpath(os.path.join(path, filename), package_name))
    return paths


class PostInstallCommand(install):
    """Custom post-installation command to set up the service."""
    def run(self):
        # Run the original install code
        install.run(self)

        service_name = "devops-bot"
        service_file = f"/etc/systemd/system/{service_name}.service"

        # Systemd service file content
        service_content = f"""
[Unit]
Description=DevOps Bot Service
After=network.target

[Service]
User=root
Group=root
Environment="FLASK_APP=devops_bot.ui.app"
Environment="FLASK_ENV=production"
WorkingDirectory=/etc/devops-bot
ExecStart=/usr/local/bin/dob run-ui --port 4102
Restart=always
RestartSec=5

StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"""

        print(">>> Creating the systemd service file...")
        with open(service_file, 'w') as f:
            f.write(service_content)

        # Set proper permissions
        os.chmod(service_file, 0o644)

        # Reload systemd, enable, and start the service
        print(">>> Reloading systemd, enabling and starting the service...")
        subprocess.run(["systemctl", "daemon-reload"], check=True)
        subprocess.run(["systemctl", "enable", service_name], check=True)
        subprocess.run(["systemctl", "start", service_name], check=True)

        print(">>> Service setup complete!")


setup(
    name='devops-bot',
    version='0.1',
    description='DevOps Bot: An IaaS tool for managing infrastructure and cloud resources.',
    author='Mohamed Sesay',
    author_email='mohamed.sesay@outlook.com.au',
    url='https://www.devops-bot.com/',
    packages=find_packages(),
    install_requires=load_requirements('requirements.txt'),
    entry_points='''
        [console_scripts]
        dob=devops_bot.cli:cli
    ''',
    package_data={
        'ui': find_package_files('ui/static', 'ui') +
              find_package_files('ui/templates', 'ui'),
    },
    include_package_data=True,
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
    cmdclass={
        'install': PostInstallCommand,
    },
)

