from setuptools import setup, find_packages
import os


def load_requirements(filename):
    with open(filename, 'r') as f:
        return f.read().splitlines()


def find_package_files(directory, package_name):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.relpath(os.path.join(path, filename), package_name))
    return paths


setup(
    name='devops-bot',
    version='0.1',
    description='DevOps Bot: An IaaS tool for managing infrastructure and cloud resources.',
    author='Mohamed Sesay',
    author_email='mohamed.sesay@outlook.com.au',
    url='https://www.devops-bot.com/',
    packages=find_packages(include=["ui", "webhook", "devops_bot.*"]),
    install_requires=load_requirements('requirements.txt'),
    entry_points={
        'console_scripts': [
            'dob=devops_bot.cli:cli',
            'webhook=webhook.webhook:app',  # Entry point for the webhook
        ]
    },
    package_data={
        'ui': find_package_files('ui/static', 'ui') +
              find_package_files('ui/templates', 'ui'),
        'webhook': ['*.py'],  # Include all Python files in the webhook module
    },
    include_package_data=True,
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)

