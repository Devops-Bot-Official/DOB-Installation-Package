from setuptools import setup, find_packages
import os

# Helper function to load dependencies from requirements.txt
def load_requirements(filename):
    with open(filename, 'r') as f:
        return f.read().splitlines()

# Include non-Python files (HTML, CSS) in the `ui` package
def include_files_in_package(package_name, directory):
    paths = []
    for (path, directories, filenames) in os.walk(directory):
        for filename in filenames:
            paths.append(os.path.relpath(os.path.join(path, filename), package_name))
    return paths


setup(
    name='devops-bot',
    version='0.1',
    description='DevOps Bot: An IaaS tool for managing infrastructure and cloud resources.',
    author='Mohamed Sesay',
    author_email='mohamed.sesay@outlook.com.au',
    url='https://www.devops-bot.com/',
    packages=find_packages(),
    install_requires=load_requirements('requirements.txt'),
    entry_points='''
        [console_scripts]
        dob=devops_bot.cli:cli
    ''',

    package_data={
        'devops_bot': include_files_in_package('devops_bot', 'devops_bot/ui'),
    },
    include_package_data=True,

    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)

