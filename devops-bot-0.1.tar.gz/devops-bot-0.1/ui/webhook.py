from flask import Flask, request, jsonify
import hmac
import hashlib
import subprocess
import os
import random
import string
import glob
import click
import json
import secrets
import shutil

# Flask app instance
app = Flask(__name__)

BASE_DIR = os.path.expanduser("/etc/devops-bot")
WEBHOOK_API_DIR = os.path.join(BASE_DIR, "webhook-api")
WEBHOOK_SECRET_FILE = os.path.join(BASE_DIR, "webhook-api.json")
EXECUTION_RESULTS_DIR = os.path.join(BASE_DIR, "webhook_results")
CLONE_DIR = os.path.join(BASE_DIR, "webhook_artifacts")
os.makedirs(CLONE_DIR, exist_ok=True)
os.makedirs(EXECUTION_RESULTS_DIR, exist_ok=True) 
os.makedirs(WEBHOOK_API_DIR, exist_ok=True)  # Ensure the directory exists

PIPELINE_COMMAND = None


def generate_webhook_secret():
    """
    Generate a new webhook secret key and save it to a file.
    """
    secret_key = secrets.token_hex(32)
    secret_data = {"webhook_secret": secret_key}
    with open(WEBHOOK_SECRET_FILE, "w") as f:
        json.dump(secret_data, f)
        os.chmod(WEBHOOK_SECRET_FILE, 0o600)
    return secret_key

def load_webhook_secret():
    """
    Load the webhook secret key from the file. Generate a new one if it doesn't exist.
    """
    if not os.path.exists(WEBHOOK_SECRET_FILE):
        return generate_webhook_secret()
    with open(WEBHOOK_SECRET_FILE, "r") as f:
        secret_data = json.load(f)
    return secret_data.get("webhook_secret")

# Load the secret key
WEBHOOK_SECRET = load_webhook_secret()

def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        return False
    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        return False
    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    return hmac.compare_digest(mac.hexdigest(), signature)


def generate_random_string(length=16):
    """Generate a random alphanumeric string."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def generate_api_key():
    """
    Generate a random API key and save it to a file.
    """
    webhook_api_dir = os.path.join(BASE_DIR, "webhook-api")
    os.makedirs(webhook_api_dir, exist_ok=True)

    random_name = f"devops_bot_{secrets.token_hex(4)}"
    api_key = secrets.token_hex(32)
    file_path = os.path.join(webhook_api_dir, random_name)

    with open(file_path, "w") as f:
        f.write(api_key)
        os.chmod(file_path, 0o600)

    print(f"API key generated: {file_path}")  # Log the file path for debugging
    return {"name": random_name, "token": api_key}


def validate_api_key(api_name, api_token):
    """Validate the API key provided by the user."""
    file_path = os.path.join(WEBHOOK_API_DIR, api_name)
    if not os.path.exists(file_path):
        return False

    with open(file_path, "r") as f:
        stored_token = f.read().strip()

    return hmac.compare_digest(stored_token, api_token)

@app.route('/generate-api-key', methods=['POST'])
def generate_api_key_endpoint():
    """
    Generate a new API key via HTTP request.
    """
    try:
        api_key_data = generate_api_key()
        return jsonify({
            "status": "success",
            "name": api_key_data['name'],
            "token": api_key_data['token']
        }), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@click.command()
def regenerate_webhook_secret():
    """
    Command to regenerate the webhook secret key.
    """
    new_secret = generate_webhook_secret()
    print(f"New webhook secret generated: {new_secret}")


@app.route('/generate-webhook-secret', methods=['POST'])
def generate_webhook_secret_endpoint():
    """
    Generate a new webhook secret key via HTTP request.
    """
    try:
        new_secret = generate_webhook_secret()
        return jsonify({"status": "success", "webhook_secret": new_secret}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

def get_next_build_file_path(repo_name):
    """
    Generate the next build file path for the specified repository in the results directory.
    """
    results_dir = os.path.join(EXECUTION_RESULTS_DIR, repo_name)
    os.makedirs(results_dir, exist_ok=True)

    existing_files = glob.glob(os.path.join(results_dir, "build-no-*.json"))
    if not existing_files:
        return os.path.join(results_dir, "build-no-001.json")

    build_numbers = [
        int(os.path.basename(f).split("-")[2].split(".")[0]) for f in existing_files
    ]
    next_build_number = max(build_numbers) + 1

    if next_build_number > 100:
        raise Exception("Build limit exceeded: Maximum 100 builds allowed.")

    return os.path.join(results_dir, f"build-no-{next_build_number:03}.json")


def execute_dob_command(file_path, results_path):
    """
    Execute the dob command and save the results in a structured format.
    """
    try:
        result = subprocess.run(
            ["dob", "dobbuild", "build", "--file-path", file_path],
            capture_output=True,
            text=True,
        )

        # Parse stdout into structured lines
        stdout_lines = result.stdout.strip().split("\n")
        stderr_lines = result.stderr.strip().split("\n") if result.stderr else []

        # Build a detailed result structure
        execution_result = {
            "status": "success" if result.returncode == 0 else "failure",
            "summary": {
                "exit_code": result.returncode,
                "stdout_line_count": len(stdout_lines),
                "stderr_line_count": len(stderr_lines),
            },
            "stdout": stdout_lines,
            "stderr": stderr_lines,
        }

        # Save execution results to the specified path
        with open(results_path, "w") as f:
            json.dump(execution_result, f, indent=4)

        return True, f"Execution results saved to {results_path}"
    except subprocess.CalledProcessError as e:
        return False, str(e)


def process_repository(details):
    """
    Clone the repository and execute Dobbuild.yaml.
    """
    repo_details = next(iter(details["repositories"].values()))
    source_url = repo_details["source_url"]
    branch = repo_details["branch"]
    repo_name = repo_details["repo_name"]
    clone_dir = os.path.join(CLONE_DIR, repo_name)
    execution_file = os.path.join(clone_dir, repo_details["execution_file"])
    results_path = get_next_build_file_path(os.path.join(EXECUTION_RESULTS_DIR, repo_name))

    # Ensure HTTPS clone for public repositories
    if source_url.startswith("git@github.com:"):
        source_url = source_url.replace("git@github.com:", "https://github.com/")

    try:
        # Clean up the clone directory if it exists
        if os.path.exists(clone_dir):
            print(f"Cleaning up existing directory: {clone_dir}")
            shutil.rmtree(clone_dir)

        # Clone the repository
        print(f"Cloning repository {repo_name} from {source_url}...")
        subprocess.run(["git", "clone", "--branch", branch, source_url, clone_dir], check=True)
        print(f"Repository {repo_name} cloned successfully into {clone_dir}.")

        # Check and execute the Dobbuild.yaml
        if os.path.exists(execution_file):
            print(f"Executing {execution_file}...")
            success, message = execute_dob_command(execution_file, results_path)
            if success:
                print(f"Execution successful: {message}")
                return jsonify({"status": "success", "message": message, "results_file": results_path}), 200
            else:
                print(f"Execution failed: {message}")
                return jsonify({"status": "error", "message": message}), 500
        else:
            print(f"{execution_file} not found in {clone_dir}. Aborting.")
            return jsonify({"status": "error", "message": f"{execution_file} not found"}), 404

    except subprocess.CalledProcessError as e:
        print(f"Error during repository processing: {e.stderr}")
        return jsonify({"status": "error", "message": f"Subprocess error: {e.stderr}"}), 500
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return jsonify({"status": "error", "message": f"Unexpected error: {str(e)}"}), 500


@app.route('/webhook', methods=['POST'])
def handle_webhook():
    """
    Handle incoming webhook events, validate and process only if Dobbuild.yaml is modified.
    """
    event_type = request.headers.get("X-GitHub-Event", "unknown")
    signature = request.headers.get('X-Hub-Signature-256')
    payload = request.get_data(as_text=True)

    # Verify the GitHub signature
    if not verify_signature(payload.encode(), signature, WEBHOOK_SECRET):
        print("Invalid GitHub signature!")
        return jsonify({"error": "Invalid GitHub signature"}), 403

    # Log the raw payload for debugging
    print("Raw Payload:")
    print(payload)

    if event_type != "push":
        print(f"Ignored event: {event_type}")
        return jsonify({"status": "ignored", "event": event_type}), 200

    try:
        # Parse the JSON payload
        json_payload = request.json
        print("Parsed Payload:")
        print(json.dumps(json_payload, indent=4))

        # Extract required details
        repo_name = json_payload["repository"]["full_name"]
        source_url = json_payload["repository"]["ssh_url"]  # SSH URL or HTTPS clone URL
        branch = json_payload["ref"].split("/")[-1]  # Extract branch name from ref
        modified_files = json_payload.get("head_commit", {}).get("modified", [])

        print(f"Repository: {repo_name}")
        print(f"Source URL: {source_url}")
        print(f"Branch: {branch}")
        print(f"Modified Files: {modified_files}")

        # Check if Dobbuild.yaml is modified
        execution_file = "Dobbuild.yaml"
        if execution_file not in modified_files:
            print(f"No changes detected in {execution_file}. Aborting process.")
            return jsonify({"status": "aborted", "message": f"{execution_file} not modified"}), 200

        # Prepare task details
        details = {
            "repositories": {
                repo_name: {
                    "source_url": source_url,
                    "branch": branch,
                    "repo_name": repo_name.split("/")[-1],
                    "execution_file": execution_file
                }
            }
        }

        print("Prepared Details for Processing:")
        print(json.dumps(details, indent=4))

        # Process repository and execute the task
        return process_repository(details)

    except Exception as e:
        print(f"Error processing payload: {e}")
        return jsonify({"error": f"Failed to process payload: {str(e)}"}), 500


def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        print("Missing signature header!")
        return False

    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        print(f"Unsupported hash type: {sha_name}")
        return False

    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    generated_signature = mac.hexdigest()
    print(f"Generated signature: sha256={generated_signature}")
    print(f"Received signature: {signature}")

    return hmac.compare_digest(generated_signature, signature)


if __name__ == '__main__':
    
    app.run(host='0.0.0.0', port=4103, debug=True)  # Expose on all interfaces
