from flask import Flask, render_template, request, flash, redirect, url_for, session, Response, jsonify
import sys
import hmac
import random
import secrets
import shutil
import hashlib
import string
import os
import json
from pathlib import Path
import requests
from cryptography.fernet import Fernet
import subprocess
import click
from flask_bcrypt import Bcrypt
import xml.etree.ElementTree as ET
from flask import Flask, request, redirect, url_for, flash, render_template
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
import psutil
import paramiko
from flask_cors import CORS
from flask_login import login_required

app = Flask(__name__, static_folder='static')
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'your-default-secret-key')  # Consistent secret key

active_sessions = {}
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Define the base directory for user data and other configurations
BASE_DIR = os.path.expanduser("/etc/devops-bot")
# Define the directory for storing user data and keys
USER_DATA_DIR = os.path.join(BASE_DIR, "users_data")
KEY_FILE = os.path.join(USER_DATA_DIR, "key.key")
PROXY_CREDENTIALS_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_credentials.json")
PROXY_KEY_FILE = os.path.join(BASE_DIR, "devops_bot_proxy_key.key")
WEBHOOK_API_DIR = os.path.join(BASE_DIR, "webhook-api")
WEBHOOK_SECRET_FILE = os.path.join(BASE_DIR, "webhook-api.json")
EXECUTION_RESULTS_DIR = os.path.join(BASE_DIR, "webhook_results")
CLONE_DIR = os.path.join(BASE_DIR, "webhook_artifacts")
os.makedirs(CLONE_DIR, exist_ok=True)
os.makedirs(EXECUTION_RESULTS_DIR, exist_ok=True) 
os.makedirs(WEBHOOK_API_DIR, exist_ok=True)  # Ensure the directory exists

# Ensure the directories exist
os.makedirs(USER_DATA_DIR, exist_ok=True)
UPLOAD_FOLDER = '/tmp/screenplay'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)



# Flask-Login User class definition
class User(UserMixin):
    def __init__(self, username):
        self.id = username  # Flask-Login requires the `id` attribute to identify the user.

    @staticmethod
    def get(username):
        """Retrieve user object from XML storage."""
        user_data = load_user_from_xml(username)
        if user_data:
            return User(username)
        return None

# Save user data to XML
def save_user_to_xml(username, password_hash, email, full_name):
    user_dir = os.path.join(USER_DATA_DIR, username)
    os.makedirs(user_dir, exist_ok=True)  # Create user directory if it doesn't exist

    # Create the XML structure
    user_data = ET.Element('user')
    ET.SubElement(user_data, 'username').text = username
    ET.SubElement(user_data, 'password').text = password_hash
    ET.SubElement(user_data, 'email').text = email
    ET.SubElement(user_data, 'full_name').text = full_name

    # Write the XML to a file
    tree = ET.ElementTree(user_data)
    tree.write(os.path.join(user_dir, 'config.xml'))

# Load user data from XML
def load_user_from_xml(username):
    user_dir = os.path.join(USER_DATA_DIR, username)
    config_file = os.path.join(user_dir, 'config.xml')

    if not os.path.exists(config_file):
        return None

    tree = ET.parse(config_file)
    root = tree.getroot()

    password_hash = root.find('password').text
    email = root.find('email').text
    full_name = root.find('full_name').text

    return {
        'username': username,
        'password': password_hash,
        'email': email,
        'full_name': full_name
    }

# Registration route
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        full_name = request.form['full_name']
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']

        # Check if the username already exists
        if os.path.exists(os.path.join(USER_DATA_DIR, username)):
            flash('Username already exists. Please choose another one.', 'danger')
            return redirect(url_for('register'))

        # Hash the password and save user data in XML
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')
        save_user_to_xml(username, password_hash, email, full_name)

        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')

# Login route
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Load user data from XML
        user_data = load_user_from_xml(username)
        if user_data and bcrypt.check_password_hash(user_data['password'], password):
            user = User(username)  # Create User instance for Flask-Login
            login_user(user)
            flash('Login successful!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Login failed. Check your username and password.', 'danger')

    return render_template('login.html')

# Flask-Login loader to reload the user from the session
@login_manager.user_loader
def load_user(username):
    return User.get(username)

@app.route('/')
@login_required
def index():
    return render_template('index.html')

@app.route('/file-generator')
@login_required
def file_generator():
    return render_template('file_generator.html')



@app.route('/generate-token', methods=['POST'])
@login_required
def generate_token():
    username = current_user.id

    try:
        # Use the installed 'dob' command instead of directly running cli.py
        result = subprocess.run(
            ['dob', 'generate-token', '--username', username],
            capture_output=True, text=True
        )
        if result.returncode != 0:
            flash(f"Error: {result.stderr}", 'danger')
        else:
            flash(f"Token: {result.stdout.strip()}", 'success')
    except Exception as e:
        flash(f"Error generating token: {str(e)}", 'danger')

    return redirect(url_for('index'))


@app.route('/change_password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form['current_password']
        new_password = request.form['new_password']
        if bcrypt.check_password_hash(current_user.password, current_password):
            current_user.update_password(new_password)
            flash('Password updated successfully!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Current password is incorrect.', 'danger')
    return render_template('change_password.html')

@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    if request.method == 'POST':
        email = request.form['email']
        full_name = request.form['full_name']
        current_user.update(email=email, full_name=full_name)
        flash('Settings updated successfully!', 'success')
        return redirect(url_for('index'))
    return render_template('settings.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('login'))


@app.route('/ssh', methods=['POST'])
def ssh():
    data = request.get_json()
    hostname = data.get('hostname')
    username = data.get('username')
    password = data.get('password')
    command = data.get('command')

    session_id = f"{hostname}_{username}"  # Define a unique session identifier based on the host and username

    if session_id not in active_sessions:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

        try:
            # Establish a new SSH connection
            client.connect(hostname, username=username, password=password)
            active_sessions[session_id] = client  # Store the SSH client in the global dictionary

        except paramiko.AuthenticationException:
            return jsonify({"error": "Authentication failed, please check your credentials"}), 401
        except paramiko.SSHException as e:
            return jsonify({"error": f"SSH error: {str(e)}"}), 500
        except Exception as e:
            return jsonify({"error": f"General error: {str(e)}"}), 500

    # Use the existing connection
    client = active_sessions[session_id]

    try:
        # Execute the command within the existing session
        stdin, stdout, stderr = client.exec_command(command)
        output = stdout.read().decode()
        error = stderr.read().decode()

        if output:
            return jsonify({"output": output})
        elif error:
            return jsonify({"error": error}), 400
    except paramiko.SSHException as e:
        return jsonify({"error": f"SSH error: {str(e)}"}), 500
    except Exception as e:
        return jsonify({"error": f"General error: {str(e)}"}), 500



@app.route('/close_ssh', methods=['POST'])
def close_ssh():
    data = request.get_json()
    hostname = data.get('hostname')
    username = data.get('username')

    session_id = f"{hostname}_{username}"

    # Close and remove the SSH session
    if session_id in active_sessions:
        client = active_sessions.pop(session_id, None)
        if client:
            client.close()
        return jsonify({"message": "SSH session closed"}), 200
    return jsonify({"error": "No SSH session to close"}), 400

@app.route('/execute', methods=['POST'])
@login_required
def execute():
    if request.method == 'POST':
        yaml_content = request.form['yaml_content']
        command_type = request.form.get('command_type', 'aws')  # Default to 'aws' if not provided

        # Ensure the directory exists before writing the file
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)

        temp_yaml_path = os.path.join(UPLOAD_FOLDER, 'temp_screenplay.yaml')
        with open(temp_yaml_path, 'w') as temp_yaml_file:
            temp_yaml_file.write(yaml_content)

        def generate():
            # Construct the command dynamically based on the command_type
            if command_type == 'aws':
                cmd = ['dob', 'aws', 'screenplay', temp_yaml_path, '-y']
            elif command_type == 'dks':
                cmd = ['dob', 'dks', 'config', temp_yaml_path]
            elif command_type == 'ansible':
                cmd = ['dob', 'ansible', 'config', temp_yaml_path]
            elif command_type == 'swarm':
                cmd = ['dob', 'swarm', 'config', temp_yaml_path]
            else:
                yield f"<div style='color: red;'>Unknown command type: {command_type}</div>\n"
                return

            # Run the constructed command
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=os.environ.copy()
            )
            for stdout_line in iter(process.stdout.readline, ""):
                yield f"<div>{stdout_line.strip()}</div>\n"
            process.stdout.close()
            return_code = process.wait()
            if return_code:
                for stderr_line in process.stderr:
                    yield f"<div style='color: red;'>{stderr_line.strip()}</div>\n"
            process.stderr.close()

        return Response(generate(), mimetype='text/html')
    

@app.route('/metrics')
@login_required
def metrics():
    import psutil
    import datetime

    boot_time = datetime.datetime.fromtimestamp(psutil.boot_time()).strftime("%Y-%m-%d %H:%M:%S")

    metrics_data = {
        'cpu_percent': psutil.cpu_percent(interval=1),
        'cpu_user_time': psutil.cpu_times().user,
        'cpu_system_time': psutil.cpu_times().system,
        'cpu_idle_time': psutil.cpu_times().idle,
        'cpu_count': psutil.cpu_count(),
        'memory_percent': psutil.virtual_memory().percent,
        'memory_total': round(psutil.virtual_memory().total / (1024 * 1024 * 1024), 2),
        'memory_used': round(psutil.virtual_memory().used / (1024 * 1024 * 1024), 2),
        'memory_available': round(psutil.virtual_memory().available / (1024 * 1024 * 1024), 2),
        'disk_percent': psutil.disk_usage('/').percent,
        'disk_total': round(psutil.disk_usage('/').total / (1024 * 1024 * 1024), 2),
        'disk_used': round(psutil.disk_usage('/').used / (1024 * 1024 * 1024), 2),
        'disk_free': round(psutil.disk_usage('/').free / (1024 * 1024 * 1024), 2),
        'network_sent': round(psutil.net_io_counters().bytes_sent / (1024 * 1024), 2),
        'network_received': round(psutil.net_io_counters().bytes_recv / (1024 * 1024), 2),
        'network_packets_sent': psutil.net_io_counters().packets_sent,
        'network_packets_received': psutil.net_io_counters().packets_recv,
        'boot_time': boot_time
    }
    return jsonify(metrics_data)



@app.route('/remote_metrics', methods=['GET'])
def fetch_remote_metrics_endpoint():
    """Fetch remote system metrics through the proxy."""
    try:
        credentials = load_proxy_credentials()
        if not credentials:
            return jsonify({"error": "Proxy credentials not found. Please configure the proxy first."}), 400

        api_key = credentials['api_key']
        proxy_url = credentials['proxy_url']

        headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json"
        }
        url = f"{proxy_url}/metrics"

        response = requests.get(url, headers=headers)
        response.raise_for_status()

        return jsonify(response.json())
    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to DevOps Bot Proxy: {e}"}), 500



def load_proxy_key():
    with open(PROXY_KEY_FILE, 'rb') as key_file:
        return key_file.read()

def decrypt_proxy_data(encrypted_data, key):
    cipher_suite = Fernet(key)
    decrypted_data = cipher_suite.decrypt(encrypted_data).decode()
    return decrypted_data

def load_proxy_credentials():
    """Load and decrypt proxy credentials."""
    try:
        with open(os.path.join(BASE_DIR, PROXY_CREDENTIALS_FILE), 'rb') as cred_file:
            encrypted_data = cred_file.read()

        key = load_proxy_key()  # Load encryption key
        decrypted_data = decrypt_proxy_data(encrypted_data, key)  # Decrypt data
        credentials = json.loads(decrypted_data)  # Convert JSON string to dictionary
        return credentials  # Return as dictionary
    except (FileNotFoundError, ValueError, KeyError) as e:
        click.echo(f"Failed to load proxy credentials: {e}")
        return None

def execute_command_on_server(hostname, username, command, timeout=None, real_time_output=False):
    try:
        client = paramiko.SSHClient()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        client.connect(hostname, username=username)

        # Use the timeout parameter for the exec_command
        stdin, stdout, stderr = client.exec_command(command, timeout=timeout)

        output, error = "", ""

        if real_time_output:
            # Read stdout line by line for real-time feedback
            for line in iter(stdout.readline, ""):
                print(line, end="", flush=True)  # Print each line immediately
                output += line

            # Read stderr line by line as well, for any immediate errors
            for line in iter(stderr.readline, ""):
                print(line, end="", flush=True)
                error += line
        else:
            # If not real-time, capture the full output and error at once
            output = stdout.read().decode()
            error = stderr.read().decode()

        exit_status = stdout.channel.recv_exit_status()
        client.close()

        # Interpret success based on exit status
        if exit_status == 0:
            return True, output + error  # Combine output and error for informational messages
        else:
            return False, output + error

    except Exception as e:
        # Return failure with the exception message
        return False, str(e)


def generate_webhook_secret():
    """
    Generate a new webhook secret key and save it to a file.
    """
    secret_key = secrets.token_hex(32)
    secret_data = {"webhook_secret": secret_key}
    with open(WEBHOOK_SECRET_FILE, "w") as f:
        json.dump(secret_data, f)
        os.chmod(WEBHOOK_SECRET_FILE, 0o600)
    return secret_key

def load_webhook_secret():
    """
    Load the webhook secret key from the file. Generate a new one if it doesn't exist.
    """
    if not os.path.exists(WEBHOOK_SECRET_FILE):
        return generate_webhook_secret()
    with open(WEBHOOK_SECRET_FILE, "r") as f:
        secret_data = json.load(f)
    return secret_data.get("webhook_secret")

# Load the secret key
WEBHOOK_SECRET = load_webhook_secret()

def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        return False
    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        return False
    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    return hmac.compare_digest(mac.hexdigest(), signature)


def generate_random_string(length=16):
    """Generate a random alphanumeric string."""
    return ''.join(random.choices(string.ascii_letters + string.digits, k=length))


def generate_api_key():
    """
    Generate a random API key and save it to a file.
    """
    webhook_api_dir = os.path.join(BASE_DIR, "webhook-api")
    os.makedirs(webhook_api_dir, exist_ok=True)

    random_name = f"devops_bot_{secrets.token_hex(4)}"
    api_key = secrets.token_hex(32)
    file_path = os.path.join(webhook_api_dir, random_name)

    with open(file_path, "w") as f:
        f.write(api_key)
        os.chmod(file_path, 0o600)

    print(f"API key generated: {file_path}")  # Log the file path for debugging
    return {"name": random_name, "token": api_key}


def validate_api_key(api_name, api_token):
    """Validate the API key provided by the user."""
    file_path = os.path.join(WEBHOOK_API_DIR, api_name)
    if not os.path.exists(file_path):
        return False

    with open(file_path, "r") as f:
        stored_token = f.read().strip()

    return hmac.compare_digest(stored_token, api_token)

@app.route('/generate-api-key', methods=['POST'])
def generate_api_key_endpoint():
    """
    Generate a new API key via HTTP request.
    """
    try:
        api_key_data = generate_api_key()
        return jsonify({
            "status": "success",
            "name": api_key_data['name'],
            "token": api_key_data['token']
        }), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500


@click.command()
def regenerate_webhook_secret():
    """
    Command to regenerate the webhook secret key.
    """
    new_secret = generate_webhook_secret()
    print(f"New webhook secret generated: {new_secret}")


@app.route('/generate-webhook-secret', methods=['POST'])
def generate_webhook_secret_endpoint():
    """
    Generate a new webhook secret key via HTTP request.
    """
    try:
        new_secret = generate_webhook_secret()
        return jsonify({"status": "success", "webhook_secret": new_secret}), 201
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

def get_next_build_file_path(repo_name):
    """
    Generate the next build file path for the specified repository in the results directory.
    """
    results_dir = os.path.join(EXECUTION_RESULTS_DIR, repo_name)
    os.makedirs(results_dir, exist_ok=True)

    existing_files = glob.glob(os.path.join(results_dir, "build-no-*.json"))
    if not existing_files:
        return os.path.join(results_dir, "build-no-001.json")

    build_numbers = [
        int(os.path.basename(f).split("-")[2].split(".")[0]) for f in existing_files
    ]
    next_build_number = max(build_numbers) + 1

    if next_build_number > 100:
        raise Exception("Build limit exceeded: Maximum 100 builds allowed.")

    return os.path.join(results_dir, f"build-no-{next_build_number:03}.json")


def execute_dob_command(file_path, results_path):
    """
    Execute the dob command and save the results in a structured format.
    """
    try:
        result = subprocess.run(
            ["dob", "dobbuild", "build", "--file-path", file_path],
            capture_output=True,
            text=True,
        )

        # Parse stdout into structured lines
        stdout_lines = result.stdout.strip().split("\n")
        stderr_lines = result.stderr.strip().split("\n") if result.stderr else []

        # Build a detailed result structure
        execution_result = {
            "status": "success" if result.returncode == 0 else "failure",
            "summary": {
                "exit_code": result.returncode,
                "stdout_line_count": len(stdout_lines),
                "stderr_line_count": len(stderr_lines),
            },
            "stdout": stdout_lines,
            "stderr": stderr_lines,
        }

        # Save execution results to the specified path
        with open(results_path, "w") as f:
            json.dump(execution_result, f, indent=4)

        return True, f"Execution results saved to {results_path}"
    except subprocess.CalledProcessError as e:
        return False, str(e)


def process_repository(details):
    """
    Clone the repository and execute Dobbuild.yaml.
    """
    repo_details = next(iter(details["repositories"].values()))
    source_url = repo_details["source_url"]
    branch = repo_details["branch"]
    repo_name = repo_details["repo_name"]
    clone_dir = os.path.join(CLONE_DIR, repo_name)
    execution_file = os.path.join(clone_dir, repo_details["execution_file"])
    results_path = get_next_build_file_path(os.path.join(EXECUTION_RESULTS_DIR, repo_name))

    # Ensure HTTPS clone for public repositories
    if source_url.startswith("git@github.com:"):
        source_url = source_url.replace("git@github.com:", "https://github.com/")

    try:
        # Clean up the clone directory if it exists
        if os.path.exists(clone_dir):
            print(f"Cleaning up existing directory: {clone_dir}")
            shutil.rmtree(clone_dir)

        # Clone the repository
        print(f"Cloning repository {repo_name} from {source_url}...")
        subprocess.run(["git", "clone", "--branch", branch, source_url, clone_dir], check=True)
        print(f"Repository {repo_name} cloned successfully into {clone_dir}.")

        # Check and execute the Dobbuild.yaml
        if os.path.exists(execution_file):
            print(f"Executing {execution_file}...")
            success, message = execute_dob_command(execution_file, results_path)
            if success:
                print(f"Execution successful: {message}")
                return jsonify({"status": "success", "message": message, "results_file": results_path}), 200
            else:
                print(f"Execution failed: {message}")
                return jsonify({"status": "error", "message": message}), 500
        else:
            print(f"{execution_file} not found in {clone_dir}. Aborting.")
            return jsonify({"status": "error", "message": f"{execution_file} not found"}), 404

    except subprocess.CalledProcessError as e:
        print(f"Error during repository processing: {e.stderr}")
        return jsonify({"status": "error", "message": f"Subprocess error: {e.stderr}"}), 500
    except Exception as e:
        print(f"Unexpected error: {str(e)}")
        return jsonify({"status": "error", "message": f"Unexpected error: {str(e)}"}), 500


@app.route('/webhook', methods=['POST'])
def handle_webhook():
    """
    Handle incoming webhook events, validate and process only if Dobbuild.yaml is modified.
    """
    event_type = request.headers.get("X-GitHub-Event", "unknown")
    signature = request.headers.get('X-Hub-Signature-256')
    payload = request.get_data(as_text=True)

    # Verify the GitHub signature
    if not verify_signature(payload.encode(), signature, WEBHOOK_SECRET):
        print("Invalid GitHub signature!")
        return jsonify({"error": "Invalid GitHub signature"}), 403

    # Log the raw payload for debugging
    print("Raw Payload:")
    print(payload)

    if event_type != "push":
        print(f"Ignored event: {event_type}")
        return jsonify({"status": "ignored", "event": event_type}), 200

    try:
        # Parse the JSON payload
        json_payload = request.json
        print("Parsed Payload:")
        print(json.dumps(json_payload, indent=4))

        # Extract required details
        repo_name = json_payload["repository"]["full_name"]
        source_url = json_payload["repository"]["ssh_url"]  # SSH URL or HTTPS clone URL
        branch = json_payload["ref"].split("/")[-1]  # Extract branch name from ref
        modified_files = json_payload.get("head_commit", {}).get("modified", [])

        print(f"Repository: {repo_name}")
        print(f"Source URL: {source_url}")
        print(f"Branch: {branch}")
        print(f"Modified Files: {modified_files}")

        # Check if Dobbuild.yaml is modified
        execution_file = "Dobbuild.yaml"
        if execution_file not in modified_files:
            print(f"No changes detected in {execution_file}. Aborting process.")
            return jsonify({"status": "aborted", "message": f"{execution_file} not modified"}), 200

        # Prepare task details
        details = {
            "repositories": {
                repo_name: {
                    "source_url": source_url,
                    "branch": branch,
                    "repo_name": repo_name.split("/")[-1],
                    "execution_file": execution_file
                }
            }
        }

        print("Prepared Details for Processing:")
        print(json.dumps(details, indent=4))

        # Process repository and execute the task
        return process_repository(details)

    except Exception as e:
        print(f"Error processing payload: {e}")
        return jsonify({"error": f"Failed to process payload: {str(e)}"}), 500


def verify_signature(payload, signature, secret):
    """
    Verify the GitHub signature.
    """
    if not signature:
        print("Missing signature header!")
        return False

    sha_name, signature = signature.split('=')
    if sha_name != "sha256":
        print(f"Unsupported hash type: {sha_name}")
        return False

    mac = hmac.new(secret.encode(), msg=payload, digestmod=hashlib.sha256)
    generated_signature = mac.hexdigest()
    print(f"Generated signature: sha256={generated_signature}")
    print(f"Received signature: {signature}")

    return hmac.compare_digest(generated_signature, signature)


@app.route('/execute_command', methods=['POST'])
@login_required
def execute_command():
    command_input = request.form.get('command_input')
    if not command_input:
        return f"<div style='color: red;'>Command not provided</div>", 400

    try:
        process = subprocess.Popen(
            command_input,
            shell=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            cwd=UPLOAD_FOLDER  # Ensures safety by running commands in the working directory
        )

        def generate():
            for stdout_line in iter(process.stdout.readline, ""):
                yield f"<div>{stdout_line.strip()}</div>\n"
            process.stdout.close()
            return_code = process.wait()
            if return_code:
                for stderr_line in process.stderr:
                    yield f"<div style='color: red;'>{stderr_line.strip()}</div>\n"
            process.stderr.close()

        return Response(generate(), mimetype='text/html')
    except Exception as e:
        return f"<div style='color: red;'>Error: {str(e)}</div>", 500


@click.group()
def cli():
    pass


@cli.command(name="run-ui", help="Run the UI for the screenplay.")
@click.option('--port', default=4102, help="Port to run the UI on.")
def run_ui(port):
    os.environ["FLASK_APP"] = "app.py"
    click.echo(f"Starting the UI on port {port}...")
    subprocess.run(["flask", "run", "--host=0.0.0.0", f"--port={port}"], env=os.environ)


if __name__ == '__main__':
    cli()
    app.run(host='0.0.0.0', port=4102, debug=True)  # Expose on all interfaces
